# Chapter <N>: <Chapter Title>

<Main text content, 2000-3000 words>

**【Creative Tips】**
- This template defines the format and structure of the chapter, without restricting the narrative style
- The chapter outline is a categorized information block; during creation, reorganize it according to the chronological order of events
- Avoid copying the outline block by block; integrate the information naturally into the story flow
- Use time as the axis and events as the framework; background information should be introduced naturally within the narration
- Maintain the elegant and classical style of wuxia, blending literary and vernacular language
- Descriptions of martial arts should convey charm and artistic conception
- Dialogue should carry the flavor of the jianghu (martial world)