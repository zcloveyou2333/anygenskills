# Character Profiles

## Main Characters

**<Character Name>** (Protagonist)

<Describe appearance with elegant language, highlighting the martial world aura and the most memorable features>. <Natural description of personality traits, including main characteristics, manner of speaking, habitual behaviors, etc.>. <Martial arts style and status in the martial world>. <Core flaws and potential for growth>. <Role and identity in the story, relationships with other characters, and character development throughout the plot>.

**<Character Name>** (<Role Position>)

<Same format as above, detailed description>

**<Character Name>** (<Role Position>)

<Same format as above, detailed description>

[Note: 3-5 main characters, each 150-200 words]

## Antagonists

**<Character Name>** (Primary Antagonist/Secondary Antagonist)

<Description of appearance, can be imposing but not excessively evil>. <Personality and behavioral patterns>. <Martial arts characteristics>. <Motivation for wrongdoing, conflicts with the protagonist, and final outcome>.

[Note: If the story has antagonists, each 100-150 words. Martial arts villains can be ruthless but must have logical motives]

## Important Supporting Characters

**<Character Name>**

<Brief description of appearance, emphasizing martial world traits>. <Main personality traits>. <Martial arts skills and sect>. <Role in the plot and relationship with the protagonist>.

**<Character Name>**

<Same format as above>

[Note: 2-4 important supporting characters, each 80-100 words]

## Other Characters

**<Character Name>**: <One-sentence description of appearance>. <One-sentence personality>. <One-sentence description of role>.

**<Character Name>**: <Same format as above>

[Note: Other characters if any, each 30-50 words]