# 《<Book Title>》Story Outline

## Novel Information
- **Title**: <Book Title>
- **Genre**: <Novel Genre>
- **Story Tone**: <Specific tone chosen from Q3>

## Main Characters
<Briefly list 3-5 core characters, one sentence introduction for each>

- **<Character 1>**: <One sentence introduction>
- **<Character 2>**: <One sentence introduction>
- **<Character 3>**: <One sentence introduction>

## Core Synopsis
<One sentence summarizing the core idea and appeal of the story>

## Introduction
<50-150 words, using elegant language to create a Jianghu atmosphere, showcasing the core grudges, evoking readers' anticipation of "how will this Jianghu turmoil conclude">

## Story Outline

### Beginning: <Stage Summary Name> (Chapter 1)
<Story development in this stage, 500-750 words>

### Development: <Stage Summary Name> (Chapters 2-3)
<Story development in this stage, 500-750 words>

### Twist: <Stage Summary Name> (Chapter 4)
<Story development in this stage, 500-750 words>

### Conclusion: <Stage Summary Name> (Chapter 5)
<Story development in this stage, 500-750 words>

[Note: Short stories use the structure Beginning, Development, Twist, Conclusion; Beginning (Chapter 1), Development (Chapters 2-3), Twist (Chapter 4), Conclusion (Chapter 5), totaling 2000-3000 words]