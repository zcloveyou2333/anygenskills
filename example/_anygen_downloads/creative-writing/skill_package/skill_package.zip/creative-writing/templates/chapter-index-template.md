# Table of Contents

**Chapter 1** <Chapter Title>

<A one-sentence plot summary, outlining the core events and narrative function of this chapter>

**Chapter 2** <Chapter Title>

<A one-sentence plot summary>

**Chapter 3** <Chapter Title>

<A one-sentence plot summary>

**Chapter 4** <Chapter Title>

<A one-sentence plot summary>

**Chapter 5** <Chapter Title>

<A one-sentence plot summary>

[Note: The short story is fixed at 5 chapters, corresponding one-to-one with the 5 stages of the outline. Each chapter title is elegant, classical, and poetic, with a plot summary of 30-50 words.]