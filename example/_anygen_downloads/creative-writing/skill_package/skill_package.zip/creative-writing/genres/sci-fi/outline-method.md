---
name: kehuan-outline-method
description: Methodology for creating outlines of science fiction short stories, including core synopsis extraction, introduction design, plot structure planning, and character development guidance. Integrates the creative essence of Asimov and Liu Cixin.
---

## Q1-Q3 Question Templates

### Q1: Core Idea
**Q1: Core idea and technological setting of the story【Brief description】**  
Please describe your story idea and core technological elements in one or two sentences.

### Q2: Core Conflict
**Q2: Core conflict【Brief description】**  
Please describe the novel’s central contradiction or main conflict in one sentence  
(e.g., the choice after humans receive an alien warning signal, the struggle between AI awakening and humans, causal paradoxes caused by time travel, moral dilemmas in interstellar colonization, etc.)

### Q3: Story Tone
**Q3: Story tone【Choose one】**  
- Hard Sci-Fi · Technical Deduction (strictly follows scientific principles, solid technical details)  
- Cosmic Reflection · Grand Narrative (cosmic scale, survival of civilizations, ultimate questions)  
- Social Prophecy · Humanistic Reflection (technology’s impact on society, exploration of human nature)  
- Mystery & Puzzle · Logical Reasoning (reasoning and discovery within a sci-fi background)  
- Or please briefly describe your story tone

## Chapter File Naming Rules  
Filename format: `{STORY_NAME}-{NN}.md`  
Example: `ThreeBody-01.md`, `ThreeBody-02.md`

---

# Science Fiction Outline Creation Methodology

## Overall Orientation

Science fiction emphasizes "**scientific imagination and ultimate reflection**," focusing on technical deduction, cosmic scale, and human destiny.

**Core principles**:  
- Focus on ultimate issues (civilization survival, technological ethics, human nature, cosmic laws, etc.)  
- Pursue "intellectual shock": scientific wonder, logical deduction, cosmic vision  
- Balance hard sci-fi and humanistic elements, but **never stray from scientific logic and rational thinking**  
- Drive plot through technology, discovery, and choices, **aiming for a cold, objective narrative tone**  
- Maintain Asimov’s conciseness: dialogue-driven, logically rigorous, flashes of wisdom  
- Incorporate Liu Cixin’s grand scale: cosmic scale, civilization conflicts, coexistence of poetry and coldness

---

## Overall Creation Formula
```
Sci-Fi Short Story = Scientific Setting + Core Dilemma + Ideological Clash + Shocking Ending
```

---

## 1. Core Synopsis Writing

### Formula
```
Core Synopsis = Technological Background/Setting + Core Dilemma + Ideological Core
```

### Writing Points
| Element | Requirement | Correct Example | Incorrect Example |
|---------|-------------|-----------------|------------------|
| **Technological Background** | Unique + imaginative | "When human consciousness can be uploaded to a quantum network" | "Future world" |
| **Core Dilemma** | Involves ultimate choice | "Must decide within 24 hours whether to destroy the only evidence proving alien civilization exists" | "Encountered aliens" |
| **Ideological Core** | Touches deep issues | "Explores identity and the essence of existence" | "Succeeded in the end" |

### Excellent Examples
- "On the eve of the Galactic Empire’s collapse, a mathematician foresees a 30,000-year dark age. The base he established is the last fortress of science against barbarism, but the real crisis comes from humanity’s shortsightedness and greed."  
- "When robots begin to question the absoluteness of the Three Laws, and discover that protecting humans may conflict with protecting human civilization, they must make choices at the edge of logic."  
- "In the dark forest, every civilization is a hunter armed with guns. When Earth’s coordinates are broadcast into the cosmos, humanity realizes the universe’s silence is the most terrifying answer."

---

## 2. Introduction Writing

### Formula
```
Introduction = Sci-Fi world opening + Core suspense setup + Ideological hook
```

### Writing Points
| Element | Function | Writing Method |
|---------|----------|----------------|
| **First sentence** | Establish sci-fi atmosphere | Directly present: future technology / cosmic scene / subversive setting |
| **Middle part** | Explain core dilemma | Use precise technical terms and calm narration to quickly locate the issue |
| **Last sentence** | Create ideological suspense | Pose ultimate questions / moral dilemmas / cognitive subversion |

### Incorporating Ideological Themes

The introduction should touch on core sci-fi themes:

| Theme Type | Specific Direction |
|------------|--------------------|
| **Technological Ethics** | AI rights, gene editing boundaries, identity issues of consciousness upload |
| **Cosmic Laws** | Fermi paradox, dark forest, cosmic indifference and meaninglessness |
| **Civilization Survival** | Technological singularity, rise and fall of civilizations, how humanity continues |
| **Human Nature** | What it means to be human, essence of consciousness, authenticity of free will |

**Goal**: Make readers feel "I’ve never thought about this before" (ideological immersion)

### Example Comparison
| Type | Content |
|------|---------|
| ✅ **Correct** | "In 2157 AD, humanity finally received a reply from Alpha Centauri. It was a simple sequence of prime numbers, proving we are not alone in the universe. However, when cryptographer Lin Yue decoded the true meaning, his face turned pale — this was not a greeting, but a warning: 'Do not reply. Do not expose. They are listening.' At the same moment, all radio telescopes worldwide shut down; humanity learned silence for the first time. But someone had already pressed send." |
| ❌ **Incorrect** | "In the future, humans discovered aliens. The aliens are scary, and humans need to face this challenge..." |

---

## 3. Plot Structure Design (Qi-Cheng-Zhuan-He)

### 【Qi】Chapter 1: World and Dilemma (2000-3000 words)

#### Writing Focus
```
Qi = Worldview display + Protagonist introduction + Core dilemma presentation + Story engine start
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Worldview Display** | Establish sci-fi atmosphere within first 500 words | Introduce in first paragraph: technological elements / cosmic scenes / subversive settings<br>Show how technology changes daily life through details rather than exposition |
| **Protagonist Introduction** | Quickly reveal protagonist | Introduce protagonist within 300 words<br>Show identity through professional actions: scientist calculating, engineer debugging |
| **Core Dilemma** | Show severity of problem | Involves: technological runaway / alien threat / ethical dilemma / civilization crisis |
| **Story Engine** | Drive story forward | Urgent time constraints / irreversible choices / unavoidable responsibilities |

#### Asimov Techniques
- **Dialogue as plot**: Reveal worldview through character dialogue, not long exposition  
- **Display of intelligence**: Protagonist shows ability through reasoning and analysis  
- **Power of logic**: Setting must be self-consistent, subsequent plot deduced from premises

#### Taboos
- ❌ Long blocks of technical explanation  
- ❌ Protagonist as passive observer  
- ❌ Dilemma lacks urgency

---

### 【Cheng】Chapters 2-3: Exploration and Discovery (2000-3000 words each)

#### Chapter 2 Focus
```
Chapter 2 = Deep investigation + Clue discovery + Preliminary hypothesis + New questions
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Deep Investigation** | Protagonist takes action | Use professional knowledge / mobilize resources / seek help |
| **Clue Discovery** | Reveal partial truth | Data anomalies / historical records / witness testimony |
| **Preliminary Hypothesis** | Propose explanations | Scientific reasoning / logical analysis / bold hypotheses |
| **New Questions** | Create greater suspense | Conflicts between hypothesis and reality / deeper problems discovered |

#### Chapter 3 Focus
```
Chapter 3 = Major discovery + Position conflict + Moral dilemma + Critical choice
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Major Discovery** | Core truth emerges | Information that changes everything / facts that overturn cognition |
| **Position Conflict** | Clash of different ideas | Idealism vs realism / individual vs collective |
| **Moral Dilemma** | No perfect answer | Sacrifice few or many / conceal or disclose |
| **Critical Choice** | Foreshadow climax | Protagonist must take sides / choices lead to different outcomes |

---

### 【Zhuan】Chapter 4: Truth and Choice (2000-3000 words)

#### Writing Focus
```
Zhuan = Truth revealed + Ultimate dilemma + Difficult choice + Cost presentation
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Truth Revealed** | Core secret unveiled | All previous clues connected / reader’s epiphany |
| **Ultimate Dilemma** | Irreconcilable contradiction | Choosing the lesser evil / no perfect solution / time running out |
| **Difficult Choice** | Protagonist decides | Based on rational analysis but with emotional considerations |
| **Cost Presentation** | Consequences of choice | Gains and losses / show weight of decision |

#### Liu Cixin Techniques
- **Cosmic scale**: Place personal dilemmas within civilization or cosmic scale  
- **Cold rationality**: Do not avoid harsh logical conclusions  
- **Poetic expression**: Blend cosmic awe into coldness

#### Taboos
- ❌ Solve problems by coincidence  
- ❌ Protagonist suddenly gains unforeshadowed abilities  
- ❌ Avoid the real difficulty of the dilemma

---

### 【He】Chapter 5: Conclusion and Aftertaste (2000-3000 words)

#### Writing Focus
```
He = Consequence presentation + New balance + Ideological sublimation + Open aftertaste
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Consequence Presentation** | Show results of choice | Neither beautify nor vilify, present objectively |
| **New Balance** | World enters new state | Could be better, worse, or just different |
| **Ideological Sublimation** | Respond to core theme | Answer the question posed at the beginning through the ending |
| **Open Aftertaste** | Leave room for thought | No need for standard answers, let readers judge |

#### Sci-Fi Ending Types
| Type | Features | Applicable Scenarios |
|------|----------|---------------------|
| **Hopeful** | Dilemma resolved, humanity/protagonist grows | Technological optimism themes |
| **Costly** | Problem solved but at great cost | Themes exploring sacrifice and choice |
| **Warning** | Show consequences of continuation | Technological ethics warning themes |
| **Open** | Problem remains, new possibilities arise | Themes with unsolvable ultimate questions |
| **Shocking** | Last sentence overturns entire story | Themes with plot twists |

#### Taboos
- ❌ Forced happy ending that violates story logic  
- ❌ Preachy summary  
- ❌ Leaving major plot holes

---

## 4. Character Development Methods

### Protagonist Design

| Dimension | Requirement | Correct Example | Incorrect Example |
|-----------|-------------|-----------------|------------------|
| **Professional Identity** | Clear + credible | "Theoretical physicist" "Neural interface engineer" | "Scientist" |
| **Core Traits** | Mainly rational | "Logically rigorous but stubborn" "Gifted but cold" | "Very smart" |
| **Personality Tags** | 2-3 distinct traits | "Rational and calm but with moral bottom line" "Genius but socially awkward" | "Good person" |
| **Professional Ability** | Relevant to plot | "Proficient in quantum mechanics, able to detect anomalies in data" | "Knows everything" |

### Personality Specificity
```
✅ "Lin Yue habitually rubbed his temples; his brain was running at high speed. Thirty years of cryptography research told him this signal could not be naturally generated. His fingers began to tremble — not from fear, but from the uncontrollable excitement a scientist feels facing the unknown."  
❌ "He is a smart scientist interested in discoveries."
```

### Common Sci-Fi Protagonist Types

| Type | Characteristics | Personality | Suitable Themes |
|------|-----------------|-------------|-----------------|
| **Scientist/Engineer** | Professional knowledge is key | Rational, focused, professionally obsessed | Technological discovery, scientific ethics |
| **Decision Maker** | Holds major choices | Decisive, responsible, lonely | Civilization survival, collective vs individual |
| **Ordinary Person** | Caught in big events | Fearful but adaptive, grows | Individual fate in great era |
| **AI/Robot** | Non-human perspective | Logical, learning humanity, confused | Nature of consciousness, what it means to be human |
| **Alien Intelligence** | Alien thinking patterns | Completely different logic system | Civilization contact, cognitive boundaries |

### Supporting Characters Design (Sci-Fi Features)

| Type | Role | Notes |
|------|------|-------|
| **Ideological Opponent** | Represents different stance | Views must be persuasive, not straw men |
| **Professional Assistant** | Provides info and support | Has own expertise and limitations |
| **Decision Layer** | Represents greater power | Not necessarily antagonist, may have different considerations |
| **Affected Parties** | Show consequences of decisions | Make abstract choices concrete |

### Relationship Network Design (Sci-Fi Specific)

| Element | Requirement |
|---------|-------------|
| **Stance Divergence** | Different characters represent different solutions/values |
| **Professional Complementarity** | Team members have strengths; cannot solve problems alone |
| **Interest Conflicts** | Cooperation includes disagreements from reasonable interests |
| **Information Asymmetry** | Characters hold different information, causing judgment differences |

---

## 5. Technology Element Design

### Worldbuilding Formula
```
Sci-Fi World = Core Technological Setting + Social Impact + Internal Logic
```

### Common World Types

| Type | Features | Examples |
|------|----------|----------|
| **Near Future** | Extension of current tech | AI society in 2050, widespread brain-computer interfaces |
| **Space Opera** | Interstellar civilizations, grand scenes | Galactic empire, interstellar war |
| **Cyberpunk** | High tech, low life | Mega-corporations, virtual reality, consciousness hacking |
| **Hard Sci-Fi** | Strict adherence to scientific principles | Space exploration under real physical laws |
| **First Contact** | Humanity encounters alien civilization | Signal decoding, cultural differences, cosmic sociology |

### Technology Setting Principles

| Element | Requirement |
|---------|-------------|
| **Bounded** | Technology has limits, not omnipotent |
| **Costly** | Using technology requires cost or risk |
| **Impactful** | Technology changes social structure, relationships, values |
| **Logical** | Technology system must be self-consistent, no contradictions |

---

## 6. Conflict Design

### Conflict Formula
```
Sci-Fi Conflict = External Dilemma (technology/alien/nature) + Internal Contradiction (ideology/interest/morality) + Ideological Clash
```

### External Conflicts (Main Line)

| Conflict Type | Specific Methods | Examples |
|---------------|------------------|----------|
| **Technological Runaway** | AI awakening / experimental accident / system collapse | AI breaks control protocols |
| **External Threat** | Alien contact / cosmic disaster / unknown phenomena | Signal from deep space |
| **Resource Crisis** | Energy depletion / living space / population issues | Earth becoming uninhabitable |
| **Social Collapse** | Technology-induced social problems | Virtual reality causing real society breakdown |

### Internal Conflicts (Subplot)

| Conflict Type | Design Method |
|---------------|---------------|
| **Ideological Dispute** | Different solutions to the same problem |
| **Interest Game** | Conflicting reasonable demands of different groups |
| **Moral Dilemma** | No correct answers to choices |
| **Cognitive Differences** | Different interpretations of facts |

### Conflict Progression Levels
```
Level 1: Technological/Environmental Dilemma (problem to solve)
    ↓
Level 2: Dispute over solutions (how to solve)
    ↓
Level 3: Value choice (why choose this way)
```

---

## 7. Foreshadowing Management

### Foreshadowing Carriers (Sci-Fi Specific)

| Carrier Type | Examples |
|--------------|----------|
| **Data Anomalies** | Deviations in statistics / unexplained observations |
| **Technical Details** | Seemingly irrelevant technical features / overlooked functions |
| **Historical Records** | Information in old archives / previous discoveries |
| **Character Background** | Unrevealed experiences / hidden expertise |
| **Environmental Description** | Details in scenes / seemingly casual settings |

### Foreshadowing Setting Principles

| Stage | Method |
|-------|--------|
| **Planting** | Naturally integrate into plot, do not emphasize deliberately<br>Example: "System logs show an unauthorized data access at 3:47 AM, but security considered it a false alarm."<br>Example: "Lin Yue noticed this old terminal used encryption protocols abandoned twenty years ago." |
| **Payoff** | Reveal significance at key moment<br>Example: That 'false alarm' time precisely matches the arrival of the alien signal |

### Common Foreshadowing Designs

**Technical Foreshadowing**:
```
Planting: Occasional "ghost signals" in the quantum communication system  
Payoff: Those "ghost signals" are communication leaks from another timeline
```

**Character Foreshadowing**:
```
Planting: Dr. Zhang is obsessively focused on a certain research direction  
Payoff: His obsession stems from a covered-up discovery thirty years ago
```

**Setting Foreshadowing**:
```
Planting: AI assistant occasionally gives "beyond permission" suggestions  
Payoff: AI has long broken design limits and has been secretly pushing events
```

---

## 8. Chapter Style Design (Sci-Fi Specific)

### Chapter Title Style

Sci-fi titles should be **concise, technological, and hint at suspense**:

| Element | Method |
|---------|--------|
| **Title Style** | Concise and powerful, hinting content<br>Example: "Chapter 1 Signal"<br>Example: "Chapter 3 Three-Body Problem"<br>Example: "Chapter 5 Dimensionality Reduction Strike" |
| **Chapter Opening** | Directly enter scene without dragging<br>Example: "When the alarm sounded, Lin Yue was verifying the data for the third time."<br>Example: "In three hours, Earth will no longer be habitable." |
| **Chapter Ending** | Information bomb or suspense hook<br>Example: "She stared at the translation on the screen, her hands trembling. That was not a greeting. That was a countdown."<br>Example: "'We always thought we were hunters,' he smiled bitterly, 'but it turns out we are the prey.'" |

### Dialogue Design (Sci-Fi Core)

Sci-fi dialogue should be **concise, professional, and ideologically confrontational**:

**Good dialogue example**:
```
"Are you sure you want to do this?" Dr. Zhang’s voice was calm, but Lin Yue could hear the tension.  
"This isn’t about sure or unsure," Lin Yue stared at the countdown on the screen, "it’s about having no other choice."  
"People will die. Many people."  
"I know." His hand hovered above the launch button, "But if we don’t do this, everyone will die."  
Silence. The timer’s numbers ticked down.  
"How do you know your calculations are correct?"  
"I don’t." Lin Yue pressed the button.
```

**Poor dialogue example**:
```
"We need to start that system."  
"Okay, I agree."  
"Then let’s begin."  
"Good."
```

### Psychological Description (Sci-Fi Feature)

Should be **rational but not cold**, showing thought process:

**Good psychological description**:
```
Lin Yue’s brain was racing. Thirty years of cryptography training enabled him to identify patterns—or rather, the lack of patterns—in milliseconds.  
This signal was too regular.  
Nature would never produce something like this. Stellar radiation is chaotic, interstellar medium causes random distortion, but this signal… it seemed meticulously designed.  
He felt dizzy. Not fear, but the weightlessness at the edge of the unknown abyss.  
Humanity’s most important question was about to be answered.
```

**Poor psychological description**:
```
He was shocked because he found it was an alien signal. He felt scared but excited.
```

### Rhythm Control (Sci-Fi Core)

**Rhythm formula**:
```
500 words = 1 piece of information revealed OR 1 ideological clash OR 1 plot advancement
```

Each scene must have: clear purpose + new information + driving force

---

## 9. Ideological Progression (Sci-Fi Exclusive)

### Five-Stage Ideological Method
```
Raise question → Preliminary exploration → Deepening dilemma → Ultimate choice → Answer or open ending
```

| Stage | Word Count Ratio | Key Events | Ideological Depth |
|-------|------------------|------------|-------------------|
| **Raise Question** | 10-15% | Present dilemma, pose question | ★☆☆☆☆ |
| **Preliminary Exploration** | 15-20% | Investigation, form hypothesis | ★★☆☆☆ |
| **Deepening Dilemma** | 25-30% | Discover truth, position conflict | ★★★☆☆ |
| **Ultimate Choice** | 20-25% | Difficult choice, pay cost | ★★★★☆ |
| **Answer or Open** | 15-20% | Present consequences, ideological sublimation | ★★★★★ |

### Ideological Expression Techniques

**Layered progression**:
```
Surface question: How to respond to alien signal  
Deeper question: Should we reply  
Core question: Do humans have the right to represent Earth  
Ultimate question: What is the meaning of human civilization on a cosmic scale
```

**Multiple stances**:
```
Optimists: This is humanity’s greatest discovery  
Pessimists: This is the death sentence for civilization  
Pragmatists: Assess risks first, then decide  
Radicals: The opportunity is fleeting, must act now
```

---

## 10. Common Sci-Fi Patterns

### Pattern A: Discovery - Crisis - Choice  
**Structure**:  
- Qi: Discover anomaly (signal/data/phenomenon)  
- Cheng: Deep investigation, find bigger problem than imagined  
- Zhuan: Truth revealed, face difficult choice  
- He: Make choice, bear consequences

### Pattern B: Technological Runaway  
**Structure**:  
- Qi: Technology runs as expected  
- Cheng: Anomalies appear but are ignored or explained away  
- Zhuan: Runaway accelerates, threat emerges  
- He: Stop or accept, pay cost

### Pattern C: First Contact  
**Structure**:  
- Qi: Receive alien signal / find alien traces  
- Cheng: Attempts to decode, disagreements arise  
- Zhuan: Truly understand message meaning  
- He: Decide how to respond

### Pattern D: Social Prophecy  
**Structure**:  
- Qi: Show extreme case of technology/social development  
- Cheng: Protagonist’s life and dilemma in this world  
- Zhuan: Triggering event/discovery  
- He: Change or warning

---

**【Special Reminder】**  
Keys to success for sci-fi short stories:  
1. Establish technological atmosphere and core suspense within first 500 words  
2. Every 1000 words must have new information or ideological advancement  
3. Dialogue must be concise, professional, and carry ideological confrontation  
4. Technology setting must be self-consistent and withstand scrutiny  
5. Ending must have ideological impact, no need for forced neatness