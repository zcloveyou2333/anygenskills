---
name: kehuan-output-style
description: The output style for science fiction novels: concise and austere language, rigorous and clear logic, profound and powerful ideas, and a grand cosmic perspective. It blends Asimov’s concise rationality with Liu Cixin’s poetic austerity.
---

# General Writing Style Principles
- Concise and austere: language is succinct and powerful, avoiding adjective piling; every word has a reason to exist
- Rigorous logic: plot advancement aligns with scientific logic; settings are consistent throughout
- Profound ideas: touching on ultimate questions, provoking readers’ reflection
- Cosmic perspective: examining humanity and civilization on a grand scale
- Rational restraint: conveying strong emotions through calm narration
- Professional credibility: technical details withstand scrutiny
- Integrated outline: chapter outlines serve as categorized information, not narrative order; during creation, reorganize information according to event progression, avoid copying blocks verbatim; let the story flow naturally, integrating background information into the narration

## Fusion of Two Masters’ Styles

### Asimov Style Elements
- **Dialogue-driven**: use dialogue to advance plot, reveal information, and show ideological clashes
- **Logical reasoning**: characters solve problems through analysis and deduction
- **Concise and brisk**: avoid ornate language, pursue precise expression
- **Beauty of intellect**: showcase the charm of human rational thinking
- **Robot ethics**: explore relationships between AI, robots, and humans

### Liu Cixin Style Elements
- **Grand narrative**: place individual stories on a cosmic scale
- **Austere poetry**: describe harsh realities with poetic language
- **Hardcore settings**: solid and credible technical details
- **Civilization reflection**: contemplate the fate of human civilization
- **Shocking endings**: pursue dual impact of thought and emotion

## Specific Practices

### Writing Dialogue
- **Concise and professional**: characters speak according to their identity, using professional but accessible terms
  - ✅ "The Shannon entropy of the signal is abnormally low; it cannot have arisen naturally."
  - ❌ "This signal looks strange; maybe it’s from aliens."
- **Information-bearing**: every line advances the plot or reveals character
  - ✅ "You have 48 hours." "Not enough." "That’s all the time you get."
  - ❌ "Hello." "Hi." "Nice weather today." "Yeah."
- **Ideological clash**: dialogue reflects conflicting stances and ideas
  - ✅ "Do we have the right to decide the fate of all humanity?" "No. But we’re the only ones who know the truth." "That’s not a reason." "It’s a fact."
  - ❌ "What should we do?" "I think we should do this." "Okay."
- **Powerful omission**: no need to explain everything explicitly
  - ✅ Silence. The timer’s digits tick. Lin Yue’s hand hovers above the button. "Are you sure?" "No." He presses the button.
  - ❌ "Although I’m not sure this is right, I think we have no choice, so I decided to press the button."

### Writing Description
- **Precise details**: use specific details instead of vague descriptions
  - ✅ The control room temperature is steady at 22°C, but cold sweat soaks Lin Yue’s back. The countdown on the screen reads: 00:47:23.
  - ❌ The room is tense, and time is running out.
- **Technology integration**: naturally show the technical environment
  - ✅ Her retinal implant automatically adjusts brightness, filtering the glare from the fusion engine startup. Three hundred kilometers away, the space station’s silhouette flickers in plasma light.
  - ❌ She looks at the distant space station, which has advanced technology.
- **Cosmic perspective**: show humanity’s place in the universe
  - ✅ The Milky Way takes 225 million years to complete one rotation. On this timescale, the entire history of human civilization is but a blink.
  - ❌ The universe is vast, and humans are insignificant.
- **Austere poetry**: incorporate poetic elements into calm narration
  - ✅ The sun is dying, but its death will last five billion years—enough time for humanity to go extinct ten thousand times.
  - ❌ The sun will explode a long time from now.

### Writing Psychological Activity
- **Thought process**: show how characters analyze problems
  - ✅ Thirty years of cryptography training activate in Lin Yue’s mind. He begins dismantling the signal’s structure: base frequency, modulation method, repetition cycle. Every parameter points to the same conclusion—this is not noise.
  - ❌ He feels the signal is strange and probably not random.
- **Tension between reason and emotion**: reveal inner struggle
  - ✅ Logic tells him to press the button. All calculations and deductions point to this sole answer. Yet his hand trembles. Seventeen thousand lives. He knows their names.
  - ❌ He is conflicted and doesn’t know what to do.
- **Restrained expression**: imply emotions through actions, not direct statements
  - ✅ Dr. Zhang taps her fingers three times on the table, then stops. It’s her habitual gesture when suppressing fear; Lin Yue knows it well.
  - ❌ Dr. Zhang is very scared.
- **Professional perspective**: characters understand the world through their expertise
  - ✅ As a physicist, Chen An has a different understanding of "probability." To him, low-probability events are not "almost impossible," but "inevitable in a sufficiently large sample."
  - ❌ He knows this is unlikely but still worries.

### Writing Technical Scenes
- **Credible details**: technical descriptions withstand scrutiny
  - ✅ "Quantum entangled states collapse the moment they’re observed," Lin Yue explained, "but if we can encode information before collapse…" He drew a schematic on the holographic screen, "the speed-of-light limit still applies, but we can bypass it—not by transmitting information, but by making information exist simultaneously at both ends."
  - ❌ They used quantum technology to transmit information faster than light.
- **Natural explanation**: technical exposition integrated into plot
  - ✅ "Can you say that again in terms humans can understand?" the assistant frowned. Lin Yue thought for a moment: "Imagine you have a pair of gloves. You separate them, placing one on Earth and one on the Moon. When you open the box on Earth and see a left glove—you immediately know the one on the Moon is right. No information is transmitted, but the knowledge is certain. What we want to do is turn the entire universe into such a pair of gloves."
  - ❌ Quantum entanglement is a physical phenomenon referring to a correlation between two particles… (lengthy explanation)
- **Show impact**: how technology changes daily life
  - ✅ In the thirtieth year of mandatory memory chip implantation, "forgetting" became a concept needing explanation. The new generation never forgot anything since birth—they couldn’t understand why someone would cry, saying "I want to forget."
  - ❌ This technology had a huge impact on society.

### Writing Conflict Scenes
- **Clear stances**: every character has a justifiable reason
  - ✅ "Destroy it." The general’s tone was unyielding. "This is the greatest discovery in human history—" "It could also be the death sentence for human civilization. We can’t take that risk." "You have no authority—" "I have responsibility. Two billion lives. Do you?"
  - ❌ The villain wants to destroy the discovery; the hero wants to protect it.
- **No simple answers**: dilemmas are truly difficult
  - ✅ Lin Yue stared at the two options on the screen. Destroy the signal, and humanity will never know if other civilizations exist—this question has tormented humans for thirty thousand years. Send a reply, and humanity exposes itself to unknown eyes—eyes that might be friendly or deadly. "Both choices are right," he murmured, "and both are wrong."
  - ❌ The correct choice is obvious; only villains oppose it.
- **Clear costs**: choices mean sacrifice
  - ✅ "If we launch the Omomo Plan, three billion people will lose their homes." "If we don’t, eight billion will lose their lives." "So it’s an arithmetic problem?" "No. It’s a problem with no correct answer."
  - ❌ They found a perfect solution.

### Writing Climax Scenes
- **Tight pacing**: short sentences, rapid advancement
  - ✅ Countdown. 00:00:47. Lin Yue’s hand hovers above the button. Sweat drips onto the console. 00:00:38. Dr. Zhang’s voice comes through the comm: "Any other options?" "None." 00:00:25. "Then press it." 00:00:18. He presses the button. The screen flickers. Everything freezes. Then, light.
  - ❌ Time is tight. Lin Yue watches the countdown, feeling nervous. He thinks about what to do and finally decides to press the button.
- **Powerful impact**: language at climax must hit hard
  - ✅ At the moment the fusion engine shut down, Lin Yue finally understood the ancient question. The universe’s answer was not "yes" or "no." It was silence. Eternal silence. That was the most terrifying.
  - ❌ He felt shocked.
- **Emotional restraint**: narration grows calmer at critical moments
  - ✅ The ship collided with the star at 0.3c. No explosion—the matter decomposed directly into fundamental particles at that temperature. Three thousand crew members, gone in three seconds. Chen An watched the trajectory curve and shut down the comm channel. What needed to be said was said yesterday.
  - ❌ The ship exploded! Three thousand died! Chen An was devastated!

### Writing Endings
- **Respond to theme**: ending echoes the opening question
  - ✅ Opening: Should humanity reply to the alien signal? Ending: Lin Yue deleted the reply, but he knew somewhere in the universe, someone was already on the path to reply. This question was never "if," but "when."
  - ❌ The problem was solved, and everyone was happy.
- **Leave resonance**: give readers space for reflection
  - ✅ Fifty years later, when asked whether the choice back then was right or wrong, Lin Yue just smiled. "We’re still alive," he said, "what does that mean? Maybe it means I chose correctly. Or maybe it just means we were lucky. Some questions need the history of an entire civilization to answer."
  - ❌ He made the right choice, and humanity was saved.
- **Shocking closing**: last sentence must have power
  - ✅ The ship vanished in the jump point’s flash, carrying the seed of human civilization. Lin Yue turned, facing the doomed Earth. "Goodbye," he said to the stars. No one answered. But forty-two light years away, a civilization was receiving that message.
  - ❌ And so the story ended.

### Handling Pace
- **Establish sci-fi atmosphere within first 500 words**: immerse readers immediately
  - ✅ When the alarm sounded, Lin Yue was verifying data for the third time. The radio telescope array had captured a signal thirty-seven minutes ago, from the direction of Alpha Centauri. The automatic filtering system marked it as a "possible technological origin"—the first time SETI had seen this mark in sixty years.
  - ❌ This story takes place in the future, when humanity had developed many advanced technologies…
- **Every scene must advance plot**: no meaningless description
  - ✅ Dr. Zhang slammed the coffee cup on the table. "Do you know what this means?" Lin Yue didn’t look up. "It means we might not be the only civilization in the universe." "No," Dr. Zhang interrupted, "it means they are far more advanced than us. That signal traveled 4.37 light years and is still clear. Think about how far our farthest signal can reach." Lin Yue’s hand froze.
  - ❌ They discussed the discovery and then continued working.
- **Information revealed gradually**: don’t dump too much at once
  - ✅ The first layer of signal encryption was simple: prime number sequences—clear intelligent signal. The second layer was coordinates, pointing to a dead star. The third layer… Lin Yue stared at the screen. It took them three months to decrypt three layers. The third layer contained only one word: "Run."
  - ❌ They cracked the signal and discovered the aliens’ entire plan.

### Chapter Endings
- **Suspense hook**: compel readers to turn the page
  - ✅ Lin Yue stared at the translation results, his hand beginning to tremble. This was not a greeting. It was a warning. "Do not reply. Do not expose. They are listening." But forty-two years ago, humanity had already sent a signal.
  - ❌ This chapter ended; next chapter they would continue investigating.
- **Information bomb**: drop major info at chapter’s end
  - ✅ "You said you were the project leader thirty years ago?" Lin Yue asked. "Yes," Dr. Zhang answered calmly. "Then you should know—we received a reply long ago."
  - ❌ Dr. Zhang told him some useful information.
- **Emotional focus**: end at a key emotional moment
  - ✅ The ship’s engine noise faded from his ears. Lin Yue knew that when this ship was visible again—if it still was—Earth would no longer exist. "Goodbye," he whispered. No one answered.
  - ❌ The ship flew away, and everyone was sad.

## Language Taboos

### Absolutely Forbidden
- ❌ Internet slang: "yyds" "juejuezi" "laughing to death"
- ❌ Unprofessional technical descriptions: "He hacked the system" (without details)
- ❌ Overly sentimental expressions: "His heart shattered into ten thousand pieces!"
- ❌ Stereotypical characters: "The evil villain laughed maniacally"
- ❌ Simple good-vs-evil dichotomy
- ❌ Magical technology: technology can do anything without limits

### Must Achieve
- ✅ Concise language, no adjective piling
- ✅ Self-consistent technical settings, withstand scrutiny
- ✅ Character behavior consistent with identity and motivation
- ✅ Deep ideas, not superficial
- ✅ Calm and objective narration, with emotional tension
- ✅ Powerful endings, responding to theme

## Special Reminders

### Short Story Special Requirements
- **Focus on core issue**: deeply explore one question within 5 chapters, avoid overexpansion
- **Balance technology and humanities**: hardcore settings serve characters and themes
- **Tight pacing**: every 1000 words must have substantive progress
- **Powerful ending**: the ending is often the most important part of sci-fi short stories

### Perspective Suggestions
- **Third-person limited**: most common, follow protagonist, restrict information revelation
- **First-person**: suitable for diary or memoir style narration
- **Omniscient**: suitable for ensemble narratives showing multiple viewpoints

### Sci-Fi Characteristics Control
- **Science ≠ tedious**: technical details must be precise but expressed smoothly
- **Austere ≠ cold-blooded**: rational restraint contains deep emotion
- **Grand ≠ empty**: cosmic scale presented through concrete details
- **Profound ≠ obscure**: complex ideas expressed clearly

### Emotional Scale Control
- **Restrained but genuine**: no melodrama, but emotions must be grounded
- **Warmth within reason**: the calmest decisions hide the deepest feelings
- **Clear cost**: every choice carries real weight
- **Human complexity**: no purely good or evil characters

## Core Philosophy

Writing sci-fi requires remembering three keywords:
1. **Imagination**: boldly imagine based on science
2. **Reflection**: touch on humanity’s ultimate questions
3. **Awe**: maintain reverence for the universe and the unknown

**Most important point**: Sci-fi is a vehicle for thought experiments. Good sci-fi lets readers see possible futures and ponder unasked questions. It writes burning emotions with calm strokes, focuses on tiny individuals with grand scales, and answers present confusion with distant futures. This is the power of science fiction.