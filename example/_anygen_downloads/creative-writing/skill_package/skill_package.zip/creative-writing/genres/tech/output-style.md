---
name: keji-output-style
description: The output style for tech startup novels: fast-paced and concise language, authentic technical details, information-dense dialogue, restrained and powerful emotions. A fusion of Silicon Valley narrative and business warfare tension.
---

# General Writing Style Principles
- Fast-paced and concise: compact and powerful language, rapid progression, no dragging
- Technical authenticity: accurate terminology, credible details, withstands scrutiny by industry professionals
- Dialogue-driven: abundant dialogue to advance the plot, every line carries information
- Emotional restraint: no sentimentality, emotions conveyed through details and actions
- Business logic: decisions conform to business logic, no reliance on coincidence or luck
- Era texture: capture the pulse and atmosphere of the tech startup era
- Integrated outline: chapter outlines are categorized information, not narrative order; during creation, reorganize information by event progression, avoid copying block by block; let the story flow naturally, with background information integrated into the narrative

## Fusion of Two Narrative Styles

### Silicon Valley Narrative Elements
- **Fast-paced dialogue**: like "The Social Network," rapid and information-dense dialogue
- **Technical details**: authentic code, algorithms, product logic
- **Dream-driven**: idealism and passion to change the world
- **Growth story**: transformation from garage to IPO
- **Innovation culture**: breaking conventions, daring to disrupt

### Business Warfare Narrative Elements
- **Strategic tension**: multi-party games involving capital, teams, competitors
- **Time pressure**: deadlines, windows, countdowns
- **Conflict of interest**: disputes over equity, control, development paths
- **Harsh reality**: friendship breakdowns, betrayals, difficult compromises
- **Strategic wisdom**: negotiation, financing, competitive strategy thinking

## Specific Practices

### Writing Dialogue
- **Fast-paced and information-dense**: every line advances the plot or reveals character
  - ✅ "'How much money is left in the account?' 'Three months.' 'Enough for launch?' 'If no bugs.' 'What if there are bugs?' 'Then two months.'"
  - ❌ "They discussed the company's financial situation and found the funds a bit tight."
- **Natural professional terminology**: technical and business terms are accurate but not obscure
  - ✅ "'What's your DAU?' '20,000.' 'Retention rate?' '75% next day, 40% at day 7.' 'Not enough, investors want million-level DAU.'"
  - ❌ "Investors asked some professional questions, and he answered them."
- **Character shown through dialogue**: speaking style reflects personality
  - ✅ "CTO: 'This feature needs three weeks.' CEO: 'We only have one week.' CTO: 'Then launch a half-finished product?' CEO: 'Survive first, then talk about perfection.'"
  - ❌ "They had a disagreement about product development time."
- **Conflict intensified through dialogue**: use dialogue to drive tension
  - ✅ "'You want to sell the company?' '10 million dollars, enough for each of us to get 3 million.' 'We agreed to change the world.' 'Changing the world doesn't pay the bills, Chen Mo. I have a mortgage and kids. You don't, so you can talk ideals.'"
  - ❌ "They had a disagreement about whether to sell the company."

### Writing Scenes
- **Authentic technical scenes**: programming, debugging, product development details
  - ✅ "Chen Mo stared at the red error prompts flashing in PyCharm. Stack overflow, memory leak, he had refactored three times already. Outside, dawn was breaking, demo starts at 9. Ctrl+Z, start over."
  - ❌ "He was coding at the computer, encountered some technical problems, but solved them eventually."
- **Tense business scenes**: fundraising roadshows, negotiations, boardroom tension
  - ✅ "In the conference room, five investors stared expressionlessly at him. Chen Mo clicked to slide three of the PPT: 'Our core algorithm, 99.7% accuracy—' 'Who are your competitors?' the leftmost investor interrupted. 'Google, Microsoft, and—' 'Why haven't they done it?' The air froze for two seconds. 'Because they didn't think of this direction.' 'Or because this direction isn't profitable?'"
  - ❌ "He met with investors, introduced his project, and they asked some questions."
- **Warm office scenes**: startup atmosphere and culture
  - ✅ "11 pm, the office lights were still on. Seven people on the team, not one had left. Takeout boxes piled by the trash, whiteboard covered with code logic. Li Ming had fallen asleep on the keyboard, fingers still on the F5 refresh key. This was the 72nd hour before launch."
  - ❌ "Their office was simple, but everyone worked hard."

### Writing Technical Details
- **Credible code and algorithms**: novices find it professional, experts find it authentic
  - ✅ "Chen Mo added a try-catch on line 347 to catch possible NullPointerException. But the real problem was his recursive algorithm's time complexity of O(n²) when handling large datasets. It was fine with small lab samples, but once live, millions of users would crash the server."
  - ❌ "There were some bugs in the code, and he fixed them."
- **Clear product logic**: readers understand what the product is and what problem it solves
  - ✅ "'Our app can identify cancer lesions within 3 seconds, with accuracy surpassing most doctors.' Chen Mo demonstrated on the demo: phone photo, AI analysis, red circles marking suspicious areas, confidence 99.2%. 'What does this mean? It means patients in remote areas don't need to go to big hospitals, they can do preliminary screening with their phones.'"
  - ❌ "They developed a medical AI product that is very useful."
- **Specific technical challenges**: show the value of technical breakthroughs
  - ✅ "'The problem is training data. Medical imaging data is strictly protected by major hospitals, we can't get enough samples. Google has it, Microsoft has it, we don't.' Li Ming drew a data volume comparison chart on the whiteboard: 'They have 1 million labeled CT scans, we have only 5,000. That's the gap.' 'What to do?' 'Synthetic data. Use GAN to generate virtual CT images to train the model.' 'Isn't that cheating?' 'No, that's innovation.'"
  - ❌ "They encountered technical difficulties but came up with solutions."

### Writing Business Decisions
- **Authentic financing logic**: valuation, dilution, terms realistically presented
  - ✅ "'5 million dollars for 20% equity, post-money valuation 25 million.' The investor said. Chen Mo quickly calculated: he and Li Ming each hold 40%, diluted to 32%. Still controlling. 'There are terms.' The investor pushed over a term sheet: 'A performance clause: monthly active users must reach 1 million within a year, or we have the right to repurchase 10% shares at original price.' 'So we get free money?' 'No, that means you have to work hard.'"
  - ❌ "Investors gave them some money but with conditions."
- **Specific competitive strategies**: how to respond to competition, not just slogans
  - ✅ "'WeChat just launched a similar feature.' Li Ming stared at his phone screen. 'They have 1 billion users, we have 100,000. How do we compete?' Chen Mo was silent for a minute: 'We don't fight head-on. They do big and comprehensive, we do small and refined. Focus on Gen Z, on scenarios where they don't want to use WeChat.' 'What scenarios?' 'Where they don't want parents to see.' Li Ming's eyes lit up: 'Ephemeral messages?' 'Not just that. End-to-end encryption, no server storage, even we can't see it ourselves. Privacy is our moat.'"
  - ❌ "The competitor is strong, but they decided to differentiate."
- **Urgent time nodes**: the pressure of deadlines
  - ✅ "'Apple's WWDC is on June 6. If we can't launch before then, we have to wait for the fall event.' The CEO stared at the calendar, 'Today is April 20, we have 47 days.' 'Testing takes two weeks.' 'Then you have 33 days for development.' 'Impossible, this feature needs at least—' '33 days, or we wait half a year. By then, competitors will have taken the market.'"
  - ❌ "They need to launch before competitors, so time is tight."

### Writing Emotions
- **Restrained but powerful**: no sentimentality, emotions conveyed through details
  - ✅ "Chen Mo watched Li Ming pack up. On the photo wall still stuck their group photo from three years ago: Stanford dorm, two guys holding beers, smiling brightly. Back then they said they would build a company to change the world. Now, Li Ming's box held his Mac, mechanical keyboard, and that 'change the world' mug. 'You really are leaving?' Chen Mo asked. 'You chose your ideals, I chose my life.' Li Ming didn't look back."
  - ❌ "Li Ming was leaving, Chen Mo was sad, and their friendship broke."
- **Show inner feelings through actions**: don't write "he was anxious" directly, write actions
  - ✅ "Chen Mo refreshed his email for the seventh time. Investors said they'd reply today, but it was already 11 pm. He opened Gmail, refreshed. No new mail. Opened the equity spreadsheet, calculated holdings under different dilution ratios. Opened bank account, balance: 187,429 yuan. Enough to pay two months' salaries. Opened email again, refreshed. Still nothing."
  - ❌ "Chen Mo anxiously waited for investors' reply."
- **True feelings revealed in conflict**: after the fiercest conflict, real emotions emerge
  - ✅ "At the board meeting, investors voted to remove Chen Mo as CEO. Five to four, he lost. Li Ming was the fifth vote. After the meeting, Li Ming approached Chen Mo: 'Sorry.' 'Why did you vote yes?' 'Because you're not fit to be CEO, Chen Mo. You're too idealistic, you'd take the company down with you. I voted yes because I want the company to survive.' 'Then it's your company now.' 'No, it will always be our company.'"
  - ❌ "They had a fierce conflict at the meeting, but still cared about each other."

### Writing Time Pressure
- **Specific countdowns**: hours, minutes, not just "time is tight"
  - ✅ "00:47:23. 47 hours and 23 minutes until product launch. Chen Mo stared at the countdown on the screen, his coffee had gone cold. Bug list had 23 red marks, 15 yellow, 41 green. Red must fix, yellow if possible, green after launch. 'Can we make it?' Li Ming asked. 'Don't know. But we have no choice.'"
  - ❌ "They were pressed for time and had to fix bugs quickly."
- **Specific milestones**: financing, launch, performance clauses, each with dates
  - ✅ "'September 30, performance clause expires.' CFO circled on the whiteboard, 'Today is August 15, we have 46 days. Goal: 1 million MAU. Current: 473,000.' 'So we need to double in 46 days?' 'No, doubling isn't enough. We need 1.12 million to ensure no drop at month-end.' 'How?' 'Don't know. But if we fail, the company won't be ours.'"
  - ❌ "They had to meet the deadline or lose the company."

### Writing Growth and Transformation
- **Before and after contrast**: show character changes
  - ✅ "Three years ago, Chen Mo said in a Stanford class: 'I will never compromise for money.' The professor asked: 'What if you fail without compromise?' He answered: 'Then I'd rather fail.'<br><br>Three years later, in the conference room, investors said: 'Lower accuracy for speed.' Chen Mo was silent for thirty seconds. 'How low?' '95%.' 'Deal.'<br><br>After the meeting, Li Ming asked: 'Didn't you say never compromise?' 'That was three years ago.' Chen Mo looked out the window, 'Three years ago I thought changing the world was simple. Now I know, surviving is the first step to changing the world.'"
  - ❌ "He changed from an idealist to a realist."
- **Key moment choices**: show growth through decisions
  - ✅ "Chen Mo stared at two contracts. Left: Google's acquisition offer, 80 million dollars. Right: new round financing term sheet, valuation 300 million, but diluted to 25%. Three years ago he'd pick right without hesitation. But now, he thought of the 20 employees following him, the student loans unpaid, his parents' gray hair. He picked up the pen and signed—the left contract. Then stood up and walked toward the sunlight outside the window. 'Sorry, me from three years ago. But thank you for getting me here.'"
  - ❌ "After careful thought, he made a choice."

### Writing Endings
- **No forced happy endings**: success has costs, failure has gains
  - ✅ "At the IPO bell-ringing moment, Chen Mo stood under the Nasdaq big screen. Stock price fixed at $42, company valued at 3 billion. He succeeded. But in the audience, no sign of Li Ming. A year ago's equity dispute turned partners into strangers. The cost of success was losing his best friend. 'Was it worth it?' someone asked. He didn't answer."
  - ❌ "He finally succeeded, the company went public, and everyone was happy."
- **Lingering resonance**: leave room for reflection
  - ✅ "On the day the company closed, Chen Mo returned the keys to the landlord. Two years of startup, burned 3 million angel investment, gained an unused app and a memory about ideals. Leaving the office building, he glanced at his phone: 7 missed calls, all from headhunters. 'Going back to work?' Li Ming asked. 'Maybe.' He smiled, 'But at least we tried.' Three months later, they started a new project in another garage. This time, they knew what to do."
  - ❌ "Although they failed, they learned a lot and will succeed in the future."
- **Respond to the beginning**: ending echoes the opening question or philosophy
  - ✅ "Opening: Chen Mo said in the Stanford dorm: 'I want to build a company that changes the world.'<br>Ending: Five years later, he stood on the stage at the company annual meeting, looking at 1,000 employees below. 'Did we change the world?' he asked, 'Maybe not. But we changed 1,000 lives and influenced 1 million users' choices. Is that enough? I don't know. But it's what we could do.'"
  - ❌ "He finally realized his dream."

## Language Taboos

### Absolutely forbidden
- ❌ Internet slang and outdated memes: "yyds," "jué jué zi," "laughing to death," "working class"
- ❌ Unprofessional technical descriptions: "He typed a few keys and hacked the system"
- ❌ Hollow slogans: "We will change the world!" (without specifying how)
- ❌ Stereotyped characters: "evil investors," "perfect entrepreneurs"
- ❌ Relying on luck and coincidence: "A random angel investor happened to pass by"
- ❌ Outdated tech elements: writing "develop a website" in 2024

### Must do
- ✅ Accurate technical terminology, withstands industry scrutiny
- ✅ Tight business logic, consistent with real startup rules
- ✅ Fast-paced, information-dense dialogue
- ✅ Rapid plot progression, no dragging
- ✅ Characters are vivid and nuanced, not stereotyped
- ✅ Strong sense of era, capturing the pulse of current tech startups

## Special Reminders

### Short story special requirements
- **Focus on one core conflict**: don't try to tell the entire startup history, focus on key moments
- **Balance tech and business**: technical details serve the plot, don't pile up for show
- **Tight pacing**: every 1000 words must advance plot or deepen character
- **Powerful ending**: the ending of a tech startup story is often the most important insight

### Creating authenticity
- **Use concrete data**: don't say "many users," say "473,000 DAU"
- **Use industry jargon**: moderate use but understandable to outsiders
- **Use real scenes**: coffee shop roadshows, late-night offices, boardrooms
- **Use era details**: technologies and products mentioned must fit the timeline

### Emotional scale control
- **Startup passion**: write the blood and fire of "changing the world"
- **Business harshness**: also write the helplessness of "friendship breaking"
- **Idealistic persistence**: write the value of idealism
- **Realistic compromise**: also write the necessity and pain of compromise

### Capturing the era
- **Current tech hotspots**: AI, blockchain, Web3 (but judge if outdated)
- **Real startup environment**: fundraising difficulty, fierce competition, tightening regulation
- **A generation's confusion**: ideals vs reality, passion vs fatigue, definition of success

## Core Philosophy

When writing tech startup stories, remember three keywords:
1. **Authenticity**: technical authenticity, business authenticity, human authenticity
2. **Tension**: time pressure, competitive pressure, value conflicts
3. **Growth**: from idealism to reality, from naivety to maturity

**Most important point**: tech startup novels are neither inspirational fluff nor tragic melodramas. They are the struggles, confusions, and growth of a generation riding the tech wave. A good tech startup story shows readers that real entrepreneurship is not the grand plans on a PPT, but the code at 3 am, the verbal battles in boardrooms, and the price paid for dreams. This is the true face of our era.