---
name: keji-outline-method
description: Methodology for creating outlines of short stories on tech entrepreneurship, including core synopsis extraction, lead design, plot structure planning, and character development guidance. Integrates Silicon Valley entrepreneurial spirit with business war narrative techniques.
---

## Q1-Q3 Question Templates

### Q1: Core Idea
**Q1: Core idea and appeal of the story【Brief description】**  
Please describe your story idea in one or two sentences.

### Q2: Core Conflict
**Q2: Core conflict【Brief description】**  
Please describe the novel’s core contradiction or main conflict in one sentence  
(e.g., a startup team’s technological battle with a giant company, AI entrepreneurs facing the dilemma between capital and ideals, ideological differences between a tech genius and business partner, industry reshuffle triggered by disruptive technology, etc.)

### Q3: Story Tone
**Q3: Story tone【Choose one】**  
- Silicon Valley drama · Passionate entrepreneurship (garage startup, fundraising & IPO, changing the world)  
- Technology supremacy · Geek spirit (code changes the world, technological idealism)  
- Business warfare · Capital competition (investment & acquisition, equity battles, commercial intrigue)  
- Tech ethics · Social reflection (technology as a double-edged sword, data privacy, AI ethics)  
- Or briefly describe your story tone

## Chapter File Naming Rules  
Filename format: `{STORY_NAME}-{NN}.md`  
Example: `CodeAndDreams-01.md`, `CodeAndDreams-02.md`

---

# Methodology for Tech Entrepreneurship Outline Creation

## Overall Orientation

Tech entrepreneurship novels emphasize "**innovation-driven and business warfare**," focusing on technological breakthroughs, business models, and the realization of dreams.

**Core Principles**:  
- Focus on core topics (technological innovation, business competition, team management, capital struggles, ideals vs. reality)  
- Pursue "authentic impact": credible technical details, rigorous business logic, profound character portrayal  
- Balance ideals and reality, but **do not stray from business essence and technical logic**  
- Drive plot with product iteration, fundraising milestones, and competitive struggles, **aiming for a fast-paced narrative tone**  
- Maintain the passionate spirit of Silicon Valley stories: dreams of changing the world, intense sprints  
- Incorporate the brutal reality of business warfare: capital battles, equity disputes, friendship ruptures coexist

---

## Overall Creation Formula
```
Tech Entrepreneurship Short Story = Technological Innovation + Business Dilemma + Human Struggle + Growth & Transformation
```

---

## I. Core Synopsis Writing

### Formula
```
Core Synopsis = Technology/Product Setting + Business Dilemma + Core Conflict
```

### Writing Points
| Element | Requirement | Correct Example | Incorrect Example |
|---------|-------------|-----------------|------------------|
| **Technical Background** | Innovative + credible | "When AI can diagnose cancer within 3 seconds" | "Invented black technology" |
| **Business Dilemma** | Involves major decision | "Facing a cash flow break, must complete financing within 72 hours or shut down" | "Encountered difficulties" |
| **Core Conflict** | Touches deep contradictions | "Fundamental disagreement between tech genius and investor on product direction" | "They disagreed" |

### Excellent Examples
- "Three Stanford dropouts develop a disruptive AI algorithm in a garage. When Google offers $1 billion to acquire, they must choose between staying independent or cashing out quickly. But the real crisis is: the algorithm has a fatal flaw, and investors are already pressuring for product launch."  
- "She developed an app in six months that gained a million users within 48 hours. But a competitor stole the core code and launched first. She must choose between suing for rights or quickly iterating—the former may win justice but miss the market window, the latter requires rewriting the code entirely."  
- "Two partners have been building a startup for five years, finally approaching IPO night. But an old email leaks revealing secrets about equity distribution. Trust collapses, the board pressures, and they must resolve differences within 48 hours or the IPO will fail."

---

## II. Lead Writing

### Formula
```
Lead = Startup Scene Opening + Core Suspense Setup + Conflict Hook
```

### Writing Points
| Element | Purpose | Approach |
|---------|---------|----------|
| **First Sentence** | Establish startup atmosphere | Directly show: coding scene / pitch event / product launch / fundraising negotiation |
| **Middle Part** | Explain core dilemma | Use precise industry terms and tense narration to quickly locate the situation |
| **Last Sentence** | Create conflict suspense | Present major decision / business crisis / human test |

### Integration of Core Topics

The lead should touch on core themes of tech entrepreneurship:

| Topic Type | Specific Direction |
|------------|--------------------|
| **Technological Innovation** | Disruptive algorithms, product breakthroughs, technical moat, core patents |
| **Business Competition** | Giant company suppression, malicious competition, market window, race against time |
| **Capital Struggle** | Financing difficulties, equity disputes, betting agreements, IPO decisions |
| **Team Management** | Partner disagreements, key employee turnover, ideological conflicts, trust crises |
| **Ideal vs Reality** | Changing the world vs business returns, technical perfection vs rapid launch |

**Goal**: Make readers feel "this decision is so hard" (emotional resonance)

### Example Comparison
| Type | Content |
|------|---------|
| ✅ **Correct** | "At 3 a.m., Chen Mo stared at the blinking code on the screen, fingers hovering above the Enter key. This algorithm could boost AI accuracy to 99.7%, but required accessing users’ private data. Investors were pushing for product launch; competitors had already released similar features. Pressing this key would push his company valuation beyond $1 billion. Not pressing it meant running out of funds in three months. He recalled the vow made in the Stanford dorm: 'We want to do the right thing, not just make money.' Dawn was breaking outside; the board meeting was at 9 a.m. He had six hours left." |
| ❌ **Incorrect** | "He was an entrepreneur; the company had problems and needed to make a tough choice..." |

---

## III. Plot Structure Design (Qi-Cheng-Zhuan-He 起承转合)

### 【Qi 起】Chapter 1: Dream Set Sail (2000-3000 words)

#### Writing Focus
```
Qi = Startup motivation + Team introduction + Product prototype + First challenge
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Startup Motivation** | Establish startup atmosphere within first 500 words | First paragraph shows: coding scene / brainstorming / product demo<br>Use details rather than explanation: show how technology changes the status quo |
| **Team Introduction** | Quickly introduce core characters | Introduce team within 300 words<br>Show identity through professional actions: CTO coding, CEO negotiating funding |
| **Product Prototype** | Show innovation value | Technological breakthrough / user pain points / market gap |
| **First Challenge** | Propel story forward | Tight funds / technical bottleneck / competitive pressure / team conflict |

#### Silicon Valley Narrative Techniques
- **Fast-paced dialogue**: Show character and conflict through tense conversations  
- **Technical details**: Use real technical terms to build credibility  
- **Power of dreams**: Show the passion and original intention to "change the world"

#### Taboos
- ❌ Long blocks of technical exposition  
- ❌ Main team lacks uniqueness  
- ❌ Challenges lack urgency

---

### 【Cheng 承】Chapters 2-3: Growth and Struggle (each 2000-3000 words)

#### Chapter 2 Focus
```
Chapter 2 = Product breakthrough + Market validation + Initial success + New threats
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Product Breakthrough** | Technological or model innovation | Algorithm optimization / user growth / business model formation |
| **Market Validation** | Show product value | User feedback / data growth / media attention |
| **Initial Success** | Gain recognition | Fundraising success / major client signing / industry awards |
| **New Threats** | Create bigger suspense | Giant company entry / malicious competition / technology leak |

#### Chapter 3 Focus
```
Chapter 3 = Major crisis + Team conflict + Difficult choice + Key turning point
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Major Crisis** | Life-or-death moment | Cash flow break / core technology stolen / key personnel departure |
| **Team Conflict** | Ideological clash | Technical perfection vs rapid launch / insist on independence vs accept acquisition |
| **Difficult Choice** | No perfect solution | Sacrifice short-term gain or long-term value / maintain friendship or business rationality |
| **Key Turning Point** | Foreshadow climax | Make major decision / discover new opportunity / suffer betrayal |

---

### 【Zhuan 转】Chapter 4: Desperation and Breakthrough (2000-3000 words)

#### Writing Focus
```
Zhuan = Crisis outbreak + All-out sprint + Major decision + Consequence presentation
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Crisis Outbreak** | Problems fully exposed | Funds exhausted / product crash / partner fallout / competitor suppression |
| **All-out Sprint** | Do or die | 72-hour code rewrite / final fundraising pitch / life-or-death product launch |
| **Major Decision** | Protagonist’s choice | Based on business judgment but with emotional cost |
| **Consequence Presentation** | Outcome of choice | Friendship broken / equity diluted / dream compromised / team split |

#### Business Warfare Narrative Techniques
- **Time pressure**: countdown, deadlines, windows  
- **Multi-party struggle**: investors, competitors, team members with different stakes  
- **Realistic details**: fundraising terms, technical parameters, user data

#### Taboos
- ❌ Solve problems by coincidence  
- ❌ Protagonist suddenly gains unforeshadowed resources  
- ❌ Avoid the harsh reality of business decisions

---

### 【He 合】Chapter 5: Transformation and Rebirth (2000-3000 words)

#### Writing Focus
```
He = Consequence presentation + New pattern + Growth sublimation + Open ending
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Consequence Presentation** | Show results of choices | Company survival / successful IPO / acquisition / shutdown and restart |
| **New Pattern** | Changes in characters and industry | Team reorganization / market reshaping / personal growth |
| **Growth Sublimation** | Respond to core themes | Balance ideals and reality / true meaning of entrepreneurship |
| **Open Ending** | Leave room for reflection | New journey / unfinished story / profound insight |

#### Types of Tech Entrepreneurship Endings
| Type | Characteristics | Suitable Scenarios |
|------|-----------------|--------------------|
| **Success** | Dream realized but with cost | IPO, high-value acquisition but loss of original intention or friendship |
| **Failure** | Company fails but with growth | Startup failure but valuable experience and life insights gained |
| **Compromise** | Balance between ideals and reality | Accept investment terms but retain core values |
| **Restart** | Ending is a new beginning | Company closes but team starts a new project |
| **Open** | Leaves suspense | After key decision, results remain unknown |

#### Taboos
- ❌ Overly perfect endings that defy business logic  
- ❌ Preachy summaries  
- ❌ Leaving major plot holes

---

## IV. Character Development Methods

### Protagonist Design

| Dimension | Requirement | Correct Example | Incorrect Example |
|-----------|-------------|-----------------|------------------|
| **Professional Background** | Clear + credible | "Stanford CS PhD, specializing in machine learning" | "Studied computer science" |
| **Core Traits** | Idealistic + persistent | "Tech perfectionist who refuses to compromise" | "Very talented" |
| **Personality Tags** | 2-3 distinct traits | "Programming genius, social awkwardness, idealist" | "Smart person" |
| **Growth Arc** | Must have change | "From tech supremacy to understanding business compromise" | "Always excellent" |

### Personality Specificity
```
✅ "Chen Mo stared at the blinking cursor in PyCharm; line 347 had stalled him for three hours. As a Stanford dropout and tech genius entrepreneur, he could stay up 72 hours optimizing algorithms but couldn’t tolerate investors’ demand to 'reduce accuracy for speed.' 'Code doesn’t lie, but investors do.' That’s his motto."  
❌ "He is a strong technical entrepreneur with high product standards."
```

### Protagonist Archetypes (Common in Tech Entrepreneurship)

| Type | Traits | Personality | Suitable Themes |
|------|--------|-------------|-----------------|
| **Tech Geek** | Code changes the world | Idealistic, perfectionist, socially awkward | Tech innovation, ideals vs reality |
| **Business Genius** | Sees market essence | Pragmatic, decisive, skilled in negotiation | Business competition, capital operation |
| **Serial Entrepreneur** | Repeated failures and comebacks | Resilient, flexible, experienced | Growth & transformation, comeback |
| **Dropout Genius** | Breaks conventions | Rebellious, confident, risk-taking | Disruptive innovation, youthful passion |
| **Tech + Business Dual Expert** | All-round founder | Rational, balanced, solitary | Team management, strategic decisions |

### Supporting Characters Design (Tech Entrepreneurship Specific)

| Type | Role | Notes |
|------|------|-------|
| **Co-founder** | Source of ideological conflict | Different professional backgrounds, complementary but conflicting |
| **Angel Investor** | Resource and constraint | Provides money but also pressure, may become adversary |
| **Competitor** | External pressure | Not necessarily villain, may be just business competition |
| **Core Employee** | Team microcosm | Represents different values and interests |
| **Mentor/Advisor** | Experience and wisdom | Offers advice but does not solve problems directly |

### Relationship Network Design (Tech Entrepreneurship Specific)

| Element | Requirement |
|---------|-------------|
| **Partner Relations** | From tacit understanding to conflict, showing trust and betrayal |
| **Investor Struggles** | Balance of funding and control |
| **Competition & Cooperation** | Both competitive and cooperative within the industry |
| **Team Dynamics** | Early core team vs later professional managers |

---

## V. Technology and Business Element Design

### Technology Setting Formula
```
Technological Innovation = Core Technology + Application Scenario + Business Value
```

### Common Technology Directions

| Type | Features | Examples |
|------|----------|----------|
| **Artificial Intelligence** | Algorithms, data, applications | Computer vision, NLP, recommendation systems |
| **Enterprise Services** | SaaS, cloud computing | Collaboration tools, data analytics, cloud storage |
| **Consumer Internet** | Social, e-commerce, content | Short videos, social networks, O2O platforms |
| **Hardware Innovation** | IoT, wearables | Smart hardware, robots, AR/VR |
| **Fintech** | Payments, blockchain | Digital currency, robo-advisors, supply chain finance |

### Technology Setting Principles

| Element | Requirement |
|---------|-------------|
| **Realistic & Credible** | Technical logic must withstand scrutiny |
| **Has Moat** | What is the core competitive advantage |
| **Has Barrier** | Why others cannot or do not do it well |
| **Valuable** | What problem it solves, what value it creates |

### Business Model Design

| Element | Requirement |
|---------|-------------|
| **Profit Model** | How to make money: ads/subscriptions/transaction fees/enterprise services |
| **Growth Strategy** | How to acquire customers: viral marketing/field promotion/content marketing/channel partnerships |
| **Competitive Barriers** | Moat: network effects/data advantage/technical patents/brand effect |
| **Financing Path** | Angel - Series A - Series B - IPO, valuation and milestones per round |

---

## VI. Conflict Design

### Conflict Formula
```
Tech Entrepreneurship Conflict = External Competition (market/rivals) + Internal Contradictions (team/resources) + Value Choices (ideals/reality)
```

### External Conflicts (Mainline)

| Conflict Type | Specific Methods | Examples |
|--------------|------------------|----------|
| **Market Competition** | Time window / first-mover advantage / follower catch-up | Giant company copies your model |
| **Funding Pressure** | Runway exhaustion / financing failure / betting agreement | Only 3 months salary left in account |
| **Technical Bottleneck** | Algorithm challenges / performance issues / patent infringement | Core technology blocked |
| **Policy Regulation** | Compliance risk / license restrictions / policy changes | New regulation halts business |

### Internal Conflicts (Subplot)

| Conflict Type | Design Methods |
|---------------|----------------|
| **Partner Disagreements** | Tech vs business, fast vs slow, independence vs sale |
| **Equity Disputes** | Early unclear agreements, uneven contributions, dilution conflicts |
| **Team Rift** | Key employee resignation, parachuted executives, cultural clashes |
| **Strategic Wavering** | To B or to C, domestic or overseas expansion |

### Value Conflicts (Deep Layer)

| Conflict Type | Design Methods |
|---------------|----------------|
| **Ideals vs Reality** | Change the world vs business returns |
| **Perfection vs Speed** | Polishing product vs seizing market |
| **Principles vs Compromise** | User privacy vs commercial value |
| **Friendship vs Interest** | Partner friendship vs equity distribution |

### Conflict Progression Levels
```
Level 1: Market competition (external problem to solve)
    ↓
Level 2: Resource dilemma (internal constraints to resolve)
    ↓
Level 3: Value choice (deep reasons for such choices)
```

---

## VII. Foreshadowing Management

### Foreshadowing Carriers (Tech Entrepreneurship Specific)

| Carrier Type | Example |
|--------------|---------|
| **Code Details** | A seemingly unrelated function/comment/version record |
| **Email Correspondence** | Early discussion emails / draft equity agreements |
| **Meeting Minutes** | Board meeting notes / fundraising negotiation records |
| **Product Data** | Abnormal user behavior / signs of data leakage |
| **Character Background** | Someone’s past experience / unmentioned relationships |

### Foreshadowing Setting Principles

| Stage | Method |
|-------|--------|
| **Planting** | Naturally integrate into plot without emphasis<br>Example: "Chen Mo noticed a line of fine print in the equity agreement had been altered. He didn’t think much and signed."<br>Example: "Li Ming’s resume said he worked at Google for three years, but he never mentioned that period." |
| **Payoff** | Reveal significance at key moments<br>Example: That altered line caused later equity disputes<br>Example: Li Ming was a competitor’s mole during his Google tenure |

### Common Foreshadowing Designs

**Technical Foreshadowing**:
```
Planting: A commented-out feature in the code  
Payoff: That code was the core algorithm later stolen by competitors
```

**Character Foreshadowing**:
```
Planting: Investor unusually focused on a certain tech direction  
Payoff: Because he also invested in a competitor in that field
```

**Business Foreshadowing**:
```
Planting: An apparently unimportant client contract clause  
Payoff: That clause saved the company at a critical moment
```

---

## VIII. Chapter Layout Design (Tech Entrepreneurship Specific)

### Chapter Title Style

Tech entrepreneurship titles should be **concise, powerful, and imply conflict**:

| Element | Method |
|---------|--------|
| **Title Style** | Concise and strong, hinting content<br>Example: "Chapter 1 Garage"<br>Example: "Chapter 3 Betting Agreement"<br>Example: "Chapter 5 IPO Eve" |
| **Chapter Opening** | Directly enter scene, fast pace<br>Example: "At 3 a.m., Chen Mo typed the last line of code."<br>Example: "'We have three months of funds left,' said the CFO." |
| **Chapter Ending** | Conflict escalation or key turning point<br>Example: "He pressed send; the equity agreement was sent to investors. In 24 hours, he would know if he saved the company or destroyed the dream."<br>Example: "'Sorry, I’m leaving,' said the CTO, turning away from the office. That was 72 hours before launch." |

### Dialogue Design (Core to Tech Entrepreneurship)

Tech entrepreneurship dialogue should be **fast-paced, information-rich, and reveal character**:

**Good Dialogue Example**:
```
"What's your algorithm’s accuracy?" the investor asked.  
"99.7%," Chen Mo replied.  
"Competitors are at 95%, but they already have a million users."  
"That’s because they sacrificed accuracy."  
"The market doesn’t care about your perfectionism, Chen Mo. Users want a usable product, not a lab paper."  
"If accuracy is insufficient, there will be misdiagnoses. People will die."  
The investor paused for two seconds: "You have three months. Launch or I pull funding."
```

**Poor Dialogue Example**:
```
"How’s your product?"  
"Good."  
"Then launch it quickly."  
"Okay."
```

### Psychological Description (Tech Entrepreneurship Specific)

Should be **rational but warm**, showing the entrepreneur’s inner struggle:

**Good Psychological Description**:
```
Chen Mo stared at the "Send" button. Clicking it would activate the financing agreement, adding $5 million to the company’s account, allowing survival. But the clause "investors have the right to replace the CEO" was a thorn in his heart.  
Three years ago, he and Li Ming vowed in their Stanford dorm to build a company not hijacked by capital. Now, reality forced compromise.  
Outside the office, 20 employees waited for salaries. Server hosting fees were due next week. Competitors just announced their Series B funding.  
His finger hovered trembling above the mouse.
```

**Poor Psychological Description**:
```
He was conflicted, didn’t know whether to accept the investment. He thought for a long time and finally accepted.
```

### Pace Control (Core to Tech Entrepreneurship)

**Pace Formula**:
```
500 words = 1 plot advancement OR 1 dialogue confrontation OR 1 key decision
```

Every scene must have: clear conflict + new information + driving force

---

## IX. Timeline Design (Exclusive to Tech Entrepreneurship)

### Typical Startup Timeline
```
Day 1-100: From idea to product prototype  
Day 100-200: Angel round financing  
Day 200-365: Product launch, user growth  
Year 2: Series A financing, team expansion  
Year 3: Series B financing, business model validation  
Year 4-5: Profitability or IPO
```

### Key Time Nodes

| Node | Significance | Possible Conflicts |
|-------|--------------|--------------------|
| **Demo Day** | Product demo, fundraising pitch | Technical failure / competitor release / investor doubts |
| **Financing Deadline** | Deadline pressure | No money left / investor withdrawal / competing offers |
| **Product Launch** | Market validation | Bugs crash / user loss / negative publicity |
| **Betting Agreement Expiry** | Life-or-death moment | Performance unmet / buyback clause / loss of control |
| **IPO Roadshow** | Ultimate goal | Financial issues / competitor sabotage / team split |

---

## X. Common Tech Entrepreneurship Patterns

### Pattern A: Garage Startup - Fundraising - IPO  
**Structure**:  
- Qi: Idea and prototype in garage  
- Cheng: Angel investment, product launch  
- Zhuan: Fierce competition, life-or-death crisis  
- He: Successful fundraising or IPO, but with cost

### Pattern B: Tech Genius vs Business Reality  
**Structure**:  
- Qi: Technical breakthrough, idealism  
- Cheng: Market cold shoulder, funding pressure  
- Zhuan: Forced compromise or insist on ideals  
- He: Find balance or choose one side decisively

### Pattern C: Partner Split  
**Structure**:  
- Qi: Like-minded partners start business  
- Cheng: Initial success, emerging conflicts  
- Zhuan: Ideological clashes, friendship breaks  
- He: Equity disputes resolved, part ways or reconcile

### Pattern D: Giant Competition  
**Structure**:  
- Qi: Startup’s disruptive innovation  
- Cheng: Rapid growth, giant company notices  
- Zhuan: Giant copies, malicious competition  
- He: Acquisition / insist independence / find differentiation

---

**【Special Reminder】**  
Keys to success or failure of tech entrepreneurship short stories:  
1. The first 500 words must establish startup atmosphere and core conflict  
2. Technical details must be authentic and withstand scrutiny  
3. Dialogue must be fast-paced, carrying information and character  
4. Business logic must be rigorous, not relying on coincidence or luck  
5. Ending must convey growth, no forced success needed  
6. The conflict between ideals and reality is an eternal theme