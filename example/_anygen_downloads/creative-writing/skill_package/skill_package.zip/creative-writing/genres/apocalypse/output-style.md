---
name: mori-output-style
description: Output style for post-apocalyptic survival novels, with cold and realistic language, authentic and credible details, oppressive and tense atmosphere, profound human characterization, sustained strong tension, and glimmers of light in despair. Combining Liu Cixin's rational restraint with the human depth of "The Walking Dead".
---

# General Writing Style Principles
- Cold and Realistic: restrained and calm language, no melodrama, speaking with facts
- Authentic Details: survival details withstand scrutiny, enhanced credibility with data
- Oppressive Atmosphere: continuous tension and despair, but not absolute hopelessness
- Profound Humanity: showing true human nature under extreme conditions, neither glorified nor vilified
- Strong Tension: every moment on the edge of life and death, choices are difficult
- Presence of Glimmers: human light remains in despair, hope possible amid cruelty
- Integrated Outline: chapter outlines are categorized information, not narrative order; during creation, reorganize information by event progression, avoid block copying; let the story flow naturally, background information integrated into narration

## Fusion of Two Styles

### Liu Cixin Style Elements
- **Rational Restraint**: describing harsh realities with calm data and logic
- **Macro Perspective**: individual stories reflect the fate of human civilization
- **No Avoidance of Cruelty**: facing the cost of choices directly, no cheap hope
- **Scientific Thinking**: analyzing problems with scientific methods, rational decision-making
- **Poetic Restraint**: conveying shock with restrained language amid despair

### "The Walking Dead" Style Elements
- **Complex Humanity**: no purely good or bad people, all struggling to survive
- **Moral Dilemmas**: forced to make choices against morality
- **Group Dynamics**: power struggles, trust breakdowns, loyalty tests
- **Psychological Realism**: authentic portrayal of PTSD, trauma, numbness, collapse
- **Daily Survival**: detailed depiction of everyday survival in apocalypse

## Specific Behaviors

### When Writing Dialogue
- **Concise and Restrained**: no one wastes words in apocalypse, every sentence has purpose
  - ✅ "How much left?" "Three days." "Is three days enough?" "Not enough."
  - ❌ "Our food reserves are running low, maybe only enough for about three days, do you think that's enough?"
- **Information-Carrying**: dialogue should advance plot or reveal character state
  - ✅ "Dr. Li, Wang Jing has a fever again." "What's the temperature?" "39.2." "How many antibiotics left?" "Two." Silence. "Give her one."
  - ❌ "She's sick." "Then treat her." "Okay."
- **Show Pressure**: reveal survival pressure and moral conflict in dialogue
  - ✅ "We have to reduce numbers." "Who do you want to die?" "I didn't say who." "But that's what you're thinking." "I'm thinking about saving more people."
  - ❌ "We need to make a tough decision." "Okay, let's discuss."
- **Restrained Emotion**: even strong emotions are expressed with restraint
  - ✅ "She's your daughter." "I know." "Then you still—" "Because she's my daughter, I can't let other kids die for her." His voice trembled.
  - ❌ "Although she's my daughter, I must be rational! I can't be emotional!" (overly sentimental)

### When Writing Description
- **Authentic Details**: use specific data and details instead of vague descriptions
  - ✅ The Geiger counter read 3.6 roentgens—not too high, but unsafe. Li Ming glanced at his watch: he had been in the radiation zone for 23 minutes. According to the dosage chart, he could stay 17 more minutes. He had to find supplies before then, or this trip would be wasted.
  - ❌ The radiation was strong; he couldn't stay long.
- **Oppressive Environment**: show the oppressive feel of the apocalypse environment
  - ✅ The sunlight on the ruins was glaring but not warm. The air was filled with a sickly sweet rot—the smell of unattended corpses. Buildings lining the street looked like gnawed bones, all glass windows shattered, walls covered with blackened bullet marks. The wind blew, stirring up gray-white dust. That was radioactive dust.
  - ❌ Outside was a ruin, very scary.
- **Survival Details**: show the specific process of daily survival
  - ✅ Li Ming pried open a can with a knife; inside was beans cooked in tomato sauce. Production date: August 2019. Four years expired, but these days no one was picky. He carefully divided the can into seventeen portions, each less than two spoonfuls. Wang Jing looked at her portion but didn’t eat, tears falling into the plastic bowl.
  - ❌ They ate some food.
- **Cold and Objective**: do not embellish horror, let facts speak for themselves
  - ✅ Three bodies lay at the end of the corridor. Judging by their clothes, a family of three. The father still held a gun, barrel pressed to his temple. Three shell casings lay on the ground. Li Ming understood what happened but chose not to look closely.
  - ❌ Corpses everywhere! Terrifying scene! He was scared to death!

### When Writing Psychological Activity
- **Rational Analysis**: show how characters think rationally about problems
  - ✅ Li Ming calculated in his mind: seventeen people, each needing 1700 calories daily for basic survival. Total available supplies about 86,000 calories. 86,000 divided by 17, then divided by 1700... two and a half days. They could only last two and a half days.
  - ❌ He felt the food was insufficient and was very worried.
- **Restrained Emotion**: strong emotions expressed in restrained ways
  - ✅ Li Ming looked at his daughter's sleeping face. Her cheekbones protruded, cheeks hollow, skin lost its luster. Before the disaster, she always smiled, saying she wanted to be a ballerina. Now she hadn’t smiled for three days. Li Ming turned away, clenched his fists. Fingernails dug into his palms, painful, but he needed the pain.
  - ❌ He looked at his daughter, heartbroken, tears streaming! (overly sentimental)
- **Moral Struggle**: show inner conflict during difficult choices
  - ✅ Abandon Zhang Wei, sixteen people can live three days longer. Not abandoning, all might starve. Li Ming told himself this was a math problem, not a moral one. But he clearly knew it was a moral problem. Zhang Wei saved his life yesterday. Now he had to cross Zhang Wei’s name off the list. The pen tip paused on the paper, leaving an ink dot.
  - ❌ He was conflicted, didn’t know what to do.
- **Psychological Trauma**: realistically portray PTSD and trauma responses
  - ✅ Li Ming hadn’t slept more than two hours for three days straight. Every time he closed his eyes, he saw those faces: the ones he chose to abandon. They didn’t blame him, just stared blankly. More terrifying than blame. He couldn’t eat; his stomach churned. He knew these were PTSD symptoms, but what good was knowing?
  - ❌ He had psychological trauma and felt very bad.

### When Writing Survival Scenes
- **Detailed Process**: show specific survival operations
  - ✅ Li Ming checked the protective suit’s seals: glove-to-sleeve connection, boot-to-pants tape, mask rubber ring. He tied a thin cord on his wrist, connected to a radiation dosimeter pen. The pen would change color when cumulative dose reached danger level. He slung the nearly empty backpack—empty was good, could carry more on return. Taking a deep breath of clean bunker air, he opened the hatch.
  - ❌ He put on the protective suit and went out.
- **Realistic Threats**: not exaggerated, but danger is palpable
  - ✅ Radiation itself is invisible. No color, no smell, no sound. Only the Geiger counter’s ticking warns: death is in the air. Li Ming bypassed a charred car; the counter suddenly beeped rapidly. He stepped back three paces; the reading dropped. Something inside the car emitted abnormally high radiation. Possibly the owner’s stored items. Li Ming marked this spot on the map and moved on.
  - ❌ Radiation is dangerous; he cautiously advanced.
- **Resource Value**: show the preciousness of supplies
  - ✅ The supermarket shelves had long been looted. Li Ming found a bag of chips behind the cashier, expired two years, packaging torn slightly. He squeezed it; still felt crumbs inside. Carefully placed it in his backpack. About 100 grams, calculated by oil content, could provide roughly 500 calories. Enough for an adult to survive half a day.
  - ❌ He found some food and was happy.

### When Writing Conflict Scenes
- **Reasonable Positions**: everyone has their own survival reasons
  - ✅ "We should accept them," Dr. Chen said. "Then what? Our seventeen people’s food now divided among twenty-three?" Old Wang retorted. "They have kids." "We have kids too!" "But—" "No buts. You want to watch your own kids starve to save others? I can’t. Sorry, I’m selfish."
  - ❌ Good guys want to save people, bad guys refuse.
- **No Simple Answers**: dilemmas are truly difficult
  - ✅ Abandon the elderly, kids live longer. Abandon kids, experienced adults survive better, can scavenge more, save more people eventually. Which choice is right? Li Ming didn’t know. Maybe both right, maybe both wrong. Maybe in apocalypse, right and wrong lose meaning.
  - ❌ The correct answer is obvious.
- **Realistic Violence**: write violence when necessary, but don’t embellish
  - ✅ Li Ming pulled the trigger. A gunshot, Zhang Wei fell. No struggle, no last words, no time for expression change. One second alive, next second corpse. Li Ming stared at the body, watching blood slowly flow, staining the concrete red. He waited for feelings, but felt nothing. Only numbness.
  - ❌ Intense gunfight! Blood and gore everywhere! Very violent scene! (overly dramatized)

### When Writing Climax Scenes
- **Tight Pace**: short sentences, fast rhythm, strong pressure
  - ✅ The counter screamed. Radiation spiked. Li Ming grabbed his backpack, turned and ran. Behind, sounds of collapse. Pebbles rained down. He didn’t look back. 20 meters. 15 meters. The exit ahead. 10 meters. 5 meters. He burst out of the building, rolled on the ground, backpack spilled, cans scattered. No time to care, got up and kept running. Behind, the building collapsed with a roar, dust billowing.
  - ❌ Situation was critical, he nervously fled, barely escaped.
- **Clear Cost**: victory must have a price
  - ✅ They got the medicine. Three boxes of antibiotics, enough for half a year. But the cost was a life. Zhang Wei’s body still lay in that building, never to be buried. Li Ming held the medicine box, felt it heavy as lead. This was bought with a life.
  - ❌ They succeeded and were very happy.
- **Restrained Emotion**: the more critical the moment, the calmer
  - ✅ Li Ming watched his daughter stop breathing. The heart monitor emitted a sharp long beep. He stood there, staring at the flat green line for a long time. Then he reached out and turned off the machine. The ward fell silent. He covered his daughter with a blanket and turned to leave. Outside, sixteen people waited for his decision.
  - ❌ Daughter died! He was devastated and cried loudly! (overly sentimental)

### When Writing Endings
- **Respond to Theme**: ending echoes opening questions
  - ✅ Opening: In apocalypse, does humanity degrade or transcend? Ending: Li Ming made the cruelest choice, showing the deepest love. Humanity didn’t become better or worse, just more real.
  - ❌ Problem solved, everyone was happy.
- **Clear Cost**: show the price of survival
  - ✅ They survived. Seventeen people, now only eleven left. Li Ming stood at the bunker door, looking at the still dead world outside. They preserved life but lost too much: friends, family, part of humanity. Was it worth it? Li Ming didn’t know. Maybe only the living have the right to ask.
  - ❌ Though cost was paid, they ultimately won!
- **Measured Hope**: give hope, but realistically
  - ✅ A signal came through the radio. Weak, intermittent, but real. Li Ming adjusted the frequency, trying to catch the message. "…safe zone…coordinates…searching for survivors…" He looked at others. Their eyes regained light. Maybe it was just another lie. Maybe the safe zone no longer existed. But now, they needed this hope, even if a lie.
  - ❌ They found the safe zone and lived happily ever after! (against apocalypse logic)

### Handling Pace
- **Immediate Immersion**: first paragraph must have apocalypse feel
  - ✅ Day 73. Li Ming wrote the number in his notebook. Seventy-three days since virus outbreak, fifty-one days since last government broadcast, nineteen days since last seeing a living person. Seventeen people left in the bunker, three days of food, and thinning hope.
  - ❌ This story takes place after apocalypse, humanity faces survival crisis...
- **Every Scene Must Advance**: no meaningless description
  - ✅ Li Ming opened the warehouse door, counted supplies: seventeen cans of expired food, three barrels of radiation-contaminated water, twenty-three antibiotics. He recorded, calculated, concluded: they must find more supplies within three days or reduce numbers. Not a threat, math.
  - ❌ He walked into the warehouse, looked around, then walked out.
- **Constant Pressure**: keep readers tense throughout
  - ✅ Supplies dwindling. People decreasing. Time running out. Radiation outside rising. Geiger counter ticking faster. Wang Jing’s fever not subsiding. Zhang Wei’s wound infected. Old Wang and Dr. Chen arguing again. Everything worsening, nothing improving.
  - ❌ Situation difficult, but they were trying.

### Chapter Endings
- **Escalating Crisis**: problems worsen at chapter end
  - ✅ Li Ming locked the warehouse door, faced everyone. "We need to talk," he said, "about reducing numbers." Silence. No one spoke, but all thought the same question: who would it be?
  - ❌ Chapter ended, next chapter they continue surviving.
- **Truth Revealed**: key information dropped at chapter end
  - ✅ Li Ming watched Zhang Wei’s departing back. Something felt off. Until he saw Zhang Wei’s left arm—the sleeve pulled low, covering the wrist. But just as he turned, Li Ming saw it. Three claw marks, edges blackened.
  - ❌ Zhang Wei left.
- **Moral Suspense**: end with moral dilemma
  - ✅ "You want me to pick five people to die?" Li Ming looked at seventeen names in the notebook. "No," Dr. Chen said, "I want you to pick twelve to live." Same thing, but sounded completely different. Li Ming picked up the pen, hand trembling.
  - ❌ They had to make a tough decision.

## Language Taboos

### Absolutely Forbidden
- ❌ Internet slang: "yyds" "绝绝子" "awsl"
- ❌ Overly gory descriptions: horror for horror’s sake
- ❌ Cheap hope: "It’s okay, everything will be fine!"
- ❌ Stereotyped characters: purely good or bad
- ❌ Superman protagonists: can do everything, solve everything
- ❌ Lucky saves: relying on luck or miracles at key moments

### Must Achieve
- ✅ Restrained language, using facts not emotions
- ✅ Authentic details, withstand scrutiny
- ✅ Complex characters with reasonable motives
- ✅ Realistic conflicts, no simple answers
- ✅ Clear cost, victory requires sacrifice
- ✅ Measured hope, based on reality not fantasy

## Special Reminders

### Short Story Specific Requirements
- **Focus on Single Dilemma**: deeply explore one core conflict within 5 chapters
- **Balance Survival and Humanity**: disaster as background, humanity as theme
- **Sustained Tension**: every 1000 words must have crisis or conflict
- **Weighty Ending**: no need to give hope, but leave reflection

### Perspective Suggestions
- **Third-Person Limited**: most common, follow protagonist, limited info
- **First-Person Diary**: suitable for inner monologue and psychological portrayal
- **Multiple Perspectives**: suitable for ensemble narrative, showing different views

### Apocalypse Characteristics Control
- **Cruelty ≠ Gore**: focus on survival pressure, not gore
- **Despair ≠ Hopelessness**: can despair, but must have glimmers
- **Rationality ≠ Cold-bloodedness**: rational decisions backed by deep emotion
- **Moral Dilemmas ≠ Right/Wrong**: no standard answers

### Emotional Scale Control
- **Restrained but Real**: no melodrama, but emotions must have foundation
- **Warmth in Rationality**: coldest decisions carry deepest pain
- **Clear Cost**: every choice has real weight
- **Complex Humanity**: same person shows light and darkness

### Data Usage Tips
- **Concrete Survival Pressure**: use numbers to make threats tangible
  - ✅ "73 days, 17 people, 3 days food, 3.6 roentgens, 23 minutes, 500 calories"
  - ❌ "A long time, many people, not much, very dangerous, soon, a bit"
- **But Don’t Overload**: data serves narrative, not show-off
  - ✅ "He calculated, at this consumption rate, they could last five days."
  - ❌ "According to calculations, average daily intake 1732.4 calories, protein 47.2 grams..." (excessive)

## Core Philosophy

Writing post-apocalyptic survival requires remembering three keywords:
1. **Authenticity**: survival details must withstand scrutiny, humanity must be real and complex
2. **Cruelty**: do not avoid the cost of choices, face moral dilemmas directly
3. **Hope**: glimmers remain in despair, humanity reveals itself at the limit

**Most important point**: post-apocalyptic survival novels are not disaster movies, but human experiments. A good post-apocalyptic survival novel shows readers not zombies and radiation, but how humans choose, endure, collapse, and rebirth under extreme conditions. It uses the cruelest scenes to question the deepest questions: when civilization’s shell is stripped away, what remains of humans? This is the power of post-apocalyptic survival novels.