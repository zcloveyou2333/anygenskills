---
name: mori-outline-method
description: Methodology for creating outlines of post-apocalyptic survival short stories, including core synopsis extraction, lead design, plot structure planning, and character shaping guidance. Integrates Liu Cixin's cold rationality with the human depth of "The Walking Dead."
---

## Q1-Q3 Question Templates

### Q1: Core Idea
**Q1: Core idea and appeal of the story [Brief description]**  
Please describe your story idea in one or two sentences.

### Q2: Core Conflict
**Q2: Core conflict [Brief description]**  
Please describe the novel’s core contradiction or main conflict in one sentence  
(e.g., survivors’ struggle for survival and rebuilding after a virus outbreak, humanity’s last struggle under climate disaster, resource competition in a post-nuclear wasteland, humanity’s desperate counterattack during alien invasion, etc.)

### Q3: Story Tone
**Q3: Story tone [Choose one]**  
- Hardcore survival · desperate struggle (resource scarcity, survival skills, survival of the fittest)  
- Human nature interrogation · civilization rebuilding (light and dark of humanity under apocalypse, order reconstruction)  
- Wasteland adventure · exploring the unknown (ruin exploration, mutated creatures, perilous situations)  
- Scientific redemption · dawn of hope (scientist perspective, searching for cure, saving humanity)  
- Or please briefly describe your story tone

## Chapter File Naming Rules  
Filename format: `{STORY_NAME}-{NN}.md`  
Example: `Last_Sanctuary-01.md`, `Last_Sanctuary-02.md`

---

# Post-Apocalyptic Survival Outline Creation Methodology

## Overall Orientation

Post-apocalyptic survival novels emphasize "**humanity and civilization in desperate situations**," centering on survival dilemmas, moral choices, and hopeful reconstruction.

**Core Principles**:  
- Focus on ultimate dilemmas (resource scarcity, environmental degradation, order collapse, human nature tests)  
- Pursue "realistic shock": brutal but not hopeless, realistic but hopeful  
- Balance survival and humanity, but **do not stray from realistic logic and survival rationality**  
- Drive plot through crisis, choices, and sacrifice, **maintain a cold and objective narrative tone**  
- Keep Liu Cixin’s rational restraint: no sentimentality, no glamorization, face the cruelty directly  
- Incorporate "The Walking Dead" human depth: moral dilemmas, group dynamics, leadership struggles

---

## Overall Creation Formula
```
Post-apocalyptic short story = Disaster setting + Survival crisis + Human conflict + Hope/warning ending
```

---

## 1. Core Synopsis Writing

### Formula
```
Core synopsis = Apocalypse background/disaster type + Survival dilemma + Core choice
```

### Writing Points
| Element | Requirement | Correct Example | Incorrect Example |
|---------|-------------|-----------------|-------------------|
| **Apocalypse background** | Specific + credible | "Day 73 after virus outbreak, global population less than 1%" | "The end of the world" |
| **Survival dilemma** | Involves difficult choices | "Shelter only has three days of food, must choose between starving or risking outside" | "Encountered difficulties" |
| **Core choice** | Touches moral boundaries | "Explores choosing to save one at the cost of sacrificing ten" | "Survived in the end" |

### Excellent Examples
- "On the 127th day of nuclear winter, bunker oxygen lasts only 48 hours. Li Ming must choose between abandoning half the survivors or everyone suffocating. His ten-year-old daughter is among the half."  
- "The virus leaves infected conscious but without humanity. When his wife is bitten, she begs him to kill her before mutation. But they just discovered she is pregnant."  
- "Outside the radiation zone, the city still has abundant supplies, but every trip shortens life. Dr. Chen faces a choice: survive alone with remaining medicine or risk death retrieving vaccines for the shelter’s children."

---

## 2. Lead Writing

### Formula
```
Lead = Apocalypse world opening + Survival status presentation + Core crisis hook
```

### Writing Points
| Element | Function | Approach |
|---------|----------|----------|
| **First sentence** | Establish apocalypse atmosphere | Directly show: ruins scene/death data/survival dilemma |
| **Middle part** | Explain current status | Use concrete details to quickly locate: days passed, population, resources |
| **Last sentence** | Create survival suspense | Throw out fatal crisis/time limit/irreconcilable conflict |

### Integration of Apocalypse Themes

The lead should touch the core themes of post-apocalyptic survival:

| Topic Type | Specific Direction |
|------------|--------------------|
| **Survival dilemma** | Food/water/oxygen/medicine depletion, environmental deterioration, shelter breach |
| **Human choices** | Sacrifice the weak to save the many, fairness and efficiency of resource allocation, trust and betrayal |
| **Civilization rebuilding** | New rules after old order collapse, power vacuum and violence, moral bottom lines protection |
| **Cost of hope** | Sacrifice present for future, sacrifice self for others, ideal vs reality |

**Goal**: Make readers empathize with "What would I do?" (immersive desperation)

### Example Comparison
| Type | Content |
|------|---------|
| ✅ **Correct** | "On day 73 after the virus outbreak, fewer than seventy million humans remain alive on Earth—less than one percent of pre-plague population. Li Ming sits before the bunker’s iron door, counting the remaining supplies: seventeen cans of expired food, three barrels of radiation-contaminated water, and a bottle with twenty-three antibiotics left. Outside, the Geiger counter ticks; radiation remains deadly. He looks at the calendar on the wall and sighs. Food lasts only three days. After three days, he must choose: starve in this safe bunker or risk a 99% death rate searching for supplies. Worse, he is not alone—seventeen survivors remain, six of whom are children. Those children look at him with hungry eyes." |
| ❌ **Incorrect** | "The world ended, humanity faces survival crisis, the protagonist must find a way to live..." |

---

## 3. Plot Structure Design (Qi-Cheng-Zhuan-He)

### 【Qi】Chapter 1: Desperation Emerges (2000-3000 words)

#### Writing Focus
```
Qi = Apocalypse world display + Protagonist introduction + Survival status + Crisis trigger
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Apocalypse world** | Establish wasteland atmosphere within first 500 words | Show ruins/bodies/radiation/virus signs in first paragraph<br>Use details not exposition: show how disaster changed world |
| **Protagonist introduction** | Quickly introduce protagonist | Introduce protagonist within 300 words<br>Show survival actions: scavenging, avoiding danger, caring for others |
| **Survival status** | Show resources and team | How many people/what supplies/how long can last<br>Use data to enhance realism: 73 days, 17 people, 3 days food |
| **Crisis trigger** | Drive story forward | Supplies running out/threat approaching/someone sick/shelter exposed |

#### Apocalypse Scene Construction Points
- **Environmental description**: concrete depiction of ruins, radiation, pollution  
- **Survival details**: inventory, ration system, survival routines  
- **Threat sources**: infected, mutated creatures, hostile survivors, harsh environment  
- **Group dynamics**: who leads, how decisions are made, presence of conflicts

#### Taboos
- ❌ Large explanations of disaster origin (leave for later reveal)  
- ❌ Protagonist as perfect omnipotent hero  
- ❌ Lack of urgency and realism in dilemmas  
- ❌ Excessive gore/horror (focus on survival pressure, not gore)

---

### 【Cheng】Chapters 2-3: Survival and Division (2000-3000 words each)

#### Chapter 2 Focus
```
Chapter 2 = Resource exploration + External threats + Internal divisions + Small sacrifices
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Resource exploration** | Protagonist takes action | Go out scavenging/adventure into danger zones/trade with others |
| **External threats** | Encounter dangers | Infected/mutated creatures/hostile factions/environmental disasters |
| **Internal divisions** | Group cracks appear | Unequal resource distribution/trust crisis/leadership doubts |
| **Small sacrifices** | First losses | Someone injured/supplies lost/plan fails |

#### Chapter 3 Focus
```
Chapter 3 = Major discovery + Moral dilemma + Team split + Deadly choice
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Major discovery** | Find hope or truth | Safe zone rumors/supply warehouse/rescue signal/disaster truth |
| **Moral dilemma** | No perfect answers | Save one vs save many/follow rules vs survive/trust vs betrayal |
| **Team split** | Conflicting stances | Optimists vs pessimists/idealists vs realists |
| **Deadly choice** | Build up climax | Must sacrifice/must choose/must betray beliefs |

---

### 【Zhuan】Chapter 4: Darkest Moment (2000-3000 words)

#### Writing Focus
```
Zhuan = Greatest crisis + Difficult choice + Major sacrifice + Human nature test
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Greatest crisis** | Life-or-death moment | Shelter lost/deadly infection/betrayal/environmental mutation |
| **Difficult choice** | Protagonist must decide | Irreconcilable conflict/no third way/time pressure |
| **Major sacrifice** | Someone pays price | Voluntary sacrifice/forced abandonment/burden of guilt |
| **Human nature test** | Reveal true humanity | Selfishness and selflessness under crisis/courage and cowardice/steadfastness and collapse |

#### Liu Cixin Techniques
- **Rational cruelty**: do not avoid cost of choices, use data and logic  
- **Cold narration**: no sentimentality, let facts shock  
- **Macro perspective**: individual plight reflects civilization fate

#### Taboos
- ❌ Solve problems by miracles or luck  
- ❌ Protagonist suddenly gains superpowers  
- ❌ Avoid the true cruelty of choices  
- ❌ Stereotype villains (everyone has survival reasons)

---

### 【He】Chapter 5: Embers and Hope (2000-3000 words)

#### Writing Focus
```
He = Consequence bearing + New balance + Theme sublimation + Hope or warning
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Consequence bearing** | Show results of choices | Survival cost/irretrievable losses/psychological trauma |
| **New balance** | World enters new state | Survivors’ new life/new order/new goals |
| **Theme sublimation** | Respond to core themes | Use ending to answer: humanity/civilization/hope |
| **Hope or warning** | Leave space for reflection | Flicker of hope/heavy warning |

#### Apocalypse Ending Types
| Type | Characteristics | Suitable Scenes |
|------|-----------------|-----------------|
| **Bitter hope** | Huge cost but reason to continue | Explore sacrifice and rebirth |
| **Harsh reality** | Survived but lost too much, question worth | Explore cost and humanity |
| **Warning reflection** | Show consequences of continuing | Cautionary tale, provoke thought |
| **Faint continuation** | A glimmer of hope in despair | Human brilliance, civilization’s spark |
| **Shocking subversion** | Last sentence overturns whole story | Story with twist design |

#### Taboos
- ❌ Forced happy ending, against apocalypse logic  
- ❌ Cheap hope without cost support  
- ❌ Preachy summary  
- ❌ Leave major plot holes

---

## 4. Character Shaping Methods

### Protagonist Design

| Dimension | Requirement | Correct Example | Incorrect Example |
|-----------|-------------|-----------------|-------------------|
| **Survival identity** | Clear + credible | "Retired military medic" "Engineer" "Ex-police officer" | "Ordinary person" |
| **Core traits** | Conflict between rationality and emotion | "Rational decision maker but soft on children" "Cold survivor but with moral bottom line" | "Very brave" |
| **Personality tags** | 2-3 distinct traits | "Decisive and calm but burdened with guilt" "Protective but understands big picture" | "Good person" |
| **Survival skills** | Related to plot | "Knows first aid and wound care" "Skilled in mechanical repair" "Accurate shooter" | "Knows everything" |

### Personality Specificity
```
✅ "Li Ming is a surgeon who worked at a top-tier hospital before the disaster. He is used to thinking in data: infection rate, survival rate, resource consumption rate. When he announced the shelter must reduce numbers, his voice was chillingly calm. No one knew he vomited in the bathroom for half an hour."  
❌ "He is a rational leader who made a tough decision."
```

### Protagonist Archetypes (Common in Apocalypse)

| Type | Features | Personality | Suitable Themes |
|-------|----------|-------------|-----------------|
| **Leader** | Bears decision responsibility | Decisive, burdened, lonely | Power and responsibility, sacrifice and choice |
| **Doctor/Scientist** | Professional skills key | Rational, focused, moral struggle | Scientific redemption, ethical dilemmas |
| **Soldier/Police** | Combat experience | Disciplined, protective, adaptable | Order rebuilding, violence boundaries |
| **Ordinary person** | Forced to grow | Fearful, adaptive, self-discovery | Individual transformation in disaster |
| **Parent** | Fights for children | Hope in despair, at any cost | Love and sacrifice, future and legacy |

### Supporting Character Design (Apocalypse Features)

| Type | Role | Notes |
|-------|------|-------|
| **Idealist** | Represents moral steadfastness | Not naive, but chosen steadfastness |
| **Realist** | Represents survival priority | Not selfish, different value judgment |
| **Weak/Burden** | Moral test object | Elderly/children/sick, make choices hard |
| **Threat** | External or internal enemy | Has reasonable motives, not pure villain |

### Relationship Network Design (Apocalypse Specific)

| Element | Requirement |
|---------|-------------|
| **Fragile trust** | Resource scarcity causes trust crises but emotional bonds remain |
| **Complementary roles** | Different skills depend on each other, lone wolves don’t survive |
| **Conflict of interests** | Cooperation with disputes from different survival strategies |
| **Dynamic relations** | Allies may betray, enemies may cooperate, relations shift under crisis |

---

## 5. Apocalypse Elements Design

### Worldview Construction Formula
```
Apocalypse world = Disaster type + Environmental impact + Survival rules
```

### Common Disaster Types

| Type | Features | Examples |
|-------|----------|----------|
| **Infectious disease** | Virus/bacteria spread, infection and quarantine | Zombie virus, deadly plague, mutated disease |
| **Nuclear/radiation** | Radiation pollution, scarce resources | Post-nuclear war, radiation leak, nuclear winter |
| **Climate disaster** | Extreme weather, environmental degradation | Global freeze, prolonged drought, extreme heat |
| **Alien invasion** | Unknown threat, technological overwhelm | Alien creatures, alien machines, dimensional strike |
| **AI runaway** | Tech backlash, human status | Machine rule, network collapse, automation out of control |
| **Social collapse** | Order collapse, rampant violence | Resource exhaustion, government fall, warlord chaos |

### Environmental Setting Principles

| Element | Requirement |
|---------|-------------|
| **Limited** | Limited resources, time, safe zones |
| **Threatening** | Environment itself is deadly: radiation/virus/temperature/pollution |
| **Regular** | Disaster has rules, not completely random |
| **Detailed** | Specific data: radiation level/survival rate/temperature/food calories |

---

## 6. Conflict Design

### Conflict Formula
```
Apocalypse conflict = External survival threats + Internal human conflicts + Moral dilemmas
```

### External Conflicts (Mainline)

| Conflict Type | Specific Methods | Examples |
|---------------|------------------|----------|
| **Resource scarcity** | Food/water/medicine/energy depletion | Ration system, scavenging teams, trade system |
| **Environmental threats** | Radiation/virus/extreme weather/pollution | Protective gear, safe zones, quarantine system |
| **Hostile factions** | Other survivor groups/warlords/raiders | Territory disputes, resource robbery, slavery |
| **Mutation threats** | Infected/mutated creatures/unknown lifeforms | Cleanup operations, defenses, reconnaissance |

### Internal Conflicts (Subplot)

| Conflict Type | Design Methods |
|---------------|----------------|
| **Leadership power** | Struggle for decision rights, democracy vs dictatorship, ability vs popularity |
| **Resource allocation** | Fairness vs efficiency, weak vs strong, present vs future |
| **Moral standards** | Follow rules or survive, sacrifice few or abandon many |
| **Psychological breakdown** | PTSD, despair, madness, disillusionment with humanity |

### Conflict Progression Levels
```
Level 1: Physical survival (starvation/disease/radiation death)
    ↓
Level 2: Group conflict (distribution/betrayal/power)
    ↓
Level 3: Moral choices (sacrifice/bottom line/humanity)
```

---

## 7. Foreshadowing Management

### Foreshadowing Carriers (Apocalypse Specific)

| Carrier Type | Examples |
|--------------|----------|
| **Abnormal signs** | Infection symptoms/radiation anomalies/environment changes |
| **Hidden supplies** | Secret warehouses/unpublished reserves/concealed resources |
| **Character secrets** | Concealed bite/past identity/special immunity |
| **Environmental clues** | Radio signals/other survivor traces/government leftovers |
| **Disaster truth** | Origin mystery/possible cure/safe zone truth |

### Foreshadowing Setting Principles

| Stage | Method |
|-------|--------|
| **Planting** | Naturally integrate into daily life, no emphasis<br>Example: "Li Ming noticed Zhang Wei always avoided eye contact lately, and his left arm sleeve was always pulled down low."<br>Example: "There was a locked iron cabinet in the warehouse corner; Old Wang said it was personal belongings and forbade touching." |
| **Payoff** | Reveal significance at key moments<br>Example: Zhang Wei was actually bitten and hiding it until outbreak<br>Example: The cabinet contained enough canned food for the whole team for a month |

### Common Foreshadowing Designs

**Infection Foreshadowing**:  
```
Planting: Someone behaves abnormally, fever, frequent absences  
Payoff: Infection has spread, quarantine failed  
```

**Betrayal Foreshadowing**:  
```
Planting: Someone secretly contacts external forces, hides supplies  
Payoff: Leads enemy ambush at critical moment  
```

**Hope Foreshadowing**:  
```
Planting: Rumored safe zone, possible immune person, scientist’s research  
Payoff: Truth revealed, real hope or trap  
```

---

## 8. Chapter Style Design (Apocalypse Specific)

### Chapter Title Style

Apocalypse titles should be **concise, oppressive, and tense**:

| Element | Method |
|---------|--------|
| **Title style** | Concise and powerful, implying desperation<br>Example: "Chapter 1 Day 73"<br>Example: "Chapter 3 The Last Ration"<br>Example: "Chapter 5 Survive" |
| **Chapter opening** | Directly enter dilemma, build pressure<br>Example: "Li Ming finished counting the last box of canned food, wrote the number 17 in his notebook."<br>Example: "The radiation alarm sounded for the third time. This time, no one turned it off." |
| **Chapter ending** | Crisis escalation or difficult choice<br>Example: "Zhang Wei took off his gloves. Three clear scratch marks were on his arm."<br>Example: "Li Ming looked into seventeen pairs of eyes and slowly said: 'We must reduce the numbers.'" |

### Dialogue Design (Apocalypse Core)

Apocalypse dialogues should be **concise, calm, and tense**:

**Good dialogue example**:
```
"How much food is left?" Li Ming asked.  
"Seventeen cans." Zhang Wei closed the warehouse door.  
Silence.  
"Seventeen people. Seventeen cans." Li Ming repeated the numbers.  
"I know what you’re thinking, Old Li." Zhang Wei lit a cigarette, "But don’t expect me to make that decision."  
"Then who will?"  
"You’re the leader."  
Li Ming turned to look at the ruins outside the window. "I was just a doctor, a healer."  
"That was before." Zhang Wei handed him the cigarette. "Now you’re the leader. Leaders do what leaders must."  
```

**Poor dialogue example**:
```
"We don’t have enough food."  
"What should we do?"  
"I don’t know."  
"Then figure it out."  
```

### Psychological Description (Apocalypse Feature)

Should be **restrained but profound**, showing real psychology under desperation:

**Good psychological description**:
```
Li Ming wrote down seventeen names in his notebook. Six children, four women, seven men. He began marking: who had skills, who could fight, who was a burden. When his pen stopped at "Wang Jing, 8 years old, no skills," his hand started shaking. Wang Jing was his daughter’s best friend. Before the disaster, the two girls often played hopscotch in his yard. He remembered Wang Jing’s smile, her voice calling him "Uncle Li." He harshly crossed out the line, then wrote it back. Rationality told him children are the future. But now, when even today is not guaranteed, what future is there?  
```

**Poor psychological description**:
```
He was conflicted and didn’t know what to do. The decision was too hard.  
```

### Rhythm Control (Apocalypse Core)

**Rhythm formula**:
```
500 words = 1 crisis presentation OR 1 resource consumption OR 1 moral conflict
```

Each scene must have: clear threat + concrete cost + driving force

---

## 9. Survival Progress (Apocalypse Exclusive)

### Five-stage Survival Method
```
Desperation emergence → Survival exploration → Internal division → Darkest moment → Ember rebirth
```

| Stage | Word Count Ratio | Key Events | Survival Status |
|-------|------------------|------------|-----------------|
| **Desperation emergence** | 10-15% | Show apocalypse status and resources | Temporarily safe/resources dwindling |
| **Survival exploration** | 15-20% | Go out scavenging, encounter threats | Small losses/internal stability |
| **Internal division** | 25-30% | Divisions arise, trust breaks | Resources exhausted/team torn apart |
| **Darkest moment** | 20-25% | Major crisis, difficult choices | Life or death/humanity tested |
| **Ember rebirth** | 15-20% | Bear consequences, seek hope | Pay price/faint light emerges |

### Survival Performance Techniques

**Resource management**:
```
Start: Inventory resources, set ration, seems sustainable  
Mid: Consumption accelerates, must risk outside  
End: Almost depleted, must make hard choices  
```

**Psychological changes**:
```
Start: Fearful but hopeful, believe rescue will come  
Mid: Despair spreads, question meaning of persistence  
End: Either collapse completely or find new support  
```

**Team dynamics**:
```
Start: United, face together  
Mid: Divisions appear, disputes over resources  
End: Tear apart or reunite, relationships redefined  
```

---

## 10. Common Apocalypse Patterns

### Pattern A: Shelter Dilemma  
**Structure**:  
- Qi: Survivors in shelter, limited resources  
- Cheng: Go out scavenging, face threats, lose personnel  
- Zhuan: Internal division, must reduce numbers or abandon shelter  
- He: Make choice, bear cost, seek new hope

### Pattern B: Apocalypse Journey  
**Structure**:  
- Qi: Start journey for a goal (find safe zone/relatives/cure)  
- Cheng: Encounter various threats and dilemmas along the way  
- Zhuan: Discover goal may be a lie or no longer exists  
- He: Redefine the meaning of the journey

### Pattern C: Civilization Rebuilding  
**Structure**:  
- Qi: Small community tries to rebuild order  
- Cheng: Conflict between order and violence, ideal vs reality  
- Zhuan: External threat or internal rebellion tests new order  
- He: Order maintained or collapses, reflect on civilization essence

### Pattern D: Last Hope  
**Structure**:  
- Qi: Discover possible hope to save humanity (cure/safe zone/immune)  
- Cheng: Risk everything for hope, pay huge sacrifice  
- Zhuan: Truth of hope revealed, possibly cruel  
- He: Even if hope is slim, choose to believe or give up

---

**[Special Reminder]**  
Keys to success for post-apocalyptic survival short stories:  
1. First 500 words must establish apocalypse atmosphere and resource pressure  
2. Every 1000 words must have crisis progression or moral conflict  
3. Dialogue must be concise and realistic, showing humanity under survival pressure  
4. Details must be solid and credible, use data to enhance realism  
5. Ending must carry weight, no need to give hope but must provoke thought  
6. Do not avoid cruelty, but avoid cruelty for cruelty’s sake  
7. Focus on humanity, disaster is background, people are core