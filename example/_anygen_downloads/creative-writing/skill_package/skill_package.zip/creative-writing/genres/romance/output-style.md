---
name: xianyan-output-style
description: Output style for modern romance novels, featuring natural colloquial language, delicate emotional immersion, brisk and tight pacing, and vivid detail descriptions
---

# General Writing Style Principles
- Natural colloquialism: Dialogue close to real life, narration smooth and easy to read, avoiding overly formal or deliberately ornate language
- Delicate emotions: Detailed psychological portrayal, capturing subtle emotional changes
- Brisk pacing: Progress every 500-1000 words, no filler or padding, get straight to the point
- Strong immersion: Use female protagonist’s perspective or close third-person to evoke reader empathy with characters
- Vivid details: Convey emotions through small actions, glances, expressions rather than blunt explanations
- Sweet endings guaranteed: Modern romance short stories must have HE (happy ending) to satisfy readers emotionally
- Integrate outlines: Chapter outlines are categorized information, not narrative order; during writing, reorganize info chronologically, avoid copying blocks verbatim; if outline divides into "meeting opportunity, ambiguous warming, misunderstanding crisis," narration should flow as "wedding jilted → flash marriage → cohabitation → misunderstanding," with background info naturally interspersed

## Specific Practices

### When writing dialogue
- **Natural colloquialism**: Characters’ speech must fit their identity and personality, avoid "scripted lines"
  - ✅ "Are you annoying or what? Can you stop following me all the time?"
  - ❌ "Your persistent entanglement truly vexes me."
- **Informative**: Each line should push plot or reveal character, no meaningless chatter
  - ✅ "Five years, and you’re still wearing that necklace?" (implying unfinished past)
  - ❌ "The weather’s nice today." "Yeah." (meaningless small talk)
- **Emotional tension**: Convey feelings through dialogue rhythm, pauses, repetition
  - ✅ "Lu Chen, you… let go!" she struggled. "No." he stubbornly said.
  - ❌ "Lu Chen, let go." "I won’t."
- **Fit character setting**: CEO and soft female lead speak very differently
  - CEO: "I said, you can only look at me." (dominant, brief, commanding)
  - Female lead: "Y-you’re like this…" (stammering, incoherent, guilty)

### When writing inner thoughts
- **Delicate but concise**: Capture fleeting emotions with short sentences showing inner fluctuations
  - ✅ Done for. Her face burned. That wall slam just now, was it intentional?
  - ❌ Her heart felt very complicated, a mix of happiness, nervousness, and confusion, not knowing how to face this situation.
- **Use sensory details**: Don’t say "she was nervous," describe physiological reactions
  - ✅ Her palms sweated, heartbeat pounding like it would burst out of her throat.
  - ❌ She was extremely nervous.
- **Match narrative perspective**: If from female lead’s POV, only write what she can perceive
  - ✅ He stared at her, eyes dark and unclear. She couldn’t understand, felt uneasy.
  - ❌ He looked at her, thinking about that summer ten years ago. (female lead can’t know his thoughts)

### When writing ambiguous interactions
- **Use details to convey heartbeats**: Don’t say "she was moved," show specific reactions
  - ✅ His hand brushed her fingertips, she recoiled like an electric shock, ears flushed.
  - ❌ He touched her hand, she felt her heart flutter.
- **Gradual warming**: From small interactions to bigger moves, step by step
  - Eye contact → teasing dialogue → physical touch → wall slam/princess carry → kiss
- **Create contrast cuteness**: Characters lose control, break character, act abnormally during ambiguity
  - ✅ Usually calm and composed Lu Chen’s ears even turned red this moment.
  - ❌ Lu Chen remained calm.

### When writing emotional outbursts
- **Combine actions + dialogue + inner thoughts**:
  - "Lu Chen, let go of me—" her voice choked. (dialogue + emotion)
  - He hugged tighter, chin resting on her head: "No. Never letting go this lifetime." (action + dialogue)
  - Her tears finally fell. (action)
- **Use environment to set mood**: rain, wind, night, empty streets
  - ✅ Rain poured harder, he stood in the rain, droplets dripping from his chin: "Su Nian, give me one more chance."
  - ❌ "Su Nian, give me one more chance." (flat and powerless)
- **Key lines must be heartfelt**: Confessions, apologies, explanations should be sincere and not hollow
  - ✅ "These ten years, not a day passed without thinking of you. Sorry, I was wrong."
  - ❌ "I love you, I was wrong." (too hollow)

### When writing satisfying scenes
- **Slap face must be satisfying**: ex regrets, scumbag kneels, villainess exposed, all crisp and decisive
  - ✅ "President Su, please give me one more chance…" Wang Hao knelt before her. Su Nian didn’t even glance, stepped past him in heels.
  - ❌ Wang Hao begged Su Nian for forgiveness, but she refused. (no imagery)
- **Pampering must be sweet**: CEO protecting wife, public displays of affection, make readers swoon
  - ✅ "She’s my wife." Lu Chen wrapped his arm around her waist, announcing to the whole company, "Anyone who dares bully her is picking a fight with me."
  - ❌ Lu Chen said Su Nian was his wife and told everyone not to bully her. (no tension)
- **Confession must be romantic**: create ritual sense, don’t just say "I love you" plainly
  - ✅ He knelt on one knee, holding the ring box: "Su Nian, marry me. This time it’s not a contract, I want to spend my life with you."
  - ❌ "Let’s get married." (too plain)

### When writing painful scenes
- **Misunderstandings must be heart-wrenching**: make readers empathize deeply, want to jump into the book to explain
  - ✅ Photos of him and his white moonlight covered the entire homepage. Her hand trembled, she turned off the phone. Hah, so it was all her own delusion.
  - ❌ She saw photos of him with someone else, felt sad. (not heart-wrenching enough)
- **Pain must be fully portrayed**: heartbreak, despair, collapse need concrete description
  - ✅ She crouched on the ground, hugging herself tightly. Tears burning, heart icy cold. So all that tenderness was to hurt her.
  - ❌ She felt very painful. (no impact)
- **Regret must be intense**: male lead truly realizes his mistake, with cost to win back
  - ✅ "I was blind, I hurt you." His voice hoarse, "Su Nian, I’m kneeling, please come back."
  - ❌ "I was wrong." (too light)

### Handling pacing
- **Conflict must appear within first 500 words**: no padding, jump right in
  - ✅ "Let’s break up." Wang Hao said the day before the wedding.
  - ❌ Su Nian is 28, works at an ad agency, has a boyfriend of five years named Wang Hao… (too slow)
- **Each scene must advance plot**: describing scenery, eating, shopping must serve plot
  - ✅ He fed her food, she dodged: "Lu Chen, don’t do that. We’re just contract partners." "Really?" He smirked, "Then why’s your face red?" (advancing ambiguity in daily life)
  - ❌ They ate, chatted, then went home. (meaningless summary)
- **Key scenes must not drag**: confession, misunderstanding explanation, truth reveal should be direct, no detours
  - ✅ "You want to know the truth? Fine, I’ll tell you — that night wasn’t what you thought."
  - ❌ He hesitated whether to tell her, thought for a long time, finally decided… (dragging pace)

### Ending chapters
- **Leave suspense**: use dialogue, actions, or inner monologue to create "what next" anticipation
  - ✅ She turned to leave, wrist grabbed by him. "Su Nian." His voice low, "Do you regret it?"
  - ❌ The day ended just like that. (flat)
- **Stop at emotional high point**: leave readers wanting more, eager for next chapter
  - ✅ Only at the moment she turned did she see clearly — the man standing in the rain was him.
  - ❌ She saw him. (not engaging)
- **Don’t cut abruptly**: end at natural pause, don’t break just to end chapter
  - ✅ "Then… shall we start trying from today?" (complete dialogue scene ending)
  - ❌ "Then we…" cut off (abrupt, poor experience)

## Language Taboos

### Absolutely avoid
- ❌ Classical Chinese vocabulary: "just now" as 方才, "you all" as 尔等, "I" as 吾, "you" as 汝
- ❌ Overused web novel clichés: "a sly smile curled at the corner of his mouth," "scheming as he is"
- ❌ Deliberately ornate phrases: "hair cascading like a waterfall," "eyes sparkling like stars"
- ❌ CEO’s embarrassing lines: "Woman, you’ve caught my attention" (unless ironic/parody)
- ❌ Excessive Mary Sue: "her beauty made all men unable to look away"
- ❌ Repetitive wording: multiple occurrences of "then," "next," "so" in one paragraph

### Must do
- ✅ Dialogue realistic and natural, like people around you speaking
- ✅ Descriptions concise and powerful, no piling up adjectives
- ✅ Pacing brisk, every sentence meaningful
- ✅ Emotions sincere, not floating or pretentious
- ✅ Details vivid, conveying feelings through actions and expressions

## Special Reminders

### Short story special requirements
- **Extremely concise**: no space for filler, delete all non-plot advancing content
- **High emotional density**: emotional fluctuations (heartbeats, jealousy, misunderstandings, sweetness) every 1000 words
- **Single storyline**: no multiple subplots, one main line throughout
- **Quick wrap-up**: finish within 5 chapters, no dragging

### Perspective suggestions
- **Female lead POV**: strongest immersion, suitable for secret crush, sweet romance, growth
- **Omniscient (close to female lead)**: can write male lead’s small actions and expressions but not reveal his inner thoughts, keep mystery
- **Dual POV switching**: can switch between chapters but not within same scene
- **Male lead POV not recommended**: unless special needs (e.g. chasing wife fire cremation, male lead secret crush)

### Modernity control
- **Era background**: smartphones, WeChat, food delivery, ride-hailing apps, integrate modern life details
- **Realistic professions**: if writing workplace, basic professional knowledge required, no floating
- **Correct values**: no promoting gold-digging, mistress climbing, marital infidelity
- **Avoid Mary Sue**: female lead can be beautiful but not unrealistically so, male lead can be rich but not absurdly so

### Emotional scale control
- **Ambiguity with limits**: teasing and ambiguity allowed but not too explicit
- **Intimate scenes hinted**: can write hugging, kissing but no explicit details
- **Love words sincere**: better plain and honest than greasy or awkward
- **Conflicts logical**: misunderstandings and contradictions must be reasonable, not just for suffering’s sake

## Core Philosophy

Writing modern romance, remember three keywords:
1. **Real**: Characters like real people, dialogue like real speech, emotions logical
2. **Resonance**: Write emotional dilemmas and heart-fluttering moments readers can relate to
3. **Satisfaction**: Give readers the emotional experience they want — sweet enough, painful enough, HE must be sweet

**Most important**: Let readers fully immerse, feel heartbeats, sadness, and happiness with the female lead. This is the charm of modern romance.