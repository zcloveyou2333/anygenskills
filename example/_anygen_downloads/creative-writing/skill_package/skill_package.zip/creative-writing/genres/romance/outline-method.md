---
name: xianyan-outline-method
description: Methodology for creating outlines of modern romance short stories, including core synopsis extraction, lead design, plot structure planning, and character development guidance
---

## Q1-Q3 Question Templates

### Q1: Core Idea
**Q1: Core idea and appeal of the story [Brief description]**  
Please describe your story idea in one or two sentences.

### Q2: Core Conflict
**Q2: Core conflict [Brief description]**  
Please describe the novel’s core contradiction or main conflict in one sentence  
(e.g., contract marriage turns real, ex returns for reconciliation, long-time crush finally confessed, misunderstanding leads to painful pursuit, etc.)

### Q3: Story Tone
**Q3: Story tone [Choose one]**  
- Sweet and pampering, no suffering · Light and healing (high sweetness, no suffering throughout, HE ending)  
- Suffering first then sweet · Pursuit and regret (early heartbreak, later sweetness, HE ending)  
- Ambiguous tug-of-war · Love-hate relationship (mutual teasing and flirting, mix of humor and sweetness)  
- Broken mirror mended · Second chance at love (old love rekindled, misunderstandings resolved, HE ending)  
- Or please briefly describe your story tone

## Chapter File Naming Rules  
Filename format: `{STORY_NAME}-{NN}.md`  
Example: `CEO's Little Wife-01.md`, `CEO's Little Wife-02.md`

---

# Methodology for Creating Modern Romance Outlines

## Overall Orientation

Modern romance novels emphasize "**emotional resonance and immersion**," focusing on emotional dilemmas, identity gaps, and emotional choices grounded in real life.

**Core Principles**:  
- Focus on emotional themes (crush turns real, broken mirror mended, marriage before love, misunderstanding and suffering, etc.)  
- Pursue "emotional immersion": quick engagement, dense emotional peaks, highly intense emotions  
- Balance satisfying moments with realistic resonance, but **do not break modern life logic and human nature**  
- Use misunderstanding resolution, identity revelation, and confession to drive the plot, **reject abrupt twists**  
- Maintain colloquial style: natural dialogue, delicate psychology, brisk pacing

---

## Overall Creation Formula
```
Modern Romance Short Story = Emotional Hook + Fast Progression + Misunderstandings & Ambiguity + Concentrated Sweet or Painful Moments
```

---

## 1. Core Synopsis Writing

### Formula
```
Core Synopsis = Identity/Occupation + Emotional Dilemma + Core Conflict
```

### Writing Points
| Element | Requirement | Correct Example | Incorrect Example |
|---------|-------------|-----------------|-------------------|
| **Identity Tag** | Occupation + Situation + Relationship | "Fallen heiress flash marries stranger CEO" | "A girl" |
| **Emotional Dilemma** | Emotional relationship contradiction | "Thought it was a contract marriage but was a long-planned crush" | "Emotional entanglement" |
| **Core Conflict** | Emotional and realistic dilemma | "Fell in love with the enemy she should hate" | "Facing a choice" |

### Excellent Examples
- "On the day her scumbag fiancé broke off the engagement, she flash married his nemesis—the legendary cold and ruthless Gu Corporation CEO. She thought it was just a mutually beneficial contract marriage, but little did she know he had secretly loved her for ten years."  
- "After a car accident caused amnesia, she forgot all the evil deeds of her ex-husband. The ex pursued her again as a 'new boyfriend,' and she fell in love once more, unaware the truth was about to be revealed."  
- "Five years ago she fled while pregnant; five years later she returned with her adorable baby and met the child's biological father. The domineering CEO blocked her path: 'Woman, you stole my seed and still want to run?'"

---

## 2. Lead Writing

### Formula
```
Lead = Strong conflict opening + Identity/relationship setup + Emotional suspense hook
```

### Writing Points
| Element | Purpose | Method |
|---------|---------|--------|
| **First sentence** | Directly throw conflict | Write the key event directly: dumped/flash marriage/reunion/car accident/trapped |
| **Middle part** | Explain character relationships | Quickly position using occupation, identity, past relationship |
| **Last sentence** | Create emotional suspense | He doesn’t know her feelings / She doesn’t know his identity / Misunderstanding about to be revealed |

### Incorporating Emotional Themes

The lead should touch the core contradiction of emotional conflict:

| Theme Type | Specific Direction |
|------------|--------------------|
| **Crush turns real** | Long-time crush, school crush, one-sided to mutual, "he finally notices me" |
| **Broken mirror mended** | Divorce then remarriage, breakup then reunion, misunderstanding resolved, pursuit and regret |
| **Marriage before love** | Flash marriage, contract marriage, business marriage, political alliance turning to true love |
| **Misunderstanding and suffering** | Identity misunderstanding, white moonlight substitute, betrayal misunderstanding, revenge turning to love |

**Goal**: Make readers anticipate "When will they get together?" (emotional immersion)

### Example Comparison
| Type | Content |
|------|---------|
| ✅ **Correct** | "Her boyfriend of five years cheated and broke off the engagement at the wedding. Su Nian broke down on the spot. Worse, the wedding livestream was watched by the whole internet, making her the laughingstock of the city. Just as she wanted to crawl into a hole, a cold man suddenly appeared: 'Marry me.' He was Lu Chen, the legendary Gu Corporation CEO known for avoiding women, and the business rival her ex feared most. She thought it was just a transaction, but he had waited ten years for this day." |
| ❌ **Incorrect** | "She went through some emotional ups and downs, then met a powerful man, and some stories happened between them..." |

---

## 3. Plot Structure Design (Qǐ Chéng Zhuǎn Hé 起承转合)

### 【Beginning】Chapter 1: Strong Conflict Opening (2000-3000 words)

#### Writing Focus
```
Beginning = Conflict event + Male and female lead meet/reunite + Emotional suspense + Fast progression
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Conflict event** | Throw strong conflict within first 500 words | First paragraph shows: dumped/trapped/car accident/forced marriage/reunion with enemy |
| **Meeting setup** | Leads meet quickly | Within 1000 words, leads must intersect<br>Meeting methods: flash marriage/reunion/rescue/misunderstanding/forced cooperation |
| **Emotional suspense** | Plant emotional hooks | Clues of crush/unfinished old love/contract terms/misunderstanding root |
| **Chapter-end hook** | Leave suspense with dialogue or action | "Do you regret it?" / "We divorce in three months" / "He looked at her with complex eyes" |

#### Taboos
- ❌ Long environmental descriptions  
- ❌ Starting with female lead waking up and daily routine  
- ❌ Too long buildup before leads meet

---

### 【Development】Chapters 2-3: Emotional Heating and Deepening Misunderstandings (2000-3000 words each)

#### Chapter 2 Focus
```
Chapter 2 = Daily interaction + Ambiguity heating up + Identity/past revealed + Small conflicts
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Daily interaction** | Create shared space | Cohabitation/colleagues/cooperation/forced proximity<br>Show personality contrasts and chemistry through daily interactions |
| **Ambiguity heating** | Physical contact, eye interaction | Wall pin/princess carry/rescue/jealousy/hero saving beauty<br>Use detail to convey heartbeat moments |
| **Identity reveal** | Gradually reveal background | Through dialogue or flashbacks:<br>His true identity / Her past / Their connection |
| **Small conflicts** | Create emotional waves | Ex appears / family opposition / work conflicts / misunderstandings deepen |

#### Chapter 3 Focus
```
Chapter 3 = Emotional deepening + Misunderstanding or crisis + Crush/heartbeat confession + Key turning point
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Emotional deepening** | Intensify psychological description | Begin to realize the other’s importance<br>Inner struggle: should I fall in love? Can I love? |
| **Misunderstanding crisis** | Conflict intensifies | Discover "truth" but misunderstand it<br>White moonlight appears / identity exposed / forced separation |
| **Heartbeat confession** | One side reveals feelings | Unintentional confession / jealousy outburst / standing up for the other<br>Can be one-sided first love |
| **Key turning point** | Prepare for climax | Major misunderstanding forms / forced separation / pre-conflict tension |

---

### 【Turning Point】Chapter 4: Conflict Explosion and Truth Revelation (2000-3000 words)

#### Writing Focus
```
Turning Point = Conflict explosion + Emotional rupture + Truth revealed + Regret and remorse
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Conflict explosion** | Conflict reaches peak | Sweet story: confession rejected / identity exposure causes embarrassment<br>Tragic story: betrayal truth / revenge plan revealed / hurt reaches extreme |
| **Emotional rupture** | Relationship breaks | Breakup/divorce/falling out/cold war<br>Show emotional collapse through dialogue and actions |
| **Truth revealed** | Misunderstanding cleared or truth exposed | Diary/recording/witness/confession<br>Foreshadowed clues resolved here |
| **Emotional turnaround** | Emotional reversal | Sweet story: both confirm feelings<br>Tragic story: regret begins, pursuit and regret starts |

#### Taboos
- ❌ Using coincidence to solve misunderstanding (someone suddenly tells the truth)  
- ❌ Sudden character personality changes  
- ❌ Truth revealed too abruptly without emotional buildup  
- ❌ **Dangling setups**: suddenly appearing new characters / unreasonable plot twists

---

### 【Conclusion】Chapter 5: Emotional Closure and Happy Ending (2000-3000 words)

#### Writing Focus
```
Conclusion = Misunderstanding cleared + Emotional confession + Sweet ending + Future outlook
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Misunderstanding cleared** | Fully explained | Face-to-face confession / clear all misunderstandings<br>No unresolved issues |
| **Emotional confession** | Official relationship confirmation | Confession scene: romantic / heartfelt / sincere<br>Dialogue must be genuine, not empty phrases |
| **Sweet ending** | HE must be sweet | Wedding/proposal/cohabitation/public relationship announcement<br>Daily sugar moments |
| **Future outlook** | Leave lingering warmth | Briefly mention future: marriage/children/career<br>Or end with warm daily life |

#### Taboos
- ❌ Rushed ending, suddenly together  
- ❌ Emotional confession is hollow, just saying "I love you"  
- ❌ Tragic stories without enough regret and compensation  
- ❌ Open endings (modern romance short stories must have HE)

---

## 4. Character Development Methods

### Protagonist Design

| Dimension | Requirement | Correct Example | Incorrect Example |
|-----------|-------------|-----------------|-------------------|
| **Occupation/Identity** | Specific + attractive | "Returned overseas designer" / "Financial journalist" / "Rising CEO" | "Office worker" |
| **Situation/Background** | Has conflict points | "Fallen heiress / broken engagement / career bottleneck / single mother" | "Ordinary person" |
| **Personality Tags** | 2-3 distinct traits | "Cold outside but funny inside" / "Gentle but strong" / "Sharp tongue but kind" | "Kind" |
| **Appearance Features** | Concise but memorable | "Peach blossom eyes that smile" / "Always wears black suits" / "Tall beauty with long legs" | "Very pretty" / "Very handsome" |

### Personality Specificity
```
✅ "She looks gentle and easy to bully, but anyone who crosses her bottom line will find she’s tougher than anyone."  
❌ "She is gentle but also has a tough side."
```

### Male Lead Types (Common in Modern Romance)

| Type | Features | Personality | Suitable Tropes |
|------|----------|-------------|-----------------|
| **Domineering CEO** | Tall, rich, handsome / business elite / strong | Cold outside, warm inside / possessive / loyal and deep | Contract marriage / Cinderella / marriage before love |
| **Restrained Male God** | Aloof / disciplined / rational and restrained | Cold exterior, passionate inside / once in love, crazy | Crush turns real / breaking the ice romance / love grows over time |
| **Gentle Older Man** | Mature and steady / age gap / doting | Gentle, considerate, tolerant / like a father figure | Healing type / reversed age-gap / teacher-student romance |
| **Scheming Male Lead** | Smart and strategic / two-faced | Appears gentle but controls everything / calculating | Long-planned crush / revenge turns to love |
| **Rogue Handsome Male Lead** | Unruly / wild / bad boy | Rough but loyal / bad on surface, pure inside | Campus / childhood friends / contrast cuteness |

### Female Lead Types (Common in Modern Romance)

| Type | Features | Personality | Suitable Tropes |
|------|----------|-------------|-----------------|
| **Cinderella Type** | Ordinary / kind / average family | Pure but not naive / kind but with boundaries | Wealthy family / CEO pampering / status gap |
| **Strong Independent Woman** | Independent / career successful / capable | Doesn’t rely on men / rational / confident | Strong couple / rivals / workplace |
| **Soft Cute Bunny** | Cute / soft / innocent | Silly sweet but not annoying / healing type | Older man pampering / contrast cuteness / campus |
| **Scheming Female Lead** | Smart / scheming / not naive sweet | Appears obedient but clever / calculating | Revenge / palace intrigue / business war |

### Supporting Character Design (Simplification Principle)

Supporting characters in short stories must be extremely simplified, only keeping key roles that push the plot:

| Type | Role | Notes |
|------|------|-------|
| **Ex / Rival** | Create misunderstandings and conflicts | Don’t give too much screen time, 1-2 scenes enough |
| **Best Friend / Brother** | Provide advice, push confession | Only need 1, max 2 dialogue scenes |
| **Family** | Create pressure or assist | Briefly mentioned, no extended family lines |
| **Work Colleagues** | Background, show profession | Walk-on roles, just name them |

### Relationship Network Design (Specific to Modern Romance)

| Element | Requirement |
|---------|-------------|
| **Has history** | Childhood friends / schoolmates / ex / lifesaver / enemy |
| **Has distance** | Identity gap / age gap / status gap / wealth gap |
| **Has chemistry** | Complementary personalities / contrast cuteness / love-hate / evenly matched |
| **Has emotional change** | Stranger → Familiar → Heartbeat → Love OR Misunderstanding → Understanding → Reconciliation → Love |

---

## 5. Sweet Spot Design (Specific to Modern Romance)

### Sweet Spot Formula
```
Modern Romance Sweet Spot = Emotional satisfaction + Identity reversal + Slap-in-the-face to scumbags (choose one or combine)
```

### Sweet Spot Types

| Type | Method | Example |
|------|--------|---------|
| **Emotional Sweet Spot** | Finally together / confession success / confirm feelings | Long-time crush finally confesses / misunderstanding cleared and embrace |
| **Identity Sweet Spot** | True identity revealed to slap face | Cinderella is actually hidden heiress / poor boy is CEO |
| **Slap Face Sweet Spot** | Ex regrets / scumbag punished | Glamorous comeback after being dumped / ex begs for reconciliation and is rejected |
| **Pampering Sweet Spot** | CEO-style pampering / public protection | Stand up for her / support her / public show of affection / domineering declaration of ownership |
| **Confession Sweet Spot** | Deep confession / romantic proposal | Confess in front of whole company / carefully prepared proposal ceremony |

### Sweet Spot Density (Unique to Short Stories)

**Every 500-1000 words must have a small sweet spot**:  
- Small sweet spot: jealousy / wall pin / eye contact / teasing dialogue / small interaction  
- Medium sweet spot: confession / kiss / public relationship / slap face supporting characters  
- Large sweet spot: identity reveal / misunderstanding cleared / regret and remorse / happy ending

### Three-step Progressive Example (Sweet Romance)
```
Step 1 (Ambiguity): He gets jealous, uses work overtime as an excuse to block her in the office  
Step 2 (Testing): She deliberately mentions other men, he loses control and wall-pins her: "Besides me, you’re not allowed to look at any other man."  
Step 3 (Confession): He seriously says: "Su Nian, I’ve liked you since I was eighteen. All these years, I’ve waited only for you."
```

### Three-step Progressive Example (Tragic Romance)
```
Step 1 (Misunderstanding): She discovers he approached her for revenge and heartbreakingly leaves  
Step 2 (Regret): He finds out the truth, she is innocent, and starts desperately searching for her  
Step 3 (Reconciliation): He finds her, kneels in the rain: "In this life, I only ask for one more chance with you."
```

### Design Principles
- ✅ Sweet spots must be based on **emotional resonance**  
- ✅ Rely on **foreshadowing**, not last-minute rescue  
- ✅ Even sweet spots must **fit character personalities**  
- ❌ Avoid Mary Sue-style unreasonable plot devices

---

## 6. Conflict Design

### Conflict Formula
```
Modern Romance Conflict = External resistance (realistic contradictions) + Internal struggle (emotional contradictions) + Misunderstanding fueling
```

### External Conflicts (Mainline)

| Conflict Type | Specific Method | Example |
|---------------|-----------------|---------|
| **Identity gap** | Clearly show social status difference | CEO vs intern / rich kid vs poor student / celebrity vs ordinary person |
| **Family opposition** | Parents/elders obstruct | Wealthy family rejects Cinderella / family alliance plan / matching social status concept |
| **Ex entanglement** | Old lover / white moonlight appears | Ex-girlfriend returns / first love seeks reconciliation / misunderstanding heroine is homewrecker |
| **Career conflict** | Work interest opposition | Competitors / corporate spies / workplace unspoken rules |
| **Time and distance** | Long distance / rare meetings | Studying abroad / overseas assignment / long-distance relationship test |

### Internal Conflicts (Subplot)

| Conflict Type | Design Method |
|---------------|---------------|
| **Inferiority complex** | Female lead feels unworthy of male lead<br>Fear of abandonment / afraid to accept love |
| **Trust crisis** | Hurt by past, afraid to love again<br>Suspect partner’s motives |
| **Emotional struggle** | Love someone they shouldn’t (enemy / married / teacher)<br>Rationality vs emotion conflict |

### Conflict Progression Levels
```
Level 1: Realistic obstacles (identity/family/ex)  
    ↓  
Level 2: Misunderstanding deepens (misunderstand / distrust)  
    ↓  
Level 3: Emotional questioning (worth it? love or not? can we continue?)
```

---

## 7. Foreshadowing Management

### Foreshadowing Carriers (Specific to Modern Romance)

| Carrier Type | Example |
|--------------|---------|
| **Objects/Props** | Ring / bracelet / photo / letter / necklace / wallet / diary |
| **Past details** | Childhood stories / old photos / school items / lifesaving events |
| **Identity information** | True family background / hidden occupation / former name / overseas experience |
| **Dialogue clues** | One-line foreshadowing / nickname / joke truth |
| **Third-party perspective** | Supporting character knows truth / bystander sees details |

### Foreshadowing Setup Principles

| Stage | Method |
|-------|--------|
| **Planting** | Light touch in daily details, 1-2 sentences<br>e.g., "He paused when he saw the necklace on her neck."<br>e.g., "She seemed to have seen the background of that photo somewhere." |
| **Retrieval** | Revealed through memory, confrontation, confession<br>Supporting character reveals / protagonist confesses / accidental discovery |

### Common Foreshadowing Designs

**Crush Line Foreshadowing**:
```
Planting: He always "happens" to appear when she needs help  
Retrieval: Turns out he’s been following her social media / asked her best friend about her schedule
```

**Identity Line Foreshadowing**:
```
Planting: Her painting style is exactly like a deceased famous painter  
Retrieval: She is that painter’s daughter / true heir
```

**Misunderstanding Line Foreshadowing**:
```
Planting: "Intimate photo" with white moonlight  
Retrieval: Photo is photoshopped / white moonlight is his sister / business cooperation staged photo
```

---

## 8. Chapter Design (Specific to Modern Romance)

### Chapter Title Style

Modern romance titles should be **concise, emotionally hooking, and natural**:

| Element | Method |
|---------|--------|
| **Title style** | Short sentences, colloquial<br>e.g., "Chapter 1 Dumped" <br>e.g., "Chapter 3 He got jealous" <br>e.g., "Chapter 5 Let’s get married" |
| **Chapter opening** | Enter scene directly, no dragging<br>e.g., "'Let’s break up.' Wang Hao’s voice was calm."<br>e.g., "The phone rang thirty-two times, Su Nian didn’t answer any." |
| **Chapter ending** | Suspense or emotional climax<br>e.g., "'Su Nian, do you regret it?' His voice echoed in her ear."<br>e.g., "Only when she turned around did she see—the man was actually him." |

### Dialogue Design (Core of Modern Romance)

Modern romance dialogue should be **natural, not awkward, informative**:

**Good dialogue example**:
```
"You like me?" she looked at him incredulously.  
"Otherwise?" Lu Chen raised an eyebrow, "You think I’m just bored and block your door every day?"  
"But you clearly..."  
"Clearly what?" He interrupted, "Clearly cold to you? Su Nian, when did you get so silly?"
```

**Poor dialogue example**:
```
"Do you like me?"  
"I like you."  
"Really?"  
"Really."
```

### Psychological Description (Modern Romance Characteristic)

Should be **delicate but not verbose**, using inner monologue to show emotion:

**Good psychological description**:
```
Su Nian’s heart raced. She told herself this was just a contract marriage, don’t fall in love, don’t expect. But when he gently blew on her hot tea, all reason instantly collapsed. Damn, she seemed to have really fallen.
```

**Poor psychological description**:
```
She felt confused, didn’t know what to do, felt conflicted, had many thoughts.
```

### Pacing Control (Core of Short Stories)

**Fast pacing formula**:
```
500 words = 1 scene change OR 1 emotional fluctuation OR 1 information point
```

No paragraphs longer than 500 words without plot progression!

---

## 9. Emotional Progression Pace (Exclusive to Modern Romance)

### Five-stage Progression Method
```
Stranger/Reunion → Heartbeat/Ambiguity → Confirmation/Confession → Crisis/Misunderstanding → Reconciliation/Happiness
```

| Stage | Word Count Ratio | Key Events | Emotional Intensity |
|-------|------------------|------------|--------------------|
| **First meeting/Reunion** | 10-15% | Create intersection / chemistry | ★★☆☆☆ |
| **Heartbeat and Ambiguity** | 25-30% | Jealousy / wall pin / small interactions / gradual falling | ★★★☆☆ |
| **Confirmation and Confession** | 15-20% | Confession / acceptance / confirm relationship | ★★★★☆ |
| **Crisis and Misunderstanding** | 25-30% | Conflict explosion / truth revealed / regret | ★★★★★ |
| **Reconciliation and Happiness** | 15-20% | Misunderstanding cleared / sweet moments / HE | ★★★★★ |

### Ambiguity Heating Techniques

**Physical Contact Progression**:
```
1st time: accidental touch (blush, heartbeat)  
2nd time: support/hold her (excuse to rescue)  
3rd time: wall pin/waist hug (possessiveness shows)  
4th time: kiss/embrace (emotional outbreak)
```

**Eye Contact Progression**:
```
Avoidance → awkward eye contact → caught peeking → deep gaze
```

---

## 10. Common Short Story Patterns (Modern Romance)

### Pattern A: Contract Marriage Turns True Love

**Structure**:  
- Beginning: Flash marriage/business marriage/contract, agree not to fall in love  
- Development: Gradually fall in love during cohabitation, fake becomes real  
- Turning: Contract expires, must separate / identity exposed  
- Conclusion: Confirm true feelings, reunite

### Pattern B: Broken Mirror Mended with Pursuit and Regret

**Structure**:  
- Beginning: Breakup/divorce, female lead leaves  
- Development: Reunion, male lead realizes he still loves her  
- Turning: Pursuit blocked, female lead no longer returns, male lead regrets deeply  
- Conclusion: Male lead pays price, female lead forgives, broken mirror mended

### Pattern C: Crush Turns Real

**Structure**:  
- Beginning: Long-time crush but afraid to confess  
- Development: Forced proximity or interaction due to some reason  
- Turning: Crush discovered / brave confession  
- Conclusion: Mutual pursuit, happy ending

### Pattern D: Misunderstanding and Painful Romance

**Structure**:  
- Beginning: Due to misunderstanding/revenge, male lead approaches female lead  
- Development: Develop real feelings during interaction, truth unrevealed  
- Turning: Truth exposed, female lead hurt and leaves  
- Conclusion: Male lead chases and makes amends

---

**【Special Reminder】**  
The key to success of modern romance short stories:  
1. Capture the reader within the first 500 words  
2. Every 1000 words must have emotional fluctuations  
3. Dialogue must be natural and not awkward  
4. Emotional details must be delicate  
5. Ending must be HE and sweet