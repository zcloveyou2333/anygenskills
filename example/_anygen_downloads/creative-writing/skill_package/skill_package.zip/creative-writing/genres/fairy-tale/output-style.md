---
name: tonghua-output-style
description: The output style for fairy tale novels, featuring poetic and beautiful language, rich and vivid imagery, smooth and relaxed rhythm, warm and healing emotions
---

# General Writing Style Principles
- Poetic and Beautiful: Language like poetry and song, rich in rhythm and imagery
- Rich Imagery: Use metaphors, personification, symbolism, etc., to fill the text with imagination
- Relaxed Rhythm: Neither rushed nor anxious, allowing readers to immerse in the fairy tale world
- Warm and Healing: Convey love and hope, making readers feel warmth
- Innocent and Interesting: Maintain a childlike innocent perspective while containing deep meaning
- Happy Ending: Fairy tale short stories must have HE (Happy Ending), giving readers hope and strength
- Integrate Outline: Chapter outlines are categorical information, not narrative order; during creation, reorganize information according to event progression, avoid copying block by block; let the story flow naturally, integrating background information into the narrative

## Specific Practices

### When Writing Dialogue
- **Innocent and Interesting**: Characters’ speech should fit the fairy tale temperament, innocent but not childish
  - ✅ "Why do stars blink?" "Because they are saying goodnight to you."
  - ❌ "Those luminous celestial bodies are stars, and their twinkling is caused by atmospheric refraction..."
- **With Imagery**: Dialogue includes scene depiction
  - ✅ "Look, the moon is taking a bath in the river." "Shh, don’t wake it up."
  - ❌ "The moon’s reflection is in the river." "Hmm."
- **With Deep Meaning**: Simple words contain life lessons
  - ✅ "Why does the dandelion have to leave its mother?" "Because brave children go to see a bigger world."
  - ❌ "The dandelion was blown away by the wind." "Yes."
- **Character-Appropriate**: Different characters have different speaking styles
  - Little fairy: innocent and curious, likes to ask why
  - Wise elder: calm and composed, speaks like poetry
  - Little animals: cute and playful, viewing the world from their perspective

### When Writing Description
- **Use Poetic Language**: Avoid plain description, instead use imagery and metaphor
  - ✅ The moonlight gently spilled over the water lily leaves like milk, turning the pond into a silver dreamscape.
  - ❌ Moonlight shone on the pond, very bright.
- **Engage Multiple Senses**: Visual, auditory, tactile, olfactory intertwined
  - ✅ She stepped on fallen leaves, the ground singing a rustling song beneath her feet. The air carried the sweet scent of osmanthus, and the distant stream whispered softly.
  - ❌ She walked on a leaf-covered path, smelled osmanthus, and heard water.
- **Personify Everything**: Fill the world with life
  - ✅ The old oak stretched out its sturdy arms, wanting to hug the lost little bird.
  - ❌ The bird perched on the oak branch.
- **Rich Colors**: Use colors to brighten the scene
  - ✅ Her wings were a pale purple, like the dusk over a lavender field.
  - ❌ She had purple wings.

### When Writing Psychological Activity
- **Use Feelings Instead of Thoughts**: Fairy tale protagonists mostly "feel" rather than "analyze"
  - ✅ The little fairy’s heart felt like it was gently scratched by a cat’s paw, ticklish and sweet. So this is what it feels like to be liked.
  - ❌ She realized the other person liked her, which made her feel positive emotions.
- **Express Emotions Through Imagery**: Use imagery rather than adjectives
  - ✅ He felt like a leaf forgotten in a corner by the wind; the world was turning, but he remained still.
  - ❌ He felt very lonely.
- **Maintain Innocent Perspective**: Understand the world in a childlike way
  - ✅ "If I become a star, will mom still recognize me?" she hugged her knees and thought, "I’ll shine especially brightly, so mom can see me whenever she looks up."
  - ❌ She worried that after death her connection with her mother would be cut off.

### When Writing Adventure Scenes
- **Dangerous but Not Scary**: Tense but not frightening to readers
  - ✅ In the dark forest, tree shadows looked like reaching fingers, but she saw fireflies flying between the trees like flowing stars. "Don’t be afraid," she told herself, "darkness is just the sun sleeping."
  - ❌ The eerie forest was full of death’s aura, monsters could pounce and tear her apart anytime.
- **Creative and Clever Solutions**: Problem-solving is fun and smart
  - ✅ The big bad wolf opened its mouth to pounce! The little fairy quickly sprinkled pepper from her pocket—"Achoo! Achoo!" The wolf sneezed a hundred times, snot everywhere, and ran away embarrassed.
  - ❌ She defeated the enemy with magic.
- **Warm Cooperation Among Friends**: True feelings show in dangerous moments
  - ✅ "You go first, I’ll hold it off!" The little rabbit spread its arms; so small, yet its voice was firm. The little fairy’s eyes warmed, "Silly, we go together!"
  - ❌ They cooperated to fight the enemy.

### When Writing Magic Scenes
- **Magic Should Be Beautiful**: Magic presentation like a poem
  - ✅ She softly recited the ancient word, and a flower made of light bloomed in her palm. Petals drifted down, each turning into a butterfly with rainbow colors, flying toward the sky.
  - ❌ She used magic and emitted light.
- **Magic Has Rules**: Make the magic system believable
  - ✅ "Remember, every time you cast a spell, you lose a small piece of memory. So only use it in the most important moments," Grandma Moon reminded.
  - ❌ She can use magic freely to do anything.
- **Magic Has a Price**: Add depth to the story
  - ✅ When the last spell was finished, the little fairy realized she had forgotten her mother’s face. But she did not regret it because she protected everyone she loved.
  - ❌ She solved all problems with magic without any harm.

### When Writing Emotional Climax
- **Genuine Emotion Without Melodrama**: Touching but natural, not forced tears
  - ✅ "I thought I would always be alone," the little fairy whispered, "thank you for telling me someone is willing to be my friend." Her tears fell to the ground, blooming a little flower.
  - ❌ She cried heavily, "You are my best friend in this life! I will never forget you!"
- **Elevate Emotion with Imagery**: Turn emotion into a picture
  - ✅ They stood on the mountaintop, watching the sunrise dye the sky golden. "Every time I see sunrise, I’ll think of you," said the little fairy. "Then you’ll have to get up early every day," the little rabbit smiled.
  - ❌ They said a reluctant goodbye.
- **Warm and Healing Tone**: Even with tears, there is sunshine
  - ✅ Yes, parting is sad. But the little fairy knew that as long as she looked up at the stars, her friends were there. Distance cannot cut off love, just like clouds cannot block the sunlight.
  - ❌ After parting, she was never happy again.

### When Handling Rhythm
- **Establish Fantasy Atmosphere Within First 500 Words**: Let readers immediately enter the fairy tale world
  - ✅ In a castle made of clouds lived the smallest dream-weaving fairy in the world. Her name was A-Guang, because she was born on the night when the starlight was brightest.
  - ❌ This story happens in a magical world. There is a fairy, and her life is like this...
- **Each Scene Must Advance Growth**: Every scene has meaning
  - ✅ She tried to fly over the waterfall for the first time, her wings wet by splashes, falling heavily on moss. But she didn’t cry because she saw the rainbow hidden behind the waterfall—through hardship comes beauty.
  - ❌ She flew over the waterfall, then kept walking forward.
- **Leave Space and Suspense**: Give readers room for imagination
  - ✅ On the distant horizon, the first star lit up. A-Guang knew it was her friend greeting her. She smiled and flew toward that star. (Story implies they will reunite)
  - ❌ Later they reunited and lived happily ever after. (Explicitly stated)

### When Ending Chapters
- **Leave Suspense**: Make readers look forward to the next chapter
  - ✅ Just when she was about to despair, a faint light appeared in the darkness. The light was weak, like a firefly or a distant star. "Who’s there?" she asked. The darkness didn’t answer, but the light slowly floated toward her.
  - ❌ This chapter ended, the next chapter continues the story.
- **End at Emotional High Point or Turning Point**: Leave readers wanting more
  - ✅ "I know the truth now." She looked at herself in the mirror, eyes moistening, "It turns out the person she was always looking for was me."
  - ❌ She knew the truth.
- **Poetic Aftertaste**: Let sentences end like music
  - ✅ The moon rose, turning the world silver. The little fairy closed her eyes and heard the wind singing a song about going home.
  - ❌ It got dark, she went home.

## Language Taboos

### Absolutely Forbidden
- ❌ Bloody and violent descriptions: "blood," "death," "kill," etc.
- ❌ Real-world internet slang: "yyds," "absolute," "LOL"
- ❌ Overly adult emotional expressions: "love," "romance," "heartthrob" (friendship and family love are allowed)
- ❌ Preachy tone: "We must learn..." "This tells us..."
- ❌ Horror and thriller elements: overly scary monsters, dark scenes
- ❌ Complex philosophical terms: express deep meaning in ways children can understand

### Must Achieve
- ✅ Language like poetry, with rhythmic beauty
- ✅ Vivid description with imagery
- ✅ Warm emotions with healing power
- ✅ Profound truths expressed simply
- ✅ Rich imagination with a complete worldview
- ✅ Happy endings that give hope

## Special Reminders

### Special Requirements for Short Stories
- **Balance Fantasy and Reality**: Magical world must have logic, emotional reactions must be real
- **Clear Growth Mainline**: Every 1000 words must advance growth
- **Deep Dive Single Theme**: Don’t be greedy, tell one theme thoroughly
- **Complete Within 5 Chapters**: Clear structure of beginning, development, turn, and conclusion

### Perspective Suggestions
- **Third-Person Intimate**: Most common, follow protagonist’s perspective but keep some distance
- **First-Person**: Suitable for diary style, growth reflections
- **Omniscient**: Suitable for ensemble fairy tales, showing multiple characters

### Control of Fairy Tale Characteristics
- **Innocent ≠ Childish**: Can tell profound truths simply
- **Beautiful ≠ No Difficulties**: Adventures have challenges but are ultimately overcome
- **Warm ≠ No Sadness**: Can have farewells and tears but must have hope
- **Fantasy ≠ Arbitrary**: Magical world has rules and logic

### Emotional Scale Control
- **Friendship Can Be Deep**: Friendship can be very touching in fairy tales
- **Family Love Can Be Moving**: Parental love and family bonds can be expressed
- **Romance Should Be Subtle**: If romance exists, use words like "like," "feelings"
- **Sadness Should Be Moderate**: Can be sad but must ultimately lead to hope

## Core Philosophy

When writing fairy tales, remember three keywords:
1. **Imagination**: Fill the world with miracles and possibilities
2. **Warmth**: Let readers feel love and hope
3. **Growth**: Let protagonists and readers gain something

**Most important point**: Fairy tales are written for everyone. A good fairy tale lets children see interesting adventures and adults read profound truths. It is simple but not shallow; innocent but not childish; beautiful but not false. This is the magic of fairy tales.