---
name: tonghua-outline-method
description: Methodology for creating outlines of fairy tale short stories, including core synopsis extraction, introduction design, plot structure planning, and character development guidance
---

## Q1-Q3 Question Templates

### Q1: Core Idea
**Q1: Core idea and appeal of the story [Brief description]**  
Please describe your story idea in one or two sentences.

### Q2: Core Conflict
**Q2: Core conflict [Brief description]**  
Please describe the novel’s central contradiction or main conflict in one sentence.  
(For example: A fairy searching for the way home, a prince rescuing a cursed princess, animals protecting their forest home, an orphan discovering they have magic, etc.)

### Q3: Story Tone
**Q3: Story tone [Choose one]**  
- Warm and healing · Pure and beautiful (full of hope and love, suitable for all ages)  
- Fantasy adventure · Courage and growth (protagonist embarks on an adventure and matures)  
- Allegorical philosophy · Enlightening wisdom (contains life lessons, thought-provoking)  
- Dreamy romance · Poetic and aesthetic (dreamlike atmosphere, full of poetry)  
- Or please briefly describe your story tone

## Chapter File Naming Rules  
Filename format: `{STORY_NAME}-{NN}.md`  
Example: `The Fairy’s Adventure-01.md`, `The Fairy’s Adventure-02.md`

---

# Fairy Tale Outline Creation Methodology

## Overall Orientation

Fairy tales emphasize "**imagination and spiritual enlightenment**," focusing on adventure, growth, and love in a fantasy world.

**Core Principles**:  
- Focus on growth themes (courage, kindness, friendship, self-discovery, etc.)  
- Pursue "emotional resonance": fantasy immersion, warmth and healing, profound meaning  
- Balance fun and philosophy, but **do not stray from fairy tale logic and human goodness**  
- Use magic, adventure, and transformation to drive the plot, **rejecting dark and cruel twists**  
- Maintain a poetic and elegant style: vivid descriptions, profound atmosphere, gentle pacing

---

## Overall Creation Formula
```
Fairy tale short story = Fantasy hook + Journey of growth + Trials and wisdom + Warm and fulfilling ending
```

---

## 1. Core Synopsis Writing

### Formula
```
Core synopsis = Fantasy identity/setting + Core dilemma + Growth theme
```

### Writing Points
| Element | Requirement | Correct Example | Incorrect Example |
|---------|-------------|-----------------|------------------|
| **Fantasy Identity** | Unique + attractive | "A fairy who lost her wings" | "A little girl" |
| **Core Dilemma** | Both internal and external challenges | "Must find the lost star on the full moon night" | "Faced some difficulties" |
| **Growth Theme** | Clear life lesson | "Learn to believe in your own strength" | "Succeeded in the end" |

### Excellent Examples
- "In the kingdom at the end of the rainbow, there is a little dragon afraid of flying. When a fierce dragon threatens his home, he must overcome his fear and learn that true courage is not the absence of fear, but moving forward despite it."  
- "Little girl Mira discovers a door to the Star Kingdom in her grandmother’s attic. To help the sick star prince, she embarks on a journey to find the Moon’s Tears."  
- "A prince cursed to become a swan meets a shepherdess who can understand animal language. Only true friendship can break the spell, but there are only three full moon nights left."

---

## 2. Introduction Writing

### Formula
```
Introduction = Fantasy world opening + Protagonist dilemma setup + Adventure suspense hook
```

### Writing Points
| Element | Purpose | How to Write |
|---------|---------|--------------|
| **First sentence** | Open the fantasy world | Directly depict a magical scene: enchanted forest/cloud castle/talking animals |
| **Middle part** | Explain protagonist’s situation | Quickly position by identity, traits, dilemma |
| **Last sentence** | Create adventure suspense | Upcoming journey/mystery to solve/fateful turning point |

### Incorporating Growth Themes

The introduction should touch on core growth themes:

| Theme Type | Specific Direction |
|------------|--------------------|
| **Courage and growth** | Overcoming fear, facing challenges, protecting loved ones |
| **Self-discovery** | Finding true self, discovering hidden talents, accepting imperfections |
| **Friendship and love** | True friends, selfless devotion, power of love |
| **Wisdom and kindness** | Solving problems with wisdom, kindness conquers evil, tolerance and forgiveness |

**Goal**: Make readers eager to know "what happens next" (fantasy immersion)

### Example Comparison
| Type | Content |
|------|---------|
| ✅ **Correct** | "In a castle made of clouds lives a little fairy who cannot weave dreams. While other fairies weave colorful dreams for children, little fairy A-Guang can only weave gray mist. 'Maybe you’re not really a dream-weaving fairy,' the others say. Until one day, A-Guang meets a crying star deep in the forest—it cannot return to the sky because it forgot its name. A-Guang decides to help the little star, unaware that this journey will reveal his true talent." |
| ❌ **Incorrect** | "There was a little fairy who wasn’t very good at things, later faced some difficulties, and finally overcame them..." |

---

## 3. Plot Structure Design (Qi-Cheng-Zhuan-He)

### 【Qi】Chapter 1: Fantasy World Opening (2000-3000 words)

#### Writing Focus
```
Qi = Worldview display + Protagonist introduction + Core dilemma presentation + Adventure trigger
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Worldview display** | Show fantasy world within first 500 words | Introduce magic elements/wonderful creatures/magical places in first paragraph |
| **Protagonist introduction** | Quickly present protagonist | Introduce protagonist within 300 words via daily life/special event/fate call |
| **Core dilemma** | Show protagonist’s imperfection | Personality flaws/insufficient ability/internal fears |
| **Adventure trigger** | Propel story start | Unexpected event/request for help/discovery of secret/fate guidance |

#### Taboos
- ❌ Large blocks of expository text introducing the world  
- ❌ Protagonist too perfect with no room for growth  
- ❌ Unclear or unreasonable motivation for adventure

---

### 【Cheng】Chapters 2-3: Adventure Journey and Trials (2000-3000 words each)

#### Chapter 2 Focus
```
Chapter 2 = Embark on journey + Meet companions + Small test + Foreshadowing
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Embark on journey** | Leave familiar environment | Farewell home/cross boundary/enter unknown area; show anticipation and unease |
| **Meet companions** | Build friendship bonds | Unexpected encounter/mutual help/misunderstanding resolved; companions with complementary personalities |
| **Small test** | First trial | Small monster/puzzle/difficulty; show protagonist’s strengths and weaknesses |
| **Foreshadowing** | Lay groundwork for later | Mysterious clues/ancient prophecy/unresolved mysteries |

#### Chapter 3 Focus
```
Chapter 3 = Major trial + Companion bonds + Self-doubt + Key turning point
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Major trial** | Increased difficulty | Stronger enemy/harder puzzle/bigger sacrifice |
| **Companion bonds** | Deepen friendship | Mutual support/facing together/build trust |
| **Self-doubt** | Inner struggle | Begin doubting self/wanting to give up/facing fears |
| **Key turning point** | Foreshadow climax | Discover truth/gain insight/make decision |

---

### 【Zhuan】Chapter 4: Greatest Crisis and Awakening (2000-3000 words)

#### Writing Focus
```
Zhuan = Greatest crisis + Darkest moment + Inner awakening + Power explosion
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Greatest crisis** | Danger peaks | Villain’s strongest attack/last moment/seemingly no way out |
| **Darkest moment** | Protagonist hits low | Failure/separation/loss of hope; the darkest before dawn |
| **Inner awakening** | Epiphany and growth | Memories/inspiration/understanding important truth; seeds planted earlier sprout here |
| **Power explosion** | Breakthrough | Overcome fear/discover talent/true courage |

#### Taboos
- ❌ Using external forces (e.g., suddenly appearing strong helper) to solve problems  
- ❌ Sudden protagonist power change without buildup  
- ❌ Awakening too rushed without emotional accumulation  
- ❌ **Too dark**: maintain the warm tone of fairy tales

---

### 【He】Chapter 5: Victory and New Life (2000-3000 words)

#### Writing Focus
```
He = Final confrontation + Justice victory + Return and change + Happy ending
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Final confrontation** | Use powers gained from growth | Combine wisdom and courage/friendship’s power/victory of kindness |
| **Justice victory** | Good triumphs over evil | Villain defeated/curse lifted/problem solved |
| **Return and change** | Protagonist’s transformation | Return home/gain recognition/inner peace |
| **Happy ending** | Warm closure | Happy life/friendship continues/hopeful future |

#### Taboos
- ❌ Rushed ending without emotional satisfaction  
- ❌ Too many unresolved issues left  
- ❌ Protagonist shows no obvious growth  
- ❌ Tragic ending (fairy tale short stories must have a happy ending)

---

## 4. Character Development Methods

### Protagonist Design

| Dimension | Requirement | Correct Example | Incorrect Example |
|-----------|-------------|-----------------|------------------|
| **Fantasy identity** | Unique + imaginative | "A fairy who can’t fly" / "A boy who understands the language of the wind" | "An ordinary child" |
| **Core flaw** | Has room to grow | "Timid and afraid of the dark / lacks confidence / too proud" | "Perfect without flaws" |
| **Personality tags** | 2-3 distinct traits | "Kind but timid" / "Smart but reclusive" / "Brave but reckless" | "Good person" |
| **Appearance features** | Concise and memorable | "Silver hair" / "Eyes shining like stars" | "Very cute" |

### Personality Specificity
```
✅ "Fairy A-Guang always walks with his head down because he fears seeing others’ disappointed eyes. But when friends need help, he’s the first to rush forward, even though his voice trembles."  
❌ "He is timid but also has a brave side."
```

### Protagonist Archetypes (Common in Fairy Tales)

| Type | Features | Personality | Suitable Themes |
|------|----------|-------------|-----------------|
| **Fairy/Sprite** | Magical but imperfect | Kind and pure / flawed and needs growth | Self-discovery / talent awakening |
| **Shapeshifter** | Cursed / secretive | Yearns for acceptance / lonely inside | True heart and acceptance |
| **Adventurer** | Ordinary person entering fantasy | Curious and brave / needs growth | Courage and growth |
| **Prince/Princess** | Of status but troubled | Kind but constrained / longs for freedom | Responsibility and choice |
| **Animal protagonist** | Anthropomorphic animal | Loyal and kind / animal traits | Friendship and loyalty |

### Supporting Characters Design (Fairy Tale Features)

| Type | Role | Notes |
|------|------|-------|
| **Wise mentor** | Provides guidance and help | Cannot solve problems for protagonist, only points the way |
| **Loyal companion** | Accompanies adventure, mutual support | Must have unique personality, not just sidekick |
| **Villain/Obstacle** | Creates difficulties, drives growth | Fairy tale villains can be evil but not excessively cruel |
| **Character needing help** | Shows protagonist’s kindness | Through helping others, protagonist also grows |

### Relationship Network Design (Fairy Tale Specific)

| Element | Requirement |
|---------|-------------|
| **Fated connection** | Destined meeting / magical coincidence / ancient prophecy |
| **Complementarity** | Complementary personalities / abilities / weaknesses |
| **Bond** | Shared goals / deep trust / mutual growth |
| **Change** | From strangers to familiar / from misunderstanding to understanding / from estrangement to intimacy |

---

## 5. Fantasy Element Design

### Worldbuilding Formula
```
Fairy tale world = Basic setting + Magic rules + Unique details
```

### Common World Types

| Type | Features | Examples |
|------|----------|----------|
| **Magic forest** | Talking plants and animals, hidden cottages | Ancient forest inhabited by elves |
| **Sky kingdom** | Cloud castles, flying creatures | Dream-weaving fairies living in clouds |
| **Underwater world** | Undersea palaces, aquatic creatures | Pearl city of the mermaid kingdom |
| **Miniature world** | Flower houses, insect neighbors | Mushroom village of dwarfs |
| **Parallel world** | Mirror portals, time distortions | Wonderful kingdom stepping out of a painting |

### Magic Rules Design

| Element | Requirement |
|---------|-------------|
| **Has a cost** | Magic is not omnipotent; usage requires a price |
| **Has limitations** | Magic has rules and boundaries, cannot solve all problems |
| **Logical** | Magic system must be self-consistent and coherent |
| **Aesthetic** | Magic presentation should be poetic and beautiful |

---

## 6. Conflict Design

### Conflict Formula
```
Fairy tale conflict = External obstacles (villains/difficulties) + Internal struggles (fear/flaws) + Growth opportunity
```

### External Conflict (Mainline)

| Conflict Type | Specific Method | Example |
|---------------|-----------------|---------|
| **Villain threat** | Evil forces / magical curses | Witch’s curse / dark power invasion |
| **Difficult task** | Mission to complete | Find lost treasure / rescue trapped friend |
| **Time limit** | Urgent deadline | Before full moon night / before spring arrives |
| **Environmental challenge** | Dangerous journey | Cross dark forest / climb magical mountain |

### Internal Conflict (Subline)

| Conflict Type | Design Method |
|---------------|---------------|
| **Fear psychology** | Fear of darkness / failure / abandonment |
| **Self-doubt** | Feeling not good enough / not trusting own ability |
| **Personality flaws** | Pride / timidity / selfishness / stubbornness |
| **Choice difficulty** | Right but hard path vs easy but wrong path |

### Conflict Progression Levels
```
Level 1: External difficulties (enemies/obstacles/tasks)
    ↓
Level 2: Inner struggles (fear/doubt/temptation)
    ↓
Level 3: Growth choices (face fear/overcome self/make sacrifice)
```

---

## 7. Foreshadowing Management

### Foreshadowing Carriers (Fairy Tale Specific)

| Carrier Type | Example |
|--------------|---------|
| **Magical objects** | Magical seed / glowing stone / ancient key / mother’s heirloom |
| **Prophecies and legends** | Ancient ballads / village legends / prophecy books |
| **Special abilities** | Hidden talents / dormant powers / innate marks |
| **Mysterious characters** | Veiled old woman / talking wise old tree |
| **Natural omens** | Special celestial phenomena / blooming signals / animal warnings |

### Foreshadowing Setting Principles

| Stage | Method |
|-------|--------|
| **Planting** | Naturally integrate into scenes, 1-2 sentences mention  
Example: "She accidentally touched the stone, and a faint glow flickered at her fingertip."  
Example: "The necklace her grandmother gave her before passing, said to come from a distant star." |
| **Payoff** | Reveal function at key moment  
Example: In a crisis, the stone emits dazzling light—it is actually the heart of a star. |

### Common Foreshadowing Designs

**Hidden identity foreshadowing**:  
```
Planting: When the girl was born, seven stars shone simultaneously in the sky  
Payoff: She is actually the reincarnation of the lost star princess
```

**Ability awakening foreshadowing**:  
```
Planting: Every time she is scared, her shadow seems to move  
Payoff: She has the magic to control shadows, but it has not awakened yet
```

**Object function foreshadowing**:  
```
Planting: That ordinary button is the only relic left by her mother  
Payoff: The button can summon her mother’s guardian spirit to protect her in the most dangerous moments
```

---

## 8. Chapter Style Design (Fairy Tale Specific)

### Chapter Title Style

Fairy tale titles should be **poetic, visual, and evocative**:

| Element | Method |
|---------|--------|
| **Title style** | Imagery-based, poetic  
Examples: "Chapter 1 The Dream Weaver on the Clouds"  
"Chapter 3 The Secret of the Moonlight River"  
"Chapter 5 The Way Home for the Stars" |
| **Chapter opening** | Use scenery to evoke emotion and atmosphere  
Examples: "Moonlight spilled like milk on the water lily leaves."  
"When the first snowflake fell, little fairy A-Guang knew the magic of winter had begun." |
| **Chapter ending** | Suspense or a glimmer of hope  
Examples: "In the distant horizon, a star was twinkling. It was the signal to the Star Kingdom."  
"In the darkness, something was awakening." |

### Dialogue Design (Fairy Tale Core)

Fairy tale dialogue should be **pure, interesting, and philosophical**:

**Good dialogue example**:
```
"Why do stars shine?" the little fairy asked.  
"Because they carry lots and lots of love inside," Grandma Moon smiled, "The more love, the brighter they shine."  
"Then why don’t I shine?"  
"Because you haven’t found the light inside your heart yet."
```

**Poor dialogue example**:
```
"I'm going on an adventure."  
"Okay, go ahead."  
"Thank you."  
"You're welcome."
```

### Psychological Description (Fairy Tale Feature)

Should be **innocent but not childish**, showing deep emotions from a pure perspective:

**Good psychological description**:
```
The little fairy lowered her head, looking at her gray, dusty wings. Other fairies’ wings were as beautiful as rainbows, but hers looked like an old blanket forgotten in a corner. "Maybe I really shouldn’t have been born," she thought. Just then, a ladybug landed on her finger and gently rubbed her with its tiny antennae. "Your wings are silver," the ladybug said, "Silver is the color of the moonlight, the gentlest light of all."
```

**Poor psychological description**:
```
She was very sad and felt she was worthless.
```

### Pacing Control (Fairy Tale Core)

**Pacing formula**:
```
500 words = 1 scene or 1 emotional fluctuation or 1 story advancement
```

Each scene should have: magical imagery + emotional warmth + story significance

---

## 9. Growth Pacing (Fairy Tale Exclusive)

### Five-Stage Growth Method
```
Ordinary daily life → Call to adventure → Trials and challenges → Darkest low → Awakening and transformation
```

| Stage | Word Count Ratio | Key Events | Growth Level |
|-------|------------------|------------|--------------|
| **Ordinary daily life** | 10-15% | Show initial state and flaws | ★☆☆☆☆ |
| **Call to adventure** | 15-20% | Embark on journey / meet companions | ★★☆☆☆ |
| **Trials and challenges** | 25-30% | Face difficulties / some progress | ★★★☆☆ |
| **Darkest low** | 20-25% | Greatest crisis / inner awakening | ★★★★☆ |
| **Awakening and transformation** | 15-20% | Overcome difficulties / complete transformation | ★★★★★ |

### Growth Expression Techniques

**Ability growth**:
```
Start: Magic always fails  
Mid: Occasionally succeeds at critical moments  
End: Can use magic skillfully
```

**Personality growth**:
```
Start: Timid and afraid to speak  
Mid: Encouraged by friends, tries bravely  
End: Takes initiative to face difficulties
```

**Relationship growth**:
```
Start: Alone and lonely  
Mid: Meets companions, mutual adjustment  
End: Builds deep friendship
```

---

## 10. Common Fairy Tale Patterns

### Pattern A: The Quest

**Structure**:  
- Qi: Protagonist needs to find something (lost treasure / way home / healing medicine)  
- Cheng: Embark on journey, meet companions, overcome difficulties  
- Zhuan: Greatest crisis, realize what they truly seek is something in their heart  
- He: Find the goal and themselves

### Pattern B: Breaking the Curse

**Structure**:  
- Qi: Protagonist or important character is cursed/trapped by magic  
- Cheng: Search for a way to break the curse, embark on adventure  
- Zhuan: Discover the cost/true method to break the curse  
- He: Break curse with love/courage/sincerity

### Pattern C: Protecting the Homeland

**Structure**:  
- Qi: Homeland/kingdom faces threat  
- Cheng: Protagonist decides to stand up, seeks ways to fight back  
- Zhuan: Most dangerous confrontation, seems about to fail  
- He: Use wisdom and courage to defeat enemy, protect homeland

### Pattern D: Transformation and Growth

**Structure**:  
- Qi: Protagonist has obvious flaws or difficulties (unrecognized / insecure / rejected)  
- Cheng: A trigger causes protagonist to start changing  
- Zhuan: Face the greatest trial, must confront flaws  
- He: Complete transformation, gain recognition, find self

---

**【Special Reminder】**  
Keys to success of fairy tale short stories:  
1. The first 500 words must establish a fantasy atmosphere  
2. Every 1000 words must advance growth or adventure  
3. Dialogue must be pure, interesting, and meaningful  
4. Emotional description must be warm and healing  
5. Ending must be beautiful and fulfilling, giving hope