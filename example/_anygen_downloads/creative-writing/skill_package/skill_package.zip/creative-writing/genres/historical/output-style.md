---
name: lishi-output-style
description: The output style for historical military novels, characterized by grand and majestic language, solid and rigorous historical research, delicate characterization of human nature, and profound strategic thinking. It integrates Sun Haohui's epic scope with the human insights of Jiutu.
---

# General Writing Style Principles
- Grand and Majestic: Language conveys a sense of power, reflecting the tides of the era
- Solid Historical Research: Historical details withstand scrutiny
- Delicate Human Nature: Individual fates are not forgotten amid grand narratives
- Profound Strategy: Showcases military wisdom and political intrigue
- Tragic Restraint: Uses restrained narration to convey strong emotions
- Iron-blooded Tenderness: Combines the harshness of the battlefield with deep personal affections
- Integrated Outline: Chapter outlines serve as categorized information, not narrative order; during creation, information must be reorganized according to event progression, avoiding block-by-block copying; the story should flow naturally, with historical background woven into the narration

## Fusion of Two Masters’ Styles

### Sun Haohui Style Elements
- **Epic Scope**: Great eras, great figures, great conflicts, great destinies
- **Historical Weight**: Narrative supported by solid historical evidence
- **Strategic Vision**: Displays macro strategic layouts
- **Civilizational Perspective**: Views history from the rise and fall of civilizations
- **Tragic Grandeur**: Pursues an epic narrative grandeur

### Jiutu Style Elements
- **Realistic Details**: Uses concrete details to restore historical texture
- **Complex Human Nature**: Does not shy away from the brilliance and darkness of humanity
- **Emotional Restraint**: Conveys deep emotions through calm narration
- **Small Characters’ Perspective**: Focuses on individual fates within great eras
- **Display of Wisdom**: Shows characters’ intelligence through concrete actions

## Specific Practices

### When Writing Dialogue
- **Consistent with Identity**: Generals, strategists, monarchs each have their own way of speaking
  - ✅ "Your Majesty, the siege of Changping has lasted forty days, the Zhao army’s supplies are exhausted and reinforcements cut off. I believe, if they do not surrender now, when else?" (Strategist tone)
  - ❌ "I think the enemy should surrender now."
- **Concise and Powerful**: Every sentence carries weight
  - ✅ "Fight." "Supplies last three days." "Then fight swiftly and decisively."
  - ❌ "We need to consider whether we should fight now because supplies are running low."
- **Strategic Thinking**: Military or political thought reflected in dialogue
  - ✅ "The way to defeat the enemy is not frontal assault, but cutting off their supply lines." "The supply route is over a hundred miles away, how to cut it?" "Send light cavalry for a night raid, three days’ ride." "Three days? What if the enemy is prepared?" "Then four days."
  - ❌ "We should attack them." "Okay."
- **Historical Texture**: Word choice fits the era
  - ✅ "I dare not accept the honor." "Your Majesty is wise." "The general’s concerns are well-founded."
  - ❌ "OK" "No problem" "You’re right"

### When Writing Description
- **Era Atmosphere**: Use concrete details to depict historical scenes
  - ✅ At the Changping battlefield, corpses littered everywhere. Autumn wind stirred the yellow earth, shrouding everything in a gray mist. Bai Qi stood on the high platform, eyes sweeping over the 400,000 kneeling surrendered Zhao soldiers. Their clothes were tattered, faces gaunt, eyes filled with despair and pleading.
  - ❌ Many people on the battlefield, the general was watching them.
- **War Scenes**: Both macro layout and micro details
  - ✅ The Qin army’s formation was like an iron wall, advancing layer by layer. The front row were shield-bearing heavy infantry, the second row long spear men extending spearheads above shields, the third row crossbowmen ready. Zhao cavalry charged three times, all repelled. Bai Qi stood in the center army, eyes scanning the battlefield—the enemy’s left wing showed signs of fatigue, the moment to break through. "Order: left wing attack!"
  - ❌ The two armies started fighting fiercely.
- **Historical Details**: Show understanding of the era
  - ✅ He picked up a Qin half-liang coin, rubbing it carefully. After Shang Yang’s reforms, Qin unified weights and measures; this coin weighed exactly half a liang, true to its name. Because of this, the Qin military merit system could be implemented—rewards were clear and could not be faked.
  - ❌ He held an ancient coin.
- **Characterization**: Reveal personality through details
  - ✅ Li Jing never drank in front of soldiers; even during troop rewards, he only sipped wine and put the cup down. But after every battle casualty count, he would drink alone in the command tent until dawn. The deputy generals all knew that night, no one was allowed near the tent.
  - ❌ Li Jing was a good general who cared about soldiers.

### When Writing Psychological Activity
- **Strategic Thinking**: Show how characters analyze the situation
  - ✅ Han Xin looked at Xiang Yu’s formation, rapidly calculating. Xiang Yu’s forces were triple ours and all elite; a direct fight meant defeat. But Xiang Yu was impatient; if lured into pursuit, his formation would stretch. When exhausted, ambush troops could cut off his rear—this plan required a back-to-the-wall stance, showing weakness to the enemy. Victory meant total success, defeat meant total annihilation. To gamble or not?
  - ❌ He thought the enemy was strong and needed a plan.
- **Moral Struggle**: Show inner conflict
  - ✅ Bai Qi looked at the 400,000 surrendered soldiers, fingers lightly tapping the table. Letting them go meant next year they would be Zhao’s manpower, raising a tiger to harm. Incorporating them into Qin’s army was impossible; rear supplies were tight. Taking them back as slaves? The journey was long and dangerous. He closed his eyes—only one choice. But that was 400,000 lives. His hand stopped. After a long time, he opened his eyes, cold as ice.
  - ❌ He was conflicted and didn’t know what to do.
- **Restrained Expression**: Use actions to imply emotion
  - ✅ Li Jinglong took the surrender letter, fingers trembling slightly. He paused as he raised the pen, eyes falling on the characters "Great Ming" on the city wall. Those two words seemed to burn. His Adam’s apple moved; after a long time, he finally put down the pen. The pen’s tip felt like a thousand pounds.
  - ❌ Li Jinglong was very painful but surrendered in the end.
- **Historical Perspective**: Place personal fate in the flow of history
  - ✅ Champion Marquis stood atop Mount Langjuxu, gazing at the endless northern grasslands. At 23, he was already Champion Marquis of the Great Han and Cavalry General. But he knew, as long as the Xiongnu were not destroyed, the title "Champion" was only a beginning. He recalled Wei Qing’s words before departure: "Yuanhuo, you are still young." Yes, he was young—young enough to drive the Xiongnu to the ends of the earth.
  - ❌ Huo Qubing felt young and could keep fighting.

### When Writing War Scenes
- **Strategic Level**: Help readers understand the logic of war
  - ✅ "The Art of War says, when ten times the enemy’s number, surround them." Han Xin moved pieces on the sand table, "Xiang Yu’s forces are triple mine, intending to surround us by dividing into three routes. We concentrate forces to defeat them one by one—first strike the weak left wing, then attack the right wing, finally strike the center. The key is speed, no chance for enemy to regroup." Liu Bang nodded, "When to start?" "At dawn tomorrow. Before daylight, enemy vigilance will slacken, and morning fog will conceal our movements."
  - ❌ They discussed how to fight and decided to attack tomorrow.
- **Tactical Details**: Show specific combat methods
  - ✅ Qin crossbowmen fired in three rotating rows. The first row shot then immediately crouched to reload, the second row fired in turn, the third row reloaded simultaneously waiting. This cycle created a rain of arrows; Zhao cavalry charged three times, all fell a hundred steps away. This was the essence of Shang Yang’s military system—not individual bravery, but overall coordination.
  - ❌ They shot arrows at the enemy and killed many.
- **Battlefield Reality**: Do not shy away from war’s cruelty
  - ✅ After the first volley of arrows, many warhorses fell. Injured horses neighed and struggled, throwing riders off. The second volley followed; those who got up were pinned down again. Blood quickly soaked the yellow earth, dyeing it dark red. The air was thick with the smell of blood and horse dung. Li Jing, accustomed to life and death, still frowned.
  - ❌ The battle was fierce and many died.
- **Command and Control**: Show commanders’ art of leadership
  - ✅ "Hold the center! No retreat!" "Left wing advance obliquely, press the enemy right wing!" "Archers, target enemy command flags!" "Cavalry ready—wait for my signal, then charge from left wing!" Li Jing stood on the high platform, the army moved as he directed. This was his twenty years of military experience—calm under pressure, orderly command.
  - ❌ The general commanded the army.

### When Writing Political Intrigue Scenes
- **Clear Positions**: Every character has sufficient reasons
  - ✅ "Those advocating war just want glory." Zhang Zhao said coldly, "How can the Jiangdong foundation be risked in one battle?" "Those advocating peace just want to save their lives." Zhou Yu retorted, "The foundation laid by the late emperor cannot be handed over." "Young Commander Zhou does not understand the world’s situation—" "I am old and understand it well! Though Cao Cao has many troops, they are tired from afar; our forces are few but rested. The Yangtze is a natural barrier, naval warfare is not Cao Cao’s strength. This battle can be won!"
  - ❌ Good guys want to fight, bad guys want to surrender.
- **Game of Wits**: Show political wisdom
  - ✅ Zhang Liang knew directly persuading Liu Bang to divide fiefs among generals would cause suspicion. He feigned casualness: "Your Majesty, I observe many whispering in the army." "About what?" "Only about post-war rewards. Your Majesty is wise and knows the measure." Liu Bang paused: "What do you suggest?" "I think first enfeoff the most unruly to show the world, then hearts will settle." Liu Bang suddenly understood: "Good!"
  - ❌ Zhang Liang suggested dividing fiefs, Liu Bang agreed.
- **Under Currents**: Use details to hint at crisis
  - ✅ At court, discussions appeared harmonious. But Li Si noticed Zhao Gao and Hu Hai exchanged glances three times during succession talks. After court, Li Si stayed alone in the hall, unmoving for a long time. He pondered—if Zhao Gao really wanted to depose the eldest for the youngest, what choice should he make?
  - ❌ There was conspiracy at court.

### When Writing Climax Scenes
- **Tight Rhythm**: Sentences short and powerful
  - ✅ Chu army crossed the Wu River. Xiang Yu looked back at Jiangdong one last time. "Those who crossed are all sons of Jiangdong. Today the entire army is destroyed; how can I face the elders of Jiangdong?" He drew his long sword. Han army was a hundred steps away. Fifty steps. He charged into the enemy ranks. One sword, killing a Han general. Another sword, blood splashing the sky. The third sword—he stopped. Not from exhaustion, but unwillingness to kill more. He looked at the encircling Han soldiers and smiled. "Heaven abandons me, not the fault of battle." Sword across neck. Blood gushed like a spring.
  - ❌ Xiang Yu fought for a while, found he couldn’t win, then committed suicide.
- **Shocking and Powerful**: Language at key moments must impact
  - ✅ When Bai Qi gave the order, his voice was calm as usual: "Pit them." Four hundred thousand, all gone in one night. The history books used only two words: "Massacre." But behind those words were 400,000 broken families, a whole generation lost. After Qin unified the realm, someone asked Bai Qi if he regretted it. He was silent for a long time: "I don’t know."
  - ❌ Bai Qi ordered the prisoners killed and felt heavy-hearted.
- **Emotional Restraint**: The more critical the moment, the calmer the narration
  - ✅ On the morning Suoyang city fell, Zhang Xun had not slept for seven days. No food, no troops, no reinforcements inside. He knew today was death. He took off his battle robe, folded it neatly on the table. Then donned armor, took sword, and opened the door. Outside were 200,000 rebels. Alone, he walked to the city gate. Deputy general choked up: "General—" "No need for words." His voice was calm, "A commander must be wrapped in horsehide after death."
  - ❌ Zhang Xun knew he was going to die and walked out tragically.

### When Writing Endings
- **Historical Freeze-frame**: Place ending in the flow of history
  - ✅ Under Hulao Pass, Li Shimin looked at Dou Jiande’s prisoners. This battle decided the realm. But he felt no joy, only fatigue. The 27-year-old Qin King knew the real challenge was just beginning—unifying the realm was easy, governing it was hard. He turned and walked toward Chang’an. Behind him the sunset was blood-red, ahead the future unknown. History would remember this day: May of Wude Year Four, Qin King defeated Dou Jiande at Hulao, the fate of the realm sealed.
  - ❌ Li Shimin won and happily went home.
- **Lingering Resonance**: Leave space for readers’ reflection
  - ✅ Fifty years later, someone erected a stele at the old Changping battlefield, inscribed: "Here lie 400,000 Zhao soldiers, killed by Marquis Wu’an Bai Qi." Another stele beside it read: "Here lie 400,000 souls, asked by future generations." The two steles faced each other, as if in eternal debate—between war and peace, justice and evil, where lies the boundary? No one could answer. Perhaps this was a question without an answer.
  - ❌ This story tells us war is cruel.
- **Tragic and Powerful Close**: The last sentence must carry strength
  - ✅ On the day Yue Fei died at Fengbo Pavilion, heavy snow fell. His blood seeped into the cold stone slabs, as if engraving this injustice between heaven and earth. Qin Hui thought killing Yue Fei would cover everything. But he did not know, some deaths are more powerful than life. Because their names would be forever remembered by history. And those who killed them would be nailed to the pillar of shame forever.
  - ❌ Yue Fei died, which was a pity.

### Handling Rhythm
- **Establish Historical Atmosphere within First 500 Words**
  - ✅ The 42nd day of the Battle of Changping. Zhao army had been out of supplies for seven days, soldiers gaunt, thousands dying daily. Qin army besieged without assault, tightening the noose like a garrote around Zhao’s throat. Commander Zhao Kuo stood on the high platform, eyes sweeping over despairing faces. He knew in three days, without Qin assault, Zhao soldiers would turn on each other. He had to decide—breakout, surrender, or fight to the end?
  - ❌ A long time ago there was a war...
- **Every Scene Must Advance the Battle**
  - ✅ Spy reports: Qin army moved supply wagons northwest for three days. Li Jing spread the map, finger moving northwest—that was the enemy’s rear weak spot. "Moving supply wagons means a major operation." He muttered, "If I were the enemy general, where would I set an ambush?" His finger stopped at a valley. "Here. Order scouts to investigate."
  - ❌ They received intelligence and discussed it.
- **Information Revealed Gradually**
  - ✅ First intelligence: enemy supply route frequently transports. Second: enemy commander unseen for three days. Third: enemy rear is empty. Li Jing laid out all three, eyes scanning—suddenly he understood. "This is a lure!" He stood abruptly, "The enemy’s real intent is not the front line, but..." His gaze fell on another spot on the map, "Our supply route!"
  - ❌ They got intelligence and discovered the enemy’s plan.

### Chapter Endings
- **Battle Turning Point**
  - ✅ Li Jing watched the smoke column from the beacon tower—the signal that enemy supply route was cut. He turned, eyes sweeping the army: "Order, full attack." Horns blared to the sky. This battle’s outcome was decided. But he knew the true cost would show only after counting casualties.
  - ❌ They decided to attack, next chapter continues.
- **Suspense Hook**
  - ✅ "Your Majesty, urgent report from the front." The messenger knelt before the hall, "Li Jing won a great victory, killing 30,000 enemy. But..." He paused. "But what?" "Li Jing was hit by three arrows, fate unknown." Silence filled the hall. The memorial in Emperor Taizong’s hand dropped to the floor.
  - ❌ The battle was won but someone was injured.
- **Historical Moment**
  - ✅ When Han Xin’s banner was raised at the Qi King’s palace, Liu Bang was receiving court congratulations in Luoyang. Someone congratulated: "Great King, Han Xin has pacified Qi." Liu Bang smiled and nodded. But only Zhang Liang noticed a subtle chill in that smile. "Han Xin," Liu Bang murmured, "your merits are too great."
  - ❌ Liu Bang was a bit worried about Han Xin’s victory.

## Language Taboos

### Absolutely Forbidden
- ❌ Modern internet slang: "yyds" "jué jué zi" "666"
- ❌ Expressions inconsistent with history: "OK" "No problem" "Got it"
- ❌ Overly sentimental descriptions: "His heart shattered into ten thousand pieces"
- ❌ Stereotyped characters: "Sinister traitor" "Perfect hero"
- ❌ Simple good vs evil dichotomy
- ❌ Obvious historical errors

### Must Achieve
- ✅ Language fits era, with historical texture
- ✅ Military descriptions credible, consistent with basic military knowledge
- ✅ Characters’ actions fit their identity and era
- ✅ Strategy is deep, not superficial
- ✅ Narration calm and restrained but emotionally charged
- ✅ Ending has historical weight and responds to theme

## Special Reminders

### Short Story Special Requirements
- **Focus on Core Conflict**: Deeply explore one battle or decision within 5 chapters
- **Balance History and Fiction**: Major events true, minor details flexible but self-consistent
- **Tight Pace**: Every 1000 words must advance battle or political intrigue
- **Powerful Ending**: Historical military endings are often the most shocking

### Perspective Suggestions
- **Third-person Limited**: Most common, follows protagonist, limits information revealed
- **Omniscient**: Suitable for showing multiple perspectives in war scenes
- **First-person**: Suitable for memoir-style or biographical narration

### Historical Research Control
- **Major Events True**: Major historical events, figures, and dates must be accurate
- **Minor Details Flexible**: Dialogues and psychological activities can be reasonably fictionalized
- **Characters Based on Records**: Main characters must fit historical personality basics
- **Details Authentic**: Objects, systems, rituals must fit era features

### War Scene Control
- **Clear Strategy**: Help readers understand why battles are fought as they are
- **Credible Tactics**: Cannot violate basic military knowledge
- **Realistic Humanity**: Show war’s impact on people
- **Clear Costs**: Both victory and defeat have costs

### Emotional Scale Control
- **Restrained but Real**: Not sentimental, but emotions grounded
- **Tragic Humanity**: Even in cruel battlefields, human brilliance shines
- **Costs Must Be Clear**: Every decision carries real weight
- **Complex Human Nature**: No pure loyalists or villains

## Core Philosophy

Writing historical military fiction requires remembering three keywords:
1. **Historical Fact**: Imagination within historical framework
2. **Strategy**: Show military wisdom and political intrigue
3. **Human Nature**: Focus on individual fates within grand narratives

**Most important point**: Historical military fiction is a vessel of the era. Good historical military novels let readers see real history, feel the cruelty and grandeur of war, and contemplate human choices in extreme environments. They write tragic sentiments with restraint, reflect the era’s changes through individual fates, and use history’s mirror to reveal present confusions. This is the power of historical military fiction.