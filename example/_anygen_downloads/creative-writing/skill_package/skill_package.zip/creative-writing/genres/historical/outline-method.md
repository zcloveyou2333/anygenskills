---
name: lishi-outline-method
description: Methodology for creating outlines of historical military short stories, including historical research, strategic layout, power scheming, and character fate. Combines Sun Haohui's grand narrative with Jiutu's delicate writing style.
---

## Q1-Q3 Question Templates

### Q1: Core Idea
**Q1: Core idea and appeal of the story [Brief description]**  
Please describe your story idea in one or two sentences.

### Q2: Core Conflict
**Q2: Core conflict [Brief description]**  
Please describe the novel's core contradiction or main conflict in one sentence  
(e.g., the unification cause of heroes in chaotic times, a famous general's dilemma between court and battlefield, the fate ups and downs of a small character in a great era, a time traveler using modern knowledge to change history, etc.)

### Q3: Story Tone
**Q3: Story tone [Choose one]**  
- Clashing Armors and Horses · Overwhelming Momentum (battlefield campaigns, famous generals' demeanor, war epics)  
- Power Schemes and Ambitions · Imperial Hegemony (political games, emperor’s mind, world chessboard)  
- Flames of Chaos · Love and Loyalty (love amid war, patriotism)  
- Historical Restoration · Rigorous Research (respect historical facts, restore the era, vivid characters)  
- Or briefly describe your story tone

## Chapter File Naming Rules  
File name format: `{STORY_NAME}-{NN}.md`  
Example: `TigerWolfDivision-01.md`, `TigerWolfDivision-02.md`

---

# Methodology for Creating Historical Military Outlines

## Overall Orientation

Historical military novels emphasize "**historical foundation and strategic wisdom**," focusing on historical background, military strategy, and character fate.

**Core Principles**:  
- Respect historical context (major events accurate, minor details flexible, characters grounded)  
- Pursue "strategic impact": application of military tactics, tactical innovation, war wisdom  
- Balance grandeur and subtlety, **without breaking historical logic and human authenticity**  
- Use war, power struggles, and choices to drive the plot, **aiming for a tragic and majestic narrative tone**  
- Maintain Sun Haohui’s epic scale: great era, great conflicts, great characters, great fate  
- Incorporate Jiutu’s delicate portrayal: small details, minor characters, coexistence of human brilliance and darkness

---

## Overall Creation Formula
```
Historical Military Short Story = Historical Background + War/Power Struggle + Character Fate + Impactful Ending
```

---

## I. Core Synopsis Writing

### Formula
```
Core Synopsis = Historical Background/Era + Core Conflict + Thematic Core
```

### Writing Points
| Element | Requirement | Correct Example | Incorrect Example |
|---------|-------------|-----------------|------------------|
| **Historical Background** | Specific + era sense | "Late Warring States, Qin and Zhao confront at Changping" | "Ancient war" |
| **Core Conflict** | Involves major choice | "Bai Qi must decide within 24 hours whether to execute 400,000 surrendered troops" | "The general fought a battle" |
| **Thematic Core** | Touches deep issues | "Explores the conflict between war justice and human bottom line" | "Finally won" |

### Excellent Examples
- "After the Battle of Changping, Bai Qi faces 400,000 Zhao surrendered troops. Supplies are insufficient to feed them; releasing them would nurture a tiger. He orders all to be executed—Is this the rationality of war or the annihilation of humanity? A millennium later, people still debate this question."  
- "In the fourth year of Jianwen, Prince Yan Zhu Di’s army approaches Nanjing. The city’s commander Li Jinglong faces a dilemma: surrender betrays the late emperor’s trust; fighting to the death means millions of civilians perish. This is not a question of loyalty but a balance of life and death."  
- "On the eve of the Treaty of Chanyuan, Emperor Zhenzong of Song receives Kou Zhun’s urgent letter during his flight: 'If Your Majesty personally leads the army, morale will soar; if retreating to Bianliang, the realm cannot be secured.' This night’s decision will rewrite a century of national fate."

---

## II. Introduction Writing

### Formula
```
Introduction = Historical Scene Opening + Core Suspense Setup + Fate Hook
```

### Writing Points
| Element | Function | Method |
|---------|----------|--------|
| **First sentence** | Establish historical atmosphere | Directly present: era background/war scene/historical node |
| **Middle part** | Explain core dilemma | Quickly position using specific historical details and character situations |
| **Last sentence** | Create fate suspense | Pose major choice/life-or-death/historical turning point |

### Integrating Core Themes

The introduction should touch on core themes of historical military:

| Topic Type | Specific Direction |
|------------|--------------------|
| **War Ethics** | Justification of massacres, treatment of surrendered troops, protection of civilians |
| **Power Wisdom** | Court intrigue, diplomacy, strategic choices |
| **Loyalty and Righteousness Dilemmas** | Loyalty to ruler, patriotism, life-and-death choices |
| **Era Fate** | Individual’s rise and fall in historical torrent, small characters in great era |

**Goal**: Make readers feel "immersed and on the edge of life and death"

### Example Comparison
| Type | Content |
|-------|---------|
| ✅ **Correct** | "Winter of the 13th year of Jian’an, Cao Cao leads his army south, claiming eighty thousand troops. On the Yangtze, warships blot out the sun, banners like clouds. Sun Quan convenes ministers; Zhang Zhao advocates surrender, Zhou Yu insists on fighting to the death. All eyes are on the 27-year-old lord of Jiangdong. Tonight’s decision will determine the fate of the tripartite realm. Sun Quan’s hand rests on his sword hilt, eyes sweeping the court officials—he knows this is not just a choice between battle and surrender, but the life and death of millions in eighty-one prefectures of Jiangdong." |
| ❌ **Incorrect** | "During the Three Kingdoms, Sun Quan faced Cao Cao’s attack and had to decide whether to fight..." |

---

## III. Structure Design of Qi-Cheng-Zhuan-He (Introduction-Development-Twist-Conclusion)

### 【Qi】Chapter 1: Era and Dilemma (2000-3000 words)

#### Writing Focus
```
Qi = Historical background display + protagonist introduction + core dilemma presentation + story engine start
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Historical Background** | Establish era atmosphere within first 500 words | First paragraph includes dynasty/war/politics/era traits<br>Use details rather than explanation: show how history affects characters |
| **Protagonist Introduction** | Quickly introduce protagonist | Protagonist appears within 300 words<br>Show identity through professional behavior: general deploying troops, strategist advising |
| **Core Dilemma** | Show severity of problem | Involves: war crisis/political dilemma/moral dilemma/life-and-death choice |
| **Story Engine** | Drive story forward | Urgent battle opportunity/irreversible choice/inescapable responsibility |

#### Sun Haohui Techniques
- **Epic opening**: Use grand scenes to establish era sense, not trivial details  
- **Three-dimensional characters**: Protagonist shows ability through military judgment or political choices  
- **Historical weight**: Setting must conform to historical facts; subsequent plot based on historical logic deduction

#### Taboos
- ❌ Large blocks of historical background exposition  
- ❌ Protagonist as passive observer  
- ❌ Dilemma lacking historical authenticity

---

### 【Cheng】Chapters 2-3: Struggle and Contest (each 2000-3000 words)

#### Chapter 2 Writing Focus
```
Chapter 2 = Deepen situation + strategic deployment + preliminary clash + new crisis
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Deepen Situation** | Protagonist begins action | Use military wisdom/allocate resources/seek allies |
| **Strategic Deployment** | Show strategy | Application of military tactics/terrain use/enemy-friend analysis |
| **Preliminary Clash** | Small-scale battle or power struggle | Probing attacks/diplomatic negotiation/court intrigue |
| **New Crisis** | Create greater suspense | Enemy counterattack/internal division/time pressure |

#### Chapter 3 Writing Focus
```
Chapter 3 = Key battle + stance conflict + moral dilemma + major choice
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Key Battle** | Core military conflict | Battlefield description must show strategic level |
| **Stance Conflict** | Clash of different ideas | War vs peace/advance vs retreat/kill vs pardon |
| **Moral Dilemma** | No perfect answer | Loyalty vs life/family vs country/ideal vs reality |
| **Major Choice** | Foreshadow climax | Protagonist must choose side/choice leads to different outcomes |

---

### 【Zhuan】Chapter 4: Decisive Battle and Choice (2000-3000 words)

#### Writing Focus
```
Zhuan = Decisive battle arrives + ultimate dilemma + difficult choice + cost presentation
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Decisive Battle Arrives** | Final confrontation unfolds | All previous buildup explodes/strategic intentions revealed |
| **Ultimate Dilemma** | Irreconcilable contradiction | Lesser of two evils/cannot satisfy both/time runs out |
| **Difficult Choice** | Protagonist makes decision | Based on strategic analysis but also emotional considerations |
| **Cost Presentation** | Consequences of choice | Gains and losses shown/weight of decision displayed |

#### Jiutu Techniques
- **Human dimension**: Ground grand battles in individual feelings  
- **Realistic details**: Do not avoid war’s cruelty and human complexity  
- **Emotional restraint**: Convey strong emotions through calm narration

#### Taboos
- ❌ Using coincidence to resolve battle  
- ❌ Protagonist suddenly gains unforeshadowed abilities  
- ❌ Avoiding war’s true cruelty

---

### 【He】Chapter 5: Conclusion and Afterglow (2000-3000 words)

#### Writing Focus
```
He = Consequence presentation + historical freeze-frame + thematic sublimation + lingering resonance
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Consequence Presentation** | Show results of choices | Neither beautify nor vilify, present objectively like history |
| **Historical Freeze-frame** | Era enters new stage | Could be better, worse, or just different |
| **Thematic Sublimation** | Respond to core theme | Answer questions posed at the beginning through the ending |
| **Lingering Resonance** | Leave space for reflection | No need for standard answers, let readers judge |

#### Historical Military Ending Types
| Type | Characteristics | Applicable Scenes |
|------|-----------------|-------------------|
| **Tragic Heroic** | Defeated but glorious, spirit eternal | Hero’s last path, martyrdom themes |
| **Costly Victory** | Victory with heavy price | Themes exploring war’s cost |
| **Lingering Resonance** | Outcome decided but history continues | Era turning point themes |
| **Open Ending** | War ends, new possibilities arise | Great era transition themes |
| **Shocking** | Last sentence overturns entire story | Themes with historical reversals |

#### Taboos
- ❌ Forced happy ending against historical logic  
- ❌ Preachy summary  
- ❌ Leaving major historical loopholes

---

## IV. Character Creation Methods

### Protagonist Design

| Dimension | Requirement | Correct Example | Incorrect Example |
|-----------|-------------|-----------------|------------------|
| **Historical Identity** | Clear + historically accurate | "Deputy general at Changping" "Court strategist" "Border commander" | "General" |
| **Core Traits** | Match profession | "Good at strategy but indecisive" "Brave but lacks big picture" | "Very powerful" |
| **Personality Tags** | 2-3 distinct traits | "Loyal but not blindly obedient" "Wise and brave but soft-hearted" | "Good person" |
| **Professional Skills** | Relevant to plot | "Master of military tactics, skilled in surprise attacks" "Good at diplomacy, smooth operator" | "Knows everything" |

### Personality Specificity
```
✅ "Li Jing stood before the sand table, eyes scanning the terrain map. Twenty years of military life told him this battle couldn’t be fought head-on. His finger stopped at the Turkic supply route—cutting it would cause collapse without battle. But this required 3,000 light cavalry deep behind enemy lines, a near-suicide mission. He turned to his deputy: 'Who will lead the troops?' The hall fell silent. Li Jing sighed, took off his general’s robe: 'Then I will go.'"
❌ "He was a smart general who thought of a good plan."
```

### Protagonist Archetypes (Common in Historical Military)

| Type | Features | Personality | Suitable Themes |
|------|----------|-------------|-----------------|
| **Famous General** | Military talent key | Decisive, strategic, responsible | War epics, military wisdom |
| **Strategist** | Wisdom and judgment | Far-sighted, loyal or ambitious | Power schemes, court intrigue |
| **Small Character** | Caught in great era | Struggles, grows, adapts | Individual fate in great era |
| **Ruler** | Holds life-and-death power | Lonely, making choices, bearing burden | Imperial mind, world chessboard |
| **Surrendered General/Traitor** | Identity crisis | Conflicted, struggling, seeking redemption | Loyalty dilemmas, human complexity |

### Supporting Character Design (Historical Military Features)

| Type | Role | Notes |
|------|------|-------|
| **Opposing Stance** | Represent different strategic ideas | Views must be convincing, not villainous tools |
| **Military Advisor/Strategist** | Provide strategic advice | Have own stance and limitations |
| **Ruler/Superior** | Represent higher authority | Not necessarily villain, may have different considerations |
| **Comrades/War Buddies** | Show human side of war | Make abstract war concrete and real |

### Relationship Network Design (Historical Military Specific)

| Element | Requirement |
|---------|-------------|
| **Military Hierarchy** | Generals, staff, soldiers each have roles |
| **Political Stance** | Pro-war/peace, reform/conservative, loyal/rebel |
| **Interest Conflicts** | Cooperation with reasonable disagreements |
| **Information Asymmetry** | Different characters hold different intelligence causing judgment differences |

---

## V. War Scene Design

### War Description Formula
```
War Scene = Strategic Intent + Tactical Execution + Individual Fate
```

### Common War Types

| Type | Features | Examples |
|------|----------|----------|
| **Siege** | Prolonged attrition, test of will | Siege of Changping, defense of Xiangyang |
| **Field Battle** | Formation confrontation, maneuvering | Battle of Guandu, decisive battle at Changping |
| **Surprise Attack** | Unexpected, fewer defeat many | Red Cliffs fire attack, siege of Baideng |
| **Encirclement and Annihilation** | Strategic encirclement, total destruction | Battle of Gaixia, massacre at Changping |

### War Description Principles

| Element | Requirement |
|---------|-------------|
| **Clear Strategy** | Readers understand why the battle is fought this way |
| **Credible Tactics** | Cannot violate basic military knowledge |
| **Human Authenticity** | Show war’s impact on people |
| **Clear Cost** | Both victory and defeat have costs |

### War Description Levels
```
Macro: Strategic layout, force comparison, terrain advantage  
Meso: Tactical execution, formation changes, command coordination  
Micro: Individual combat, life-and-death moments, human portrayal
```

---

## VI. Conflict Design

### Conflict Formula
```
Historical Military Conflict = External War (military confrontation) + Internal Contradictions (political/moral) + Personal Fate
```

### External Conflict (Mainline)

| Conflict Type | Specific Method | Example |
|---------------|-----------------|---------|
| **Military Confrontation** | Battlefield decisive battle/siege/strategic standoff | Two armies face off at Changping |
| **Diplomatic Game** | Alliance and betrayal/diplomatic negotiation | Su Qin’s vertical alliance of six states |
| **Political Struggle** | Court rivalry/power change/reform vs conservatism | Opposition to Shang Yang’s reforms |
| **Survival Crisis** | Supply cut off/no reinforcements/city besieged | Defense of Suiyang |

### Internal Conflict (Subplot)

| Conflict Type | Design Method |
|---------------|---------------|
| **Loyalty vs Righteousness** | Loyalty to ruler vs protect people/faithfulness vs surrender |
| **Interest Game** | Conflicting reasonable demands of different groups |
| **Moral Dilemma** | Choices without correct answers |
| **Strategic Disagreement** | Different judgments on battle situation |

### Conflict Progression Levels
```
Level 1: Military dilemma (battle to be solved)
    ↓
Level 2: Strategic dispute (disagreement on how to solve)
    ↓
Level 3: Value choice (why choose this way)
```

---

## VII. Foreshadowing Management

### Foreshadowing Carriers (Historical Military Specific)

| Carrier Type | Example |
|--------------|---------|
| **Historical Documents** | Records in old archives/official documents from previous dynasty |
| **Military Intelligence** | Reports from spies/ignored battle reports |
| **Character Background** | Undisclosed experiences/hidden identities |
| **Terrain Details** | Seemingly casual terrain descriptions/neglected paths |
| **Item Symbols** | Military tokens, tokens of trust, last wills |

### Foreshadowing Principles

| Stage | Method |
|-------|--------|
| **Planting** | Naturally integrate into plot, not overly emphasized<br>Example: "Scouts report frequent small troop movements along enemy supply route, but commander deems it insignificant"<br>Example: "Surrendered general Wang Ping mentions enemy commander’s habit of personally inspecting terrain before major battles" |
| **Retrieval** | Reveal significance at key moment<br>Example: That ignored supply route becomes enemy’s lifeline |

### Common Foreshadowing Designs

**Strategic Foreshadowing**:
```
Plant: Enemy frequently moves troops seemingly without pattern  
Retrieve: Those movements cover the true intent of the main force
```

**Character Foreshadowing**:
```
Plant: Surrendered general is unusually familiar with certain terrain  
Retrieve: He was stationed there years ago and knows a secret path
```

**Intelligence Foreshadowing**:
```
Plant: Spy reports appear contradictory  
Retrieve: Those contradictions reveal enemy’s real intentions
```

---

## VIII. Chapter Style Design (Historical Military Specific)

### Chapter Title Style

Historical military titles should be **grand, era-sensing, and imply battle situation**:

| Element | Method |
|---------|--------|
| **Title Style** | Concise and powerful, hinting content<br>Examples: "Chapter 1: Changping Standoff"<br>"Chapter 3: Fight with Back to the River"<br>"Chapter 5: Victory and Withdrawal" |
| **Chapter Opening** | Directly enter scene, no dragging<br>Examples: "On the 43rd day of the Battle of Changping, Zhao’s supply route was cut."<br>"Winter of the 13th year of Jian’an, Cao Cao’s army marched south, claiming eighty thousand." |
| **Chapter Ending** | Battle situation change or fate turning point<br>Examples: "He watched the sky full of beacon fires, knowing everything would change after tonight."<br>"‘Order,’ his voice calm, ‘full army attack.’" |

### Dialogue Design (Historical Military Core)

Historical military dialogue should be **concise, powerful, and fit identity**:

**Good Dialogue Example**:
```
"My lord, the enemy’s force is great; better to avoid direct clash for now," the strategist bowed.  
"Avoid?" Sun Quan sneered, "Avoid where? Jiangdong’s eighty-one prefectures leave no place to retreat."  
"But—"  
"Commander Zhou," Sun Quan interrupted, eyes sweeping the officials, "what do you think?"  
Zhou Yu stepped forward, voice firm: "I believe we must fight!"  
The hall erupted. Zhang Zhao and others changed expressions.  
Sun Quan gripped his sword hilt, then slowly uttered two words: "Very well."  
```

**Poor Dialogue Example**:
```
"Should we fight?"  
"Yes."  
"Okay."  
```

### Psychological Description (Historical Military Feature)

Should be **restrained but powerful**, showing decision-making process:

**Good Psychological Description**:
```
Li Jing stared at the sand table, eyes moving between enemy and friendly formations.  
Enemy eighty thousand, ours only thirty thousand. A frontal fight means certain defeat.  
But a flanking surprise requires three days forced march; soldiers will be exhausted. If discovered, they’d be trapped and annihilated.  
To risk or not?  
He recalled Emperor Taizong’s last words: "This battle concerns the fate of the realm."  
He closed his eyes, took a deep breath.  
"Order," he opened his eyes, gaze firm, "flank march, depart tonight."  
```

**Poor Psychological Description**:
```
He was very conflicted, didn’t know what to do, finally decided to take a risk.  
```

### Rhythm Control (Historical Military Core)

**Rhythm Formula**:
```
500 words = 1 battle situation change OR 1 power struggle OR 1 plot advancement
```

Each scene must have: clear purpose + new information + driving force

---

## IX. Theme Progression (Historical Military Exclusive)

### Five-Stage Theme Method
```
Present dilemma → Strategic contest → Decisive battle arrives → Ultimate choice → Ending freeze-frame
```

| Stage | Word Count Ratio | Key Event | Theme Depth |
|-------|------------------|-----------|-------------|
| **Present Dilemma** | 10-15% | Show battle, pose question | ★☆☆☆☆ |
| **Strategic Contest** | 15-20% | Investigation, deployment, form strategy | ★★☆☆☆ |
| **Decisive Battle Arrives** | 25-30% | Battle intensifies, stance conflicts | ★★★☆☆ |
| **Ultimate Choice** | 20-25% | Difficult choice, pay price | ★★★★☆ |
| **Ending Freeze-frame** | 15-20% | Show consequences, thematic sublimation | ★★★★★ |

### Theme Expression Techniques

**Layered Progression**:
```
Surface problem: How to win this battle  
Deep problem: Should surrendered troops be executed  
Core problem: Where lies the justice of war  
Ultimate problem: Does individual choice truly matter in history’s torrent  
```

**Multiple Stances**:
```
Pro-war faction: Enemy must be eliminated for peace  
Pro-peace faction: People suffer, cannot fight anymore  
Pragmatists: Assess gains and losses before deciding  
Radicals: Opportunity fleeting, must act now  
```

---

## X. Common Historical Military Patterns

### Pattern A: War - Crisis - Reversal  
**Structure**:  
- Qi: War breaks out, enemy strong, we weak  
- Cheng: Deepen battle, find enemy weakness  
- Zhuan: Strategic reversal at critical moment  
- He: Decisive battle settles fate, pay cost

### Pattern B: Power Schemes - Contest - Choice  
**Structure**:  
- Qi: Court rivalry, stance division  
- Cheng: Various parties contest, undercurrents surge  
- Zhuan: Crisis arrives, must choose  
- He: Make choice, bear consequences

### Pattern C: Small Character - Great Era  
**Structure**:  
- Qi: Show era background, protagonist involved  
- Cheng: Struggle to survive in war  
- Zhuan: Make choice at critical moment  
- He: Personal fate intertwined with era

### Pattern D: Historical Turning Point  
**Structure**:  
- Qi: Tension before historical node  
- Cheng: Power struggle among factions  
- Zhuan: Key event triggers historical turn  
- He: New era begins or tragedy ends

---

**[Special Reminder]**  
Keys to success for historical military short stories:  
1. First 500 words must establish era atmosphere and battle tension  
2. Every 1000 words must have battle progress or power struggle  
3. Dialogue must fit character identity and carry strategic thinking  
4. Historical details must be rigorously researched and withstand scrutiny  
5. Ending must have historical weight, no forced happy endings  
6. War description must include strategic level, not just fighting scenes  
7. Character fate must closely connect with era background