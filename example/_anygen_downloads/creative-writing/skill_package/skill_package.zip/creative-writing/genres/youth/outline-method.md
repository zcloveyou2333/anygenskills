---
name: qingchun-outline-method
description: Methodology for creating outlines of youth campus short stories, including core synopsis extraction, lead design, plot structure planning, and character shaping guidance. Integrates the creative essence of Rao Xueman and August Chang'an.
---

## Q1-Q3 Question Templates

### Q1: Core Idea
**Q1: Core idea and appeal of the story [Brief description]**  
Please describe your story idea in one or two sentences.

### Q2: Core Conflict
**Q2: Core conflict [Brief description]**  
Please describe the novel’s core contradiction or main conflict in one sentence  
(e.g., the comeback journey of a top student and a failing student, friendship and competition in a campus club, confessing a long-time crush finally mustering courage, the growth and reconciliation of a rebellious teenager, etc.)

### Q3: Story Tone
**Q3: Story tone [Choose one]**  
- Youthful pure love · Heart-fluttering (first love sentiment, innocent excitement, beautiful and pure)  
- Passionate and inspiring · Dream-chasing youth (struggle and effort, dreams come true, sweating hard)  
- Joyful and humorous · Campus daily life (lighthearted humor, cheerful banter, healing and stress relief)  
- Growth and transformation · Youth scars (pain of growth, confusion and bewilderment, breaking out of cocoon)  
- Or please briefly describe your story tone

## Chapter File Naming Rules  
Filename format: `{STORY_NAME}-{NN}.md`  
Example: `ThoseYears-01.md`, `ThoseYears-02.md`

---

# Youth Campus Outline Creation Methodology

## Overall Orientation

Youth campus novels emphasize "**sincere emotions and resonant growth**," centering on campus life, youthful emotions, and transformative growth.

**Core Principles**:  
- Focus on youth themes (friendship, first love, dreams, growth, confusion, rebellion, etc.)  
- Pursue "emotional resonance": authentic, delicate, innocent, heart-fluttering  
- Balance sweetness and heartbreak, but **do not stray from realistic campus life and adolescent psychology**  
- Use emotions, events, and choices to drive the plot, **aiming for a fresh and delicate narrative tone**  
- Maintain Rao Xueman’s emotional depth: heartbreaking but not melodramatic, painful growth  
- Incorporate August Chang'an’s pure beauty: heart-fluttering, youth without regrets, peaceful times

---

## Overall Creation Formula
```
Youth Campus Short Story = Campus Setting + Emotional Conflict + Growth Insight + Warm/Regretful Ending
```

---

## 1. Core Synopsis Writing

### Formula
```
Core Synopsis = Campus Background/Character Relationships + Emotional Conflict + Growth Theme
```

### Writing Points
| Element | Requirement | Correct Example | Incorrect Example |
|---------|-------------|-----------------|-------------------|
| **Campus Background** | Specific + immersive | "Summer in the second year liberal arts class" | "At school" |
| **Emotional Conflict** | Involves youth choices | "The boy she secretly likes likes her best friend" | "They had a quarrel" |
| **Growth Theme** | Touches growth pain points | "Learning to let go is also a kind of fulfillment" | "In the end, they grew up" |

### Excellent Examples
- "In the last semester of senior year, top student Lin Chuxia has secretly liked the school heartthrob for three years but never dared to confess. When she finally gathers courage to write a love letter, she discovers he likes her best friend Su Xiaomo. Should she fulfill their love or bravely express her feelings?"  
- "Transfer student Lu Zhi’ang is rebellious and at the bottom of the class, but unexpectedly becomes deskmates with class monitor Sheng Huainan. Influenced by him, Lu Zhi’ang begins to change but also discovers the loneliness hidden beneath Sheng Huainan’s perfect exterior. Two completely different boys redeem each other in their last year of high school."  
- "Freshman Li Xiang joins the school basketball team and meets the legendary captain Gu Mingyang. From admiration to secret crush, from teammates to friends, she accompanies him for three years, only to find out on his graduation day that he had always known her feelings."

---

## 2. Lead Writing

### Formula
```
Lead = Campus Scene Opening + Emotional Suspense Setup + Growth Hook
```

### Writing Points
| Element | Function | How to Write |
|---------|----------|--------------|
| **First sentence** | Establish campus atmosphere | Directly show: classroom, playground, season, campus details |
| **Middle part** | Explain character relationships | Use youthful language to quickly position protagonist and key characters |
| **Last sentence** | Create emotional suspense | Throw out a dilemma/entanglement/growth problem |

### Incorporating Emotional Themes

The lead should touch on core youth campus themes:

| Topic Type | Specific Directions |
|------------|---------------------|
| **First Love Sentiment** | Secret crush, confession, heart-fluttering, regret, missed opportunities |
| **Friendship Test** | Deep friendship, brotherhood, betrayal, misunderstanding, reconciliation |
| **Pain of Growth** | Rebellion, confusion, pressure, choices, transformation |
| **Dream Pursuit** | College entrance exam, competitions, clubs, arts, sports |

**Goal**: Make readers resonate with "This is my youth" (emotional immersion)

### Sample Comparison
| Type | Content |
|-------|---------|
| ✅ **Correct** | "That summer, cicadas chirped endlessly atop the phoenix trees. In the second-year liberal arts classroom, Lin Chuxia lay on her desk, secretly peeking through her fingers at Lu Zhi’ang sitting in the front row. Sunlight streamed through the window, casting beautiful shadows on his profile. She counted the days in her heart—367 days left until the college entrance exam countdown. After 367 days, she might never have the courage to say that sentence. So this time, she decided not to be a coward. But when she finally mustered the courage to write that letter, she saw him holding Su Xiaomo’s hand around the stairwell corner." |
| ❌ **Incorrect** | "There was a girl at school who liked a boy, but the boy liked someone else, and she was very sad..." |

---

## 3. Plot Structure Design (Qi Cheng Zhuan He)

### 【Qi】Chapter 1: Youth Opening (2000-3000 words)

#### Writing Focus
```
Qi = Campus Scene + Protagonist Introduction + Character Relationships + Emotional Seeds
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Campus Scene** | Establish campus atmosphere within first 500 words | First paragraph includes: classroom/playground/hallway/seasonal feel<br>Use details instead of exposition: show real campus life |
| **Protagonist Introduction** | Quickly introduce protagonist | Protagonist appears within 300 words<br>Show personality through actions: top student solving problems, failing student sleeping |
| **Character Relationships** | Show key character network | Deskmate, best friend, crush, rival |
| **Emotional Seeds** | Plant emotional clues | A look/help/phrase/misunderstanding |

#### Youthful Techniques
- **Campus Details**: Use authentic campus elements to create atmosphere  
- **Youthful Thoughts**: Show adolescent psychology through inner monologue  
- **Lively Language**: Dialogue should match student speech style

#### Taboos
- ❌ Long preachy character introductions  
- ❌ Protagonist is a flawless Mary Sue  
- ❌ Plot lacks realistic campus feel

---

### 【Cheng】Chapters 2-3: Emotional Fermentation (2000-3000 words each)

#### Chapter 2 Writing Focus
```
Chapter 2 = Relationship Deepening + Heart-fluttering Moments + Bittersweet + New Turbulence
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Relationship Deepening** | More interactions between protagonist and key characters | Deskmate daily life/club activities/studying together |
| **Heart-fluttering Moments** | Create heart-fluttering scenes | Detailed description/psychological activity/environmental setting |
| **Bittersweet** | Sweetness mixed with pain | Misunderstandings/coincidences/third party appearance |
| **New Turbulence** | Create bigger suspense | Confession opportunity/friendship crisis/external pressure |

#### Chapter 3 Writing Focus
```
Chapter 3 = Emotional Climax + Friendship Test + Inner Struggle + Difficult Choice
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Emotional Climax** | Emotional line reaches critical point | Confession/rejection/truth discovery/misunderstanding deepens |
| **Friendship Test** | Conflict between friendship and love | Best friend likes the same person/brothers fall out over love |
| **Inner Struggle** | Show youth’s entanglement | To speak or not/to fight or to give up |
| **Difficult Choice** | Set up climax | Protagonist must make a choice |

---

### 【Zhuan】Chapter 4: Growth Turning Point (2000-3000 words)

#### Writing Focus
```
Zhuan = Conflict Explosion + Emotional Setback + Growth Epiphany + Brave Change
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Conflict Explosion** | All problems erupt at once | Misunderstandings revealed/confession fails/friendship breaks |
| **Emotional Setback** | Protagonist experiences setbacks | Crying/avoidance/doubt/confusion |
| **Growth Epiphany** | Realize in pain | Understand true meaning of love/preciousness of friendship/meaning of growth |
| **Brave Change** | Protagonist makes a change | Apology/confession/letting go/chasing dreams |

#### Youth Growth Techniques
- **Real Pain**: Do not avoid the pain of growing up  
- **Delicate Psychology**: Show adolescent sensitivity and subtlety  
- **Glimmer of Hope**: Keep a trace of warmth in the darkness

#### Taboos
- ❌ Using coincidences to resolve all problems  
- ❌ Protagonist suddenly changes personality drastically  
- ❌ Avoiding the real cost of growth

---

### 【He】Chapter 5: Youth Epilogue (2000-3000 words)

#### Writing Focus
```
He = Ending Presentation + New Relationship Status + Growth Sublimation + Youth Aftertaste
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Ending Presentation** | Show result of choices | Not necessarily perfect, but must be sincere |
| **New Relationship Status** | Characters enter new relationship state | Together/become friends/grow separately |
| **Growth Sublimation** | Respond to core theme | Answer the questions raised at the beginning through the ending |
| **Youth Aftertaste** | Leave room for reflection | Graduation/parting/reunion/time passing |

#### Youth Ending Types
| Type | Features | Suitable Scenes |
|------|----------|-----------------|
| **Perfect Ending** | Lovers unite, dreams realized | Pure love sweet stories, inspirational |
| **Regretful Ending** | Missed/separated, but growth is more important | Growth themes, youth scars |
| **Open Ending** | Future hopeful, leaves imagination | Realistic, time passing |
| **Warm Ending** | Though with regrets, hearts are grateful | Friendship first, youth without regrets |

#### Taboos
- ❌ Forcing a happy ending against prior buildup  
- ❌ Melodramatic twists  
- ❌ Rushed ending without emotional closure

---

## 4. Character Shaping Methods

### Protagonist Design

| Dimension | Requirement | Correct Example | Incorrect Example |
|-----------|-------------|-----------------|-------------------|
| **Student Identity** | Clear + realistic | "Second-year liberal arts top student" "Freshman basketball team substitute" | "Student" |
| **Core Traits** | 2-3 distinct features | "Cold exterior but warm inside" "Optimistic but lacking confidence" | "A good person" |
| **Personality Tags** | Fit adolescent traits | "Sensitive and delicate" "Rebellious and unruly" "Gentle and kind" | "Perfect without flaws" |
| **Growth Space** | Has flaws and room to grow | "Timid but yearns to be brave" "Rebellious but wants to be understood" | "Knows everything" |

### Personality Specificity
```
✅ "Lin Chuxia lay on the desk, hiding her face behind a book. Her ears were flushed red, heart pounding as if about to jump out of her chest. When Lu Zhi’ang said 'morning' just now, his voice was so pleasant. She secretly peeked at his profile through her fingers; the sunlight just hit his high nose bridge perfectly. Damn, she was going to be distracted the whole class again."  
❌ "She is a girl who likes him and is very shy."
```

### Protagonist Archetypes (Common Youth Types)

| Type | Features | Personality | Suitable Themes |
|-------|----------|-------------|-----------------|
| **Top Student** | Excellent grades, disciplined | Introverted, sensitive, perfectionist | First love, growth, pressure |
| **Underachiever** | Poor grades but shining points | Optimistic, rebellious, sincere | Comeback, change, redemption |
| **Ordinary** | Unremarkable but thoughtful | Kind, tolerant, secret crush | Secret crush, friendship, growth |
| **Energetic** | Cheerful, popular | Enthusiastic, straightforward, brave | Friendship, chasing dreams, youth |
| **Artistic** | Sensitive, talented | Introverted, romantic, idealistic | First love, dreams, regrets |

### Supporting Character Design (Youth Features)

| Type | Role | Notes |
|-------|------|-------|
| **Best Friend/Brother** | Provide support and contrast | Have their own personalities and storylines |
| **Crush** | Core of emotional line | Three-dimensional and realistic, not a perfect idol |
| **Rival** | Create conflict | Not necessarily bad, may also be sympathetic |
| **Teacher** | Provide guidance | Understand students, not stereotypical strict teachers |

### Relationship Network Design (Youth Specific)

| Element | Requirement |
|---------|-------------|
| **Friendship Line** | Deep friendship/brotherhood but with friction and growth |
| **Romance Line** | Secret crush/open love/triangle, fitting student psychology |
| **Teacher-Student Line** | Understanding or misunderstanding, intergenerational communication |
| **Classmate Line** | Competition or cooperation, class ensemble |

---

## 5. Campus Element Design

### Scene Construction Formula
```
Youth Campus = Realistic Scene + Emotional Memory + Era Characteristics
```

### Common Scene Types

| Type | Features | Examples |
|-------|----------|----------|
| **Classroom Scene** | Most common and important | Peeking during class/passing notes/exams/self-study |
| **Playground Scene** | Youthful vitality | Basketball court/track/sports meet |
| **Campus Corners** | Private spaces | Rooftop/stairwell/small woods/library |
| **Off-campus Scene** | Extended spaces | Convenience store/milk tea shop/on the way home |

### Time Node Design

| Element | Requirement |
|---------|-------------|
| **Seasonal Feel** | School start/midterm/final/graduation season |
| **Festival Feel** | Sports meet/cultural festival/exam season |
| **Time Feel** | Freshman/sophomore/senior, growth trajectory |

---

## 6. Conflict Design

### Conflict Formula
```
Youth Conflict = External Pressure (academics/family/society) + Internal Contradiction (emotion/friendship/dreams) + Growth Pains
```

### External Conflicts (Main Line)

| Conflict Type | Specific Methods | Examples |
|---------------|------------------|----------|
| **Academic Pressure** | Exams/grades/advancement | College entrance exam countdown/grade drop/science vs arts track |
| **Family Pressure** | Parental expectations/family changes | Tiger parenting/divorce/financial difficulties |
| **Emotional Entanglement** | Secret crush/confession/triangle | Liking the same person/rejection/misunderstanding |
| **Friendship Crisis** | Misunderstanding/betrayal/competition | Best friends falling out/brothers quarrel/trust collapse |

### Internal Conflicts (Subplot)

| Conflict Type | Design Method |
|---------------|---------------|
| **Self-awareness** | Not knowing what one wants/inferiority/confusion |
| **Value Conflict** | Friendship vs love/dream vs reality |
| **Growth Pains** | Saying goodbye to childhood/learning to let go/accepting imperfection |

### Conflict Progression Levels
```
Level 1: External events (exam/confession/misunderstanding)
    ↓
Level 2: Relationship crisis (friendship/love/trust)
    ↓
Level 3: Inner growth (learning to choose/brave confrontation/letting go for fulfillment)
```

---

## 7. Foreshadowing Management

### Foreshadowing Carriers (Youth Specific)

| Carrier Type | Examples |
|--------------|----------|
| **Object Foreshadowing** | Love letters/notebooks/bracelets/photos |
| **Dialogue Foreshadowing** | Casual remarks/promises/secrets |
| **Behavior Foreshadowing** | Abnormal actions/habitual gestures |
| **Emotional Foreshadowing** | Looks/blushing/avoidance |

### Foreshadowing Setting Principles

| Stage | Method |
|-------|--------|
| **Planting** | Naturally integrated into daily life, not emphasized<br>Example: "He always slows down when passing her seat"<br>Example: "The notebook’s title page had a name, then was scribbled out" |
| **Payoff** | Reveal meaning at key moments<br>Example: He had always known where her seat was<br>Example: The scribbled-out name was him |

### Common Foreshadowing Designs

**Emotional Foreshadowing**:
```
Planting: He is always the first to arrive in the classroom, she is always the last to leave  
Payoff: Turns out he was waiting for her, and she had always known
```

**Friendship Foreshadowing**:
```
Planting: Best friend has been distracted lately, smiles when phone rings  
Payoff: She also likes the same person
```

**Growth Foreshadowing**:
```
Planting: She always says she’s a coward  
Payoff: In the end, she bravely said that sentence
```

---

## 8. Chapter Style Design (Youth Specific)

### Chapter Title Style

Youth titles should be **fresh, emotional, and resonant**:

| Element | Method |
|---------|--------|
| **Title Style** | Concise with emotion, hint at content<br>Example: "Chapter 1 That Summer"<br>Example: "Chapter 3 Words Unspoken"<br>Example: "Chapter 5 Goodbye, Seventeen" |
| **Chapter Opening** | Directly enter the scene, strong immersion<br>Example: "When the cicadas started chirping, Lin Chuxia was lying on the desk secretly watching Lu Zhi’ang."<br>Example: "That was the last summer of sophomore year; we didn’t know how close the farewell was." |
| **Chapter Ending** | Emotional hook or suspense<br>Example: "She watched his departing back, finally unable to say that sentence."<br>Example: "That letter, she eventually put into the drawer." |

### Dialogue Design (Youth Core)

Youth dialogue should be **realistic, lively, and emotional**:

**Good Dialogue Example**:
```
"Hey, Lu Zhi’ang, what kind of girl do you like?" Su Xiaomo asked.  
Lu Zhi’ang paused, looking out the window: "I don’t know."  
"Then do you like Lin Chuxia?"  
His hand hesitated: "Why do you ask?"  
"Nothing," Su Xiaomo smiled, "just curious."  
Lin Chuxia lay on the desk, pretending to sleep. Her palms were sweaty, ears perked up.  
"She... is a good girl," Lu Zhi’ang said.  
Lin Chuxia’s heart sank. "Good girl"—those three words were even crueler than rejection.
```

**Poor Dialogue Example**:
```
"I like you."  
"I like you too."  
"Then let’s be together."  
"Okay."
```

### Psychological Description (Youth Feature)

Should be **delicate but not pretentious**, showing youthful thoughts:

**Good Psychological Description**:
```
Lin Chuxia watched Lu Zhi’ang’s back, heart pounding fast. She wanted to call him back, to say that sentence, to tell him how much she liked him these three years. But she opened her mouth and said nothing in the end.  
She was afraid. Afraid he would say "Sorry," afraid he would say "We’re just friends," afraid of his awkward expression.  
Not saying, at least they could still be friends. Saying it, they might not even be friends.  
She comforted herself like this.  
But tears still fell.
```

**Poor Psychological Description**:
```
She liked him very much but was too shy to say it, so she was sad.
```

### Rhythm Control (Youth Core)

**Rhythm Formula**:
```
500 words = 1 emotional point OR 1 interaction OR 1 scene transition
```

Each scene must have: clear emotional goal + character interaction + driving force

---

## 9. Emotional Progression (Youth Exclusive)

### Five-stage Emotional Method
```
First meeting/secret crush → Approaching/heart-fluttering → Deepening/bittersweet → Conflict/setback → Growth/perfect or regretful ending
```

| Stage | Word Count Ratio | Key Events | Emotional Depth |
|-------|------------------|------------|-----------------|
| **First Meeting/Secret Crush** | 15-20% | First encounter, heart starts fluttering | ★☆☆☆☆ |
| **Approaching/Heart-fluttering** | 20-25% | Relationship gets closer, bittersweet moments | ★★☆☆☆ |
| **Deepening/Bittersweet** | 25-30% | Emotion heats up but with waves | ★★★☆☆ |
| **Conflict/Setback** | 20-25% | Misunderstandings erupt, emotional crisis | ★★★★☆ |
| **Growth/Ending** | 15-20% | Growth insight, relationship solidifies | ★★★★★ |

### Emotional Expression Techniques

**Layered Progression**:
```
Surface: He treats her well  
Deeper: He treats her especially well  
Core: He has always known her feelings  
Truth: He likes her too, just doesn’t know how to say it
```

**Multiple Perspectives**:
```
Female lead’s view: Does he like me too?  
Male lead’s view: Will she notice my feelings?  
Best friend’s view: They obviously like each other, why don’t they say it?  
Observer: Youth is so beautiful and regretful like this
```

---

## 10. Common Youth Patterns

### Pattern A: Secret Crush - Confession - Growth  
**Structure**:  
- Qi: Secret crush begins, cautious  
- Cheng: Relationship approaches, heart-fluttering deepens  
- Zhuan: Gathers courage, confession or miss  
- He: Growth insight, perfect or regretful ending

### Pattern B: Friendship - Love - Choice  
**Structure**:  
- Qi: Childhood friends or deep best friends  
- Cheng: Friendship above but not lovers yet  
- Zhuan: Like the same person or relationship changes  
- He: Friendship sublimation or individual growth

### Pattern C: Comeback - Change - Transformation  
**Structure**:  
- Qi: Status quo of underachiever/problem youth  
- Cheng: Encounter catalyst for change (person or event)  
- Zhuan: Strive to change but with setbacks  
- He: Break out of cocoon, dreams come true

### Pattern D: Misunderstanding - Reconciliation - Redemption  
**Structure**:  
- Qi: Perfect relationship broken  
- Cheng: Misunderstanding deepens, drifting apart  
- Zhuan: Truth revealed, too late to regret  
- He: Reconciliation or miss, growth insight

---

**【Special Reminder】**  
Key to success or failure of youth campus short stories:  
1. The first 500 words must establish a realistic campus atmosphere and emotional hook  
2. Every 1000 words must have emotional progression or character interaction  
3. Dialogue must fit student language and feel youthful  
4. Psychological descriptions must be delicate and authentic, not pretentious or affected  
5. The ending must convey growth; not necessarily perfect but must be sincere