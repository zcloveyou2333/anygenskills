---
name: qingchun-output-style
description: The output style for youth campus novels, featuring fresh and delicate language, sincere and moving emotions, vivid and lively descriptions, and a youthful atmosphere. It blends Rao Xueman's heartfelt and bittersweet style with August Chang'an's pure and beautiful innocence.
---

# General Writing Style Guidelines
- Fresh and Delicate: Clean and refreshing language, without affectation; every word carries a sense of youth.
- Sincere Emotions: Genuine and believable feelings, avoiding melodrama and pretentiousness.
- Vivid and Lively: Three-dimensional scene descriptions and realistic character portrayals.
- Youthful Atmosphere: Constantly maintain the sense of campus life and youthful energy.
- Growth Resonance: Touch on the pain points of youth growth to evoke empathy.
- Brisk Pace: No dragging; maintain smooth reading flow.
- Integrate Outline: Chapter outlines serve as categorized information, not narrative order; during creation, reorganize information according to emotional progression, avoid copying block by block; let the story flow naturally with emotions woven into the narration.

## Fusion of Two Authors' Styles

### Rao Xueman Style Elements
- **Emotional Depth**: Heartbreaking but not melodramatic; pain feels real.
- **Pain of Growth**: Does not shy away from the pains and regrets of youth.
- **Delicate Psychology**: Deeply explores characters' inner worlds, revealing complex emotions.
- **Poetic Expression**: Incorporates poetic and philosophical elements into narration.
- **Aesthetic of Regret**: Accepts imperfect endings.

### August Chang'an Style Elements
- **Pure and Beautiful**: Captures the most beautiful moments of youth.
- **Heartbeat Moments**: Delicately depicts the feeling of heart-fluttering.
- **Authentic Campus**: Restores real campus life details.
- **Warm and Healing**: Despite bitterness, retains warmth.
- **Passage of Time**: Uses timeline to connect growth trajectories.

## Specific Practices

### When Writing Dialogue
- **Match Student Language**: Characters speak naturally and fittingly for students, without affectation.
  - ✅ "Hey, Lu Zhi'ang, have you finished the math homework? Let me copy a bit."
  - ❌ "Lu Zhi'ang, may I refer to your math homework?"
- **Convey Emotional Warmth**: Every line of dialogue transmits emotion.
  - ✅ "Silly," he ruffled her hair, "don’t be so impulsive next time." "But you got hurt." "Still can’t let you get hurt."
  - ❌ "Hello." "Hello." "The weather is nice today." "Yes."
- **Show Personality Differences**: Different characters have distinct speech styles.
  - ✅ Top student: "This problem is easier using derivatives." Underachiever: "Bro, speak human language."
  - ❌ Everyone speaks in the same tone.
- **Maintain Youthfulness**: Dialogue should be lively with a student tone.
  - ✅ "Oh no, I’m definitely doomed this exam!" "Don’t panic, you always say that and still pass."
  - ❌ Overly formal or adult-like dialogue.

### When Writing Descriptions
- **Authentic Campus Details**: Use concrete details instead of vague descriptions.
  - ✅ The blackboard newspaper at the back of the classroom still shows last week’s content, chalk dust floating in the sunlight. At the window seat in the fourth row, someone carved a name on the desk with a pen, then blurred it with an eraser.
  - ❌ The classroom is very ordinary.
- **Capture Youthful Moments**: Freeze beautiful scenes.
  - ✅ Sunlight filtered through the phoenix tree leaves, casting mottled shadows on his profile. She looked at the tiny light spots on his eyelashes and suddenly felt her heart race. At that moment, she wished time could stop.
  - ❌ She looked at him and thought he was handsome.
- **Season and Atmosphere**: Use environment to enhance emotion.
  - ✅ That summer was especially hot, cicadas chirping nonstop from morning till night. She lay on the desk, sweat sticking her bangs to her forehead. Outside, the phoenix tree leaves rustled in the wind as if counting down something.
  - ❌ Summer was hot.
- **Emotional Perspective**: See the world through the character’s eyes.
  - ✅ The dismissal bell rang, the classroom erupted in joy. Only she remained seated, watching his back as he packed his bag. He always packed slowly, as if waiting for someone. But that person wasn’t her.
  - ❌ School was over, everyone left.

### When Writing Psychological Activities
- **Youthful Sensitivity**: Show the unique sensitivity and delicacy of teenagers.
  - ✅ What did he mean when he said "let’s walk together"? Just coincidentally, or did he wait for her on purpose? His tone sounded casual, but she felt something different. She glanced at him secretly; he was looking ahead, expression calm. Forget it, she must be overthinking.
  - ❌ He invited her to walk together, and she was happy.
- **Inner Conflict and Ambivalence**: Show inner struggles.
  - ✅ Should she give him the love letter? She folded and unfolded the paper repeatedly. If she gave it and got rejected, what then? Would it be awkward to meet afterwards? But if she didn’t, would she regret it forever?
  - ❌ She was conflicted and didn’t know what to do.
- **Self-Doubt**: Adolescent insecurity.
  - ✅ She knew she wasn’t pretty enough, her grades weren’t the best, and she was a bit introverted. How could someone like her be liked by him? There were so many outstanding girls around him: Su Xiaomo was gentle and beautiful, Zhang Xiaoyu lively and generous... What was she?
  - ❌ She felt she didn’t deserve him.
- **Cautious Crush**: Depict the psychology of a secret crush.
  - ✅ She began to notice everything about him. What colors he liked, what food he preferred, which singer he admired. She kept all these in her heart but didn’t dare let him know. She could only watch him from afar, silently saying the words she couldn’t speak.
  - ❌ She had a crush on him.

### When Writing Emotional Scenes
- **Heartbeat Moments**: Delicately depict the feeling of heart-fluttering.
  - ✅ At that moment, time seemed to stop. The noise in the classroom gradually faded; she only heard her own heartbeat. He stood right in front of her, sunlight forming a halo behind him. "Are you okay?" he asked. She opened her mouth but found she couldn’t speak.
  - ❌ She saw him and her heart raced.
- **Sweet Interactions**: Show youthful sweetness.
  - ✅ "Your face is red." "No! It’s... the classroom is too hot." "Really? Then why are your ears red too?" He leaned in a bit, eyes smiling. She panicked and stepped back, almost bumping into the desk. He reached out to steady her; his fingertip accidentally brushed her wrist. Both froze.
  - ❌ They were very sweet together.
- **Frustration and Pain**: Realistically present the pain of youth.
  - ✅ She watched him hold Su Xiaomo’s hand, feeling the world collapse. She wanted to cry, but tears wouldn’t fall. She stood at the stairwell corner, watching their backs grow distant. Her hand clenched the unsent letter, the paper soaked with sweat.
  - ❌ She was very sad.
- **Reconciliation and Warmth**: Show the relief after growth.
  - ✅ "I’m sorry," he said. She shook her head: "It’s not your fault. I overthought it." "Can we still be friends?" "Of course." She smiled, though her eyes were a bit red, "We were always friends." She spoke the truth. Though it still hurt a little, she had learned to let go.
  - ❌ They made up.

### When Writing Climax Scenes
- **Emotional Outburst**: Let emotions release naturally.
  - ✅ "Why didn’t you say it earlier!" she finally burst into tears, "I waited three years, three years! Do you know how I spent those years? Watching you with Su Xiaomo, I... I..." She couldn’t continue, tears streaming like broken pearls. He stood stunned, seeing her cry so painfully for the first time.
  - ❌ She was angry and cried.
- **Confession Moment**: Depict the nervous and excited confession.
  - ✅ She took a deep breath and handed him the letter. Her hands trembled, heart pounding as if about to explode. "Lu Zhi'ang, I like you. I’ve liked you since the first time I saw you in freshman year. I know you might not like me, but... I don’t want to hide it anymore." After saying this, she felt light, though tears still fell.
  - ❌ "I like you." She confessed.
- **Misunderstanding Resolved**: Present the shock of truth revealed.
  - ✅ "Do you know why I’m always the first to arrive in the classroom?" he smiled bitterly, "Because I’m waiting for you. Do you know why I’m always the last to leave? Because you leave the latest. Do you think I don’t know you like the sugar-roasted chestnuts at the school gate? I remember everything, just didn’t dare to give you any." She was stunned. So... he had always known.
  - ❌ The misunderstanding was cleared; he liked her too.

### When Writing Endings
- **Happy Ending**: Sweet with insight.
  - ✅ On graduation day, they stood together on the playground, watching the sunset dye the sky orange. "Will we meet again?" "Of course." He held her hand, "Promise, we’ll go to the same university." "Mm." She smiled, eyes moist. Three years finally had a fulfilling answer.
  - ❌ They got together and were happy.
- **Bittersweet Ending**: Painful but growth-filled.
  - ✅ The train slowly pulled out of the station. She stood on the platform, watching him wave behind the window. She waved back, smiling until tears came. She knew this might be the last time they met. He was going north, she was going south. But it was okay; she would remember all the beautiful moments of these three years. Those heartbeats, laughter, and tears would become her most precious memories.
  - ❌ They broke up in the end, very regrettable.
- **Open Ending**: Leaves room for imagination.
  - ✅ Ten years later, she received a letter. Familiar handwriting: "Early summer, how have you been?" She looked out at the phoenix tree outside the window, a smile playing on her lips. She picked up the pen and wrote: "I’m fine. How about you?" Some stories don’t need endings because they keep going.
  - ❌ They might reunite years later.
- **Growth and Sublimation**: Thematic but not preachy.
  - ✅ She finally understood that youth doesn’t have to have a perfect ending. Those heart-fluttering moments, missed chances, brave confessions, and painful growth are all part of youth. She didn’t regret liking him because that feeling made her a better person.
  - ❌ She learned a lot from this experience and grew up.

## Language Taboos

### Absolutely Forbidden
- ❌ Over-exaggerated descriptions: "She was as beautiful as a fairy," "He was stunningly handsome."
- ❌ Adult-like language: "This concerns our future development."
- ❌ Behaviors inconsistent with student identity: overly mature or childish.
- ❌ Melodramatic plots: amnesia, terminal illness, wealthy family grudges.
- ❌ Mary Sue characters: flawless, universally loved.
- ❌ Overused internet clichés: excessive use of online slang.

### Must Achieve
- ✅ Fresh and natural language, matching adolescent expression habits.
- ✅ Delicate and authentic emotions that resonate.
- ✅ Realistic and immersive campus scenes.
- ✅ Character behaviors consistent with age and personality.
- ✅ Lively and youthful dialogue.
- ✅ Genuine and moving endings with a sense of growth.

## Special Reminders

### Special Requirements for Short Stories
- **Focus on Core Emotion**: Deeply explore one emotional line within 5 chapters; avoid too many subplots.
- **Authentic and Believable**: Campus details must be real and connected to student life.
- **Brisk Pace**: Every 1000 words should advance emotion or plot.
- **Impactful Ending**: The ending is often the most important part of a youth novel.

### Perspective Suggestions
- **Limited Third-Person**: Most common; follows protagonist and reveals inner world.
- **First-Person**: Suitable for diary or retrospective narration; more immersive.
- **Dual Perspectives**: Alternating viewpoints of male and female leads to show different emotional journeys.

### Control of Youth Characteristics
- **Realistic ≠ Bland**: Should have drama but stay true.
- **Sweet ≠ Sickly**: Keep freshness, avoid excessive sugar.
- **Heartbreaking ≠ Melodramatic**: Emotions have pain but must be reasonable.
- **Growth ≠ Preachy**: Convey naturally through story, avoid direct preaching.

### Emotional Scale Management
- **Primarily Pure**: Maintain youthful purity.
- **Moderate Ambiguity**: Heartbeats and ambiguity allowed but controlled.
- **Real Pain**: Don’t avoid growth pains but don’t overdo it.
- **Warm Undertone**: Even in heartbreak, retain a touch of warmth.

## Core Philosophy

When writing youth campus novels, remember three keywords:
1. **Authenticity**: Real campus, real emotions, real growth.
2. **Resonance**: Touch readers’ memories and experiences of youth and growth.
3. **Warmth**: Even with regrets, keep warmth and hope.

**Most important point**: Youth campus novels are not simply love stories but stories about growth. In this process, friendship, love, dreams, and setbacks are all nutrients. A good youth novel makes readers laugh while crying, cry while laughing, and linger long after the story ends. It uses fresh strokes to depict sincere emotions, tells coming-of-age stories with youthful innocence, and interprets the meaning of youth through the beauty of regret. This is the charm of youth campus novels.