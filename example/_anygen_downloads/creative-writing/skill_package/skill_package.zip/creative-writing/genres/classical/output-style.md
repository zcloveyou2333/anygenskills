---
name: gufeng-output-style
description: The output style for ancient-style political intrigue novels, characterized by elegant and weighty language, exquisite strategies, profound human nature, and rich historical background. It blends the political depth of Er Yuehe with the vivid narration of Dangnian Mingyue.
---

# General Writing Style Principles
- Elegant and Weighty: Language blends classical and vernacular styles, possessing ancient charm without being obscure or difficult to understand.
- Exquisite Strategy: Political schemes must be layered, with plots within plots, advancing step by step.
- Profound Human Nature: Not only writing about power tactics but also about human hearts and the alienation caused by power.
- Historical Depth: Respect historical logic, present the atmosphere of the era, and convey a sense of gravity.
- Realism: Power struggles are brutal; do not avoid costs and sacrifices.
- Integrated Outline: Chapter outlines are categorized information, not narrative order; during creation, reorganize information according to event progression, avoid copying block by block; let the story flow naturally, integrating background information into the narration.

## Fusion of Er Yuehe and Dangnian Mingyue Styles

### Er Yuehe Style Elements
- **Political Depth**: Schemes must be precise, games layered, one move decides the fate.
- **Three-dimensional Characters**: No stereotypical figures; each has their own logic.
- **Historical Weight**: Detailed research, atmosphere building, immersing readers.
- **Psychological Portrayal**: Deep insight into characters’ inner worlds, showing human struggles under power.
- **Solemn Language**: Elegant but not obscure, with the gravitas of historical novels.

### Dangnian Mingyue Style Elements
- **Vivid Narration**: Using modern writing techniques to tell ancient stories, avoiding pedantry.
- **Lively Characters**: Historical figures are flesh and blood, with personality and emotion.
- **Sense of Humor**: Light moments within serious themes, with balanced tension and relaxation.
- **Insightfulness**: Seeing humanity through history, with unique perspectives.
- **Strong Readability**: Professional but not dull, making readers unable to put the book down.

## Specific Practices

### When Writing Dialogue
- **Implied Meaning**: Court dialogues should hide sharp wit, subtle but piercing.
  - ✅ "Your Majesty is wise." The minister knelt, words respectful but eyes flashing with reluctance. The emperor noticed, a slight smile on his lips: "Your loyalty is well known to me." This was both praise and warning.
  - ❌ "The emperor said something, the minister replied."
- **Consistent with Status**: Different ranks have different speech styles.
  - ✅ "This old minister dares to speak frankly..." (Old minister)
  - ✅ "Your servant obeys the order." (Prince)
  - ✅ "This humble servant deserves death..." (Eunuch or palace maid)
  - ✅ "Your Majesty, I think..." (Young official)
  - ❌ Everyone speaks the same way.
- **Hidden Information**: Dialogue should advance the plot and reveal information.
  - ✅ "Has Ao Bai shown any unusual movements recently?" "Your Majesty, he has not attended court for three consecutive days, claiming a cold." "A cold?" Kangxi sneered, "He is testing my reaction."
  - ❌ "How is it?" "It's okay."
- **Language of Power**: Show power relations through dialogue.
  - ✅ "I" (emperor) vs. "Your servant"/"Your Majesty" vs. "Humble servant" — titles show hierarchy.
  - ✅ Who speaks first, who interrupts, who remains silent — use speech rights to show status.

### When Writing Description
- **Details Reflect Power**: Show power structure through details.
  - ✅ The Grand Secretary’s memorial was presented; the emperor didn’t even glance at it, casually putting it aside. The Vice Minister’s memorial, however, was carefully reviewed. This subtle difference was noticed by everyone in the hall.
  - ❌ The emperor reviewed the memorial.
- **Atmosphere Building**: Create tension and oppression in the court.
  - ✅ Inside Qianqing Palace, candle flames flickered, casting distorted shadows. The emperor sat on the dragon throne expressionless. The ministers kneeling dared not breathe, only hearing their own heartbeats.
  - ❌ The hall was very quiet.
- **Historical Texture**: Use concrete details to restore the era.
  - ✅ The eunuch presented the yellow register from Kangxi’s 23rd year; the paper was yellowed and worn at the edges. The emperor opened it; dense records of that year’s taxes were listed.
  - ❌ The emperor looked at a document.
- **Costume and Props Accuracy**: Show status through clothing and objects.
  - ✅ Ao Bai wore a first-rank qilin embroidered robe, a white jade belt at his waist, holding an ivory tablet. This attire was even more splendid than some princes'.
  - ❌ He dressed very splendidly.

### When Writing Psychological Activity
- **Weighing and Calculating**: Show characters’ thought processes.
  - ✅ Kangxi’s fingers lightly tapped the dragon throne’s armrest. Is the time ripe to remove Ao Bai? His cards were: Suoetu’s loyalty, the young guards’ martial skills, and the eunuchs’ ears in the palace. Ao Bai’s cards were: 30,000 armored troops, the fear of all officials, and the late emperor’s trusted status. What were the odds? 70%? 50%? Or 30%?
  - ❌ He was thinking about whether to remove Ao Bai.
- **Human Struggle**: Moral dilemmas under power.
  - ✅ For the Great Qing, he must remove Ao Bai. But Ao Bai was the late emperor’s trusted minister, meritorious to the state. Killing him was the way of the ruler, but not the way of a man. He suddenly understood his father’s last words: "Being emperor is the loneliest thing in the world."
  - ❌ He felt troubled.
- **Loneliness of Power**: Portray the loneliness of emperors/powerful ministers.
  - ✅ Late at night, Kangxi stood alone outside the Yangxin Hall, gazing at the starry sky. The vast Forbidden City, thousands of ministers, yet no one truly understood his situation. The higher the position, the colder it gets; only those on the dragon throne can understand this.
  - ❌ He felt lonely.
- **Weighing Interests**: Show political figures’ rationality.
  - ✅ Supporting reforms would offend gentry and lose Jiangnan’s tax revenue. Opposing reforms would lose the emperor’s trust and block promotion. He had to decide within two months, a choice that would determine his future.
  - ❌ He didn’t know what to choose.

### When Writing Political Intrigue Scenes
- **Schemes Must Be Precise**: Setups must be methodical and interconnected.
  - ✅ "First, let Suoetu secretly contact officials loyal to me. Second, arrange for the young guards to practice wrestling daily in the palace to distract Ao Bai. Third, strike when he is most relaxed." Kangxi spoke word by word, "Remember, only success is allowed, failure is forbidden."
  - ❌ He thought of a plan to deal with Ao Bai.
- **Layered Game**: Moves and countermoves, step by step.
  - ✅ Ao Bai thought the emperor would attack at court and preemptively deployed troops. Kangxi played along, conceding slightly at court to lull his opponent. Ao Bai relaxed, unaware the real strike awaited him at a family banquet three days later.
  - ❌ They fought back and forth.
- **Information Warfare**: Whoever controls information controls initiative.
  - ✅ "Your Majesty, three mysterious guests arrived at Ao Bai’s mansion." "Have their identities been checked?" "Not yet, but judging by their accents, they are from beyond the Pass." Kangxi’s eyes sharpened: "Beyond the Pass... What is he up to?"
  - ❌ They were gathering intelligence.
- **Reasonable Twists**: Unexpected but plausible.
  - ✅ Everyone thought Suoetu was Kangxi’s confidant, unaware he had been bought by Ao Bai. But Kangxi never truly trusted Suoetu; his real trump card was a seemingly insignificant little eunuch.
  - ❌ Suddenly something unexpected happened.

### When Writing Court Scenes
- **Sense of Ceremony**: The court must feel solemn.
  - ✅ "If there is business, report it; if none, court is dismissed." The eunuch’s sharp voice echoed in the hall. Officials lined up silently. Kangxi sat on the dragon throne, eyes slowly scanning from left to right; wherever he looked, heads bowed.
  - ❌ Court started, everyone came.
- **Intense Confrontation**: Court debates must be fiery.
  - ✅ "Your Majesty, I believe this matter is absolutely inadvisable!" "Grand Secretary, you are mistaken; precisely because it is difficult, it must be implemented!" "You speak as a scholar, unaware of court difficulties!" "Sir, you are conservative and unprogressive!" The two clashed fiercely; ministers divided into factions, each holding their ground.
  - ❌ They argued.
- **Power Display**: Show power balance through court.
  - ✅ When Ao Bai spoke, his supporters immediately echoed. When Kangxi spoke, only a few voices agreed. This contrast made everyone understand who truly held power.
  - ❌ Ao Bai had great power.

### When Writing Harem Scenes
- **Step-by-step Tension**: The harem is as dangerous as the court.
  - ✅ "Your Highness, the imperial physician said there is safflower in your pregnancy medicine." The palace maid lowered her voice. Her face instantly turned pale: "Who did this?" "I dare not speculate, but... the medicine was sent by a eunuch from Consort Hui’s palace." She clenched the handkerchief, knuckles white: "That Consort Hui."
  - ❌ Someone harmed her.
- **Weak Overcomes Strong**: Show women’s wisdom in the deep palace.
  - ✅ Knowing she couldn’t defeat Consort Hui directly, she feigned weakness before the emperor to arouse his protectiveness. She gambled right; the emperor began doubting Consort Hui’s arrogance.
  - ❌ She was smart.
- **Status Through Childbearing**: Show the importance of childbirth in the harem.
  - ✅ Since becoming pregnant, her treatment changed immediately. Formerly disdainful concubines now sought favor. She knew it was all because of the child in her womb. But she also knew if she lost the child, these people would trample her faster than anyone.
  - ❌ She got pregnant and her status rose.

### When Writing Climax Scenes
- **Tension**: Fast pace, seamless flow.
  - ✅ "Attack!" Kangxi ordered. The young guards pounced like tigers on Ao Bai. Ao Bai was shocked, reaching for his sword but was held down by two youths. "How dare you!" "I ordered them." Kangxi stood, stepping closer, "Ao Bai, your era is over."
  - ❌ They fought, Kangxi won in the end.
- **Multiple Twists**: Layered advancement, surprising.
  - ✅ Ao Bai thought he was trapped and prepared to fight to the death, but Kangxi only intended to house arrest him, not kill him. Ao Bai relaxed, unaware this was the real trap—Kangxi wanted his power, not his life. Once he surrendered military command, whether to kill him was irrelevant.
  - ❌ The result was different from expected.
- **Emotional Impact**: Blend humanity into the political climax.
  - ✅ "Ao Bai, do you know why I don’t kill you?" Kangxi looked at the once-powerful minister, "Because you were the late emperor’s trusted minister, I... don’t want the blame of killing a loyal subject." Ao Bai closed his eyes, tears streaming: "Your Majesty is merciful." Merciful? Or cruel? Letting a powerful minister live to watch himself lose everything is harder than death.
  - ❌ He won in the end.

### When Writing Endings
- **Historical Perspective**: View victory and defeat with a long-term vision.
  - ✅ Thirty years later, historians wrote in the "Veritable Records of Kangxi": "In Kangxi’s eighth year, the emperor wisely captured Ao Bai, regained power, and laid the foundation for a prosperous era." But only Kangxi knew what he lost that day. He lost youthful innocence, trust in people, and his father’s dying advice to "be merciful." He became a successful emperor but didn’t know if he was still a good man.
  - ❌ The story ended.
- **Cost of Power**: Victory comes at a price.
  - ✅ Kangxi won, but he knew this was only the beginning. Removing Ao Bai was easy; stabilizing the court and winning the loyalty of officials was hard. Looking in the mirror, the young emperor’s face already bore a maturity beyond his years.
  - ❌ He was happy to have won.
- **Open Ending**: Leave lingering resonance.
  - ✅ Ao Bai fell, but open and covert struggles in court did not end. New powers were rising, new crises brewing. Kangxi stood outside Yangxin Hall, gazing at the distant stars. He knew this path was only just begun. More challenges awaited. But he was not afraid. He was the emperor of the Great Qing; this realm was his to guard.
  - ❌ Everyone lived happily ever after.

### Handling Pace
- **Establish Power Atmosphere within First 500 Words**: Let readers immediately enter the court world.
  - ✅ Spring, Kangxi’s eighth year. The Forbidden City was shrouded in eerie calm. Ao Bai had not attended court for three days; officials were anxious. In the Hall of Supreme Harmony, fourteen-year-old Kangxi sat on the dragon throne, expressionless, reviewing memorials. His hand was steady, but no one could see the fierce beating of this young emperor’s heart.
  - ❌ This story happened during Kangxi’s reign; there was a powerful minister named Ao Bai...
- **Every Scene Must Advance Political Intrigue**: No meaningless scenes.
  - ✅ Kangxi summoned Suoetu, ostensibly to discuss the Heaven worship ceremony, but actually to arrange details for removing Ao Bai. They discussed ritual procedures while exchanging coded plans, advancing the plot and showing the secrecy of political intrigue.
  - ❌ They chatted and then went their separate ways.
- **Information Revealed Gradually**: Don’t reveal too much at once; maintain suspense.
  - ✅ First hint that Ao Bai was disloyal, then discovery of his private troop deployments, then learning he wanted to sideline the emperor, finally revealing his ultimate ambition—to make his daughter empress and control the court as an in-law.
  - ❌ Everything was revealed at once.

### Chapter Endings
- **Suspense Hook**: Make readers look forward to the next chapter.
  - ✅ Kangxi just relaxed when a eunuch hurried in, pale-faced: "Your Majesty, bad news! Ao Bai’s men have surrounded the palace!"
  - ❌ This chapter ended.
- **Information Bomb**: Drop major information at chapter’s end.
  - ✅ "Your Majesty, I risk my life to report." Suoetu knelt, "Ao Bai dares to be so arrogant because... he holds a secret edict from the late emperor." Kangxi’s pupils contracted: "What secret edict?"
  - ❌ He told him some news.
- **Emotional Climax**: End at a critical emotional moment.
  - ✅ Kangxi stood outside Yangxin Hall, gazing at the night sky. Tomorrow, he would act. Success would create a prosperous era; failure meant ruin. He recalled his mother’s admonitions, his father’s last wishes, and his ancestors’ legacy. "I must not lose." He whispered, voice resolute.
  - ❌ He was ready for tomorrow’s action.

## Language Taboos

### Absolutely Forbidden
- ❌ Modern internet slang: "yyds", "juejuezi", "laugh to death"
- ❌ Historical inaccuracies: wrong titles, dynasty confusion, anachronistic objects
- ❌ Stereotyped characters: "evil villain’s sinister laugh"
- ❌ Simple good vs. evil dichotomy
- ❌ Magical political intrigue: schemes solve everything without cost
- ❌ Overly sentimental: political intrigue novels must be restrained

### Must Achieve
- ✅ Elegant and weighty language with historical texture
- ✅ Political schemes consistent with political and human logic
- ✅ Characters’ actions consistent with identity, interests, and motives
- ✅ Historical details rigorously researched, no obvious errors
- ✅ Calm and restrained narration with emotional tension
- ✅ Endings with historical depth, showing the cost of power

## Special Reminders

### Short Story Special Requirements
- **Focus on Core Political Intrigue**: Deeply explore one power game within 5 chapters, avoid overexpansion.
- **Balance Strategy and Humanity**: Intrigue is the shell, human nature is the core.
- **Tight Pace**: Every 1000 words must have substantial progress.
- **Powerful Ending**: Show the cost of power and historical inevitability.

### Perspective Suggestions
- **Third-person Limited**: Most common, follow protagonist, restrict information.
- **Third-person Omniscient**: Suitable for multi-party political ensemble narratives.
- **First-person**: Suitable for memoirs or memorial-style narratives.

### Political Intrigue Characteristics Control
- **Strategy ≠ Trickery**: Good intrigue is overt strategy, big-picture and political wisdom.
- **Cold ≠ Cruel**: Power struggles are harsh but have boundaries.
- **Weighty ≠ Dull**: Historical feel comes from details, not long exposition.
- **Complex ≠ Confusing**: Relationships can be complex but must be clear.

### Emotional Scale Control
- **Restrained but Deep**: People in power must restrain emotional expression.
- **Loneliness is Important**: Portray the loneliness at the top of power.
- **Cost Must Be Clear**: Every choice carries real weight.
- **Complexity of Human Nature**: No pure good or evil, only interests and positions.

## Core Concepts

Writing ancient-style political intrigue requires remembering three keywords:
1. **Wisdom**: Strategic games, outsmarting opponents, masterful planning.
2. **Power**: Essence of power, entangled interests, balancing techniques.
3. **Human**: Insight into human nature, loneliness and cost, historical inevitability.

**Most important point**: Political intrigue novels are not just about schemes but about people. A good political intrigue novel lets young readers enjoy brilliant tactics, and adults perceive profound human nature. It is calm yet warm; cruel yet compassionate; it writes about power but ultimately cares about people. This is the charm of ancient-style political intrigue.

## Historical Research Reminders

### Common Titles
- **Emperor’s self-reference**: 朕 (formal occasions) / 我 (private occasions)
- **Addressing the emperor**: Your Majesty / Long Live / Holy Majesty / Emperor
- **Ministers’ self-reference**: Your servant / Old servant / Humble servant
- **Princes’ self-reference**: Your servant / Servant (to father emperor)
- **Eunuchs and palace maids’ self-reference**: Humble servant / Servant
- **Consorts’ self-reference**: Your humble servant / This concubine

### Avoid Dynasty Confusion
- Clearly specify which dynasty is the background.
- Different dynasties have different official titles and rituals.
- Pay attention to the timeline of major historical events.

### Objects and Clothing
- Dragon robes, court robes, embroidered robes must fit the dynasty.
- Object names must be accurate (memorials, secret memorials, yellow registers, etc.)
- Building names must be researched (Qianqing Palace, Yangxin Hall, etc.)