---
name: gufeng-outline-method
description: Methodology for creating outlines of short ancient-style political intrigue novels, including core synopsis extraction, introduction design, plot structure planning, and character development guidance. Integrates the creative essence of Er Yuehe and Dang Nian Ming Yue.
---

## Q1-Q3 Question Templates

### Q1: Core Idea
**Q1: Core idea and appeal of the story [Brief description]**  
Please describe your story idea in one or two sentences.

### Q2: Core Conflict
**Q2: Core conflict [Brief description]**  
Please describe the novel’s central contradiction or main conflict in one sentence  
(e.g., the life-and-death struggle in a prince’s succession battle, power struggles among palace concubines, loyalist vs. traitor conflicts in the court and the fate of the nation, open and covert struggles among aristocratic clans, etc.)

### Q3: Story Tone
**Q3: Story tone [Choose one]**  
- Palace intrigue & political scheming · Step by step suspense (harem rivalry, scheming, cautious moves)  
- Court drama & national affairs · Family and country (powerful ministers’ struggles, rise and fall of dynasties, loyalty and righteousness dilemmas)  
- Mansion life · Human warmth and coldness (love, hate, and worldly vicissitudes inside grand mansions)  
- Jianghu and court · Chivalry and tenderness (intertwining of temple and martial world, coexistence of chivalry and political scheming)  
- Or briefly describe your story tone

## Chapter File Naming Rules  
File name format: `{STORY_NAME}-{NN}.md`  
Example: `EmperorSchemes-01.md`, `EmperorSchemes-02.md`

---

# Methodology for Creating Ancient-Style Political Intrigue Outlines

## Overall Orientation

Ancient-style political intrigue novels emphasize "**strategic scheming and insight into human nature**," centering on court power struggles, palace secrets, and officialdom ups and downs.

**Core reference works**: *Kangxi Emperor*, *Yongzheng Emperor*, *Stories of the Ming Dynasty*  
- From Er Yuehe learn "depth of political scheming": strategic planning, cautious advance, one move deciding the fate  
- From Er Yuehe learn "character portrayal": loneliness of emperors, choices of ministers, the cost of power  
- From Dang Nian Ming Yue learn "historical warmth": telling ancient stories with modern writing style, making characters vivid and relatable

**Core principles**:  
- Focus on political intrigue topics (succession battles, court struggles, reform dilemmas, loyalty vs. treachery)  
- Pursue "intellectual impact": exquisite schemes, subtle games, profound humanity  
- Balance power tactics and human hearts, but **do not stray from historical logic and political reality**  
- Drive plot with strategy, choices, and games, **maintaining historical weight and authenticity**  
- Maintain an elegant and profound style: rich in ancient flavor, graceful and enduring, with powerful writing

---

## Overall Creation Formula
```
Ancient-style political intrigue = power structure + strategic scheming + human choices + historical inevitability
```

---

## I. Core Synopsis Writing

### Formula
```
Core synopsis = power background/situation + core game + human theme
```

### Writing Points
| Element | Requirement | Correct Example | Incorrect Example |
|---------|-------------|-----------------|------------------|
| **Power Background** | Specific + tension | "The imperial throne struggle intensifies, nine princes vie for succession amid swords and shadows" | "Ancient court" |
| **Core Game** | Strategic confrontation | "Must identify the mastermind within three days or face entire family execution" | "Encountered trouble" |
| **Human Theme** | Touch deep contradictions | "Explores the dilemma between loyalty and scheming, revealing power’s corruption of the heart" | "Succeeded in the end" |

### Excellent Examples
- "In the eighth year of Kangxi, Ao Bai wields power over court and country, the young emperor treads on thin ice. He must quietly strategize, using fewer forces to outsmart and capture the powerful minister; only then can he reclaim authority. This is a life-or-death game for imperial power; losing means eternal ruin."  
- "In the first year of Yongzheng, the new emperor ascends amid heavy resistance to reforms. He must rectify officialdom and implement land tax reforms, challenging entrenched interests. Between loyal ministers and power-hungry officials, he must discern accurately; one misstep will bring eternal infamy."  
- "At the end of Chongzhen’s reign, the treasury is empty and bandits rise. A clean county magistrate must raise military funds within three months or the city will fall. His only tools are wisdom and courage, while his opponents are deeply rooted local gentry."

---

## II. Introduction Writing

### Formula
```
Introduction = power scene opening + core dilemma setup + strategic suspense hook
```

### Writing Points
| Element | Function | How to Write |
|---------|----------|--------------|
| **First sentence** | Establish court atmosphere | Directly show: Golden Throne Hall / secret meeting / life-or-death memorial / succession struggle |
| **Middle part** | Explain power dilemma | Quickly locate with specific political situation and interest entanglements |
| **Last sentence** | Create game suspense | Throw out strategic contest / life-or-death choice / power upheaval |

### Integration of Political Intrigue Topics

Introduction must touch on core themes of political scheming:

| Topic Type | Specific Direction |
|------------|--------------------|
| **Emperor’s Art** | How to control ministers, balance power, stabilize imperial authority |
| **Court Struggles** | Factional disputes, reform resistance, loyalty and treachery battles |
| **Harem Power Struggles** | Concubine rivalry, maternal influence, power marriages |
| **Officialdom Ups and Downs** | Official career, corruption, clean and corrupt factions |

**Goal**: Make readers anticipate "How will this game be solved?" (strategic immersion)

### Example Comparison
| Type | Content |
|------|---------|
| ✅ **Correct** | "In the eighth year of Kangxi, the Forbidden City is shrouded in eerie calm. Ao Bai controls the court, wielding power over the world; all officials are silent with fear. The fourteen-year-old Kangxi sits expressionless on the dragon throne, quietly reviewing memorials, only his hand holding the brush trembles slightly. He knows Ao Bai’s 30,000 ironclad troops are stationed around the capital, ready to revolt at any moment. But he knows even more: if he does not act, this emperor will be a mere puppet. 'Issue my decree, summon Suo E’to an audience.' He lowers his voice to the eunuch, 'Enter the palace secretly, do not alarm anyone.' This move stakes the fate of the realm; losing is not an option." |
| ❌ **Incorrect** | "There was an ancient emperor, bad people held power in court, and the emperor tried to deal with them..." |

---

## III. Plot Structure Design (Qi Cheng Zhuan He)

### 【Qi】Chapter 1: Power Crisis (2000-3000 words)

#### Writing Focus
```
Qi = power structure display + protagonist introduction + core dilemma presentation + game opportunity
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Power Structure** | Establish court atmosphere within first 500 words | First paragraph shows: court meeting / secret memorial / palace banquet / clan meeting<br>Use concrete details, not vague descriptions: who holds what power |
| **Protagonist Introduction** | Quickly introduce protagonist | Protagonist appears within 300 words<br>Show identity through power actions: attending court / reviewing memorials / advising / scheming |
| **Core Dilemma** | Show seriousness of dilemma | Power loss / reform resistance / life-threatening / national crisis |
| **Game Opportunity** | Push story forward | Urgency / opponent pressure / sudden situation change / only chance |

#### Er Yuehe Techniques
- **Details equal power**: Show power structure through details (who speaks first, whose memorial is reviewed first, who stands where)  
- **Psychology equals game**: Show calculation and weighing through character psychology  
- **Historical depth**: Naturally integrate historical background to let readers feel the era’s weight

#### Taboos
- ❌ Large blocks of historical background explanation  
- ❌ Protagonist as passive observer  
- ❌ Dilemma lacks concrete interest conflicts

---

### 【Cheng】Chapters 2-3: Secret Layout and Probing Confrontation (2000-3000 words each)

#### Chapter 2 Writing Focus
```
Chapter 2 = secret investigation + intelligence gathering + preliminary layout + probing confrontation
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Secret Investigation** | Protagonist begins action | Secret visits to confidants / archive review / covert observation / bribing informants |
| **Intelligence Gathering** | Reveal some truths | Discover interest chains / find key evidence / understand opponent background |
| **Preliminary Layout** | Begin planning | Arrange pieces / set traps / win allies / sow discord in enemy camp |
| **Probing Confrontation** | Small-scale clashes | Court verbal sparring / small tests of reactions / covert moves |

#### Chapter 3 Writing Focus
```
Chapter 3 = initial schemes revealed + stance polarization + crisis intensifies + key decisions
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Initial Schemes** | Show intelligence | Set traps / sow discord / use others to kill / kill two birds with one stone |
| **Stance Polarization** | Clear camps | Allies and enemies become clear / neutrals face choices |
| **Crisis Intensifies** | Opponent counterattack | Enemies also plan / own side suffers setbacks / time grows tighter |
| **Key Decisions** | Foreshadow climax | Must make major decisions / choices mean risks and costs |

---

### 【Zhuan】Chapter 4: Life-and-Death Game (2000-3000 words)

#### Writing Focus
```
Zhuan = ultimate showdown + peak strategy + difficult choices + cost presentation
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Ultimate Showdown** | Final showdown | Public court confrontation / secret life-or-death game / total power battle |
| **Peak Strategy** | Schemes within schemes | Both sides outwit and outmaneuver, layered reversals, step-by-step suspense |
| **Difficult Choices** | Protagonist decides | Choose between loyalty and scheming, between personal and national interests |
| **Cost Presentation** | Consequences of choices | Victory comes at a price, power carries weight |

#### Political Intrigue Climax Techniques
- **Multiple reversals**: You think he will do this, actually he wants that, but finally it’s a third option  
- **Use of information asymmetry**: Readers know part, protagonist knows part, opponent knows part  
- **Time pressure**: Countdown, deadlines, missing means irrevocable disaster

#### Taboos
- ❌ Solve problems by coincidence  
- ❌ Protagonist suddenly becomes smart or opponent suddenly becomes stupid  
- ❌ Avoid difficult choices and costs

---

### 【He】Chapter 5: New Power Order (2000-3000 words)

#### Writing Focus
```
He = dust settles + new balance + human sublimation + historical aftertaste
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Dust Settles** | Show game results | Cost for winner / fate of loser / choices of neutrals |
| **New Balance** | Power reshuffle | New structure / new hidden worries / new challenges |
| **Human Sublimation** | Respond to core theme | Protagonist growth / power insight / historical lessons |
| **Historical Aftertaste** | Leave room for reflection | View victory and defeat from historical perspective / leave deep lingering taste |

#### Political Intrigue Ending Types
| Type | Characteristics | Suitable Scenarios |
|------|-----------------|-------------------|
| **Pyrrhic Victory** | Won the game, lost the heart | Great cost in power struggle |
| **Intellectual Victory** | Small forces beat large, perfect win | Protagonist’s strategy overwhelms |
| **Lose-Lose** | Both sides damaged, others benefit | Reveal cruelty of power games |
| **Reform** | Promote change, open new order | Idealistic themes |
| **Tragedy** | Defeated but honorable, spirit immortal | Explore conflict between ideals and reality |

#### Taboos
- ❌ Forced happy ending, violating political logic  
- ❌ Preachy summary  
- ❌ Leaving major plot holes

---

## IV. Character Development Methods

### Protagonist Design

| Dimension | Requirement | Correct Example | Incorrect Example |
|-----------|-------------|-----------------|------------------|
| **Power Identity** | Clear + tension | "Newly enthroned emperor" "Disgraced prince" "Reformist official" | "Someone in the court" |
| **Core Traits** | Mainly strategic | "Patient and deep, extremely scheming" "Ambitious and tough-handed" | "Very smart" |
| **Personality Tags** | 2-3 distinct traits | "Wise and decisive but ruthless" "Idealistic but politically savvy" | "Good person" |
| **Political Ability** | Related to plot | "Good at recognizing and using people, skilled in balancing power" | "Knows everything" |

### Personality Specificity
```
✅ "Kangxi sits on the dragon throne, his face calm as still water. His fingers gently tap the armrest, a habit when thinking. The entire court thinks he’s just a fourteen-year-old boy emperor, but they don’t know he has been secretly planning for three months, waiting for the right moment. He has learned patience, learned to feign obedience before Ao Bai, but deep in his eyes lies an undeniable imperial majesty."  
❌ "He is a smart emperor with ideas about power."
```

### Protagonist Archetypes (Common in Political Intrigue)

| Type | Features | Personality | Suitable Themes |
|------|----------|-------------|-----------------|
| **Young Emperor** | Newly in power, constrained on all sides | Patient and clever, gradually growing | Power struggle and growth |
| **Reform Minister** | Pushes new policies, faces resistance | Idealistic but pragmatic | Reform and dilemma |
| **Succession Prince** | Succession battle, life-and-death game | Ambitious and scheming | Power struggle |
| **Palace Concubine** | Harem rivalry, cautious moves | Clever and patient, weak overcoming strong | Palace intrigue and survival |
| **Disgraced Minister** | Once powerful, now fallen | Old schemer, waiting for chance | Revenge and comeback |

### Supporting Character Design (Political Intrigue Features)

| Type | Role | Notes |
|------|------|-------|
| **Strategist Advisor** | Provides plans, analyzes situation | Must have unique insights, not just protagonist’s mouthpiece |
| **Power Opponent** | Creates conflict, drives plot | Opponent must be smart, with own logic and plans |
| **Loyal Subordinate** | Executes plans, gathers intelligence | Must have personality, not a tool |
| **Fence-Sitter** | Shows human nature, adds uncertainty | Their choices must have reasonable motives |

### Relationship Network Design (Political Intrigue Specific)

| Element | Requirement |
|---------|-------------|
| **Interest Entanglements** | Every character has clear interest demands |
| **Faction Division** | Clear friend and foe, but also gray areas |
| **Information Asymmetry** | Different characters hold different information, causing misjudgments and games |
| **Relationship Changes** | Relationships change with shifting interests |

---

## V. Power Element Design

### Worldview Construction Formula
```
Political intrigue world = power structure + interest groups + political rules
```

### Common Power Structures

| Type | Features | Examples |
|------|----------|----------|
| **Imperial Autocracy** | Emperor vs. ministers power game | Kangxi’s clever capture of Ao Bai |
| **Factional Struggles** | Conflicting interest groups | Donglin faction vs. eunuch faction |
| **Harem Rivalry** | Power struggles among concubines | Palace intrigue like *Empresses in the Palace* |
| **Regional Warlordism** | Central vs. local power balance | Regional governors vs. court |
| **Reform Dilemma** | Reformers vs. conservatives | Yongzheng’s new policies |

### Political Intrigue Means Design

| Element | Requirement |
|---------|-------------|
| **Layered** | From overt means to covert layout, from small schemes to grand strategy |
| **Logical** | Every step must conform to political and human logic |
| **Costly** | Using schemes comes at a cost; no zero-cost victory |
| **Restrained** | Schemes counterbalance each other; no invincible means |

---

## VI. Conflict Design

### Conflict Formula
```
Political intrigue conflict = external game (power/interest/status) + internal struggle (ideals/reality/human nature) + historical inevitability
```

### External Conflict (Main Line)

| Conflict Type | Specific Method | Example |
|---------------|-----------------|---------|
| **Power Struggle** | Succession battle / factional disputes / ministerial monopoly | Nine princes’ succession battle |
| **Reform Resistance** | New policies vs. vested interests | Land tax reform affecting gentry |
| **Loyalty vs. Treachery** | Clean vs. corrupt factions | Hai Rui vs. Yan Song |
| **Internal and External Crisis** | Court crisis / border emergencies | Chongzhen facing internal and external troubles |

### Internal Conflict (Subplot)

| Conflict Type | Design Method |
|---------------|--------------|
| **Ideal vs. Reality** | Want to be an honest official but must use scheming / want benevolent rule but must kill meritorious officials |
| **Loyalty vs. Scheming** | Must use conspiracy for greater good |
| **Personal vs. Nation** | Personal feelings vs. political stance |
| **Means vs. Ends** | Using wrong means for right ends |

### Conflict Progression Levels
```
Level 1: Power and interest conflict (what to fight for)
    ↓
Level 2: Means and method game (how to fight)
    ↓
Level 3: Value and ideology clash (why to fight)
```

---

## VII. Foreshadowing Management

### Foreshadowing Carriers (Political Intrigue Specific)

| Carrier Type | Example |
|--------------|---------|
| **Historical Records** | Late emperor’s secret edict / secret memorials / old cases |
| **Abnormal Details** | Unusual promotions / strange personnel transfers |
| **Character Relationships** | Hidden mentorship / secret marriage / unknown grudges |
| **Physical Evidence** | Jade pendants / seals / secret letters / ledgers |
| **Political Patterns** | Rise and fall of dynasties / power succession rules |

### Foreshadowing Setup Principles

| Stage | Method |
|-------|--------|
| **Planting** | Naturally integrate into plot, not emphasized<br>Example: "The eunuch’s hand trembled slightly when presenting the memorial, but no one noticed."<br>Example: "The new governor and the former governor happen to be disciples of the same grand secretary." |
| **Payoff** | Reveal meaning at key moments<br>Example: The eunuch’s trembling is because he has been bribed |

### Common Foreshadowing Designs

**Identity Foreshadowing**:
```
Plant: A minor eunuch shows unusual respect to a certain prince  
Payoff: He is actually the prince’s spy planted in the palace
```

**Interest Foreshadowing**:
```
Plant: A minister strongly advocates opening maritime trade  
Payoff: His son is the largest maritime merchant
```

**Relationship Foreshadowing**:
```
Plant: Two opposing ministers were classmates 30 years ago  
Payoff: Their grudge stems from a cheating scandal in the imperial exams
```

---

## VIII. Chapter Style Design (Political Intrigue Specific)

### Chapter Title Style

Political intrigue titles should be **solemn, meaningful, and imply mystery**:

| Element | Method |
|---------|--------|
| **Title Style** | Elegant and solemn, with hidden wit<br>Example: "Chapter 1 Wind Rises in the Forbidden City" "Chapter 3 Open and Covert Struggles" "Chapter 5 A Gamble for Heaven and Earth" |
| **Chapter Opening** | Start with scene to create atmosphere<br>Example: "Inside the Qianqing Palace, candlelight flickers."<br>Example: "After the court meeting, several grand secretaries remain, clearly with other matters." |
| **Chapter Ending** | Suspense or turning point<br>Example: "At this moment, hurried footsteps came from outside the palace gate—something has happened."<br>Example: "He looked at the secret memorial in his hand, a faint, barely noticeable smile on his lips. The game has been set." |

### Dialogue Design (Core of Political Intrigue)

Political intrigue dialogue must be **implied, witty, and subtly sharp**:

**Good dialogue example**:
```
"Your servant dares to speak frankly, Ao Bai monopolizes power; without removing him, the country will have no peace." Suo E knelt on the ground.  
Kangxi remained expressionless, flipping the memorial: "Ao Bai is the late emperor’s trusted minister, with great merits. Your words, minister, may be... inappropriate."  
"Your Majesty is wise." Suo E kowtowed, "I misspoke."  
They exchanged glances, a tacit understanding flashing in their eyes.  
Kangxi waved to dismiss attendants, lowered his voice: "Cannot move him openly, but secretly..."  
"I understand, Your Majesty," Suo E said, "I will handle it immediately."  
```

**Poor dialogue example**:
```
"We must get rid of Ao Bai."  
"Okay, I agree."  
"Then let’s start planning."  
"Good."  
```

### Psychological Description (Political Intrigue Feature)

Must **show the process of weighing and calculating**:

**Good psychological description**:
```
Kangxi’s fingers lightly traced the memorial. Removing Ao Bai, he had pondered for three whole years. Is the time ripe? Ao Bai’s 30,000 ironclad troops are stationed outside the capital; failure would be disastrous. But if he does not act, imperial power will be hollow forever. He recalled his father Shunzhi’s dying gaze, his mother Empress Dowager Xiaozhuang’s sleepless sighs. He is emperor of the Great Qing; this burden he must bear.
```

**Poor psychological description**:
```
He was worried, but decided to remove Ao Bai anyway.
```

### Rhythm Control (Core of Political Intrigue)

**Rhythm formula**:
```
500 words = 1 strategic confrontation OR 1 intelligence disclosure OR 1 power shift
```

Each scene must have: clear purpose + new information + power flow

---

## IX. Strategic Progression (Political Intrigue Exclusive)

### Five-Stage Strategy Method
```
Planning layout → secret probing → open confrontation → ultimate game → situation settled
```

| Stage | Word Proportion | Key Events | Strategy Depth |
|-------|-----------------|------------|----------------|
| **Planning Layout** | 10-15% | Analyze situation, formulate plan | ★☆☆☆☆ |
| **Secret Probing** | 15-20% | Gather intelligence, initial clashes | ★★☆☆☆ |
| **Open Confrontation** | 25-30% | Court struggles, stance polarization | ★★★☆☆ |
| **Ultimate Game** | 20-25% | Life-or-death battle, strategy peak | ★★★★☆ |
| **Situation Settled** | 15-20% | Dust settles, new order begins | ★★★★★ |

### Strategy Display Techniques

**Layered progression**:
```
Surface problem: how to remove the powerful minister  
Deeper problem: how to stabilize the situation after removal  
Core problem: how to establish true imperial authority  
Ultimate problem: what is the meaning and cost of power
```

**Multi-party game**:
```
Emperor: wants to remove minister and regain power  
Minister: wants to sideline emperor and monopolize power  
Reformers: want to use opportunity to push new policies  
Conservatives: want to maintain status quo  
Neutrals: want to play both sides
```

---

## X. Common Political Intrigue Patterns

### Pattern A: Clever Capture of Powerful Minister (Reference: *Kangxi Emperor*)  
**Structure**:  
- Qi: Young emperor, powerful minister dominates, imperial power wanes  
- Cheng: Secret layout, win hearts, cultivate forces  
- Zhuan: Seize opportunity, thunderous strike, clever capture  
- He: Regain power, open new order, but pay a price

### Pattern B: Reform Dilemma (Reference: *Yongzheng Emperor*)  
**Structure**:  
- Qi: New emperor ascends, determined to reform, touches vested interests  
- Cheng: Push new policies, heavy resistance, undercurrents  
- Zhuan: Conflict intensifies, opposition counterattacks, life and death  
- He: Reform succeeds/fails, leaves historical evaluation

### Pattern C: Succession Battle  
**Structure**:  
- Qi: Succession undecided, princes vie secretly  
- Cheng: Show skills, win factions, open and covert struggles  
- Zhuan: Emperor ill, succession intensifies  
- He: Winner rules, loser is outlaw, cost of power

### Pattern D: Palace Intrigue  
**Structure**:  
- Qi: Newcomer enters palace, first sees dangers  
- Cheng: Learn to survive, gradually compete for favor, make enemies and allies  
- Zhuan: Face crisis, life and death, weak overcomes strong  
- He: Maternal power or tragic death, power is ruthless

### Pattern E: Court Factional Struggle  
**Structure**:  
- Qi: Factional strife intense, two sides oppose, court chaotic  
- Cheng: Protagonist involved, chooses side, difficult decisions  
- Zhuan: Factional conflict escalates, involves imperial power, emperor intervenes  
- He: One faction destroyed, new order established, or both sides damaged

---

**【Special Reminder】**  
Keys to success for short ancient-style political intrigue:  
1. The first 500 words must establish power structure and tense atmosphere  
2. Every 1000 words must contain new intelligence or strategic advancement  
3. Dialogue must hide wit and show political wisdom  
4. Characters’ actions must conform to interest logic and historical logic  
5. Ending must have historical depth, no forced happy ending necessary  
