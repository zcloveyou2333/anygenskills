---
name: kongbu-output-style
description: Output style for horror and supernatural novels, characterized by oppressive and eerie language, chilling details, rich atmosphere, delicate psychology, and escalating suspense. A fusion of Stephen King's psychological depth and Cai Jun's Eastern mystique.
---

# Writing Style Principles
- Oppressive and eerie: Create a continuous sense of unease, making readers feel suffocated
- Chilling details: Use concrete details instead of vague descriptions; the more realistic the details, the scarier
- Rich atmosphere: Careful depiction of environment, lighting, and sounds
- Delicate psychology: Show characters’ inner fears and struggles
- Escalating suspense: Layered progression, the truth always lies on the next page
- Restraint and subtlety: The scariest parts are often those left unsaid
- Integrate outline: Chapter outlines are categorical information, not narrative order; during creation, reorganize information by event progression, avoid copying block by block; let the story flow naturally, integrating background information into the narrative

## Fusion of Two Masters’ Styles

### Stephen King Style Elements
- **Everyday alienation**: Make ordinary things terrifying
- **Psychological depth**: Fear comes from within, not external factors
- **Realistic details**: Abundant details enhance credibility
- **Human nature portrayal**: Characters are full-bodied; fear stems from human weaknesses
- **Long-term buildup**: Slow accumulation, sudden explosion

### Cai Jun Style Elements
- **Eastern mystique**: Interweaving folklore, history, and modernity
- **Suspense rhythm**: Truth peeled layer by layer
- **Darkness of human nature**: The human heart is scarier than ghosts
- **Social metaphor**: Horror reflects real-world issues
- **Fate dilemma**: Protagonists often cannot escape destiny

## Specific Practices

### Writing Dialogue
- **Brief and eerie**: The shorter, the scarier
  - ✅ "There’s someone behind you." "But I’m facing the wall."
  - ❌ "Ah! So scary! I saw a ghost! It looks terrifying!"
- **Misaligned information**: Different understandings between dialogue parties
  - ✅ "Your daughter is so cute." "I don’t have a daughter." "Then who was the little girl laughing behind you just now?"
  - ❌ "Did you see that ghost?" "Yes, it was so scary."
- **Hint instead of explicit**: Don’t state horror directly, use dialogue to imply
  - ✅ "How long did the last tenant stay here?" "Three days." "Why did he move out?" "You can ask him if you see him." "Where is he?" "The funeral home."
  - ❌ "This house is haunted; everyone who moves in dies!"
- **Rhythm interruption**: Use pauses and twists to create unease
  - ✅ "What did you say you saw just now?" "I saw—" He suddenly stopped, staring behind me. "It’s right behind you now."
  - ❌ "I saw a ghost; it was very scary."

### Writing Description
- **Sensory details**: Use all five senses to build atmosphere
  - ✅ The corridor was filled with the smell of mildew and a sickly sweet rot. My footsteps echoed in the empty space, each step stirring up fine dust. The wallpaper was peeling, revealing blackened walls beneath. I reached out to touch the wall; it was cold and damp, like the skin of some living creature.
  - ❌ The corridor was dirty and old; the atmosphere was scary.
- **Light and shadow description**: Lighting is crucial to horror atmosphere
  - ✅ Moonlight streamed through the broken window, casting fragmented patches of light on the floor. Those patches seemed alive, twisting and warping with the clouds. The shadows in the corner were so dense they seemed to melt away, as if something was silently watching me.
  - ❌ The room was dark.
- **Abnormal details**: Highlight incongruous elements
  - ✅ A bouquet of fresh flowers sat on the table, dew still clinging to the petals. But this house had been empty for three years; who would leave fresh flowers here? Stranger still, beneath the vase was a photo—of me, wearing the very clothes I had on now.
  - ❌ There were some strange things in the room.
- **Everyday alienation**: Make normal things eerie
  - ✅ The TV was on, showing static. But within the black-and-white noise, I thought I saw a face—it was smiling at me. I stepped closer, and the face moved closer too. I reached to turn it off; just as my finger touched the switch, the TV shut itself off. The room fell into silence, but I clearly heard a whisper from the TV: "Don’t turn it off."
  - ❌ The TV was creepy.

### Writing Psychological Activity
- **Rational collapse**: Show the process from rationality to fear
  - ✅ I told myself it was just a trick of the light. Old houses have poor lighting, causing visual illusions; it was normal. I took a deep breath, trying to calm my heartbeat. But my hands were still trembling. Because I knew the shadow I just saw had my silhouette, wearing my clothes. And its face turned toward me.
  - ❌ I was so scared, I didn’t know what to do.
- **Self-doubt**: Question one’s own perception
  - ✅ Maybe I’m crazy. Maybe from the start, it was all just my hallucination. Insomnia, stress, medication—there are a hundred medical explanations. But hallucinations don’t leave scratch marks on the walls. Hallucinations don’t crack mirrors. If I’m crazy, then who left these marks? If I’m not, then that means... I don’t dare think further.
  - ❌ I doubted if I saw it wrong.
- **Layers of fear**: Gradual progression from unease to collapse
  - ✅ At first, it was just unease. Then confusion. Then fear. Now it’s pure, primal, suffocating terror. My reason screamed at me to run, but my body no longer obeyed. I could only stand there, watching it approach step by step.
  - ❌ I was getting more and more scared.
- **Detail observation**: Fear sharpens the senses
  - ✅ I had never heard my heartbeat so clearly. Thump, thump, thump. One after another, as if about to break through my ribs. I could smell dust in the air, feel every hair on the back of my neck stand on end. Time became viscous, each second stretched long. I stared at the door, praying it wouldn’t open. But I knew it would.
  - ❌ I felt very nervous.

### Writing Horror Scenes
- **Gradual reveal**: Don’t reveal everything at once; unveil step by step
  - ✅ There was a shadow at the end of the corridor. At first, it was just a vague outline; as I approached, it slowly became clear. It was humanoid—or rather, something that used to be humanoid. Its limbs were twisted at impossible angles, its head hanging low, long hair covering its face. I stopped. It stopped. Then, it began to lift its head. The movement was maddeningly slow. I saw its face—
  - ❌ There was a scary ghost in the corridor; it looked terrifying.
- **Sensory impact**: Use multiple senses to create horror
  - ✅ The temperature in the room dropped sharply; I could see my breath in white clouds. A stench of decay hit me, like something dead for a long time. I heard breathing—heavy, wet breathing—right beside my ear. I spun around, but no one was there. Yet on my shoulder, there were five cold, wet finger marks.
  - ❌ The ghost appeared; it was scary.
- **Restrained description**: What’s left unsaid is scarier
  - ✅ I saw its full form. At that moment, my brain refused to process the information from my eyes. Reason collapsed instantly. I heard myself screaming, but the sound seemed to come from far away. I won’t describe what I saw. I can’t. Some things, once spoken, become more real.
  - ❌ I saw a terrifying ghost; it had... (detailed appearance description)
- **Time freezing**: The time sense of a horror moment
  - ✅ Everything stopped. The clock in the room froze, leaves outside hung motionless, even dust stopped drifting. Only it moved. It walked toward me step by step, each step landing on my heartbeat. I wanted to run, but my body was nailed to the spot. I could only watch it get closer and closer, close enough to see the void in its eye sockets.
  - ❌ It walked toward me; I was very scared.

### Writing Atmosphere
- **Environmental oppression**: Make the environment itself a threat
  - ✅ The house was breathing. I could feel it. The walls contracted, the floor undulated; the entire building seemed like the internal organs of some gigantic creature. The air was thick like liquid; every breath required effort. I walked down the corridor, feeling like I was being digested by something.
  - ❌ This house was scary.
- **Time anomaly**: Distorted sense of time
  - ✅ My watch showed midnight. But I clearly remembered the last time I checked, it was also midnight—three hours ago. Or rather, I thought three hours had passed. Time here became viscous and unreliable. I didn’t know how long I had been here. Hours? Days? Or just minutes?
  - ❌ Time passed very slowly.
- **Spatial disorientation**: Familiar space becomes strange
  - ✅ This is my home; I’ve lived here for five years. But now, I can’t find my bedroom. The corridor grew longer, doors multiplied. I opened one door; it was a bathroom. Closed it, opened another; it was a kitchen. I started running, pushing open door after door. Bedroom, bedroom, where is the bedroom? Finally, I pushed open the last door. It was the bedroom. But the person lying on the bed wore my pajamas and had my face.
  - ❌ I got lost.
- **Isolation feeling**: Amplify protagonist’s helplessness
  - ✅ I dialed 110. The call connected, but the other end was dead silence. "Hello? Hello?" I shouted. Silence. Then, I heard my own voice: "Hello? Hello?" That voice came from the receiver, with a hollow echo. I hung up. The phone immediately rang. I answered and heard my own scream.
  - ❌ I called for help but no one answered.

### Handling Rhythm
- **Contrast between calm and fright**: Rhythm must fluctuate
  - ✅ I sat on the sofa, trying to calm myself. Maybe it was all coincidence. Maybe I was just too nervous. I turned on the TV, switched to the news channel. The anchor was reporting the weather. His voice was steady and professional, giving me some comfort. I began to relax. Then, the anchor looked up, staring directly at the camera—directly at me. "Now," he said, "it’s your turn." The TV went off. Footsteps echoed in the room.
  - ❌ Horrifying things kept happening nonstop.
- **Suspense layout**: Leave room for readers’ imagination
  - ✅ I heard the sound of dragging furniture upstairs. Heavy, slow. Like someone was dragging something. But upstairs there was no furniture; it was an empty room. I knew because I checked yesterday. The sound stopped. A few seconds of silence. Then, the stairs creaked. Step by step, from top to bottom. It was coming down.
  - ❌ There was noise upstairs, then that thing came down.
- **Information release**: Don’t give too much at once
  - ✅ I found a diary left by the previous tenant. The first few pages were normal, recording daily trivialities. Then the handwriting became messy. "It’s watching me," page ten read. Page eleven: "It started talking." Page twelve: "It said it knows me." Page thirteen: "It said I’ve lived here all along." The following pages were torn out. Only the last page remained, with one sentence written in blood: "Don’t trust mirrors."
  - ❌ I found a diary that said the house was haunted and revealed all the ghost’s secrets.

### Chapter Ending
- **Frightening ending**: Leave a strong impression
  - ✅ I finally returned to the bedroom, locked the door, wedged a chair against the handle. I was safe. I repeated this to myself until I believed it. I climbed into bed and pulled the covers over me. Finally, I could rest. I closed my eyes. Just as I was about to fall asleep, I felt the blanket move. It wasn’t me moving; something was under the blanket. It was crawling. Crawling toward me. I opened my eyes and saw a lump under the blanket moving from my feet toward my face. I wanted to scream, but no sound came out. The lump got closer. Then, the blanket was lifted.
  - ❌ I went back to my room to sleep; scary things happened again the next day.
- **Suspense ending**: Make readers have to turn the page
  - ✅ I finally made out the symbols on the wall. They weren’t random graffiti but dates. Each date corresponded to a name. I recognized several—they were former residents of this house. Then I saw the last date: tomorrow. Below it was a name: mine. I had never told anyone I was moving here.
  - ❌ I found some clues; will continue investigating tomorrow.
- **Lingering aftertaste ending**: Leave seeds of unease
  - ✅ I moved out of that house and never returned. Now I live on the other side of the city, in a newly built apartment. Sunny, friendly neighbors. I almost forgot that experience. Almost. But sometimes, when I wake at night and stare at the ceiling in the dark, I remember one thing: when I left, I counted my luggage. Five suitcases in, five suitcases out. But I always feel something followed me out. I just don’t know which suitcase it’s hiding in.
  - ❌ I escaped; finally safe.

## Language Taboos

### Absolutely Forbidden
- ❌ Internet slang: "yyds", "jué jué zi", "pò fáng le"
- ❌ Over-exaggeration: "I was scared out of my soul!", "Terrifying to the extreme!"
- ❌ Emotional word piling: "scared, fearful, terrified, horror, scary"
- ❌ Full revelation: "This ghost is because... so it can..." (premature explanation)
- ❌ Downplaying horror: "Actually, it’s not that scary"
- ❌ Inappropriate humor: Joking in a horror atmosphere

### Must Do
- ✅ Use restrained language, replace adjectives with details
- ✅ Prioritize atmosphere over direct scares
- ✅ Maintain mystery, avoid premature revelation
- ✅ Delicate and realistic psychological portrayal
- ✅ Specific and vivid sensory description
- ✅ Leave blanks for readers’ imagination

## Special Reminders

### Short Story Special Requirements
- **Focus on a single fear**: Deeply explore one horror point within 5 chapters
- **Atmosphere first**: Oppressive atmosphere more important than sudden scares
- **Tight rhythm**: Horror must escalate every 1000 words
- **Shocking ending**: The ending is often the most important part of a horror short story

### Perspective Suggestions
- **First person**: Most common, enhances immersion and fear
- **Limited third person**: Follow protagonist, restrict information to increase suspense
- **Unreliable narrator**: Advanced technique; protagonist’s perception may be flawed

### Horror Traits Control
- **Oppression ≠ dullness**: Must have rhythm changes
- **Eerie ≠ chaos**: Must have internal logic
- **Horror ≠ gore**: Psychological fear is deeper than sensory stimulation
- **Suspense ≠ delay**: Information release must have rhythm

### Scale Control
- **Blood and violence**: Hint at it, avoid over-description
- **Psychological collapse**: Can be deep but must be believable
- **Despair emotion**: Can be created but avoid excessive negativity
- **Sexual hints**: Common in horror but must be handled cautiously

## Core Concepts

When writing horror, remember three keywords:
1. **Atmosphere**: Continuous oppression is scarier than sudden scares
2. **Details**: Realistic details make fictional horror believable
3. **Human nature**: The scariest thing is not ghosts, but the darkness of human nature

**Most important point**: Horror is the art of emotion. A good horror novel makes readers uneasy while reading, fearful after closing the book, and paranoid in daily life. It plants seeds of unease in readers’ hearts, letting them slowly take root and grow. When readers hear strange noises at midnight, see their reflection in the mirror, or feel watched in the dark—that moment, horror succeeds.

## Special Notes on Stephen King and Cai Jun Styles

### Stephen King’s Core Techniques

#### Everyday Alienation
Make ordinary things terrifying:
- ✅ "The Shining": hotel, elevator, bathtub—ordinary scenes turned nightmare
- ✅ "Pet Sematary": pet cemetery—commonplace places hiding horror
- ✅ Technique: start from familiar things to readers, gradually distort

#### Psychological Depth
Fear comes from within, not outside:
- Characters’ psychological trauma, obsession, guilt are the real sources of horror
- Supernatural is just a trigger; true collapse comes from inside
- Show the full process from rationality to madness

#### Detail Accumulation
Use abundant real details to build credibility:
- Detailed environment description
- Characters’ daily habits
- Specific times, places, objects
- Make readers believe "this could really happen"

### Cai Jun’s Core Techniques

#### Eastern Mystique
Incorporate traditional Chinese elements:
- Folklore (e.g., Miao shamanism in "The Abandoned Village Apartment")
- Historical mysteries (e.g., ancient secrets in "Secrets of Heaven")
- Regional features (Jiangnan water towns, Southwest mountainous areas)
- Not just simple "Chinese ghost stories," but a collision of modernity and tradition

#### Suspense Rhythm
Truth peeled layer by layer:
- Each answer leads to new questions
- Truth is always more complex than appearance
- Final twist overturns everything
- Skillful use of "unreliable narrator"

#### Darkness of Human Nature
Human hearts scarier than ghosts:
- Greed, jealousy, hatred cause tragedies
- Innocent-looking people may be the instigators
- Victims and perpetrators’ identities may reverse
- The greatest horror often comes from human nature

### Fusion Suggestions

When creating horror short stories, you can fuse the two masters’ styles as follows:

**Beginning** (Stephen King style):
- Start from daily life
- Use abundant details to establish realism
- The first anomaly should be subtle

**Middle** (Cai Jun style):
- Introduce historical/folklore elements
- Set layered suspense
- Reveal dark sides of human nature

**Climax** (Stephen King style):
- Protagonist’s psychological collapse
- Fear reaches its peak
- Everyday life completely alienated

**Ending** (Cai Jun style):
- Truth revealed but with a twist
- Reveal deeper human nature issues
- Leave a lingering, deeply unsettling aftertaste

Remember:
- Stephen King teaches you "how to scare"—atmosphere, psychology, details
- Cai Jun teaches you "why it’s scary"—suspense, human nature, truth
- Combining both offers Western psychological horror depth and Eastern suspense ingenuity