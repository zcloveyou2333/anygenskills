---
name: kongbu-outline-method
description: Methodology for creating outlines of horror and supernatural short stories, including core synopsis extraction, introduction design, plot structure planning (beginning, development, twist, conclusion), and character shaping guidance. Integrates Stephen King's psychological horror with Cai Jun's Eastern suspense.
---

## Q1-Q3 Question Template

### Q1: Core Idea
**Q1: Core idea and appeal of the story [Brief description]**  
Please describe your story idea in one or two sentences.

### Q2: Core Conflict
**Q2: Core conflict [Brief description]**  
Please describe the novel’s core contradiction or main conflict in one sentence  
(e.g., protagonist uncovers the eerie truth behind an old mansion, paranormal investigator fights evil spirits, tracing and breaking a curse, shocking conspiracy behind urban legends, etc.)

### Q3: Story Tone
**Q3: Story tone [Choose one]**  
- Thriller Horror · Spine-chilling (eerie atmosphere, continuous scares, deeply unsettling)  
- Folklore Tales · Eastern Mysticism (traditional folklore, rural legends, mysterious elements)  
- Suspense Mystery · Truth Reversal (layered puzzles, rational analysis, unexpected endings)  
- Lovecraftian · Cosmic Horror (unknown terror, brink of madness, indescribable)  
- Or briefly describe your story tone

## Chapter File Naming Rules  
Filename format: `{STORY_NAME}-{NN}.md`  
Example: `TheRing-01.md`, `TheRing-02.md`

---

# Horror and Supernatural Outline Creation Methodology

## Overall Orientation

Horror and supernatural fiction emphasizes "**atmosphere building and psychological fear**," focusing on oppressive eerie atmosphere, unknown threats, and human nature’s distortion.

**Core Reference Works**: Stephen King’s *The Shining*, *Pet Sematary*; Cai Jun’s *Deserted Village Apartment*, *Secrets*  
- Learn "psychological horror" from Stephen King — fear stems from the mind, not just simple scares  
- Learn "everyday alienation" from Stephen King — making ordinary things terrifying  
- Learn "Eastern mysticism" from Cai Jun — intertwining folklore, history, and modernity  
- Learn "suspense pacing" from Cai Jun — peeling layers, truth reversals

**Core Principles**:  
- Focus on the essence of fear (unknown, loss of control, death, loneliness, human nature distortion)  
- Pursue "atmospheric oppression": oppressive eeriness, penetrating details, psychological breakdown  
- Combine horror and suspense, **both to scare and to make readers want to know the truth**  
- Use details, atmosphere, and psychological description to drive plot, **avoid blunt scares**  
- Maintain Stephen King’s delicate psychology: characters’ inner fears are scarier than ghosts  
- Incorporate Cai Jun’s suspense rhythm: truth revealed layer by layer, final blow shocks the heart

---

## Overall Creation Formula
```
Horror short story = eerie opening + atmosphere buildup + truth revelation + shocking ending
```

---

## 1. Core Synopsis Writing

### Formula
```
Core synopsis = eerie setting + protagonist’s predicament + horror core
```

### Writing Points
| Element | Requirement | Correct Example | Incorrect Example |
|---------|-------------|-----------------|------------------|
| **Eerie Setting** | Unique + spine-chilling | "Every midnight, children’s laughter echoes in the old mansion, though it has been abandoned for thirty years." | "There is a haunted place." |
| **Protagonist’s Predicament** | Inescapable situation | "To repay his debts, he must stay in this cursed house for seven days." | "Encountered a ghost." |
| **Horror Core** | Touches deep fear | "He gradually realizes the scariest thing is not the ghost, but his forgotten past." | "He got scared and ran away." |

### Excellent Examples
- "The new neighbor never leaves during the day. Every midnight, I hear strange knocking next door—one knock, two knocks, three knocks, then silence. On the seventh night, I finally knocked on his door. Standing behind it was my wife who disappeared three years ago."  
- "A psychologist treats a patient who claims to see the dead. As therapy progresses, he finds every 'dead person' described has actually died unexpectedly. Now, the patient says he sees the doctor himself."  
- "An insomniac takes an experimental new drug. He finally sleeps peacefully but discovers another world in his dreams—where people say he is the real self, and the waking him is just a phantom."

---

## 2. Introduction Writing

### Formula
```
Introduction = eerie opening + atmosphere rendering + fear hook
```

### Writing Points
| Element | Function | Writing Method |
|---------|----------|----------------|
| **First sentence** | Establish uneasy atmosphere | Directly present: eerie phenomena / oppressive environment / abnormal details |
| **Middle part** | Explain protagonist’s situation | Use concrete sensory details to quickly locate<br>Make readers empathize with protagonist’s unease |
| **Last sentence** | Create fear suspense | Throw core mystery / hint terrible truth / leave chilling question |

### Incorporating Fear Themes

The introduction should touch on the core horror themes:

| Theme Type | Specific Direction |
|------------|--------------------|
| **Fear of the Unknown** | Unexplainable phenomena, unseen presence, unknown threats |
| **Fear of Loss of Control** | Loss of bodily control, environment out of control, mental breakdown |
| **Fear of Isolation** | Trapped, abandoned, no one believes |
| **Fear of Human Nature** | Betrayal of trust, identity loss, memory alteration |
| **Fear of Death** | Boundary of life and death, resurrection, eternal torment |

**Goal**: Make readers feel "This is so terrifying I want to know the truth" (fear immersion)

### Example Comparison
| Type | Content |
|------|---------|
| ✅ **Correct** | "On the first night moving into the old mansion, I heard marbles dropping upstairs. One, two, three... They rolled slowly and rhythmically, as if someone was deliberately counting the beat. I climbed the stairs and pushed open the dusty door. The room was empty, moonlight streaming through broken windows onto the floor. Just as I turned to leave, I saw—on the floor, a line of marbles spelled out: 'Welcome home.' But I have never been here before. Until I found an old family photo in the corner, the little boy in it looked exactly like me." |
| ❌ **Incorrect** | "I moved into an old house and found it haunted. I was scared but decided to investigate..." |

---

## 3. Plot Structure Design (Beginning, Development, Twist, Conclusion)

### 【Beginning】Chapter 1: Eerie Arrival (2000-3000 words)

#### Writing Focus
```
Beginning = everyday world + abnormal appearance + uneasy emotion + predicament establishment
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Everyday World** | Establish normal state in first 500 words | Show protagonist’s daily life/work/environment<br>Use details to create "calm before the storm" |
| **Abnormal Appearance** | First eerie signal | Subtle but ominous abnormalities: sounds/smells/shadows<br>Don’t start with big scares |
| **Uneasy Emotion** | Protagonist senses abnormality | Use sensory description: chill/suffocation/feeling watched<br>Conflict between rational doubt and instinctive fear |
| **Predicament Establishment** | Reason protagonist cannot escape | Financial reasons/duties/concern for others trapped<br>Make protagonist stay and face it |

#### Stephen King Techniques
- **Everyday alienation**: Make ordinary things scary (e.g., Room 237 in *The Shining*)  
- **Detail accumulation**: Use many details to build realism, making horror more believable  
- **Psychological depth**: Show protagonist’s mental state, fear comes from inside

#### Taboos
- ❌ Introducing obvious ghosts or monsters at the start  
- ❌ Protagonist stays without reason in danger  
- ❌ Insufficient atmosphere, relying on direct scares

---

### 【Development】Chapters 2-3: Fear Escalation (2000-3000 words each)

#### Chapter 2 Focus
```
Chapter 2 = frequent abnormalities + rational analysis + clue discovery + bigger questions
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Frequent Abnormalities** | Increase eerie phenomena | From occasional to frequent / from faint to obvious<br>Each time breaks common sense further |
| **Rational Analysis** | Protagonist tries to explain | Seek scientific explanations / ask others / research<br>Rational explanations always insufficient |
| **Clue Discovery** | Reveal partial truth | Historical records / eyewitness testimony / physical evidence<br>Clues point to scarier possibilities |
| **Bigger Questions** | Create deeper suspense | Clues lead to new questions / contradictions found |

#### Chapter 3 Focus
```
Chapter 3 = direct encounter + psychological collapse + failed help + isolation
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Direct Encounter** | Face horror directly | Don’t fully reveal, keep mystery<br>Use protagonist’s reaction to highlight horror |
| **Psychological Collapse** | Sanity shaken | Doubt own perception / fear going mad<br>Blurred line between reality and hallucination |
| **Failed Help** | No one believes | Others don’t see / no footage / treated as mental illness<br>Deepen isolation |
| **Isolation** | Must face alone | Communication cut off / others leave / help channels blocked |

---

### 【Twist】Chapter 4: Truth Approaches (2000-3000 words)

#### Writing Focus
```
Twist = key discovery + truth puzzle + greatest fear + desperate choice
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Key Discovery** | Reveal core secret | Protagonist finds crucial clue / unexpectedly discovers truth entry<br>Previous doubts start connecting |
| **Truth Puzzle** | Gather fragmented info | History, phenomena, motives correspond one by one<br>Make readers suddenly realize |
| **Greatest Fear** | Horror peaks | Truth scarier than imagined<br>Protagonist realizes they are part of the game |
| **Desperate Choice** | Must decide | Escape or face / believe or doubt<br>Choices all have terrible costs |

#### Cai Jun Techniques
- **Truth reversal**: Truth is always more complex than it appears  
- **Darkness of human nature**: The scariest is often not supernatural, but the human heart  
- **Fate dilemma**: Protagonist finds they were doomed from the start

#### Taboos
- ❌ Truth too simple or cliché  
- ❌ Using coincidence to solve mystery  
- ❌ Horror elements suddenly disappear

---

### 【Conclusion】Chapter 5: Final Resonance (2000-3000 words)

#### Writing Focus
```
Conclusion = final confrontation + cost paid + ending reversal + deeply unsettling
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Final Confrontation** | Protagonist’s last action | Can be escape / fight / compromise / sacrifice<br>Must fit character development |
| **Cost Paid** | Show consequences | Physical cost / mental trauma / loss of loved ones<br>Horror always has a price |
| **Ending Reversal** | Final blow | Seems over but leaves suspense<br>Or reveals greater horror |
| **Deeply Unsettling** | Open-ended resonance | Make readers think after closing book<br>Ordinary life details become suspicious |

#### Types of Horror Endings
| Type | Features | Suitable Scenes |
|-------|----------|-----------------|
| **Escape** | Protagonist escapes but is scarred | Psychological horror themes |
| **Sacrifice** | Protagonist sacrifices to stop bigger disaster | Redemption themes |
| **Cycle** | Horror repeats | Curse themes |
| **Reversal** | Last reveal overturns truth | Suspense horror |
| **Open-ended** | Horror persists, unclear ending | Fear of unknown |
| **Despair** | Protagonist cannot escape fate | Fatalistic horror |

#### Taboos
- ❌ Forced happy ending, breaking horror atmosphere  
- ❌ Ending with "it was all a dream"  
- ❌ Explaining all mysteries (keep mystery)

---

## 4. Character Shaping Method

### Protagonist Design

| Dimension | Requirement | Correct Example | Incorrect Example |
|-----------|-------------|-----------------|------------------|
| **Initial State** | Ordinary + with flaws | "Insomniac" "Debt-ridden writer" | "Superpowered" |
| **Core Flaw** | Weakness affecting judgment | "Disbelieves supernatural" "Overly rational" "Psychological trauma" | "Perfect without flaws" |
| **Personality Tags** | 2-3 distinct traits | "Rational but stubborn" "Brave but reckless" "Sensitive but fragile" | "Ordinary person" |
| **Relevance** | Connected to horror | "Lived here as child" "Professionally related" "Fated" | "Pure bystander" |

### Personality Specifics
```
✅ "Li Ming is a psychologist, trained to explain everything scientifically. When he hears footsteps at midnight, his first thought is 'old house’s thermal expansion.' When he sees bloody handprints on the wall, he thinks 'maybe a prank by the previous tenant.' This rational mindset is his armor and his cage—when true horror arrives, his worldview will collapse."  
❌ "He is an ordinary person who encounters something scary."
```

### Common Protagonist Types (Horror)

| Type | Features | Personality | Suitable Themes |
|-------|----------|-------------|-----------------|
| **Skeptic** | Disbelieves supernatural | Rational, stubborn, eventually breaks down | Science vs supernatural |
| **Sensitive** | Easily senses abnormal | Neurotic, lonely, disbelieved | Psychological horror |
| **Truth Seeker** | Actively investigates truth | Curious, stubborn, reckless | Suspense horror |
| **Victim** | Passively involved | Innocent, fragile, grows stronger | Curse / pursuit |
| **Guilty** | Carries secret/sin | Guilty, self-punishing, seeking redemption | Manifestation of inner demons |

### Supporting Character Design (Horror Features)

| Type | Role | Notes |
|-------|------|-------|
| **Doubter** | Doesn’t believe protagonist | Increases isolation, may face same horror eventually |
| **Informed** | Knows the truth | Usually meets bad end, reveals key info before death |
| **Victim** | Encounters horror first | Foreshadows protagonist’s fate |
| **Horror Source** | Ghost/monster/madman | Keep mysterious, don’t reveal fully too soon |

### Relationship Network Design (Horror Specific)

| Element | Requirement |
|---------|-------------|
| **Trust Crisis** | Close ones may be threats / no one believes protagonist |
| **Deepening Isolation** | Relationships break down, protagonist grows lonelier |
| **Survival Pressure** | Some die from horror, survivors bear psychological pressure |
| **Betrayal and Sacrifice** | Some betray others for survival / some sacrifice themselves |

---

## 5. Horror Element Design

### Worldview Construction Formula
```
Horror world = superficially normal + hidden abnormality + rule setting
```

### Common Horror Types

| Type | Features | Examples |
|-------|----------|----------|
| **Ghosts and Supernatural** | Traditional Eastern horror | Vengeful spirits, curse inheritance, forbidden places |
| **Psychological Horror** | Reality and hallucination blur | Schizophrenia, paranoia, memory alteration |
| **Monster Hunt** | Unknown creature threat | Mutants, supernatural beings, indescribable entities |
| **Locked Room Dilemma** | Fear of enclosed spaces | Trapped in haunted house, escape room, underground maze |
| **Curse Transmission** | Horror spreads | Chain deaths, rule-based killings, viral spread |

### Horror Setting Principles

| Element | Requirement |
|---------|-------------|
| **Has Rules** | Horror follows certain laws, predictable but unavoidable |
| **Has Cost** | Breaking taboo / touching truth requires paying a price |
| **Has Escalation** | Horror intensifies gradually, not static |
| **Has Logic** | Even supernatural must be internally consistent |

---

## 6. Conflict Design

### Conflict Formula
```
Horror conflict = external threat (ghost/monster/killer) + internal collapse (sanity/trust/memory) + survival choice
```

### External Conflict (Mainline)

| Conflict Type | Specific Methods | Examples |
|---------------|------------------|----------|
| **Supernatural Threat** | Ghosts / curses / monster pursuit | Dead return for revenge |
| **Human Malice** | Serial killer / cult / madman | Humans scarier than ghosts |
| **Environmental Dilemma** | Trapped / lost / isolated | Inescapable space |
| **Time Pressure** | Countdown / prophecy / curse activation | Must solve within deadline |

### Internal Conflict (Subplot)

| Conflict Type | Design Method |
|---------------|---------------|
| **Sanity Collapse** | Doubt own judgment / can’t tell real from fake |
| **Trust Crisis** | Don’t know who to trust |
| **Moral Dilemma** | Do things against conscience to survive |
| **Identity Loss** | Discover self is not who thought |

### Conflict Progression Levels
```
Level 1: Abnormal phenomena (sense something wrong)
    ↓
Level 2: Confirm danger (horror truly exists)
    ↓
Level 3: Uncover truth (know horror source)
    ↓
Level 4: Survival choice (how to respond)
```

---

## 7. Foreshadowing Management

### Foreshadowing Carriers (Horror Specific)

| Carrier Type | Examples |
|--------------|----------|
| **Detail Abnormality** | Shadow in mirror is off / extra person in photo |
| **Time Confusion** | Clock runs backward / date contradictions / memory bias |
| **Sensory Deception** | Smell something shouldn’t / hear nonexistent sounds |
| **Cursed Objects** | Strange antiques / bloodstained token / forbidden book |
| **Character Abnormality** | Someone acts strangely / someone shouldn’t appear |

### Foreshadowing Setting Principles

| Stage | Method |
|-------|--------|
| **Planting** | Subtle, ambiguous<br>Example: "In the TV reflection, I thought I saw a shadow behind me. I turned, no one was there."<br>Example: "Neighbors said the house was empty for three years. But I clearly saw someone at the window." |
| **Payoff** | Reveal meaning at key moment<br>Example: That shadow was always there, protagonist just subconsciously ignored it |

### Common Foreshadowing Designs

**Identity Foreshadowing**:
```
Planting: Protagonist feels inexplicably familiar with a place  
Payoff: Protagonist actually lived there as a child, memory was sealed
```

**Time Foreshadowing**:
```
Planting: Calendar or news dates have subtle contradictions  
Payoff: Protagonist is actually dead, living in a pre-death loop
```

**Character Foreshadowing**:
```
Planting: A supporting character only appears when protagonist is alone  
Payoff: That person doesn’t exist, is protagonist’s hallucination or split personality
```

---

## 8. Chapter Layout Design (Horror Specific)

### Chapter Title Style

Horror titles should be **eerie, suggestive, and evoke unease**:

| Element | Method |
|---------|--------|
| **Title Style** | Concise and eerie, implying ominousness<br>Example: "Chapter 1 Midnight Visitor"<br>Example: "Chapter 3 Mirror Person"<br>Example: "Chapter 5 She’s Behind Me" |
| **Chapter Opening** | Directly create uneasy atmosphere<br>Example: "At midnight, the doorbell rang."<br>Example: "The me in the mirror blinked half a beat late." |
| **Chapter Ending** | Scare point or suspense hook<br>Example: "I turned around and found she had been standing behind me all along, smiling at me."<br>Example: "My own voice came from the phone: 'Why are you in my house?'" |

### Dialogue Design (Horror Core)

Horror dialogue should be **short, suggestive, and unsettling**:

**Good dialogue example**:
```
"Do you live alone?" the stranger asked.  
"Yes," I answered cautiously.  
He glanced behind me and smiled: "No, you’re not alone."  
I turned to look, empty. When I looked back, he had vanished.
```

**Poor dialogue example**:
```
"This place is so scary!"  
"Yeah, let’s get out of here!"  
"Okay!"
```

### Psychological Description (Horror Feature)

Should be **delicate, realistic, and progressively breaking down**:

**Good psychological description**:
```
I told myself it was just a hallucination. People hallucinate when extremely tired, that’s scientifically proven. I repeated this like a mantra. But my hands trembled. Because I knew I wasn’t that tired. And hallucinations don’t leave handprints on mirrors.
```

**Poor psychological description**:
```
I was very scared and didn’t know what to do.
```

### Pace Control (Horror Core)

**Pace formula**:
```
500 words = 1 eerie detail OR 1 atmosphere rendering OR 1 horror escalation
```

Each scene must have: oppression + new unease + driving force

---

## 9. Atmosphere Progression (Horror Exclusive)

### Five-Stage Fear Method
```
Unease → Doubt → Confirmation → Despair → Collapse/Counterattack
```

| Stage | Word Count Ratio | Key Events | Fear Intensity |
|-------|------------------|------------|---------------|
| **Unease** | 10-15% | Sense abnormality, rational explanation | ★☆☆☆☆ |
| **Doubt** | 15-20% | Abnormalities increase, start doubting | ★★☆☆☆ |
| **Confirmation** | 25-30% | Direct encounter, fear confirmed | ★★★☆☆ |
| **Despair** | 20-25% | Help fails, isolated | ★★★★☆ |
| **Collapse/Counterattack** | 15-20% | Mental breakdown or final fight | ★★★★★ |

### Atmosphere Building Techniques

**Sensory layers deepening**:
```
Auditory: strange sounds  
Visual: eerie images  
Tactile: abnormal temperature/texture  
Olfactory: smells that shouldn’t be there  
Sixth sense: feeling watched/followed
```

**Use of time nodes**:
```
Midnight: traditional horror time  
3 AM: "devil’s hour"  
Dusk: blurred light, half-real half-illusion  
Rainy/foggy nights: low visibility, oppressive atmosphere
```

---

## 10. Common Horror Patterns

### Pattern A: Haunted House Exploration  
**Structure**:  
- Beginning: move in / investigate new environment  
- Development: frequent abnormalities, search for truth  
- Twist: uncover historical tragedy  
- Conclusion: confront vengeful spirit, escape or resolve

### Pattern B: Curse Transmission  
**Structure**:  
- Beginning: trigger curse condition  
- Development: death pattern emerges  
- Twist: seek cure  
- Conclusion: break or continue curse

### Pattern C: Psychological Collapse  
**Structure**:  
- Beginning: normal life cracks appear  
- Development: blurred line between sanity and madness  
- Twist: discover shocking truth (multiple personalities / experiments / already dead)  
- Conclusion: accept reality or collapse completely

### Pattern D: Monster Hunt  
**Structure**:  
- Beginning: discover unknown threat  
- Development: flee and hide  
- Twist: learn monster’s weakness  
- Conclusion: fight or sacrifice

---

**【Special Reminder】**  
Key to success of horror short stories:  
1. First 500 words must establish uneasy atmosphere and eerie details  
2. Every 1000 words must have horror escalation or new unease  
3. Use details and psychological description instead of direct scares  
4. Maintain mystery, don’t reveal everything too early  
5. Ending must be either shocking reversal or deeply unsettling  
