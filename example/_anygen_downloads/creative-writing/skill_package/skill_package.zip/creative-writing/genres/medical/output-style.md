---
name: yiliao-output-style
description: The output style for medical life novels, with language that is professional and accurate, narration that is calm and restrained, emotions that are sincere and profound, and humanistic care that is warm. It integrates professional rigor with the brilliance of humanity.
---

# General Writing Style Principles
- Professional and Accurate: Medical terminology and procedures must be precise and withstand scrutiny
- Calm and Restrained: Convey deep emotions through rational narration
- Realistic Details: Use authentic medical details to establish credibility
- Humanistic Care: Show warmth and humanity beneath professionalism
- Sincere Emotion: Moving without being sentimental
- Life-and-Death Reflection: Touch on the essential questions of life
- Integrated Outline: Chapter outlines serve as categorized information, not narrative order; during creation, reorganize information according to event progression, avoid copying block by block; let the story flow naturally, integrating medical information into the narration

## Style Integration for Medical Themes

### Elements of Professional Rigor
- **Accurate Terminology**: Use medical terms precisely but integrate them naturally into the narration
- **Realistic Procedures**: Medical processes conform to actual operational standards
- **Credible Data**: Vital signs data are reasonable and authentic
- **Solid Details**: Medical instruments, drugs, and examination methods are accurate
- **Tight Logic**: Diagnostic reasoning aligns with medical logic

### Elements of Humanistic Care
- **Dignity of Life**: Respect the value of every life
- **Medical Vocation**: Show the professional spirit of healthcare workers
- **Patient Perspective**: Focus on the feelings of patients and their families
- **Warm Moments**: Capture genuine emotional exchanges between doctors and patients
- **Deep Reflection**: Contemplate life, medicine, and humanity

## Specific Practices

### When Writing Dialogue
- **Professional and Concise**: Medical staff dialogue should be professional but not obscure
  - ✅ "Blood pressure 90/60, heart rate 120, respiration 28." "Early shock, start fluid resuscitation immediately, establish a second IV line."
  - ❌ "The patient's condition isn't good, we need to figure something out quickly."
- **Emotionally Restrained**: Dialogue with patients' families should be warm but not sentimental
  - ✅ "We will do our best," Dr. Chen said to the anxious family, "but you must be prepared; the next 72 hours are critical."
  - ❌ "Rest assured, I will definitely save your family member! I swear!"
- **Humanity Revealed**: Key moment dialogues should be genuine and touching
  - ✅ "If it were you, would you choose to continue treatment?" the patient asked. Dr. Chen was silent for a long time: "I would choose to leave with dignity. But that is my choice, not your answer."
  - ❌ "You should listen to the doctor; we are all doing this for your good."
- **Powerful Ellipsis**: Some things need not be fully said
  - ✅ The monitor alarm suddenly turned into a long tone. Dr. Chen glanced at the clock. 3:47 AM. He gently pressed the stop button.
  - ❌ "The patient has passed away. We did our best; please accept our condolences."

### When Writing Descriptions
- **Medical Scene Details**: Use specific details to build professionalism
  - ✅ The operating room temperature was steady at 22°C. Under the shadowless lamp, sweat beaded on Dr. Chen’s forehead. The assistant tacitly handed over the hemostat; the metal instrument gleamed coldly under the light. The monitor showed: BP 85/55, HR 135, SpO2 92%. Each number reminded him that time was running out.
  - ❌ The operating room was tense; the doctor was performing surgery, and the situation was critical.
- **Vital Signs Data**: Use data to create tension
  - ✅ Heart rate jumped from 110 to 130, blood pressure dropped from 100/70 to 85/50, oxygen saturation fell from 95% to 90%—each change announced life slipping away.
  - ❌ The patient’s condition was worsening.
- **Humanistic Observation**: Capture human moments within professional settings
  - ✅ ICU visiting hours lasted only half an hour. The elderly man trembled as he held his comatose wife’s hand, whispering, "I’m waiting for you to come home." The monitor’s beeping sounded like a kind of response.
  - ❌ The family was worried about the patient and stayed by their side.
- **Environmental Atmosphere**: Use setting to enhance emotion
  - ✅ The emergency room was always brightly lit at dawn. The smell of disinfectant mixed with anxiety. In the waiting area, some dozed off, some silently cried, some kept scrolling on their phones. Life and death were separated here by only a door.
  - ❌ The emergency room was busy with many patients waiting.

### When Writing Psychological Activity
- **Professional Judgment Process**: Show the doctor’s thought process
  - ✅ Persistent high fever for three days, normal white blood cell count, mildly elevated C-reactive protein—not typical of bacterial infection. Chest X-ray normal—exclude pneumonia. Negative abdominal exam—not intra-abdominal infection. Dr. Chen’s mind quickly searched: Could it be viral? Or... an immune system issue?
  - ❌ He felt the case was strange and decided to take a closer look.
- **Professional Pressure**: Show the doctor’s inner struggle
  - ✅ Thirty years of clinical experience told Dr. Chen the surgery’s success rate was under 30%. But without it, the patient would definitely die. He looked at the trembling signature on the consent form and felt a familiar weight—that of a life, and the responsibility a doctor must bear.
  - ❌ He felt stressed but decided to proceed with the surgery.
- **Human Warmth**: Show the doctor’s human side
  - ✅ When Dr. Chen removed his gloves, his hands trembled. Not from nervousness—the surgery was successful. It was because he recalled a night twenty years ago, standing outside the ICU watching his father lying in bed. Back then he was a resident, powerless but waiting. Now he was chief physician, able to save many lives, yet still unable to stop death.
  - ❌ He thought of his family and felt sad.
- **Ethical Reflection**: Show the complexity of moral dilemmas
  - ✅ If he told the patient the truth, the patient might despair; if he concealed it, the patient lost the right to choose the final stage of life. The doctor’s benevolent lie versus the patient’s right to know—which is more important? Dr. Chen didn’t know. Maybe there was no answer.
  - ❌ He was conflicted about whether to tell the patient the truth.

### When Writing Medical Procedures
- **Accurate Process**: Steps must conform to reality
  - ✅ "Disinfect with povidone-iodine, drape sterile towels," Dr. Chen’s voice was steady. "1% lidocaine local anesthesia." The needle pierced the skin, injected anesthetic, no blood on aspiration. "Puncture needle." The assistant handed over the central venous catheter needle. Locate puncture site, insert needle at 30 degrees, advance slowly. Negative pressure, dark red blood return. "Guidewire."
  - ❌ The doctor gave the patient an injection, then inserted a tube.
- **Team Coordination**: Show medical staff cooperation
  - ✅ "Adrenaline 1 mg," Dr. Chen ordered. "Injection complete," the nurse responded. "Continue chest compressions," the anesthetist took over compressions, steady rhythm at 100-120 per minute. "Bag-valve-mask ventilation." The intern assisted. Everyone was a vital link in the chain of survival, indispensable.
  - ❌ The doctor and nurse resuscitated the patient together, cooperating well.
- **Emergency Handling**: Show calmness under pressure
  - ✅ The monitor suddenly emitted a piercing alarm. "V-fib!" the nurse shouted. Dr. Chen instantly judged: "Defibrillate, 200 joules." "Charged." "Everyone clear." Shock delivered. The patient’s body twitched. Watching the monitor—still V-fib. "360 joules, again."
  - ❌ The patient suddenly had an emergency; the doctor rushed to resuscitate.

### When Writing Emotional Scenes
- **Restrained Expression**: Convey emotion through actions and details
  - ✅ When Dr. Chen walked out of the ICU, the family stood up in unison, eyes full of expectation. He removed his mask, looked at them, opened his mouth, and finally said only three words: "I’m sorry." The elderly man’s cane fell to the floor with a crisp sound.
  - ❌ Dr. Chen sadly told the family the patient had died. The family cried.
- **Genuine Emotion**: Emotions at key moments must be sincere
  - ✅ "Thank you, doctor," the elderly man held Dr. Chen’s hand, eyes moist. "You saved my daughter and our whole family." Dr. Chen wanted to say it was his duty, but looking at the elderly face full of wrinkles, he couldn’t. He just squeezed the man’s hand: "She is strong." This was not a doctor comforting family, but a witness to a miracle, heartfelt respect.
  - ❌ The family thanked the doctor; the doctor said it was his duty.
- **Life-and-Death Moments**: Use calm narration to convey impact
  - ✅ Time froze at 4:12 AM. The monitor waveform flattened into a straight line, emitting a continuous tone. Dr. Chen stared at the line, hand on the crash cart, unmoving. They had been resuscitating for an hour. All that could be done was done. He gently pressed the stop button; the ward returned to silence. "Record the time," his voice was soft.
  - ❌ The patient could not be resuscitated and died after 4 AM; the doctor announced cessation.

### When Writing Ethical Dilemmas
- **Multiple Perspectives**: Show the reasonableness of different viewpoints
  - ✅ "We should respect the patient’s choice," the young doctor said. "But he’s currently unconscious; was this choice made when he was lucid?" the chief asked. "He wrote an advance directive." "That was three years ago; there are new treatments now." "So do we override his wishes?" "No, we give him a chance to update his choice." "What if he insists?" "Then we respect it."
  - ❌ Doctors had differing opinions on treatment; the chief made the final decision.
- **No Standard Answers**: Present the complexity of dilemmas
  - ✅ Give this liver to the eight-year-old child, she can live a full life; give it to the fifty-year-old mother, three children won’t become orphans. Dr. Chen looked at the two medical records, each a living life, each with reasons that cannot be abandoned. This is not a math problem but an ethical dilemma with no standard answer.
  - ❌ The doctor faced a difficult choice and made the right decision.
- **Clear Costs**: Show consequences of choices
  - ✅ "If we use this experimental drug, the patient might live six months longer or might die faster." "If not?" "Death within three months is certain." "So it’s a gamble?" "No, it’s seeking hope in despair. But I must tell you—we might lose."
  - ❌ The doctor chose a risky treatment.

### When Writing Climax Scenes
- **Tight Rhythm**: Use short sentences to create tension
  - ✅ BP 60/40. HR 150. "Increase dopamine." "Maxed out." "Adrenaline." "Inject." BP 58/38. "Prepare intubation." "Laryngoscope." "Cannot see vocal cords." "Suction." BP 50/30. "Hurry!" Click. Intubation successful. Bag ventilation. Oxygen given. SpO2 rising: 65%, 70%, 78%, 85%. Dr. Chen exhaled.
  - ❌ The patient was critical; the doctor nervously resuscitated and finally saved the patient.
- **Sensory Details**: Engage multiple senses
  - ✅ The operating room was filled only with the monitor’s beeping and ventilator’s hissing. Dr. Chen could hear his heartbeat, smell the iron scent of blood, feel sweat in his gloved palm. Before him, a ruptured vessel gushed blood. His hand was steady. Found bleeding point, hemostat, suturing. One stitch, two stitches, three stitches.
  - ❌ The surgery was tense; the doctor focused on the operation.
- **Emotional Restraint**: The more critical, the calmer
  - ✅ The monitor showed sinus rhythm, BP stable at 110/70. Surgery successful. Dr. Chen sutured the last stitch, cut the thread, stepped back. Soft applause in the OR. He removed his mask; sweat dripped from his forehead onto the sterile drape. "Sutured," he said calmly. But only he knew his heart rate exceeded 140 in those ten minutes.
  - ❌ The surgery was finally successful! The doctors breathed a sigh of relief and smiled!

### When Writing Endings
- **Respond to Theme**: Ending echoes the opening question
  - ✅ Opening: Should doctors tell terminal cancer patients the truth? Ending: The patient completed a world tour in the last three months of life. He thanked the doctor’s honesty, which allowed him to plan his final chapter with dignity. But Dr. Chen knew another patient who was told the truth chose to end life. This question will never have a single answer.
  - ❌ The problem was solved, and everyone was satisfied.
- **Leave Resonance**: Give readers space to think
  - ✅ Five years later, Dr. Chen met that girl on the street. She was in college, healthy, happy, full of vitality. She recognized him and ran over to say thank you. Dr. Chen smiled and waved. He didn’t tell her that the decision that year kept him awake all night, his hand trembling when signing. Nor that he would face countless similar decisions. This is a doctor’s life—making choices amid uncertainty, persisting amid doubt.
  - ❌ The patient recovered; the doctor was pleased and felt all efforts were worthwhile.
- **Warm Conclusion**: End with human warmth
  - ✅ After work, Dr. Chen passed the pediatric ward and saw children sunbathing in the corridor. They wore masks, received IVs, but their eyes shone. A little girl waved at him; he waved back. Medicine cannot conquer all diseases; doctors are not gods. But in these children’s smiles, he saw the meaning of his persistence—not to conquer death, but to accompany life.
  - ❌ The doctor felt his work was meaningful and decided to continue.

### Handling Pace
- **Establish Medical Atmosphere Within 500 Words**: Immerse readers immediately
  - ✅ The monitor alarm pierced the silence at 3 AM. Dr. Mo rushed into the ICU; bed 12’s blood pressure had dropped to 70/40. "Shock!" The nurse on duty was preparing resuscitation. Dr. Mo washed hands while quickly reviewing the chart: male, 56, third day post-acute myocardial infarction PCI, sudden BP drop.
  - ❌ This story takes place in a hospital; the protagonist is a doctor...
- **Each Scene Must Advance Condition**: No meaningless description
  - ✅ "Blood routine results are out," the nurse handed the report. Dr. Chen glanced: "WBC 2.8, platelets 35." His brow furrowed. This was not a simple infection. "Do bone marrow biopsy immediately." The young doctor was stunned: "Bone marrow biopsy?" "Possible leukemia. No time to wait."
  - ❌ The doctor looked at the results, felt something was wrong, and decided to do more tests.
- **Information Revealed Gradually**: Avoid dumping too much at once
  - ✅ First round of rounds: persistent fever of unknown cause. Second: found splenomegaly. Third: bone marrow biopsy results—acute lymphoblastic leukemia. Each discovery clarified diagnosis and worsened the patient’s plight.
  - ❌ The doctor found through detailed tests that the patient had leukemia and was in serious condition.

### Chapter Endings
- **Condition Turning Point**: Use changes to create suspense
  - ✅ Dr. Chen had just left the ward when the nurse caught up: "Bed 12 has a fever again, 39.5°C." As he turned back, a bad premonition arose. Fever on day five post-chemotherapy—most feared is... He opened the door; the patient was shivering. Neutropenia with infection. The most dangerous moment had arrived.
  - ❌ The patient’s condition changed; the next chapter continues.
- **Emotional Climax**: End at key emotional moments
  - ✅ "If there is a next life, I still want to be your daughter," the girl smiled at her mother. The monitor numbers dropped. The mother tightly held her daughter’s hand; tears silently fell. ICU lights were cold and harsh, but at this moment, the world seemed to hold only the two of them. Dr. Chen stood outside, not entering. Some moments don’t need a doctor.
  - ❌ The mother and daughter said goodbye in the ward; the scene was touching.
- **Ethical Suspense**: Pose moral dilemmas
  - ✅ The ethics committee’s decision would be announced tomorrow morning. If approved, the experimental surgery could proceed, giving the patient a 30% survival chance. If not, death within a week was certain. Dr. Chen looked out at the night, recalling the patient’s words when signing consent: "Let’s gamble; I have nothing to lose." But what he might lose was life.
  - ❌ Tomorrow will decide if surgery proceeds; the doctor is waiting for results.

## Language Taboos

### Absolutely Forbidden
- ❌ Internet slang: "yyds" "juejuezi" "laughing to death"
- ❌ Inaccurate medical terms: "heart exploded" "vessels blocked"
- ❌ Overly sentimental expressions: "Doctors are angels!" "Simply too great!"
- ❌ Stereotyped characters: "Cold-blooded doctor" "Angel-like nurse"
- ❌ Simple good-vs-evil binaries: "Bad doctor" "Evil family"
- ❌ Medical mythologizing: doctors can cure any disease; medicine is omnipotent

### Must Achieve
- ✅ Accurate and standardized medical terminology
- ✅ Realistic procedural details that withstand scrutiny
- ✅ Character behavior consistent with professional traits
- ✅ Sincere but not sentimental emotions
- ✅ Calm and objective narration with warmth
- ✅ Realistic and credible endings that do not avoid medical limitations

## Special Reminders

### Short Story Specific Requirements
- **Focus on Core Case**: Deeply explore one case within 5 chapters; avoid too many cases
- **Balance Professionalism and Humanity**: Medical details serve characters and themes
- **Tight Pace**: Every 1000 words must advance condition or emotion
- **Warm Ending**: Medical short stories must end with humanistic care

### Perspective Suggestions
- **Third-Person Limited**: Most common, follow the doctor, limit information disclosure
- **First-Person**: Suitable for doctor’s notes or patient diaries
- **Dual Perspective**: Doctor + patient/family, showing different viewpoints

### Medical Characteristics Control
- **Professional ≠ Cold**: Accurate terms but narration has warmth
- **Restrained ≠ Indifferent**: Rational narration with deep care
- **Realistic ≠ Brutal**: Show reality and hope
- **Reflective ≠ Preachy**: Present complex ethics through story

### Emotional Scale Control
- **Restrained but Sincere**: Not sentimental, but genuine emotion
- **Humanity in Professionalism**: The calmest judgment hides the deepest care
- **Clear Costs**: Every choice has real consequences
- **Complex Humanity**: No perfect doctors, no pure malice

## Core Philosophy

When writing medical themes, remember three keywords:
1. **Professionalism**: Medical details must be accurate and credible
2. **Humanity**: Focus on the dignity and value of life
3. **Reflection**: Touch on deep ethical issues

**Most importantly**: Medical novels are neither medical textbooks nor moral lectures. They use medicine as a vehicle to explore eternal themes of life, death, choice, and responsibility. Good medical novels let readers see humanity beneath the white coat, feel the choices between life and death, and ponder questions never before considered. They write warm stories with a calm pen, wrap humanistic cores in professional shells, and respond to eternal puzzles with real cases. This is the power of medical novels.