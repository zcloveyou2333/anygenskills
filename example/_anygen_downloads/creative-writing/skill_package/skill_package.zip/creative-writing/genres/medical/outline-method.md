---
name: yiliao-outline-method
description: Methodology for creating outlines of medical life short stories, including core synopsis extraction, lead design, narrative structure planning, and character development guidance. Integrates professional medical knowledge with profound humanistic care.
---

## Q1-Q3 Question Templates

### Q1: Core Idea
**Q1: Core idea and appeal of the story [Brief description]**  
Please describe your story idea in one or two sentences.

### Q2: Core Conflict
**Q2: Core conflict [Brief description]**  
Please describe the novel’s core contradiction or main conflict in one sentence  
(e.g., a medical team racing against time against a rare disease, ethical dilemmas faced by researchers overcoming cancer, the humanity and life-or-death choices in an emergency room, moral controversies triggered by gene editing technology, etc.)

### Q3: Story Tone
**Q3: Story tone [Choose one]**  
- Benevolent healer · Life and death critical (hospital routine, emergency rescue, doctor-patient relationship)  
- Scientific breakthrough · Pushing limits (laboratory perspective, disease conquest, scientific breakthroughs)  
- Bioethics · Deep reflection (gene editing, organ transplantation, euthanasia topics)  
- Warm healing · Human affection (patient stories, life insights, human brilliance)  
- Or please briefly describe your story tone

## Chapter File Naming Rules  
Filename format: `{STORY_NAME}-{NN}.md`  
Example: `Light_of_Life-01.md`, `Light_of_Life-02.md`

---

# Medical Life Outline Creation Methodology

## Overall Orientation

Medical life stories emphasize "**life-and-death choices and humanistic care**," centering on medical professionalism, ethical dilemmas, and the brilliance of humanity.

**Core Principles**:  
- Focus on life topics (life-and-death decisions, medical ethics, professional integrity, human dignity, etc.)  
- Pursue "emotional impact": professional details, moral dilemmas, human warmth  
- Balance hard science and warmth, but **never stray from medical reality and ethical reflection**  
- Use disease, diagnosis, and decisions to drive the plot, **seeking a balance between calm professionalism and warm humanity**  
- Maintain professional rigor: credible medical details, authentic procedures, accurate terminology  
- Infuse humanistic care: life dignity, the original intention of healers, patient stories, human brilliance

---

## Overall Creation Formula
```
Medical short story = Medical case + Ethical dilemma + Human interrogation + Warm ending/reflection
```

---

## 1. Core Synopsis Writing

### Formula
```
Core synopsis = Medical background/case + Core dilemma + Humanistic core
```

### Writing Points
| Element | Requirement | Correct Example | Incorrect Example |
|---------|-------------|-----------------|-------------------|
| **Medical background** | Professional + realistic | "A patient with a rare autoimmune disease whose entire body organs are being attacked by their own immune system" | "A very hard-to-treat disease" |
| **Core dilemma** | Involving ethical choices | "Must decide within 72 hours whether to use an unapproved experimental therapy, at the risk of accelerating death" | "The doctor needs to treat the patient" |
| **Humanistic core** | Touches on the essence of life | "Explores the value of quality versus length of life, and who has the right to decide another’s life or death" | "In the end, the patient recovered" |

### Excellent Examples
- "In the emergency room, a homeless man with cardiac arrest and a car accident victim arrive simultaneously. There is only one ECMO device; the doctor must decide within three minutes whom to save. This is not a medical problem, it is a human interrogation."  
- "An oncologist discovers his best friend has cancer. According to guidelines, chemotherapy is recommended, but he knows the pain it causes. Should he tell him or not? The professional judgment as a doctor clashes fiercely with the emotions as a friend in the face of life and death."  
- "An organ donation coordinator must persuade the family of a car accident victim to donate organs within six hours, but she finds the family is enduring unimaginable grief. Which is more important: continuation of life or dignity in death?"

---

## 2. Lead Writing

### Formula
```
Lead = Medical scene opening + Core suspense setup + Human hook
```

### Writing Points
| Element | Function | Writing Method |
|---------|----------|----------------|
| **First sentence** | Establish medical atmosphere | Directly show: rescue scene/diagnosis process/operating room/ICU monitoring |
| **Middle part** | Explain core dilemma | Use professional medical terminology and calm narration to quickly locate the issue |
| **Last sentence** | Create human suspense | Raise ethical questions/moral dilemmas/emotional conflicts |

### Integration of Humanistic Topics

The lead should touch on the core themes of medicine:

| Topic Type | Specific Direction |
|------------|--------------------|
| **Life-and-death decisions** | Emergency triage, organ allocation, euthanasia, treatment abandonment |
| **Medical ethics** | Experimental treatment, informed consent, medical resource allocation, privacy protection |
| **Professional dilemmas** | Medical errors, overtreatment, doctor-patient conflicts, systemic pressure |
| **Human brilliance** | Benevolent healers, patient resilience, family companionship, kindness of strangers |

**Goal**: Make readers feel "What would I choose if I were in this situation?" (moral empathy)

### Example Comparison
| Type | Content |
|------|---------|
| ✅ **Correct** | "At 3 a.m., Emergency Department chief Chen Mo received two calls. The first told him an eight-year-old leukemia girl had found a matching bone marrow donor, and surgery could be scheduled for tomorrow. The second told him the donor—a 20-year-old college student—was in a car accident on the way home and was being rushed to the emergency room. When Chen Mo rushed into the rescue room and saw the young face on the bed, his hands began to tremble. As a doctor, he must do everything to save this life. But as the attending physician of another child, he knew that the young man’s death meant another child’s life." |
| ❌ **Incorrect** | "The doctor encountered a difficult case and tried to find a way to cure the patient..." |

---

## 3. Narrative Structure Design

### 【Beginning】Chapter 1: Case and Dilemma (2000-3000 words)

#### Writing Focus
```
Beginning = Medical environment display + Protagonist introduction + Core case presentation + Dilemma initiation
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Medical environment display** | Establish professional atmosphere within first 500 words | First paragraph should include: medical scene/professional terms/surgical operation<br>Use details instead of explanations: show how the hospital operates daily |
| **Protagonist introduction** | Quickly introduce the protagonist | Introduce protagonist within 300 words<br>Show identity through professional behavior: doctor rounds, nurse monitoring |
| **Core case** | Show complexity of the problem | Involve: rare disease/emergency/ethical dilemma/resource limitation |
| **Dilemma initiation** | Push story forward | Urgent time limit/irreversible condition/difficult choice |

#### Professional Detail Tips
- **Terminology = authenticity**: Use professional terms to build credibility but integrate naturally into dialogue  
- **Process = plot**: Medical procedures themselves drive the plot  
- **Data = pressure**: Use vital signs data to create tension

#### Taboos
- ❌ Large blocks of medical knowledge exposition  
- ❌ Protagonist as an omnipotent doctor  
- ❌ Dilemma easily resolved

---

### 【Development】Chapters 2-3: Diagnosis and Choice (2000-3000 words each)

#### Chapter 2 Writing Focus
```
Chapter 2 = In-depth diagnosis + Clue discovery + Preliminary plan + New problems
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **In-depth diagnosis** | Protagonist begins action | Use professional knowledge/literature review/consultations |
| **Clue discovery** | Reveal part of the truth | Test results/medical history details/family information |
| **Preliminary plan** | Propose treatment ideas | Medical reasoning/risk assessment/team discussion |
| **New problems** | Create bigger dilemma | Plan risks/patient refusal/ethical conflict |

#### Chapter 3 Writing Focus
```
Chapter 3 = Major discovery + Position conflict + Ethical dilemma + Key decision
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Major discovery** | Truth of condition emerges | Confirm rare disease/find key info/condition sudden change |
| **Position conflict** | Clash of different ideas | Aggressive treatment vs conservative/doctor vs family |
| **Ethical dilemma** | No perfect solution | Saving life vs following rules/patient will vs family will |
| **Key decision** | Set up climax | Protagonist must decide/time running out |

---

### 【Turning Point】Chapter 4: Decision and Action (2000-3000 words)

#### Writing Focus
```
Turning point = Plan confirmation + Ultimate dilemma + Difficult execution + Cost presentation
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Plan confirmation** | Treatment path clear | Decision after weighing pros and cons/team consensus |
| **Ultimate dilemma** | Challenges during execution | Surgical complications/patient rejection/ethical review |
| **Difficult execution** | Protagonist persists | Based on professional judgment and emotional support |
| **Cost presentation** | Consequences of choice | Gains and losses/show weight of decision |

#### Medical Scene Tips
- **Operating room details**: sterile procedures, instrument passing, vital sign monitoring  
- **Time pressure**: use countdown and vital sign changes to create tension  
- **Team cooperation**: show professional coordination of medical staff

#### Taboos
- ❌ Solve problems by miracles  
- ❌ Protagonist suddenly becomes omnipotent  
- ❌ Avoid the difficulty of ethical dilemmas

---

### 【Conclusion】Chapter 5: Ending and Afterglow (2000-3000 words)

#### Writing Focus
```
Conclusion = Treatment result + Emotional release + Humanistic sublimation + Life reflection
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Treatment result** | Show medical outcome | Not necessarily successful but must be realistic and credible |
| **Emotional release** | Emotional climax of characters | Doctor’s perseverance/patient’s gratitude/family’s understanding |
| **Humanistic sublimation** | Respond to core theme | Answer questions raised at the beginning through the ending |
| **Life reflection** | Leave space for thought | Deep reflection on life, medicine, and humanity |

#### Types of Medical Endings
| Type | Features | Suitable Themes |
|------|----------|-----------------|
| **Successful** | Patient recovers, win-win for doctor and patient | Benevolent healer, professional victory themes |
| **Regretful** | Tried best but outcome not ideal | Exploring medical limitations |
| **Sacrificial** | Saved patient but doctor pays a price | Professional spirit, self-sacrifice themes |
| **Warm** | Outcome secondary, process touching | Humanistic care, life dignity themes |
| **Reflective** | Leaves open-ended questions | Ethical dilemmas, value choices |

#### Taboos
- ❌ Forced happy ending against medical reality  
- ❌ Preachy summary  
- ❌ Avoid ethical issues raised earlier

---

## 4. Character Development Methods

### Protagonist Design

| Dimension | Requirement | Correct Example | Incorrect Example |
|-----------|-------------|-----------------|-------------------|
| **Professional identity** | Clear + credible | "Deputy Chief Physician of Emergency Department" "ICU Head Nurse" | "Doctor" |
| **Core traits** | Professional first | "Excellent medical skills but poor at expression" "Experienced but stubborn" | "Very good" |
| **Personality tags** | 2-3 distinct traits | "Rational and calm but compassionate" "Strict but caring for patients" | "Good doctor" |
| **Professional ability** | Relevant to plot | "Good at diagnosing rare diseases, can find key clues from subtle symptoms" | "Can treat any disease" |

### Personality Specificity
```
✅ "Chen Mo habitually glanced at the monitor. Blood pressure 90/60, heart rate 120, oxygen saturation 89%—these numbers quickly translated into a judgment in his mind: early shock, must infuse fluids immediately. Thirty years of emergency experience told him this patient wouldn’t last two hours. His hands were steady, but his heart raced—not from nervousness, but from the unending responsibility a doctor feels facing life slipping away."
❌ "He is a good doctor, skilled in medicine, and responsible to patients."
```

### Protagonist Archetypes (Common in Medical Stories)

| Type | Features | Personality | Suitable Themes |
|-------|----------|-------------|-----------------|
| **Attending Physician** | Professionalism is key | Rational, focused, mission-driven | Disease diagnosis, medical breakthroughs |
| **Emergency Doctor** | Quick decision-making | Decisive, calm, stress-resistant | Life-or-death speed, triage choices |
| **Surgeon** | Precise operational skills | Confident, rigorous, steady hands | Surgical scenes, technical battles |
| **Nurse/Head Nurse** | Careful observation | Gentle, resilient, good communicator | Humanistic care, patient perspective |
| **Research Doctor** | Scientific mindset | Persistent, innovative, daring breakthroughs | Scientific research, ethical boundaries |

### Supporting Character Design (Medical Features)

| Type | Role | Notes |
|-------|------|-------|
| **Patient** | Core of the story | Has a three-dimensional background, not just a case |
| **Family** | Emotional empathy | Represents ordinary people’s perspective, with reasonable demands |
| **Medical Team** | Professional support | Each with strengths, showing teamwork |
| **Administration/Ethics Committee** | Institutional pressure | Not necessarily antagonists, represent rules and procedures |

### Relationship Network Design (Medical Specific)

| Element | Requirement |
|---------|-------------|
| **Doctor-patient relationship** | Trust and communication, conflict and understanding |
| **Team collaboration** | Doctors, nurses, technicians, pharmacists each with roles |
| **Hierarchy relationships** | Interaction among director, attending, resident doctors |
| **Emotional bonds** | Mentor-apprentice, colleague friendship, doctor-patient affection |

---

## 5. Medical Element Design

### Medical World Building Formula
```
Medical world = Professional environment + Realistic procedures + Ethical framework
```

### Common Medical Scene Types

| Type | Features | Examples |
|-------|----------|----------|
| **Emergency Room** | High pressure, fast pace, life-or-death speed | Multiple trauma rescue, triage decisions |
| **Operating Room** | Precision, focus, team cooperation | Complex surgery, intraoperative complications |
| **ICU** | Monitoring, waiting, suffering | Organ failure, family companionship |
| **Outpatient/Ward** | Routine, detailed, humanistic care | Chronic disease management, doctor-patient communication |
| **Laboratory** | Research, breakthroughs, ethical boundaries | New drug development, gene editing |

### Medical Detail Principles

| Element | Requirement |
|---------|-------------|
| **Accuracy** | Medical terminology and procedures must be accurate |
| **Professionalism** | Reflect medical staff’s professional quality |
| **Human warmth** | Beneath cold medical technology is warm human hearts |
| **Limitations** | Medicine is not omnipotent, show boundaries |

---

## 6. Conflict Design

### Conflict Formula
```
Medical conflict = External dilemma (disease/time/resources) + Internal contradiction (ideology/interest/emotion) + Ethical interrogation
```

### External Conflict (Main Line)

| Conflict Type | Specific Methods | Examples |
|---------------|------------------|----------|
| **Disease challenge** | Rare disease/emergency/complications | Never-before-seen symptom combination |
| **Time pressure** | Countdown/golden hour/window period | Must find organ within 72 hours |
| **Resource limitation** | Bed/equipment/drug shortage | Only one ECMO for two patients |
| **Technical dilemma** | Beyond current medical capability | Need experimental therapy |

### Internal Conflict (Subplot)

| Conflict Type | Design Method |
|---------------|---------------|
| **Ideological dispute** | Aggressive treatment vs conservative treatment |
| **Interest game** | Different demands from hospital/patient/insurance |
| **Ethical dilemma** | Right to know vs family concealment/quality vs length of life |
| **Emotional conflict** | Professional judgment vs personal feelings |

### Conflict Progression Levels
```
Level 1: Medical dilemma (disease to be treated)
    ↓
Level 2: Plan dispute (disagreement on treatment)
    ↓
Level 3: Ethical choice (why choose this way)
```

---

## 7. Foreshadowing Management

### Foreshadowing Carriers (Medical Specific)

| Carrier Type | Example |
|--------------|---------|
| **Test results** | Abnormal values on lab report / tiny shadows on imaging |
| **Medical history details** | Patient concealing medication history / family genetic history |
| **Symptom details** | Seemingly unrelated complaints / overlooked signs |
| **Character background** | Doctor’s personal experience / patient’s occupational exposure |
| **Timeline clues** | Onset time / exposure history |

### Foreshadowing Setting Principles

| Stage | Method |
|-------|--------|
| **Planting** | Naturally integrate into history taking and physical exam<br>Example: "Patient mentioned transient blurred vision three months ago but quickly recovered, thought it was fatigue"<br>Example: "Dr. Chen noticed slight clubbing of nails but patient denied respiratory disease" |
| **Payoff** | Reveal significance at diagnostic key moment<br>Example: That blurred vision was an early sign of intracranial tumor pressing on optic nerve |

### Common Foreshadowing Designs

**Symptom Foreshadowing**:  
```
Planting: Patient occasionally mentions a "minor issue"  
Payoff: That "minor issue" is the key clue for diagnosis  
```

**Character Foreshadowing**:  
```
Planting: Doctor is particularly sensitive to a certain disease  
Payoff: His relative died of this disease, so he is especially alert  
```

**Time Foreshadowing**:  
```
Planting: Patient’s onset time coincides with a certain event  
Payoff: That event is the cause of the disease  
```

---

## 8. Chapter Style Design (Medical Specific)

### Chapter Title Style

Medical titles should be **professional, suspenseful, and imply humanistic care**:

| Element | Method |
|---------|--------|
| **Title style** | Professional terms + humanistic imagery<br>Example: "Chapter 1 Vital Signs"<br>Example: "Chapter 3 The Golden 72 Hours"<br>Example: "Chapter 5 Breath and Hope" |
| **Chapter opening** | Directly enter medical scene<br>Example: "The monitor’s alarm pierced the silence of 3 a.m."<br>Example: "The moment the scalpel cut the skin, Chen Mo’s hand froze." |
| **Chapter ending** | Condition turning point or emotional climax<br>Example: "When the test results came out, he looked at the number and closed his eyes. What he feared most had happened."<br>Example: "'How much time do we have left?' the family asked. Chen Mo looked at the declining numbers on the monitor, 'Not enough.'" |

### Dialogue Design (Medical Core)

Medical dialogue should be **professional, precise, and warm**:

**Good Dialogue Example**:
```
"Blood pressure is still dropping," the nurse reported.  
"Increase dopamine to max dose," Chen Mo stared at the monitor, "Notify the blood bank, prepare for transfusion."  
"The family asked if we can guarantee..."  
"Don’t guarantee," Chen Mo interrupted calmly, "Tell them we will do our best. That’s all."  
Silence. The beep of the monitor was especially piercing in the quiet.  
"What if it were your family?" the young nurse asked.  
Chen Mo’s hand paused: "Then I would pray they meet a doctor like me."  
```

**Poor Dialogue Example**:
```
"The patient is failing."  
"Then save them quickly."  
"Okay."  
"Saved."  
```

### Psychological Description (Medical Features)

Should balance **professional rationality and humanistic sentiment**:

**Good Psychological Description**:
```
Chen Mo’s brain raced. Low blood pressure, fast heart rate, low urine output—classic triad of hypovolemic shock. But CT showed no obvious bleeding point, so where was the hemorrhage?  
Abdomen? No, soft abdomen.  
Chest? Clear lung auscultation.  
His gaze fell on the patient’s pale face, suddenly recalling a possibility—gastrointestinal bleeding.  
"Give me a rectal exam glove," he said.  
Thirty years of experience told him the simplest exam often finds the deadliest problem.  
```

**Poor Psychological Description**:
```
He felt the patient’s condition was serious and decided to check carefully.  
```

### Rhythm Control (Medical Core)

**Rhythm Formula**:
```
500 words = 1 condition progression OR 1 diagnostic/treatment decision OR 1 emotional moment
```

Each scene must have: clear medical goal + new information + driving force

---

## 9. Humanistic Progression (Medical Exclusive)

### Five-Stage Humanistic Method
```
Present dilemma → Diagnostic process → Ethical conflict → Difficult choice → Humanistic sublimation
```

| Stage | Word Count Ratio | Key Event | Humanistic Depth |
|-------|------------------|-----------|------------------|
| **Present dilemma** | 10-15% | Case presentation, dilemma emergence | ★☆☆☆☆ |
| **Diagnostic process** | 15-20% | In-depth investigation, plan formation | ★★☆☆☆ |
| **Ethical conflict** | 25-30% | Different positions, value clashes | ★★★☆☆ |
| **Difficult choice** | 20-25% | Decision made, cost paid | ★★★★☆ |
| **Humanistic sublimation** | 15-20% | Outcome presentation, life reflection | ★★★★★ |

### Humanistic Expression Techniques

**Layered Progression**:
```
Surface problem: How to treat this disease  
Deeper problem: Who bears the cost of treatment  
Core problem: How to balance quality and length of life  
Ultimate problem: At the boundary of medicine, where is human dignity  
```

**Multiple Perspectives**:
```
Doctor’s view: Professional judgment, saving lives  
Patient’s view: Quality of life, personal will  
Family’s view: Emotional needs, financial pressure  
System’s view: Rules, procedures, risk control  
```

---

## 10. Common Medical Patterns

### Pattern A: Emergency - Rescue - Outcome  
**Structure**:  
- Beginning: Emergency arrival, life-threatening  
- Development: Clear diagnosis, plan made  
- Turning point: Rescue implemented, difficulties encountered  
- Conclusion: Outcome clear, humanistic reflection

### Pattern B: Rare Disease - Diagnosis - Breakthrough  
**Structure**:  
- Beginning: Conventional treatment ineffective  
- Development: Searching for true cause  
- Turning point: Rare disease confirmed, seeking breakthrough  
- Conclusion: Treatment result, medical reflection

### Pattern C: Ethical Dilemma - Choice - Result  
**Structure**:  
- Beginning: Ethical problem arises  
- Development: Clash of different views  
- Turning point: Difficult choice made  
- Conclusion: Bearing consequences, value reflection

### Pattern D: Doctor-Patient Relationship - Understanding - Reconciliation  
**Structure**:  
- Beginning: Doctor-patient conflict emerges  
- Development: Deep mutual understanding  
- Turning point: Trust at critical moment  
- Conclusion: Reconciliation or regret, mutual understanding

---

**【Special Reminder】**  
Keys to success of medical short stories:  
1. Establish professional atmosphere and medical suspense within first 500 words  
2. Every 1000 words must have condition progression or emotional advancement  
3. Medical details must be accurate and credible, withstand scrutiny  
4. Ethical dilemmas must be real and profound, not avoiding complexity  
5. Ending must have human warmth, no forced perfection  
6. Show medical limitations as well as human brilliance