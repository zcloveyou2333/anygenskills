---
name: dushi-outline-method
description: Methodology for creating outlines of urban romance short stories, including core synopsis extraction, lead design, plot structure planning, and character shaping guidance
---

## Q1-Q3 Question Templates

### Q1: Core Idea
**Q1: Core idea and appeal of the story [Brief description]**  
Please describe your story idea in one or two sentences.

### Q2: Core Conflict
**Q2: Core conflict [Brief description]**  
Please describe the novel’s core contradiction or main conflict in one sentence  
(e.g., the love-hate entanglement between a domineering CEO and an independent woman, childhood sweethearts’ missed opportunities and reunion, love trials under wealthy family grudges, career and love choices of workplace elites, etc.)

### Q3: Story Tone
**Q3: Story tone [Choose one]**  
- Sweet and pampering · High sugar (lighthearted, sweet and warm, high energy throughout)  
- Tortured love · Deeply unforgettable (misunderstandings and entanglements, heart-wrenching, reconciliation)  
- Wealthy families · Love and hatred (family disputes, social status matching, epic emotions)  
- Urban workplace · Inspirational growth (career struggles, success in both career and love)  
- Or please briefly describe your story tone

## Chapter File Naming Rules  
File name format: `{STORY_NAME}-{NN}.md`  
Example: `LightOfCity-01.md`, `LightOfCity-02.md`

---

# Urban Romance Outline Creation Methodology

## Overall Orientation

Urban romance novels emphasize "**realistic resonance and emotional texture**," focusing on workplace struggles, social pressures, and emotional choices in urban life.

**Core Principles**:  
- Focus on urban issues (workplace competition, class differences, balance between career and love, family business inheritance, etc.)  
- Pursue "realistic immersion": authentic workplace details, reasonable character motivations, natural emotional development  
- Balance career and emotional lines, **two threads intertwined and mutually driving**  
- Drive plot through career challenges, social pressure, and emotional tests, **reject floating and unreasonable settings**  
- Maintain urban texture: elite lifestyle, workplace culture, social circles, modern values

---

## Overall Creation Formula
```
Urban Romance Short Story = Workplace/Social Hook + Dual Career & Emotion Lines + Realistic Pressure Conflicts + Dual Fulfillment of Growth and Love
```

---

## 1. Core Synopsis Writing

### Formula
```
Core Synopsis = Professional Identity/Social Status + Career & Emotional Dilemma + Growth Theme
```

### Writing Points
| Element | Requirement | Correct Example | Incorrect Example |
|---------|-------------|-----------------|------------------|
| **Professional Tag** | Specific profession + social status | "Newly promoted law firm partner" "Returnee designer" "Financial reporter" | "Office worker" |
| **Dual Dilemma** | Career and emotional dilemma | "Choosing between workplace competition and reunion with first love" | "Encountered some difficulties" |
| **Growth Theme** | Character transformation direction | "From workplace rookie to independent elite" | "Succeeded in the end" |

### Excellent Examples
- "A returnee architectural designer starts a business back home and encounters a former rival. She must prove herself in a male-dominated industry, only to find her biggest opponent is the person who hurt her most ten years ago. When career and old feelings intertwine again, how will she choose?"  
- "A financial reporter offends a conglomerate through investigative reporting and is forced to resign. At her lowest, her first love appears as an investor, on the condition she works for his group. She struggles between revenge and survival, hatred and old affection, ultimately discovering hidden truths from the past."  
- "A newly promoted partner at a top law firm, known as a workaholic. An accident reunites her with her childhood sweetheart, a surgeon, who says, 'You’ve fought for your career for ten years; it’s time to live for yourself.' For the first time, she begins to question: does a successful life have to sacrifice love?"

---

## 2. Lead Writing

### Formula
```
Lead = Urban scene opening + Professional/Social identity setup + Dual suspense of career and emotion
```

### Writing Points
| Element | Purpose | How to Write |
|---------|---------|--------------|
| **First sentence** | Establish urban atmosphere | Directly describe urban scenes: office building/banquet/airport/courtroom |
| **Middle part** | Explain social position | Use profession, achievements, social relations for quick positioning |
| **Last sentence** | Create dual suspense | Present career crisis and emotional entanglement simultaneously |

### Integration of Urban Issues

The lead should touch on core contradictions of urban life:

| Issue Type | Specific Direction |
|------------|--------------------|
| **Workplace competition** | Industry rivalry, promotion pressure, entrepreneurship hardships, gender discrimination |
| **Class differences** | Wealthy families vs commoners, returnees vs locals, new rich vs established families |
| **Career & love** | Workaholic meets true love, emotional choices during career ascent, long-distance relationship challenges |
| **Social pressure** | Age anxiety, family expectations, social judgments, living costs |

**Goal**: Let readers anticipate "how he/she balances everything in the urban jungle" (realistic resonance)

### Example Comparison
| Type | Content |
|-------|---------|
| ✅ **Correct** | "In the partner election at a top law firm, Su Qing defeated all opponents at age thirty to become the youngest female partner in this century-old firm. At the celebration banquet, she held a champagne glass weaving through the crowd, smiling appropriately but feeling hollow inside. For ten years, she filled every gap in life with work, forgetting she was still a woman. Until in the emergency room, she saw Cheng Yi in a white coat—the man who said 'wait for you' ten years ago but never did. 'Lawyer Su, long time no see,' he said with complex eyes. Meanwhile, the case in her hands happened to sue the hospital he worked for." |
| ❌ **Incorrect** | "She is a very capable lawyer and very busy. One day she met her ex-boyfriend, who is a doctor. She wants to sue his hospital but still likes him..." |

---

## 3. Plot Structure Design (Qi-Cheng-Zhuan-He)

### 【Qi】Chapter 1: Urban Opening, Dual Introduction of Career and Emotion (2000-3000 words)

#### Writing Focus
```
Qi = Workplace scene + Social positioning + Dual career & emotion hooks + Fast pacing
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Workplace scene** | Show professional scene in first 500 words | First paragraph features: law firm/hospital/design institute/investment bank/editorial department<br>Show character’s professionalism through work details |
| **Social positioning** | Quickly establish character’s position | Position, achievements, social evaluation, lifestyle<br>Use details instead of explanation: luxury office/high-end attire/colleagues’ attitudes |
| **Career hook** | Present professional challenge | Important project/competitor/workplace crisis/entrepreneurship difficulty |
| **Emotional hook** | Introduce emotional thread | First encounter/reunion/accidental meeting/forced cooperation<br>Within 1500 words, create connection between male and female leads |

#### Creating Urban Texture
- **Specific professional details**: Don’t write "she was in a meeting," write "she was presenting a merger plan to the board"  
- **Realistic urban scenes**: CBD office buildings, upscale restaurants, art exhibitions, charity galas  
- **Modern lifestyle**: ride-hailing apps, takeout coffee, overtime culture, social media  
- **Social network**: colleagues, clients, partners, industry circles

#### Taboos
- ❌ Floating professional descriptions that don’t conform to industry knowledge  
- ❌ Characters appearing perfect from the start  
- ❌ Emotional and career lines disconnected, like two separate stories  
- ❌ Lack of authentic urban life texture

---

### 【Cheng】Chapters 2-3: Career and Emotion Intertwined, Pressure and Sweetness Coexist (each 2000-3000 words)

#### Chapter 2 Writing Focus
```
Chapter 2 = Career advancement + Relationship warming + Emerging social pressure + Dual-line interaction
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Career advancement** | Specify career line | Project progress/workplace competition/professional challenges<br>Show character’s ability and dilemma through work scenes |
| **Relationship warming** | Develop emotion in professional context | Sparks during work cooperation/accidental meetings outside work<br>Create attraction through professional identity contrast |
| **Social pressure** | Introduce external resistance | Position gap/industry competition/social evaluation/time conflicts |
| **Dual-line interaction** | Career affects emotion, emotion affects career | Missed dates due to busy work/distracted at work because of feelings<br>Show real dilemmas of modern people |

#### Chapter 3 Writing Focus
```
Chapter 3 = Career highlight moment + Emotional deepening + Sharp reality conflicts + Choice dilemma
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Career highlight** | Show professional achievements | Project success/promotion/salary raise/industry recognition<br>Accompanied by greater responsibility and pressure |
| **Emotional deepening** | Beyond ambiguity, true feelings revealed | Heartfelt moments during partner’s professional performance/support in crisis<br>Mature love: appreciation, respect, understanding |
| **Conflict sharpening** | Bring reality issues to the forefront | Time conflicts between work and love<br>Professional rivalry/ family opposition/social opinion |
| **Choice dilemma** | Foreshadow climax | Important project vs important date<br>Promotion opportunity vs partner’s needs |

#### Urban Romance Workplace Scene Writing Tips

**Good workplace scene**:
```
✅ Su Qing stood in the conference room facing twenty board members, analyzing each risk point of the merger plan. Her voice was steady and powerful, PPT slides switched precisely, every data point carefully scrutinized. Cheng Yi sat in the audience, watching the confident and composed woman on stage, suddenly recalling ten years ago when she was the girl who stuttered nervously in front of him.

"Lawyer Su, what if the other party refuses this clause?" a board member asked.

She smiled slightly: "Then we have Plan B." She switched slides, presenting another complete argument.

Cheng Yi suddenly understood why she reached this point in ten years. It wasn’t luck but every late-night preparation, every detail control, every challenge bravely faced.

He fell in love with this version of her.
```

**Poor workplace scene**:
```
❌ She was in a meeting, acted very professional, and everyone admired her. He watched her work and thought she was great.
```

---

### 【Zhuan】Chapter 4: Ultimate Conflict of Career and Emotion (2000-3000 words)

#### Writing Focus
```
Zhuan = Career crisis peak + Emotional relationship breakdown + Dilemma choice + Painful growth
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Career crisis** | Major challenge in career | Important project failure/being framed by competitors/company crisis<br>Promotion opportunity vs moral bottom line<br>Critical entrepreneurship moment vs emotional needs |
| **Emotional breakdown** | Reality pressure breaks love | Breakup due to work neglect<br>Professional rivalry causing opposing stances<br>Forced separation under family/social pressure |
| **Dilemma choice** | Choice that cannot have both | Overseas development opportunity vs local relationship<br>Saving company vs accompanying lover<br>Professional ethics vs emotional stance |
| **Painful growth** | Growing through loss | Re-examining life values<br>Understanding what truly matters<br>Realizing own mistakes |

#### Urban Romance Specific Conflict Types

| Conflict Type | Specific Method | Example |
|---------------|-----------------|---------|
| **Professional competition** | Opponents on same project/competing for same position | The company she sues is the hospital he works for |
| **Time conflict** | Time allocation between work and love | Anniversary night, client urgently needs a proposal |
| **Value difference** | Different views on career and life | He wants her to give up promotion to start a business with him |
| **Social pressure** | Family/circle/public opinion resistance | Wealthy family rejects self-made woman |
| **Geographical distance** | Long-distance work reality test | One at Beijing HQ, one stationed in Shanghai |

#### Taboos
- ❌ Using melodramatic misunderstandings instead of real conflicts  
- ❌ Suddenly introduced third party to sabotage relationship  
- ❌ Characters suddenly acting foolish just to create conflict  
- ❌ Career line completely sacrificed for emotional line

---

### 【He】Chapter 5: Growth and Fulfillment, Dual Success in Career and Emotion (2000-3000 words)

#### Writing Focus
```
He = Self-growth + Problem resolution + Dual-line fulfillment + Hopeful future
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Self-growth** | Character’s mature transformation | Learn to balance career and life<br>Understand what true success is<br>No longer live just to prove oneself |
| **Problem resolution** | Reasonable resolution of realistic conflicts | Find balance point between career and love<br>Turn professional competition into win-win cooperation<br>Use wisdom to resolve social pressure |
| **Career fulfillment** | Show professional achievements | Project success/promotion/entrepreneurship success<br>Not at the expense of love |
| **Emotional fulfillment** | Mature love relationship | Not cloying sweetness but mutual achievement<br>Appreciate each other’s careers<br>Plan future together |

#### Urban Romance HE Writing

**Good ending**:
```
✅ Su Qing won the lawsuit but didn’t linger long at the celebration banquet. She drove to the hospital where Cheng Yi just finished surgery.

"I heard you won," he said with complex eyes.

"Yes, but I also lost," she looked at him, "I lost the chance to spend time with you. Cheng Yi, I always thought career was everything until I almost lost you and realized I had it backwards."

"What will you do?" he asked.

"I declined the opportunity to go to London," she said, "I want to stay here, continue being a lawyer, but also make time for you and our future."

Cheng Yi smiled: "I never asked you to choose between career and me. What I want is you willing to make space for our future."

"I will," she said, "This time, we work together."

A year later, Su Qing’s law firm opened, and Cheng Yi was the first client. In the concrete jungle of the city, they each shone and warmed each other.
```

**Poor ending**:
```
❌ She gave up her career for love and went back to his hometown. They got married and were very happy.
```

#### Taboos
- ❌ Female lead sacrifices career for love (contradicts independent urban woman image)  
- ❌ All problems suddenly resolved without persuasion  
- ❌ Only emotional fulfillment written, ignoring career line closure  
- ❌ Ending too perfect, losing realistic texture

---

## 4. Character Shaping Methods

### Protagonist Design (Urban Romance Features)

| Dimension | Requirement | Correct Example | Incorrect Example |
|-----------|-------------|-----------------|------------------|
| **Professional identity** | Specific + professional | "Mergers and acquisitions lawyer" "Surgeon" "Architectural designer" | "Company employee" |
| **Social status** | Clear class positioning | "Newly promoted partner" "Returnee entrepreneur" "Wealthy heir" | "Ordinary person" |
| **Professional traits** | Personality matching profession | "Lawyer’s rigor and rationality" "Designer’s perfectionism" | "Very excellent" |
| **Lifestyle texture** | Specific lifestyle | "Lives in CBD apartment, drives Tesla, drinks specialty coffee" | "Life is good" |

### Female Lead Types (Common in Urban Romance)

| Type | Features | Personality | Suitable Plot |
|-------|----------|-------------|--------------|
| **Career woman** | Successful career/independent/rational and capable | Workaholic/pursues excellence/emotionally reserved | Melted by warm man/learns balance/encounters equal rival |
| **Returnee elite** | Overseas study background/international vision/high education | Confident and independent/cultural clash/idealistic | Returns home to start business/cultural conflicts/ideal vs reality |
| **Entrepreneur** | Self-made/resilient/daring | Stubborn and strong/under pressure/seeks recognition | Hardships of entrepreneurship/encounters benefactor/dual career and love |
| **Wealthy heiress** | Affluent family/well-educated/social butterfly | Glamorous but lonely/longs for sincerity | Escapes family/hides identity/falls in true love |
| **Workplace rookie** | New to workplace/striving/youthful energy | Innocent but resilient/strong learning ability | Rookie growth/encounters mentors and friends/turnaround |

### Male Lead Types (Common in Urban Romance)

| Type | Features | Personality | Suitable Plot |
|-------|----------|-------------|--------------|
| **Domineering CEO** | Business empire/decisive/high power | Strong at work, loyal in love/possessive | Chasing wife in fire scene/social status match/power couple |
| **Elite talent** | Highly educated/professional leader | Gentle and elegant/focused and deep feelings | Love grows over time/childhood sweethearts/workplace cooperation |
| **Entrepreneur partner** | Self-made/energetic/grounded | Resilient and pragmatic/loyal and responsible | Joint entrepreneurship/adversity companionship/dream and love |
| **Wealthy heir** | Prominent family/shoulders responsibility | Glamorous outside, repressed inside/longs for freedom | Family arranged marriage/escape constraints/true love prevails |
| **Industry tycoon** | Industry status/mature and steady/experienced | Gentle and considerate/tolerant and wise/appreciative | Age gap/master-apprentice/mentor and prodigy |

### Professional Traits Specifics

**Lawyer Role**:  
- Personality: rigorous, rational, logical, good at debate  
- Work scenes: courtroom, law firm meetings, investigation, overnight contract revisions  
- Work habits: cautious speech, detail-oriented, strong time awareness  
- Pressure sources: case outcomes, client pressure, performance evaluation

**Doctor Role**:  
- Personality: calm, decisive, responsible, emotionally restrained  
- Work scenes: operating room, ward rounds, consultations, night shifts  
- Work habits: phone on 24/7, always on call, sparing words  
- Pressure sources: patient life and death, doctor-patient relationships, surgical risks

**Designer Role**:  
- Personality: perfectionist, artistic temperament, detail-focused, emotional  
- Work scenes: design institute, construction site, client presentations, overnight drawing  
- Work habits: pursuit of aesthetics, inspiration-driven, sensitive to environment  
- Pressure sources: client demands, design concepts, construction difficulties

### Supporting Character Design (Simplification Principle)

| Type | Role | Notes |
|-------|------|-------|
| **Workplace mentor/senior** | Career guidance, life inspiration | No more than 2 scenes, keep it brief |
| **Workplace competitor** | Create professional pressure and contrast | Clear competition points, avoid stereotypes |
| **Family members** | Represent social/family pressure | Sketch briefly, no extended family history |
| **Best friends/brothers** | Emotional confidants, assist plot | 1-2 scenes, push plot forward |

---

## 5. Dual-Line Weaving Techniques (Core of Urban Romance)

### Dual-Line Interweaving Formula
```
Urban Romance = Career Line + Emotional Line + Mutual Influence of Both Lines
```

### Career Line Drives Emotional Line

| Method | Example |
|--------|---------|
| **Meeting through work** | Lawyer and client/doctor and patient’s family/project partners |
| **Attraction by professional ability** | Impressed and moved by the other’s expertise |
| **Support during work crisis** | Help and understanding during professional difficulties |
| **Sharing career achievements** | First person to share important moments |

### Emotional Line Influences Career Line

| Method | Example |
|--------|---------|
| **Emotional distraction** | Work efficiency drops due to missing the other |
| **Adjusting for love** | Skip overtime to accompany partner/change work plans |
| **Conflict choices** | Important project vs important date |
| **Breakup impact** | Work mistakes after breakup/use work to escape emotions |

### Rhythm of Dual-Line Balance

**Suggested word count distribution**:  
- Chapter 1: Career 40% + Emotion 40% + Meeting & Intertwining 20%  
- Chapter 2: Career 30% + Emotion 50% + Interaction 20%  
- Chapter 3: Career 35% + Emotion 35% + Conflict 30%  
- Chapter 4: Career 25% + Emotion 40% + Dilemma 35%  
- Chapter 5: Career 30% + Emotion 30% + Fulfillment 40%

**Taboos**:  
- ❌ Writing entire chapters only about romance, forgetting professional identity  
- ❌ Career and emotional lines unrelated  
- ❌ Career setting collapses just to write love

---

## 6. Conflict Design (Urban Romance Features)

### Conflict Layers
```
Layer 1: Professional competition (external reality)
    ↓
Layer 2: Time and energy conflicts (objective difficulties)
    ↓
Layer 3: Value differences (internal contradictions)
    ↓
Layer 4: Social pressure (external resistance)
```

### Specific Conflict Design

| Conflict Type | Specific Method | Resolution Direction |
|---------------|-----------------|----------------------|
| **Professional opposition** | Lawyer vs defendant company/reporter vs exposed party | Rational view of profession/separate work and private life/find win-win |
| **Time conflict** | Both are workaholics/often overtime and miss events | Learn to plan time/mutual understanding and support |
| **Promotion choice** | Promotion requires relocation/sacrifices family time | Communicate and negotiate/joint decisions/find balance |
| **Class gap** | Wealthy family vs white-collar/returnee vs local | Break prejudice/prove strength/sincere treatment |
| **Family opposition** | Family arranged marriage/social status matching concept | Insist on self/prove love/family compromise |

---

## 7. Foreshadowing Management (Urban Background)

### Foreshadowing Carriers (Urban Romance Specific)

| Carrier Type | Example |
|--------------|---------|
| **Professional past** | Past cases/old projects/workplace grudges |
| **Social occasions** | Charity gala/industry forum/class reunion |
| **Business information** | Contract details/company data/industry insider info |
| **Life details** | Frequent restaurants/shared memory places/special dates |
| **Props** | Project files/business cards/gifts/photos |

### Common Foreshadowing Designs

**Identity Foreshadowing**:
```
Setup: The investor always wears a mask at meetings, never shows face  
Reveal: The moment the mask is removed, it’s her first love from ten years ago
```

**Professional Foreshadowing**:
```
Setup: The case she takes over, the opposing lawyer’s name seems familiar  
Reveal: At the courtroom confrontation, it turns out to be her college debate rival
```

**Past Foreshadowing**:
```
Setup: There is a faded photo in his office, background is a certain university  
Reveal: It’s the school they once attended together, which she never knew
```

---

## 8. Urban Texture Creation

### Scene Selection

**High-frequency scenes**:  
- Office buildings/offices (workplace main stage)  
- High-end restaurants/cafes (business socializing)  
- Airport/high-speed rail stations (business trips/long-distance)  
- Gym/yoga studio (urban lifestyle)  
- Art exhibitions/concerts (cultural taste)  
- CBD apartments/luxury homes (living environment)

**Scene Description Tips**:
```
✅ Good scene description:  
Outside the floor-to-ceiling window was the CBD night view, office lights arranged like a chessboard. Su Qing’s office was on the 28th floor, overlooking the entire financial district. It was already 10 p.m., her coffee cup was empty for the third time, and the computer screen showed contract clauses revised countless times.

❌ Poor scene description:  
She was working late in the office. It was very late, and the night view outside was beautiful.
```

### Professional Details

**Must be realistic and credible**:  
- Research industry materials, understand basic processes  
- Avoid overly technical jargon but show professionalism  
- Show character traits through work details  
- Make professional pressure specific

**Example Comparison**:
```
✅ She opened the thick case files, checking the evidence chain item by item. As the plaintiff’s lawyer, she had to ensure every link was flawless. The case had lasted eight months and now reached its critical moment.

❌ She was preparing for a lawsuit, very hard-working, often working overtime.
```

### Lifestyle

**Urban elite lifestyle details**:  
- Brands: don’t overdo, sprinkle appropriately (Tesla/LV/Starbucks)  
- Diet: refined but busy (takeout/light meals/coffee for energy)  
- Social: circle-aware (industry gatherings/class reunions/business banquets)  
- Schedule: busy and irregular (overtime/business trips/time zone differences)  
- Exercise: gym/yoga/running (stress relief)

---

## 9. Common Urban Romance Patterns

### Pattern A: Workplace Competitors Become Lovers

**Structure**:  
- Qi: Meet at work, rivals  
- Cheng: Mutual admiration and growing attraction during competition  
- Zhuan: Professional conflicts intensify, forced to oppose each other  
- He: Find win-win, advance together

### Pattern B: Childhood Sweethearts Reunite in the City

**Structure**:  
- Qi: Reunite after years, vastly different identities  
- Cheng: Work brings them together again, old feelings remain  
- Zhuan: Reality gaps/family resistance become obstacles  
- He: Break free, prove true love

### Pattern C: Domineering CEO and Independent Woman

**Structure**:  
- Qi: Strong CEO meets an unyielding woman  
- Cheng: He protects her, she maintains independence  
- Zhuan: Conflicts arise from his control or her stubbornness  
- He: Learn respect and mutual achievement

### Pattern D: Career and Love Balance Journey

**Structure**:  
- Qi: Workaholic meets true love, starts to get distracted  
- Cheng: Attempts balance, faces many difficulties  
- Zhuan: Must choose one at a critical moment  
- He: Find balance, dual fulfillment

---

## 10. Urban Romance Values

### Core Values

1. **Independence and autonomy**: Women do not rely on men, have their own careers and pursuits  
2. **Mutual respect**: Not to change the other but appreciate differences  
3. **Growing together**: Love is about both becoming better  
4. **Realistic rationality**: Acknowledge real difficulties and solve them wisely  
5. **Balance career and love**: A successful life is not an either-or choice

### Pitfalls to Avoid

- ❌ Female lead gives up career for love (contradicts independent woman image)  
- ❌ Male lead uses money to solve everything (objectifies love)  
- ❌ All problems resolved by misunderstandings and coincidences (lacks depth)  
- ❌ Completely idealized, detached from urban reality (floating drama)

---

**【Special Reminder】**  
The key to success of urban romance short stories:  
1. Professional settings must be realistic, not floating  
2. Career and emotional lines must intertwine, not separate  
3. Conflicts come from real pressures, not melodramatic misunderstandings  
4. Characters must grow, not just date  
5. Endings must be win-win, reflecting urban women’s independence and love’s fulfillment