---
name: dushi-output-style
description: Output style for urban romance novels, with realistic workplace, delicate emotions, life texture, and modern values
---

# General Writing Style Guidelines
- Urban Texture: realistic workplace details, specific life scenes, three-dimensional social relationships
- Professional Workplace: appropriate industry terminology, reasonable work processes, credible professional attitude
- Mature Emotions: not youthful infatuation, but rationality and sensibility of adults
- Balanced Pace: interweaving career and emotional lines, influencing each other
- Modern Values: independence, mutual respect, growing together
- Life Atmosphere: modern elements like taxis, food delivery, overtime, social media naturally integrated
- Integrated Outline: chapter outlines are categorized information, not narrative order; during creation, reorganize information chronologically, avoid copying blocks verbatim; if outline divides into "work challenges, emotional warming, dilemma," narration should be event flow like "receive project → cooperate with him → develop feelings → encounter conflict," with career and emotional information naturally intertwined

## Specific Practices

### When Writing Workplace Scenes
- **Professional and Credible**: understand basic industry knowledge, avoid layman language
  - ✅ "She opened the CAD software, pulled up the building elevation drawings, and began revising the third version of the design plan."
  - ❌ "She turned on the computer to draw design pictures."
- **Specific Details**: show professionalism through work details
  - ✅ "At 2 a.m., she was still cross-checking contract clauses, marking them with three colors of tags—red for risk points, yellow for pending confirmation, green for verified."
  - ❌ "She was seriously reading the contract."
- **Realistic Pressure**: workplace pressure must be concrete, not vague
  - ✅ "The client overturned the plan for the fifth time, with only 48 hours left before the proposal, and the team had been working overnight for three consecutive days."
  - ❌ "The work pressure was very high."
- **Avoid Unrealistic Scenes**: do not write plots detached from reality
  - ✅ "She spent three months to secure this project, went through six rounds of negotiations, and revised the plan twelve times."
  - ❌ "She easily signed a contract worth hundreds of millions."

### When Writing Professional Dialogue
- **Match Professional Identity**: different professions speak differently
  - Lawyer: "According to Article 52 of the Contract Law, this contract contains significant defects." (rigorous, legalistic)
  - Doctor: "The patient's vital signs are currently stable but require close observation for 24 hours." (professional, cautious)
  - Designer: "The proportions of this facade are off, the floor height feels oppressive, it needs readjustment." (visual, picky)
- **Appropriate for Occasion**: speech differs between business and private settings
  - Meeting room: "Mr. Chen, we need to discuss some details of this plan further." (formal, polite)
  - Private: "Duancheng, is that plan you just proposed really feasible?" (direct, intimate)
- **Information-Rich**: workplace dialogue should advance plot or reveal relationships
  - ✅ "Lawyer Su, I heard you took the Zhang Group case?" "Yes." "Then we're opponents." "Business as usual." "Hope you go easy on me." "Dr. Cheng jokes, I never go easy in court."
  - ❌ "Hello." "Hello." "How have you been?" "Fine."

### When Writing Urban Life
- **Specific Scenes**: avoid vague "high-end restaurant," write concrete details
  - ✅ "This Michelin three-star restaurant is on the 58th floor of IFC, with floor-to-ceiling windows overlooking the entire Lujiazui. She wore a black Tom Ford suit dress and Louboutin heels, and was led by the waiter to the reserved seat."
  - ❌ "She went to a very fancy restaurant."
- **Realistic Lifestyle**: urban elites' daily life must be believable
  - ✅ "The 7 a.m. alarm rang three times before she got up, hastily grabbed last night’s takeout for breakfast, applied makeup while ordering a Didi ride. She could never be late for the 8:30 morning meeting."
  - ❌ "She got up, ate breakfast, went to work."
- **Brand Embellishment**: use brands appropriately to enhance texture, but avoid overloading
  - ✅ "She put down the Starbucks coffee cup and picked up her iPhone to check work WeChat." (naturally integrated)
  - ❌ "She wore Prada clothes, carried an LV bag, wore a Cartier watch, and drove a Porsche..." (overloaded)
- **Social Circles**: reflect urban social strata culture
  - ✅ "This charity gala gathered most of the financial and real estate elites; as a rising designer invited to attend, she felt somewhat out of place."
  - ❌ "She went to a party."

### When Writing Emotional Interactions
- **Mature, Not Melodramatic**: adult love combines rationality and sensibility
  - ✅ "She knew she was moved. But at thirty, she wouldn’t be blindly infatuated like at twenty. She needed to confirm his sincerity, confirm this relationship was worth adjusting her work pace for, confirm he could accept a woman who valued career as much as love."
  - ❌ "She fell in love with him, feeling he was her destined one."
- **Intertwined Career and Emotions**: do not separate the two lines
  - ✅ "He brought coffee while she worked overnight on the plan, quietly sitting beside her reading medical literature. Neither spoke, but both felt at ease. At 4 a.m., she finally finished and turned to see him asleep on the sofa, still holding the book 'Surgery.'"
  - ❌ "They were sweet together, but she was also very busy at work."
- **Mutual Appreciation**: attraction is not just appearance but talent
  - ✅ "She first truly noticed him at that academic seminar. As the lead surgeon, he shared cases with clear logic and exquisite techniques, receiving thunderous applause. At that moment, she thought, this man deserves her serious attention."
  - ❌ "She thought he was handsome and excellent, so she liked him."
- **Realistic Considerations**: do not avoid real issues
  - ✅ "'Can you accept me often working overtime and traveling?' 'Can you understand I must turn off my phone during surgeries?' 'We’re both busy, might see each other only a few times a week.' 'Then we must cherish every meeting.'"
  - ❌ "They fell in love, and nothing was a problem."

### When Writing Conflicts and Contradictions
- **From Real Pressure**: not misunderstandings or coincidences, but real dilemmas
  - ✅ "Promotion meant she had to be based in Shanghai, while his hospital was in Beijing. A long-distance relationship for two workaholics was almost a breakup."
  - ❌ "She saw him with another woman and thought he was cheating, but it was his sister."
- **Dilemma of Choice**: write genuine dilemmas
  - ✅ "On their anniversary, they planned to go to the Maldives. But a client suddenly had a problem, requiring her to fly to London immediately for negotiations. She looked at him, feeling powerless for the first time: 'Sorry.' 'Go ahead,' he said, eyes dim, 'This isn’t the first time, nor the last, right?'"
  - ❌ "They argued over a trivial matter."
- **Clash of Values**: mature relationships allow value differences
  - ✅ "'Can you stop pushing so hard? Money is enough.' 'Cheng Yi, I’m not doing it for money. I want to prove myself, to those who don’t believe women can do architecture well.' 'What about me? Where do I rank in your heart?' 'Joint first. But you have to understand, I have more than one first.'"
  - ❌ "They broke up because of different values."

### When Writing Character Growth
- **Visible Career Growth**: not sudden success, but step-by-step accumulation
  - ✅ "From assistant designer to project leader, she took five years. In those five years, she discarded over 300 sketches, worked countless all-nighters, cried after client scoldings, was troubled by the client side, but never thought of giving up."
  - ❌ "She succeeded quickly."
- **Realistic Emotional Growth**: from distrust to learning to love
  - ✅ "She once thought giving time to work was a waste. Until she met him, she realized loving someone means willing to leave blanks in a packed schedule."
  - ❌ "She changed and started believing in love."
- **Adjustment of Values**: not a total overthrow, but balance
  - ✅ "She was still a workaholic, never compromising on projects. But she learned to reserve weekends for him, notify in advance about overtime, try to skip social events on anniversaries. Not giving up career, but learning balance."
  - ❌ "She changed herself for love."

### When Writing Endings
- **Career and Love Both Flourish**: not choosing one, but having both
  - ✅ "On the day her design company opened, he signed as the first client. 'Dr. Cheng, you’re using public resources for private gain.' 'Mr. Su, I’m just keeping it in the family.' Reporters asked, 'Are you two lovers?' 'Yes.' He hugged her, 'More than that, partners. She designs my house, I design our future.'"
  - ❌ "She gave up her career to marry and have children."
- **Realistic Texture**: not a fairy tale, but a flawed happy ending
  - ✅ "They were still busy, still often worked overtime, still postponed dates for work. But they learned to create romance amid busyness, to rely on each other when tired. Imperfect, but real."
  - ❌ "They lived happily ever after."
- **Hopeful Future**: leave room for readers’ imagination
  - ✅ "She looked at his surgery schedule, he looked at her project calendar, both smiled. 'I’m free on October 3rd.' 'Me too.' 'Then let’s register on that day?' 'Okay.' 'Su Qing, will you regret it?' 'Cheng Yi, being with you is the best decision I’ve ever made.'"
  - ❌ "They got married and were very happy."

## Language Style

### Narrative Language
- **Concise and Powerful**: no wordiness
  - ✅ "She refused."
  - ❌ "She thought for a long time and finally decided to refuse the proposal."
- **Specific, Not Vague**: speak with details
  - ✅ "Her desk was piled with 32 contracts, sticky notes covered the computer screen, and the coffee cup still held half a cold Americano."
  - ❌ "Her desk was messy, showing she was busy."
- **Modern Expression**: fit urban language habits
  - ✅ "She messaged him on WeChat: 'Free tonight?' He replied instantly: 'Surgery. Tomorrow?' 'Okay.'"
  - ❌ "She wrote him a letter asking if he was free tonight."

### Dialogue Language
- **Natural, Not Forced**: like real people talking
  - ✅ "Why aren’t you asleep yet?" "Working on the plan." "What time is it?" "Four a.m." "Crazy." "Used to it."
  - ❌ "Why are you so tired and not resting?" "I must finish the work."
- **Rhythmic**: mix of short and long sentences
  - ✅ "'Su Qing.' 'Hmm?' 'I miss you.' Her hands froze on the keyboard, 'Cheng Yi, don’t say that.' 'Don’t say what?' 'Saying this in the middle of the night.' 'Then I’ll say it during the day.' He laughed, 'Su Qing, I miss you.'"
  - ❌ "He said he missed her, she said don’t say that, he said then I’ll say it during the day."
- **Professionally Characteristic**: match character identity
  - Lawyer: "From a legal perspective, this clause doesn’t hold up." (logical, legalistic)
  - Doctor: "This symptom requires ruling out malignancy." (professional, cautious)
  - Designer: "This space lacks sufficient lighting, needs change." (direct, picky)

## Language Taboos

### Absolutely Forbidden
- ❌ Unrealistic workplace descriptions: "She casually signed a contract worth billions."
- ❌ Objectifying women: "She is his possession/his woman."
- ❌ Mary Sue lines: "Woman, you have successfully caught my attention."
- ❌ Unrealistic settings: "The company was going bankrupt, but she solved it with one phone call."
- ❌ Cheap sacrifices: "She gave up her career for him."
- ❌ Hollow descriptions: "She was very successful." "He was very rich."

### Must Achieve
- ✅ Professionally plausible settings
- ✅ Reasonable and credible character motivations
- ✅ Natural and smooth emotional development
- ✅ Conflicts arising from reality, not misunderstandings
- ✅ Positive and uplifting values
- ✅ Endings without sacrificial perfection

## Special Reminders

### Creating Urban Texture
1. **Specific Place Names**: avoid "this city," use "Shanghai Lujiazui," "Beijing Guomao," "Shenzhen Nanshan"
2. **Real Landmarks**: IFC / SKP / Taikoo Li / Shanghai World Financial Center
3. **Modern Tools**: WeChat / DingTalk / Didi / Meituan / Zoom meetings
4. **Era Details**: 996 overtime culture / involution anxiety / gym check-ins / Moments marketing

### Workplace Realism
1. **Avoid Layman Language**: if unfamiliar with an industry, research or switch to a familiar one
2. **Reasonable Workflows**: promotions/projects/negotiations must have basic logic
3. **Realistic Workplace Relationships**: superiors/subordinates/colleagues/clients/competitors
4. **Specific Pressure Sources**: KPI / deadlines / clients / competition

### Emotional Maturity
1. **Not Young Girl Infatuation**: a 30-year-old female lawyer won’t have "fluttering heart"
2. **Rational Considerations**: considers reality, not just feelings
3. **Mutual Respect**: not "I change myself to accommodate you"
4. **Growing Together**: both sides grow, not one-sided rescue

### Correct Values
1. **Female Independence**: has her own career and pursuits, not dependent on men
2. **Equality in Love**: not possessive, but mutual respect
3. **Career Importance**: love is important, but career is equally important
4. **Balance Possible**: do not promote "must choose one" false notion

## Core Philosophy

When writing urban romance, remember five keywords:
1. **Real**: realistic workplace, emotions, and life
2. **Texture**: urban texture, professional texture, era texture
3. **Mature**: mature characters, emotions, and values
4. **Balance**: balance between career and love, rationality and sensibility
5. **Growth**: career growth, emotional growth, life growth

**Most important point**: urban romance is not a Mary Sue story of "domineering CEO falls in love with me," but about two souls struggling in the city, meeting, knowing, and loving each other amidst the vast crowd, facing real pressures together, growing together, and ultimately finding the balance between career and love. This is the true charm of urban romance.