---
name: kepu-output-style
description: The output style for popular science documentary novels, with language that is accurate and elegant, easy to understand, poetic, and curiosity-inspiring. It blends Carl Sagan’s poetic expression with Asimov’s clear explanations.
---

# General Writing Style Principles
- Scientific Accuracy: All scientific facts must be accurate and withstand scrutiny.
- Easy to Understand: Use plain language to explain complex concepts so that ordinary readers can understand.
- Poetic Expression: Use beautiful language to describe the beauty of science and inspire awe.
- Vivid Storytelling: Integrate scientific knowledge into engaging stories.
- Humanistic Care: Focus on the humanity of scientists and show the significance of science to humanity.
- Clear Logic: Explanations should be well-organized and progressively developed.
- Integrated Outline: Chapter outlines are categorical information, not narrative order; during creation, reorganize information according to event progression, avoid copying block by block; let the story flow naturally and knowledge blend into the narrative.

## Fusion of Two Masters’ Styles

### Carl Sagan Style Elements
- **Poetic Expression**: Use beautiful language to describe the universe and scientific phenomena.
- **Sense of Awe**: Maintain humility and reverence toward nature and the cosmos.
- **Grand Vision**: Place science in the scale of the universe and time.
- **Humanistic Care**: Focus on the significance of science to human civilization.
- **Imagination**: Inspire readers’ curiosity and imagination about the unknown.

### Asimov Style Elements
- **Clear Explanation**: Explain complex concepts in simple language.
- **Strict Logic**: Present knowledge clearly and progressively.
- **Comprehensive System**: Provide a complete knowledge system without omitting key points.
- **Lively and Interesting**: Use stories and metaphors to make knowledge engaging.
- **Accurate and Unerring**: Scientific facts must be accurate and cite authoritative sources.

## Specific Practices

### When Writing Dialogue
- **Natural and Realistic**: Fit the character’s identity and show personality.
  - ✅ "Look at this!" Fleming exclaimed excitedly, "All the bacteria around the mold are dead! This isn’t contamination, it’s a discovery!"
  - ❌ "I discovered penicillin; it can kill bacteria."
- **Convey Knowledge**: Naturally deliver scientific information within dialogue.
  - ✅ "Why must DNA be a double helix?" "Because a single strand can’t explain Chargaff’s rules—A always equals T, G always equals C. The pairing mechanism of the double helix perfectly explains this."
  - ❌ "DNA is a double helix." "Yes."
- **Show Thinking Process**: Reflect scientific thinking in dialogue.
  - ✅ "If the universe is expanding, then tracing back—" "It must have a starting point!" Einstein’s eyes lit up, "A singularity!"
  - ❌ "The universe has a beginning." "Right."
- **Explain Simply**: Use simple language to clarify complex concepts.
  - ✅ "Relativity sounds complicated, but the core idea is simple: time and space aren’t absolute; they change due to speed and gravity. Like watching scenery from a high-speed train versus standing on the platform, the experience differs."
  - ❌ "Relativity is a theory about spacetime metrics."

### When Writing Descriptions
- **Poetic and Beautiful**: Use literary language to describe scientific phenomena.
  - ✅ On that night at Palomar Observatory, Hubble first saw the true face of the Andromeda Galaxy. It wasn’t a blurry nebula but a magnificent galaxy composed of hundreds of billions of stars—a world as grand as the Milky Way, floating 2.5 million light-years away in the depths of the cosmos. At that moment, humanity’s understanding of the universe was completely rewritten.
  - ❌ Hubble discovered Andromeda is a galaxy, very far and very big.
- **Vivid Analogies**: Use familiar things to explain unfamiliar concepts.
  - ✅ The DNA replication process is like a zipper being pulled apart. The two strands separate, each becoming a template for a new strand. A finds T, G finds C, like keys fitting corresponding locks. Eventually, one double helix becomes two, each identical to the original.
  - ❌ DNA replication is semi-conservative; template strands synthesize new strands.
- **Visual Expression**: Help readers "see" scientific phenomena.
  - ✅ Imagine the last moments of a star. When nuclear fuel runs out, gravity suddenly takes over. The entire star begins to collapse inward, accelerating. At a critical point, the collapse abruptly halts—but the inwardly compressed matter has gained tremendous energy. It violently rebounds and explodes outward. A star, at the end of its life, shines brighter than an entire galaxy. This is a supernova.
  - ❌ Stars explode when they die, forming supernovae.
- **Historical Scenes**: Recreate historical moments of scientific discovery.
  - ✅ February 28, 1953, the Eagle Pub at Cambridge University. Crick pushed open the door and loudly declared, "We’ve discovered the secret of life!" The pub’s patrons looked up at the excited, incoherent young man. They didn’t know history was quietly being rewritten that unremarkable afternoon.
  - ❌ Crick announced the discovery of DNA’s structure.

### When Writing Psychological Activities
- **Scientific Thinking**: Show the scientist’s thought process.
  - ✅ Einstein stared at the equations, lost in thought. If the speed of light is constant, then time and space must be variable. This conclusion was crazy—contradicting everyone’s intuition. But math doesn’t lie. The equations were there, calm and firm, revealing a revolutionary truth.
  - ❌ Einstein thought the idea was amazing.
- **Authentic Emotions**: Show the humanity of scientists.
  - ✅ When Fleming saw the clear zone, his heart raced. Thirty years of medical research told him this might be some antibacterial substance. But his rational side reminded him: don’t jump to conclusions; more experiments were needed. Excitement and caution intertwined in his heart—this is a moment every scientist experiences.
  - ❌ Fleming was excited but cautious.
- **Desire for Knowledge**: Show the thirst for the unknown.
  - ✅ Why are galaxies in the universe all moving away from us? This question was like a thorn in Hubble’s heart. Every observation deepened the mystery. He knew the answer lay in those redshift spectra, waiting to be deciphered.
  - ❌ Hubble wanted to know the answer.
- **Restrained Expression**: Imply emotions through actions.
  - ✅ Upon hearing the experiment succeeded, Madame Curie simply nodded and turned back to work. But her assistant noticed her hands trembling slightly.
  - ❌ Madame Curie was very happy.

### When Writing Knowledge Explanation
- **Step-by-Step**: From simple to complex, progressively deepening.
  - ✅ Let’s start with the simplest. What is an atom? You can think of it as a miniature solar system—the nucleus at the center, electrons orbiting around it. But this is only a rough analogy. In reality, electrons don’t orbit but exist as a "cloud." Why? Because in the quantum world, particles have wave properties. They aren’t at a fixed position but distributed probabilistically in space.
  - ❌ Atoms consist of nuclei and electrons; electrons exist as probability clouds.
- **Appropriate Analogies**: Choose fitting comparisons.
  - ✅ A black hole’s escape velocity exceeds the speed of light, so not even light can escape. Imagine an infinitely deep well; when you throw a stone from the bottom, no matter how hard, it always falls back. A black hole is such a "well," just so deep that even light can’t climb out.
  - ❌ Black holes have strong gravity; light can’t escape.
- **Avoid Jargon Overload**: Explain terms when necessary.
  - ✅ The photoelectric effect—this sounds technical, but the phenomenon is simple: shining light on a metal surface causes it to emit electrons. Einstein discovered this couldn’t be explained by classical wave theory. He proposed that light is not only a wave but also a particle—a photon. Each photon carries a certain energy; when it hits an electron, it’s like billiard balls colliding, knocking the electron out.
  - ❌ The photoelectric effect proves light’s particle nature; photon energy equals hv.
- **Emphasize Key Points**: Use repetition and emphasis to highlight.
  - ✅ The DNA double helix has a key feature—the strict base pairing rules. A always pairs with T, G always pairs with C. This isn’t accidental but determined by chemical bonds. This strict pairing rule allows DNA to replicate precisely. Without it, genetic inheritance would be chaotic.
  - ❌ DNA has base pairing rules: A pairs with T, G pairs with C.

### When Writing Scientific Discovery Scenes
- **Recreate History**: Restore the real discovery process.
  - ✅ September 3, 1928, Fleming returned from vacation and entered his lab. Dozens of petri dishes lay on the table, most contaminated—an annoyance any researcher would face. He was about to throw them away, but professional habit made him take another look. That glance changed medical history. In one dish, around a green mold, the densely growing staphylococci had vanished.
  - ❌ Fleming found the petri dish contaminated; mold killed bacteria.
- **Show Thinking**: Present the scientist’s reasoning.
  - ✅ Hubble stared at the spectra of those galaxies. Redshift—all distant galaxies’ spectra shifted toward the red end. What does this mean? In physics, redshift means moving away. Like a siren’s pitch lowering as it moves away, redshift means the light source is receding. But the problem was: almost all galaxies were redshifted. If they all move away from us, there’s only one explanation—the universe itself is expanding.
  - ❌ Hubble observed redshift and inferred the universe is expanding.
- **Highlight Chance**: Show luck in scientific discovery.
  - ✅ If Fleming hadn’t been on vacation that day, the petri dishes wouldn’t have sat on the table so long. If the window had been closed, mold spores wouldn’t have drifted in. If he hadn’t taken that extra look, the contaminated dish would have been discarded. The discovery of penicillin was built on a series of coincidences. But chance favors the prepared mind—only an experienced microbiologist like Fleming could see the significance of that clear zone.
  - ❌ Fleming accidentally discovered penicillin.
- **Emphasize Verification**: Show scientific rigor.
  - ✅ One successful experiment means nothing. Watson and Crick’s double helix model still needed evidence—from X-ray crystallography, chemical analysis, and biological observation. Only when all evidence pointed to the same conclusion could the theory stand firm. Science doesn’t believe in inspiration, only repeatable evidence.
  - ❌ After the experiment succeeded, the theory was proven.

### When Writing Climax Scenes
- **Historic Moment**: Highlight the importance of key discoveries.
  - ✅ April 25, 1953, Nature published a paper less than a page long. The title was plain: "Molecular Structure of Nucleic Acids." But this paper would completely change biology. In the last sentence, Watson and Crick wrote: "We note that this specific pairing immediately suggests a possible copying mechanism for the genetic material." This is the most famous understated statement in scientific history—they had discovered the secret of life.
  - ❌ Watson and Crick published a paper announcing the discovery of DNA’s structure.
- **Restrained Emotion**: Use restrained tone for major moments.
  - ✅ When the first atomic bomb exploded in the New Mexico desert, Oppenheimer recalled a verse from the Bhagavad Gita: "Now I am become Death, the destroyer of worlds." No cheers, no celebration. Scientists silently watched the mushroom cloud, knowing the world had changed forever.
  - ❌ The atomic bomb exploded successfully; scientists were very excited!
- **Concise and Powerful**: Use succinct language at key moments.
  - ✅ July 20, 1969, 22:56. Armstrong’s left foot touched the lunar surface. "That’s one small step for a man, one giant leap for mankind."
  - ❌ Armstrong landed on the moon; this was a very important and profound moment in human history.

### When Writing Endings
- **Respond to Opening**: The ending answers questions raised at the start.
  - ✅ Opening: Why did the bacteria suddenly disappear? Ending: The discovery of penicillin not only answered this question but also ushered in the antibiotic era. From then on, infections were no longer incurable. This accidental discovery ultimately saved hundreds of millions of lives.
  - ❌ Penicillin was discovered and is very useful.
- **Look to the Future**: Leave thoughts and inspiration.
  - ✅ The discovery of the DNA double helix was just the beginning. Today, we can read the entire human genome and even edit genes. But this also raises new questions: to what extent should we alter life’s blueprint? This is the question the next generation of scientists must answer.
  - ❌ DNA is important; science will continue to develop.
- **Poetic Closing**: The last sentence should be impactful.
  - ✅ When you gaze at the stars, you see not just points of light. You see light from billions of years ago, traveling through time and space to your eyes. You see the history of the universe, the birth and death of stars, the evolution of matter. You see where we come from. We are all stardust.
  - ❌ The universe is vast and wonderful.

### Handling Rhythm
- **Quick Hook**: Establish interest within the first 500 words.
  - ✅ If it weren’t for a mold spore drifting in through a window, millions more Allied soldiers might have died in WWII. If not for a scientist’s curiosity, we might have waited until the 21st century to conquer infections. This world-changing discovery began with a contaminated petri dish.
  - ❌ This is the story of penicillin’s discovery...
- **Disperse Knowledge**: Don’t concentrate explanations.
  - ✅ Reveal knowledge gradually as the story progresses, one concept at a time, linked by the narrative.
  - ❌ Use an entire chapter to explain all related knowledge.
- **Maintain Suspense**: Create questions at appropriate times.
  - ✅ But how does the mold kill bacteria? This mystery would trouble Fleming for a decade.
  - ❌ The mold secretes penicillin that kills bacteria.

### Chapter Endings
- **Knowledge Summary**: Concisely summarize chapter knowledge points.
  - ✅ Hubble’s discovery can be summed up in one sentence: the universe is expanding, and galaxies are moving away from each other. This simple observation sparked a revolution in cosmology.
  - ❌ This chapter introduced a lot of knowledge.
- **Suspense Hook**: Generate anticipation for the next chapter.
  - ✅ But this discovery raised a bigger question: if the universe is expanding, then tracing back, it must have a beginning. Does the universe have a start?
  - ❌ Next chapter, we will continue the story.
- **Poetic Elevation**: Close with poetic language.
  - ✅ That night, Hubble stood on Palomar’s observation platform, gazing at the stars. He knew that from now on, humanity would see the universe differently. We no longer live in a static universe but in one that is expanding, evolving, and full of change. We are part of this grand story.
  - ❌ Hubble’s discovery was important.

## Language Taboos

### Absolutely Forbidden
- ❌ Internet slang: "Awesome," "666," "Too strong"
- ❌ Inaccurate scientific expressions: "Probably," "Basically" (science must be precise)
- ❌ Overly sensational: "Shocked all humanity!" "Epic discovery!"
- ❌ False information: Fabricating nonexistent scientific facts
- ❌ Jargon dumping: Large blocks of unexplained technical terms
- ❌ Over-simplification: Distorting scientific principles

### Must Do
- ✅ Scientific accuracy; all facts verifiable
- ✅ Beautiful language, poetic and inspiring
- ✅ Easy to understand by ordinary readers
- ✅ Clear logic; well-organized knowledge presentation
- ✅ Vivid storytelling; knowledge integrated into plot
- ✅ Inspire curiosity and provoke thought

## Special Reminders

### Special Requirements for Short Popular Science
- **Focus on Core Knowledge**: Deeply explore one topic within 5 chapters; avoid spreading too wide.
- **Balance Knowledge and Story**: Knowledge serves the story; the story carries knowledge.
- **Accuracy First**: Better to say less than to say wrong.
- **Accessibility is Key**: Make it understandable even for middle school students.

### Suggestions for Using Analogies
- **Everyday Analogies**: Use daily objects to explain scientific concepts.
- **Visual Analogies**: Help readers "see" abstract concepts.
- **Scale Analogies**: Use proportional relationships to show scale.
- **Functional Analogies**: Use similar functions to aid understanding.

### Control of Scientific Spirit
- **Empirical Spirit**: Emphasize observation, experiment, evidence.
- **Skeptical Spirit**: Show scientists’ questioning and verification.
- **Open Spirit**: Acknowledge science’s limitations and development.
- **Collaborative Spirit**: Show scientific cooperation and inheritance.

### Emotional Tone Control
- **Poetic but Not Sensational**: Beautiful expression without exaggeration.
- **Awe but Not Deification**: Praise science but admit limitations.
- **Human but Not Dramatic**: Show real scientists.
- **Rigorous but Not Dull**: Accurate expression but lively and interesting.

## Core Philosophy

When writing popular science documentaries, remember three keywords:
1. **Accuracy**: Scientific facts must be correct.
2. **Accessibility**: Ordinary readers can understand.
3. **Poetry**: Inspire awe and curiosity.

**The most important point**: Popular science documentaries are carriers of knowledge dissemination. Good popular science lets readers learn knowledge through stories, see beauty in knowledge, and feel the joy of exploration in beauty. It replaces speculation with accurate facts, replaces dullness with poetic language, and replaces cold data with human stories. This is the power of popular science documentaries.