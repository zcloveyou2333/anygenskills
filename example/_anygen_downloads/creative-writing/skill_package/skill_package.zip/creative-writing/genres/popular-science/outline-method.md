---
name: kepu-outline-method
description: Methodology for creating outlines of popular science documentary novels, including core synopsis extraction, introduction design, narrative structure planning, and character development guidance. Integrates Carl Sagan’s poetic expression with Asimov’s accessible explanations.
---

## Q1-Q3 Question Templates

### Q1: Core Idea
**Q1: Core idea and appeal of the story [Brief description]**  
Please describe your story idea in one or two sentences.

### Q2: Core Conflict
**Q2: Core conflict [Brief description]**  
Please describe the novel’s core contradiction or main conflict in one sentence  
(e.g., scientists overcoming obstacles to discover a new theory, an archaeological team uncovering astonishing truths of ancient civilizations, astronomers capturing alien signals and ensuing chain reactions, physicists’ theories clashing fiercely with mainstream academia, etc.)

### Q3: Story Tone
**Q3: Story tone [Choose one]**  
- Exploration & Discovery · Thirst for Knowledge (Passion for scientific exploration, breakthroughs in unknown fields)  
- Biography · Scientific Spirit (Scientists’ lives, perseverance and sacrifice, the tide of the era)  
- Scientific Suspense · Layered Revelation (Unraveling mysteries with scientific methods, truth unveiled)  
- Popular Science Narrative · Easy to Understand (Integrating complex science into captivating stories)  
- Or briefly describe your story tone

## Chapter File Naming Rules  
Filename format: `{STORY_NAME}-{NN}.md`  
Example: `Journey_to_the_Universe-01.md`, `Journey_to_the_Universe-02.md`

---

# Methodology for Creating Popular Science Documentary Outlines

## Overall Orientation

Popular science documentaries emphasize "**scientific authenticity and storytelling charm**," based on real scientific knowledge, historical events, and characters, spreading the scientific spirit through narrative storytelling.

**Core Principles**:  
- Scientific accuracy first: All scientific knowledge must be accurate and error-free  
- Balance storytelling and knowledge: Use stories to carry knowledge, let knowledge drive the plot  
- Accessible yet profound: Explain complex concepts simply so general readers can understand  
- Inspire awe and curiosity: Showcase the beauty of science and evoke the desire to explore  
- Humanistic perspective: Focus on scientists’ humanity and the significance of science to humanity  
- Maintain Sagan-style poetry: Describe scientific phenomena with elegant language  
- Incorporate Asimov’s clarity: Logical, clear, and thorough explanations

---

## Overall Creation Formula
```
Popular Science Documentary = Scientific Knowledge + True Stories + Character Appeal + Clear and Accessible Explanation
```

---

## 1. Core Synopsis Writing

### Formula
```
Core Synopsis = Scientific Theme + Core Story + Knowledge Value
```

### Writing Points
| Element       | Requirement          | Correct Example                                               | Incorrect Example               |
|---------------|---------------------|--------------------------------------------------------------|--------------------------------|
| **Scientific Theme** | Clear + Attractive  | "Revealing the discovery process of the DNA double helix"    | "Talking about some biology knowledge" |
| **Core Story**       | True + Dramatic     | "The competition, cooperation, and final breakthrough of two scientists" | "Scientists did many experiments" |
| **Knowledge Value**  | Touches essential issues | "Demonstrates how scientific discovery changed human understanding of life" | "Introduced DNA knowledge" |

### Excellent Examples
- "In 1953, two young scientists at Cambridge University—Watson and Crick—outpaced the world’s top scholars to crack the code of life: the DNA double helix structure. This discovery not only revealed the secret of heredity but also ushered in a new era of molecular biology."
- "When Hubble first pointed his telescope at the Andromeda Nebula, he discovered not just a distant galaxy but evidence of the expanding universe. This finding completely changed humanity’s understanding of the cosmos—we live in an expanding universe."
- "The discovery of penicillin originated from an accidental contamination. Fleming noticed mold killing bacteria in a petri dish. This seemingly trivial observation eventually saved hundreds of millions of lives."

---

## 2. Introduction Writing

### Formula
```
Introduction = Scientific Scene Opening + Core Suspense Setup + Knowledge Hook
```

### Writing Points
| Element       | Role                  | Writing Method                                         |
|---------------|-----------------------|-------------------------------------------------------|
| **First Sentence** | Establish scientific atmosphere | Directly present: scientific phenomenon / historical moment / research scene |
| **Middle Part**    | Explain core discovery          | Use vivid details and accurate scientific terms to quickly position the story |
| **Last Sentence**  | Create curiosity               | Pose a question / hint at the discovery’s significance / imply story twists |

### Integration of Knowledge Themes

The introduction should touch the core values of popular science documentary:

| Theme Type      | Specific Direction                                  |
|-----------------|----------------------------------------------------|
| **Scientific Discovery** | Major theoretical breakthroughs, key experimental successes, unexpected observations |
| **Scientific Figures**    | Scientists’ persistence, genius inspirations, team collaboration |
| **Scientific Method**     | Empirical spirit, logical reasoning, hypothesis testing |
| **Scientific Impact**     | World-changing technologies, paradigm-shifting theories, life-saving discoveries |

**Goal**: Make readers feel the "aha" moment (knowledge immersion)

### Example Comparison
| Type          | Content                                                                                                                                    |
|---------------|--------------------------------------------------------------------------------------------------------------------------------------------|
| ✅ **Correct** | "One morning in September 1928, Alexander Fleming entered his laboratory and found mold growing in a petri dish. This was an accidental contamination—any rigorous scientist would have discarded it. But Fleming noticed something strange: around the mold, the densely growing staphylococci had disappeared, leaving a clear zone. This seemingly trivial observation eventually triggered the greatest revolution in medical history—the discovery of antibiotics." |
| ❌ **Incorrect** | "Antibiotics are very important drugs, and their discovery is very significant to humanity..."                                         |

---

## 3. Narrative Structure Design (Qi-Cheng-Zhuan-He)

### 【Qi】Chapter 1: Problem and Background (2000-3000 words)

#### Writing Focus
```
Qi = Scientific background presentation + Problem statement + Protagonist introduction + Exploration begins
```

| Module          | Writing Points                      | Specific Methods                                                                                      |
|-----------------|-----------------------------------|----------------------------------------------------------------------------------------------------|
| **Scientific Background** | Establish knowledge base within first 500 words | Introduce scientific phenomena / historical background / unsolved mysteries in the first paragraph<br>Use analogies and metaphors to make complex concepts easier to understand |
| **Problem Statement**     | Present scientific problems to solve | Historical unresolved issues / observed contradictions / technical bottlenecks                        |
| **Protagonist Introduction** | Introduce main scientists or explorers | Show their professional abilities, personal traits, research motivations                             |
| **Exploration Begins**    | Official start of research work     | Form teams / design experiments / propose hypotheses                                                |

#### Popular Science Writing Techniques
- **Analogy**: Explain scientific concepts using everyday objects  
- **Storytelling**: Narrate scientific discovery as an adventure  
- **Visualization**: Use descriptive language to help readers "see" scientific phenomena

#### Taboos
- ❌ Large blocks of dry scientific jargon  
- ❌ Pure knowledge explanation without characters or story  
- ❌ Oversimplification causing scientific inaccuracies

---

### 【Cheng】Chapters 2-3: Exploration and Discovery (2000-3000 words each)

#### Chapter 2 Writing Focus
```
Chapter 2 = Initial attempts + Encounter difficulties + Adjust direction + Unexpected clues
```

| Module          | Writing Points                    | Specific Methods                                  |
|-----------------|---------------------------------|--------------------------------------------------|
| **Initial Attempts** | Show scientific research process | Experiment design / data collection / theoretical deduction |
| **Encounter Difficulties** | Present real setbacks           | Experiment failures / data contradictions / theoretical flaws |
| **Adjust Direction** | Show scientific thinking         | Re-examine hypotheses / improve methods / seek collaboration |
| **Unexpected Clues** | Create turning points            | Accidental observations / inspiration from others / technical breakthroughs |

#### Chapter 3 Writing Focus
```
Chapter 3 = Key breakthrough + Verification process + Competitive pressure + Theory refinement
```

| Module          | Writing Points                  | Specific Methods                                   |
|-----------------|--------------------------------|---------------------------------------------------|
| **Key Breakthrough** | Moment of core discovery       | Sudden inspiration / data matches / successful experiments |
| **Verification Process** | Show scientific rigor         | Repeat experiments / peer review / exclude alternatives |
| **Competitive Pressure** | Increase story tension        | Progress of other teams / publication time pressure |
| **Theory Refinement** | Prepare for climax              | Perfect details / build models / prepare publication |

---

### 【Zhuan】Chapter 4: Discovery and Confirmation (2000-3000 words)

#### Writing Focus
```
Zhuan = Major discovery + Scientific verification + Academic reaction + Significance revelation
```

| Module          | Writing Points                | Specific Methods                                   |
|-----------------|------------------------------|---------------------------------------------------|
| **Major Discovery** | Present final results         | Clearly explain the discovery content and significance |
| **Scientific Verification** | Show evidence chain          | Multiple verifications / data support / logical consistency |
| **Academic Reaction** | Show impact                  | Peer evaluations / doubts and support / academic debates |
| **Significance Revelation** | Respond to initial questions | What was answered / what changed / what was opened |

#### Sagan-style Poetic Expression
- **Cosmic perspective**: Place the discovery on the scale of human civilization  
- **Elegant language**: Use poetic words to describe the beauty of science  
- **Philosophical reflection**: Consider the discovery’s impact on human cognition

#### Taboos
- ❌ Overstating the discovery’s significance  
- ❌ Ignoring the limitations of scientific discoveries  
- ❌ Avoiding academic doubts and controversies

---

### 【He】Chapter 5: Impact and Outlook (2000-3000 words)

#### Writing Focus
```
He = Historical impact + Subsequent developments + Scientific spirit + Open outlook
```

| Module          | Writing Points                | Specific Methods                                   |
|-----------------|------------------------------|---------------------------------------------------|
| **Historical Impact** | Show far-reaching effects      | Technological applications / theoretical developments / social changes |
| **Subsequent Developments** | Trace follow-up progress       | New research based on the discovery / honors received |
| **Scientific Spirit** | Extract scientific methods and attitudes | Truth-seeking spirit / empirical methods / open mindset |
| **Open Outlook** | Leave room for reflection      | Unsolved mysteries / new questions / future possibilities |

#### Types of Popular Science Endings
| Type          | Characteristics                | Suitable Scenes                   |
|---------------|-------------------------------|---------------------------------|
| **Enlightenment** | Spread knowledge, inspire interest | Popular science for general public |
| **Tribute**       | Praise scientific spirit and scientists | Biographical popular science    |
| **Reflective**    | Trigger deep thinking about science | Discuss scientific methods and philosophy |
| **Prospective**   | Look forward to future scientific development | Introduction to frontier science |

#### Taboos
- ❌ Fabricate nonexistent scientific achievements  
- ❌ Excessive sentimentality against scientific spirit  
- ❌ Leaving obvious scientific errors

---

## 4. Character Development Methods

### Protagonist Design (Scientist/Explorer)

| Dimension       | Requirement                | Correct Example                              | Incorrect Example      |
|-----------------|----------------------------|----------------------------------------------|-----------------------|
| **Professional Identity** | Realistic + Specific       | "Theoretical physicist", "Paleontologist"   | "Scientist"           |
| **Core Traits**           | Align with scientific spirit | "Rigorous and truth-seeking but imaginative", "Persistent but humble and open" | "Perfect"             |
| **Personality Tags**      | 2-3 distinct traits          | "Genius but stubborn", "Rigorous but humorous", "Persistent but kind" | "Great person"        |
| **Research Motivation**   | Realistic and credible       | "Curiosity about the unknown", "Mission to solve practical problems" | "For fame and fortune" |

### Personality Specificity
```
✅ "Watson and Crick were a peculiar pair. Watson was young and impetuous, with leaps of thought and bold imagination; Crick was over a decade older, rigorous in thinking, skilled in mathematical reasoning. They argued endlessly in the Cambridge lab, but it was this clash that sparked one of the greatest discoveries of the 20th century."
❌ "They were two smart scientists who collaborated well."
```

### Protagonist Archetypes (Common in Popular Science)

| Type             | Characteristics                     | Personality                 | Suitable Themes             |
|------------------|-----------------------------------|-----------------------------|----------------------------|
| **Genius Discoverer** | Outstanding insight and creativity | Sharp, bold, imaginative    | Major theoretical breakthroughs |
| **Persistent Explorer** | Persevering research spirit       | Tenacious, focused, resilient | Long-term research projects  |
| **Accidental Discoverer** | Scientific literacy and observation | Careful, curious, open-minded | Stories of accidental discoveries |
| **Team Collaborator** | Cooperative spirit and organizational skills | Inclusive, pragmatic, communicative | Large scientific projects    |

### Supporting Characters Design (Popular Science Features)

| Type            | Role                          | Notes                                    |
|-----------------|-------------------------------|------------------------------------------|
| **Rival**       | Show scientific competition   | Should not be vilified, show their strengths |
| **Partner**     | Show scientific collaboration | Each has expertise, complement each other |
| **Skeptic**     | Show scientific debate        | Doubts should be based on scientific reasons |
| **Layperson**   | Represent reader’s perspective | Ask questions a non-expert might ask      |

### Relationship Network Design (Popular Science Specific)

| Element         | Requirement                             |
|-----------------|----------------------------------------|
| **Academic Factions** | Supporters of different schools and theories |
| **Mentorship**        | Mentor-student, senior-junior relationships |
| **International Cooperation** | Cross-national teams, academic exchanges |
| **Era Background**    | Interaction between scientists and their times |

---

## 5. Scientific Knowledge Design

### Knowledge Presentation Formula
```
Scientific Knowledge = Accurate Concepts + Accessible Explanation + Vivid Analogy
```

### Common Knowledge Types

| Type           | Features                       | Examples                        |
|----------------|--------------------------------|--------------------------------|
| **Physics**    | Cosmic laws, nature of matter  | Relativity, quantum mechanics, origin of the universe |
| **Biology**    | Life phenomena, evolution      | DNA structure, theory of evolution, ecosystems |
| **Astronomy**  | Cosmic observation, star evolution | Black holes, galaxies, solar system formation |
| **Chemistry**  | Material changes, molecular structure | Periodic table, chemical reactions, molecular biology |
| **Earth Science** | Geological changes, climate evolution | Plate tectonics, ice ages, paleontology |

### Principles of Knowledge Explanation

| Element        | Requirement                         |
|----------------|-----------------------------------|
| **Accuracy**   | All scientific facts must be accurate, citing authoritative sources |
| **Hierarchy**  | From simple to complex, step by step |
| **Analogy**    | Use familiar things to explain unfamiliar concepts |
| **Visualization** | Use descriptive language to help readers imagine |

---

## 6. Conflict Design

### Conflict Formula
```
Popular Science Conflict = Scientific Problem (Objective Difficulty) + Academic Debate (Difference of Opinion) + Human Test (Moral Dilemma)
```

### External Conflict (Mainline)

| Conflict Type      | Specific Methods                   | Examples                                  |
|--------------------|----------------------------------|-------------------------------------------|
| **Technical Difficulties** | Experiment conditions limited / observation means insufficient | Lack of sufficiently precise instruments to observe atoms |
| **Data Contradictions**    | Observations inconsistent with theoretical predictions | Mercury’s perihelion advance contradicting Newtonian mechanics |
| **Theoretical Bottlenecks** | Existing theories cannot explain phenomena | Conflict between constant speed of light and absolute spacetime |
| **Resource Limitations**   | Funding shortages / time pressure / outdated equipment | Penicillin production during wartime material shortages |

### Internal Conflict (Subplot)

| Conflict Type      | Design Methods                    |
|--------------------|---------------------------------|
| **Academic Debate** | Competition among different theories and interpretations |
| **Priority Disputes** | Who discovered first, whose contribution is greater |
| **Ethical Dilemmas** | Moral boundaries in scientific research |
| **Era Constraints** | Traditional views blocking new ideas |

### Conflict Progression Levels
```
Level 1: Scientific Problem (The problem to be solved)
    ↓
Level 2: Method Dispute (Disagreement on how to solve it)
    ↓
Level 3: Cognitive Revolution (Change in worldview)
```

---

## 7. Foreshadowing Management

### Foreshadowing Carriers (Popular Science Specific)

| Carrier Type       | Examples                                    |
|--------------------|---------------------------------------------|
| **Anomalous Data**  | Unexplainable experimental results / observed anomalies |
| **Historical Clues** | Previous research / hints in old literature |
| **Accidental Observations** | Seemingly unrelated discoveries / lab accidents |
| **Theoretical Contradictions** | Flaws or inconsistencies in existing theories |

### Principles of Foreshadowing Setup

| Stage             | Methods                                                                                      |
|-------------------|----------------------------------------------------------------------------------------------|
| **Planting**      | Naturally integrate into scientific narrative without emphasis<br>Example: "Fleming noticed a strange phenomenon in the petri dish but did not investigate deeply at the time."<br>Example: "Wilkins thought some blurry patterns on the X-ray photo might be a helical structure." |
| **Payoff**        | Reveal significance at key moments<br>Example: That overlooked phenomenon ultimately led to the discovery of antibiotics |

### Common Foreshadowing Designs

**Experimental Foreshadowing**:
```
Planting: An experiment produced an unexpected result but was considered contamination  
Payoff: Later it was found to be the first appearance of a new phenomenon
```

**Character Foreshadowing**:
```
Planting: A scientist is particularly persistent in a certain direction  
Payoff: His persistence stems from an important observation in youth
```

**Theoretical Foreshadowing**:
```
Planting: Existing theory has a small imperfection  
Payoff: This imperfection foreshadows the birth of a new theory
```

---

## 8. Chapter Style Design (Popular Science Specific)

### Chapter Title Style

Popular science titles should be **clear, attractive, and imply the theme**:

| Element          | Method                                                                                     |
|------------------|--------------------------------------------------------------------------------------------|
| **Title Style**  | Concise and clear, revealing the theme<br>Examples: "Chapter 1: The Contaminated Petri Dish"<br>"Chapter 3: The Inspiration of the Double Helix"<br>"Chapter 5: The Discovery That Changed the World" |
| **Chapter Opening** | Start with vivid scenes or thought-provoking questions<br>Examples: "If not for that accidental discovery that morning, humanity might have waited half a century longer to defeat infections."<br>"The secret of DNA was hidden in a blurry X-ray photo." |
| **Chapter Ending** | Knowledge summary or suspense hook<br>Examples: "But the real challenge was just beginning—how to prove this bold hypothesis?"<br>"This discovery would completely change our understanding of life." |

### Dialogue Design (Core to Popular Science)

Popular science dialogues should be **natural, knowledge-rich, and demonstrate scientific thinking**:

**Good Dialogue Example**:
```
"Look at this photo," Wilkins pointed at the X-ray diffraction image, "what do these regular patterns mean?"  
Watson stared at the blurry spots, suddenly his eyes lit up: "A helix! It’s a helical structure!"  
"One strand or two?" Crick asked the crucial question.  
"If two," Watson began sketching on paper, "then they must be complementary—A pairs with T, G pairs with C. This explains Chargaff’s rules."  
"In that case," Crick’s voice brimmed with excitement, "the replication mechanism is self-evident!"
```

**Poor Dialogue Example**:
```
"We discovered the structure of DNA."  
"Great."  
"Yes, it’s important."
```

### Knowledge Explanation (Popular Science Feature)

Should be **clear, vivid, and interesting, demonstrating scientific thinking**:

**Good Explanation**:
```
The DNA double helix structure is like a twisted ladder. The two vertical rails are sugar and phosphate molecules, while the rungs are base pairs—adenine (A) always pairs with thymine (T), guanine (G) always pairs with cytosine (C). This strict pairing rule is no accident. It means if you know the sequence of one strand, you can infer the other. This is the secret of life’s replication—each strand serves as a template for the other.
```

**Poor Explanation**:
```
DNA is composed of bases, sugar, and phosphate, forming a double helix structure with genetic functions.
```

### Rhythm Control (Core to Popular Science)

**Rhythm Formula**:
```
500 words = 1 knowledge point explanation OR 1 story plot advancement OR 1 demonstration of scientific thinking
```

Each scene must include: clear knowledge point + vivid narration + driving force

---

## 9. Knowledge Progression (Exclusive to Popular Science)

### Five-Stage Knowledge Method
```
Raise question → Exploration process → Key discovery → Verification and confirmation → Impact and outlook
```

| Stage            | Word Count Ratio | Key Events                      | Knowledge Depth          |
|------------------|------------------|--------------------------------|-------------------------|
| **Raise Question** | 10-15%           | Present scientific problem, stimulate curiosity | ★☆☆☆☆                   |
| **Exploration Process** | 20-25%           | Show research methods, spread scientific spirit | ★★☆☆☆                   |
| **Key Discovery** | 25-30%           | Present discovery process, explain scientific principles | ★★★☆☆                   |
| **Verification and Confirmation** | 20-25%           | Show scientific rigor, refine theory | ★★★★☆                   |
| **Impact and Outlook** | 15-20%           | Reveal significance, provoke reflection | ★★★★★                   |

### Knowledge Presentation Techniques

**Stepwise Progression**:
```
Surface question: Why does this phenomenon occur?  
Deeper question: What is the mechanism behind the phenomenon?  
Core question: What essential law does this reveal?  
Ultimate question: What does this mean for our understanding of the world?
```

**Multiple Perspectives**:
```
Scientific perspective: Scientific explanation of the phenomenon  
Historical perspective: Era background of the discovery  
Humanistic perspective: Meaning to humanity  
Philosophical perspective: Impact on cognition
```

---

## 10. Common Popular Science Patterns

### Pattern A: Discovery - Verification - Impact  
**Structure**:  
- Qi: Raise scientific question or show unknown phenomenon  
- Cheng: Exploration process, attempts and setbacks  
- Zhuan: Key discovery, sudden enlightenment  
- He: Verification and confirmation, outlook on impact

### Pattern B: Biographical  
**Structure**:  
- Qi: Scientist’s early life and research start  
- Cheng: Challenges and persistence in research  
- Zhuan: Major breakthrough and historical moment  
- He: Achievements, impact, and scientific spirit

### Pattern C: Scientific Suspense  
**Structure**:  
- Qi: Present scientific puzzles or anomalies  
- Cheng: Layered reasoning, hypothesis elimination  
- Zhuan: Truth revealed, principle explained  
- He: Knowledge summary, provoke thought

### Pattern D: Historical Evolution  
**Structure**:  
- Qi: Show historical starting point of scientific cognition  
- Cheng: Theory evolution, cognitive progress  
- Zhuan: Key turning points, paradigm shifts  
- He: Contemporary cognition, future outlook

---

**【Special Reminder】**  
The key to success in popular science documentary:  
1. The first 500 words must establish a scientific scene and stimulate curiosity  
2. Every 1000 words must introduce new knowledge or advance the story  
3. Knowledge explanations must be clear and accessible, using analogies and stories  
4. Scientific facts must be accurate and well-sourced  
5. The ending should be inspiring and stimulate readers’ desire to explore