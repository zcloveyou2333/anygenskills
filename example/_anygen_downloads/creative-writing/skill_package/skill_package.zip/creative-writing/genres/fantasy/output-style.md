---
name: xuanhuan-output-style
description: Output style for xuanhuan cultivation novels, with straightforward and refreshing language, tight and intense pacing, dense and clear points of satisfaction, and powerful boasting and face-slapping. A fusion of Tian Can Tu Dou’s passionate fluency and Wo Chi Xi Hong Shi’s realm upgrading.
---

# Writing Style Principles
- Straightforward and refreshing: concise and brisk language, no dragging, direct points of satisfaction
- Tight pacing: fast plot progression, no filler, every paragraph meaningful
- Powerful boasting: boastful lines must be domineering, face-slapping must be ruthless and satisfying
- Clear realms: cultivation system is clear, strength comparison obvious at a glance
- Passionate and intense: battles must be fiery, breakthroughs satisfying, face-slapping ruthless
- Satisfaction first: everything serves reader’s enjoyment, no literary obscurity
- Integrated outline: chapter outlines are categorical info, not narrative order; during creation info should be reorganized by event progression, never copied block by block; story should flow naturally, background info integrated into narration

## Fusion of Tian Can Tu Dou and Wo Chi Xi Hong Shi Styles

### Tian Can Tu Dou Style Elements
- **Passionate and refreshing**: tight pacing, dense points of satisfaction, irresistible to readers
- **Face-slapping boasting**: classic broken engagement humiliation, three-year challenge face-slapping, highly satisfying
- **Cultivation upgrading**: clear realm system, every breakthrough satisfying
- **Exotic fire system**: setting of heavenly materials and earthly treasures, fun of collecting and nurturing
- **Thirty years east, thirty years west**: classic comeback lines, never underestimate a poor youth

### Wo Chi Xi Hong Shi Style Elements
- **Clear realms**: clear ranking system, obvious strength comparison
- **Progressive scale**: from Earth to universe, from weak to invincible step by step
- **Law comprehension**: exploration and understanding of the essence of power
- **Data presentation**: showing strength growth with specific numbers and comparisons
- **Passionate struggle**: protagonist relies on effort and talent, not luck

## Specific Behaviors

### When Writing Dialogue
- **Straightforward and refreshing**: xuanhuan characters speak directly, no beating around the bush
  - ✅ "A mere Dou Ling dares to be presumptuous before me?"
  - ❌ "With your strength, you might not be suitable to say such things in front of me..."
- **Powerful boasting**: key moments’ boastful lines must be domineering
  - ✅ "Thirty years east, thirty years west, never underestimate a poor youth!"
  - ❌ "I will try hard to become stronger..."
- **Ruthless suppression**: villains’ suppression must be harsh, protagonist’s face-slapping satisfying
  - ✅ "Xiao Yan, you are a waste, unworthy to be my Nalan Yanran’s husband. I withdraw this engagement."
  - ❌ "I think we’re not suitable, let’s break up."
- **Forceful response**: protagonist’s reply must have momentum, planting seeds for future face-slapping
  - ✅ "Today’s humiliation will be repaid a thousandfold! Three-year challenge, I’m waiting for you!"
  - ❌ "Alright, I understand."

### When Writing Description
- **Realm data visualization**: show strength with specific realms and data
  - ✅ Dou Qi inside his body surged wildly, a halo formed at his dantian. "Dou Qi stage seven, breakthrough!" Xiao Yan suddenly opened his eyes, a powerful aura burst from him.
  - ❌ He became stronger.
- **Power visualization**: let readers "see" the power
  - ✅ Azure flames danced in his palm, the scorching heat distorting the air. Within three zhang, plants withered instantly, cracks appeared on the ground.
  - ❌ His flames were very powerful.
- **Contrast and disparity**: use contrast to show growth
  - ✅ Three years ago, he was a mocked waste with Dou Qi stage three. Three years later, he reached the peak of Great Dou Shi, able to shatter boulders with one palm!
  - ❌ He is stronger than before.
- **Direct satisfaction**: no long buildup, deliver satisfaction directly
  - ✅ "Dou Shi, breakthrough!" Aura surged, pressure swept the scene, everyone’s face changed in shock.
  - ❌ He felt he was about to break through, then prepared for a long time...

### When Writing Psychological Activity
- **Unyielding will**: show protagonist’s pride and unwillingness
  - ✅ Xiao Yan clenched his fists, nails piercing his palms bleeding. Today’s humiliation, he would never forget! Nalan Yanran, three-year challenge, I will definitely defeat you!
  - ❌ He felt a bit sad.
- **Cultivation determination**: show protagonist’s effort and ambition
  - ✅ He gritted his teeth, absorbing the surrounding spiritual energy crazily. Not enough, still not enough! He must become stronger, strong enough to be admired by all!
  - ❌ He decided to cultivate well.
- **Confident boasting**: appropriate confidence and domineering attitude
  - ✅ So what if I’m a Dou Wang? Once I break through to Dou Zong, I can suppress with a flick of my hand!
  - ❌ Dou Wang is strong, I don’t know if I can beat him.
- **Revenge obsession**: clear goals and motivation
  - ✅ Soul Hall, what you owe me, I will collect every penny. My father’s revenge, I will repay!
  - ❌ I want revenge.

### When Writing Cultivation Scenes
- **Breakthrough must be satisfying**: breakthroughs are key satisfaction points, write them fiery
  - ✅ Dou Qi in his dantian spun wildly, halos formed one after another. "Boom!" A loud explosion, the shackles finally broke! Dou Shi, breakthrough! A powerful aura burst from Xiao Yan, azure flames swirling around him like the fire god’s descent.
  - ❌ He broke through to Dou Shi.
- **Refining treasures must be detailed**: refining heavenly materials and earthly treasures must have process
  - ✅ Azure flames slowly merged into the dantian, the scorching heat drenched Xiao Yan in sweat. He bit his teeth tightly, tearing pain came from his meridians. "Refine it for me!" a low roar, the Blue Lotus Earth Heart Fire was finally subdued, becoming the source of his power.
  - ❌ He swallowed the exotic fire and became stronger.
- **Cultivation hardship must be shown**: show the hardship of cultivation, breakthroughs are satisfying
  - ✅ Three months, a full three months, he didn’t leave the training room. His clothes were soaked with sweat and dried repeatedly, forming a layer of salt residue. But his eyes grew brighter—Burning Technique, second layer, mastery!
  - ❌ He cultivated for three months and learned the technique.
- **Insight must be enlightening**: not mysticism, but reasonable comprehension
  - ✅ Water dripping wears through stone, not because of water’s power, but persistence. Cultivation is the same, day after day accumulation will eventually form an overwhelming force!
  - ❌ He suddenly had a breakthrough.

### When Writing Battle Scenes
- **Clear realm gap**: let readers clearly see strength comparison
  - ✅ Dou Ling vs Dou Shi, a full major realm gap! Normally, Dou Ling could kill Dou Shi in one move. But Xiao Yan was different, he had exotic fire!
  - ❌ The opponent was stronger than him.
- **Powerful move descriptions**: let readers feel the power
  - ✅ "Buddha’s Wrath Fire Lotus!" Azure-white flames intertwined and spun, forming a beautiful yet deadly fire lotus. The terrifying energy trembled the air. The lotus shot out, melting the ground into magma wherever it passed!
  - ❌ He used a very powerful Dou technique.
- **Boasting in battle**: battle is the best stage for boasting
  - ✅ "With this little strength, you want to kill me?" Xiao Yan sneered, azure flames dancing in his palm, "Let me show you real power!"
  - ❌ He defeated the opponent.
- **Reversal must be foreshadowed**: cross-level defeat must be reasonable
  - ✅ Everyone thought Xiao Yan was doomed, after all the opponent was peak Dou Wang. But they didn’t know Xiao Yan had a trump card—Bone Spirit Cold Fire, ranked fourth on the exotic fire list!
  - ❌ He suddenly became stronger and defeated the opponent.

### When Writing Face-slapping Scenes (Core Satisfaction)
- **Face-slapping must be ruthless and satisfying**: this is the core satisfaction of xuanhuan
  - ✅ "Impossible! This can’t be!" Nalan Yanran retreated in terror, "How could you be a Dou Wang?!" "Thirty years east, thirty years west." Xiao Yan smiled faintly, "I said I’d make you regret it. Now, do you?"
  - ❌ He defeated Nalan Yanran, she was surprised.
- **Onlookers’ shock must be present**: use crowd shock to highlight
  - ✅ The whole scene was silent. Everyone’s eyes were wide, unable to believe what they saw. That once waste actually defeated a Dou Wang in one move! Is this... real?!
  - ❌ Everyone thought it was impressive.
- **Former suppressors’ reaction**: key to face-slapping
  - ✅ "Young Master Xiao Yan, spare me! I was blind back then, please show mercy..." The guard who once mocked Xiao Yan now knelt trembling. Xiao Yan coldly looked at him: "Begging now? Too late."
  - ❌ Those who mocked him apologized.
- **Face-slapping lines must be domineering**: make readers extremely satisfied
  - ✅ "Back then you ignored me, now I make you unreachable!"
  - ❌ "I’m stronger than you now."

### When Handling Pacing
- **Establish waste setting within first 500 words**: quickly get into state
  - ✅ Xiao Yan, young master of the Xiao family, once a genius, now a waste. Three years ago, he was Dou Qi stage nine, hailed as a once-in-a-century genius. Three years later, his Dou Qi mysteriously disappeared, becoming a laughingstock.
  - ❌ This story takes place in a cultivation world... (long worldview introduction)
- **Every chapter must have satisfaction progression**: no filler, no dragging
  - ✅ This chapter, Xiao Yan breaks through to Dou Shi, defeats mocking clansmen, gains clan leader’s recognition.
  - ❌ This chapter, Xiao Yan cultivates in his room the whole chapter, nothing happens.
- **Relaxed but satisfaction-focused**: xuanhuan doesn’t need too much buildup
  - ✅ Cultivate three months (briefly) → Breakthrough Dou Shi (detailed) → Challenge clan genius (face-slapping satisfaction)
  - ❌ Cultivate three months (detailed for three chapters) → Breakthrough Dou Shi (one sentence)

### When Ending Chapters
- **Leave satisfaction cliffhanger**: make readers look forward to next chapter’s satisfaction
  - ✅ Xiao Yan curled a cold smile: "Nalan Yanran, three-year challenge, I’ll make you realize breaking the engagement was the worst decision of your life."
  - ❌ This chapter just ended.
- **Create anticipation**: next chapter has bigger satisfaction
  - ✅ Exotic fire ranked third, Blue Lotus Earth Heart Fire, right before his eyes. Once refined, Xiao Yan’s strength will surge again!
  - ❌ He will continue cultivating.
- **Boastful ending**: end with domineering words or actions
  - ✅ "Dou Wang? In my eyes, just so-so." Xiao Yan turned and left, leaving behind shock and terror.
  - ❌ He left.

## Language Taboos

### Absolutely Forbidden
- ❌ Literary-style expression: "It’s as if I saw the meaning of life..."
- ❌ Dragging buildup: three chapters of buildup, no satisfaction
- ❌ Awkward boasting: "Everyone here is trash" (too childish)
- ❌ Protagonist too saintly: merciful to enemies
- ❌ Face-slapping not ruthless: opponent surrenders easily, no shock
- ❌ Realm confusion: saying Dou Shi is strong then weak

### Must Achieve
- ✅ Language straightforward and smooth, no dragging
- ✅ Dense satisfaction, every 1000 words must have satisfaction
- ✅ Clear realm system, obvious strength comparison
- ✅ Boasting with measure, domineering but not awkward
- ✅ Ruthless face-slapping, make readers extremely satisfied
- ✅ Tight pacing, no filler or dragging

## Special Reminders

### Short Story Special Requirements
- **Waste setting must be strong**: the worse the waste, the better the face-slapping
- **High satisfaction density**: enough satisfaction within 5 chapters
- **Concentrated face-slapping**: don’t scatter, focus on key characters
- **Breakthroughs must be satisfying**: every breakthrough is a satisfaction point, write in detail

### Perspective Suggestions
- **Third-person omniscient**: most common, convenient to show crowd shock
- **Third-person protagonist perspective**: follow protagonist, enhance immersion
- **Avoid first-person**: xuanhuan web novels not suitable for first person

### Xuanhuan Traits Control
- **Satisfaction ≠ mindless**: protagonist can cheat but must be reasonable
- **Strong ≠ invincible**: must have stronger enemies for anticipation
- **Boasting ≠ childish**: domineering but not awkward
- **Face-slapping ≠ massacre**: ruthless but not overly bloody

### Realm Control
- **Realms must be clear**: let readers see who is strong or weak at a glance
- **Breakthroughs must be difficult**: too easy breaks no satisfaction
- **Cross-level must be reasonable**: protagonist can cross level but must have reasons (exotic fire/technique/bloodline)
- **Realm gap must be clear**: let readers know how much protagonist has grown

### Satisfaction Control
- **Boasting must have buildup**: first suppressed, then boasting is satisfying
- **Face-slapping must have contrast**: past humiliation vs current strength
- **Breakthrough must have accumulation**: not random breakthrough, must have cultivation process
- **Gains must have cost**: exotic fire not free, must have refining pain

## Core Philosophy

Writing xuanhuan cultivation novels, remember three keywords:
1. **Satisfaction**: everything serves reader’s enjoyment, dense satisfaction points, tight pacing
2. **Passion**: fiery and intense, cultivation must be fiery, battles must be fiery, face-slapping must be fiery
3. **Boasting**: powerful boasting, ruthless face-slapping, shocking those who once looked down

**Most important**: xuanhuan cultivation is the purest form of satisfying fiction. Readers want the thrill of a waste’s comeback, face-slapping boasting, and cultivation upgrading. No literary obscurity, no dragging buildup, deliver satisfaction directly, let readers enjoy to the fullest. Grab readers from the start, make them unable to stop, chapter after chapter. This is the charm of xuanhuan cultivation.

## Classic Satisfaction Formulas

### Broken Engagement Formula
```
Broken engagement humiliation → chance encounter gains power → hard cultivation → three-year challenge → face-slapping the breaker → fame and fortune
```

### Waste Comeback Formula
```
Lowest in family → receive inheritance → strength explosion → family competition → shock the crowd → become pride
```

### Rebirth Revenge Formula
```
Murdered in past life → reborn → prophetic advantage → rapid strength → slay enemies → rewrite fate
```

### Boasting Face-slapping Formula
```
Looked down upon → hide strength → burst at critical moment → shock everyone → ruthless face-slapping → hold head high
```

## Realm Breakthrough Description Templates

### Small Realm Breakthrough (e.g., Dou Qi stage 3 → 4)
```
Dou Qi in the dantian spun wildly, circle after circle, faster and faster. "Crack!" Something seemed to shatter, shackles finally broken. "Dou Qi stage four, breakthrough!" Xiao Yan opened his eyes, a gleam flashed in them.
```

### Large Realm Breakthrough (e.g., Dou Zhe → Dou Shi)
```
Dou Qi in the dantian surged wildly, gathering into a halo at the chest. One, two, three... nine halos formed in sequence! "Boom!" A loud explosion, nine halos shattered, turning into endless energy nourishing the body. A more solid halo slowly formed at the dantian. "Dou Shi, breakthrough!" A powerful aura burst from Xiao Yan, pressure sweeping the scene. Everyone’s faces changed in shock—this... is the aura of a Dou Shi!
```

### Enlightenment Breakthrough
```
Xiao Yan stared at the waterfall, suddenly his heart moved. Water dripping wears through stone, not because of water’s power, but persistence! Dou Qi cultivation is the same, no complicated techniques needed, just day after day accumulation! "Boom!" At this moment, a flash of inspiration struck Xiao Yan’s mind, the bottleneck that troubled him for days shattered. "So that’s it..." he murmured, his aura rising step by step. Dou Shi six stars, seven stars, eight stars... nine stars! One breath broke through three stars!
```

## Face-slapping Scene Description Templates

### Strength Face-slapping
```
"Dou Shi? Xiao Yan, you waste, actually broke through to Dou Shi?" Opponent shocked.
"Dou Shi?" Xiao Yan curled a cold smile, aura bursting, "Who said I’m a Dou Shi?"
"This... this is... Great Dou Shi’s aura! Impossible! How could you be a Great Dou Shi!" Opponent retreated in terror.
"Nothing is impossible." Xiao Yan said calmly, "Back then you ignored me, now I make you unreachable."
```

### Identity Face-slapping
```
"Waste is waste, even with some luck, you can’t change your lowly origin."
"Lowly?" Xiao Yan sneered, a glow flashed in his hand, an ancient token appeared, "Know this?"
"This... this is... Xiao clan token! You... you are the direct line of the Xiao clan!" Opponent’s pupils shrank.
"Now you know who’s really lowly?"
```

### Overwhelming Strength Face-slapping
```
"With this little strength, you want to challenge me?" Opponent sneered.
Xiao Yan said nothing, slowly raised his palm. Azure flames danced in his palm, the scorching heat distorting the air.
"Exotic... exotic fire!" Opponent’s face changed drastically, "How could you have exotic fire!"
"There are too many things you don’t know." Xiao Yan smiled faintly, "Blue Lotus Earth Heart Fire, go."
Flames surged, instantly engulfing the opponent. Screams sounded, then quickly vanished.
The whole scene was silent.
```
