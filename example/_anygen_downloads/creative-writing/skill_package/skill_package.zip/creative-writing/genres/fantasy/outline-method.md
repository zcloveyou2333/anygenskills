---
name: xuanhuan-outline-method
description: Methodology for creating outlines of xuanhuan cultivation short stories, including core synopsis extraction, prologue design, narrative structure planning, and character shaping guidance. Integrates the essence of fast-paced storytelling from Tian Can Tu Dou and Wo Chi Xi Hong Shi.
---

## Q1-Q3 Question Templates

### Q1: Core Idea
**Q1: Core idea and appeal of the story [Brief description]**  
Please describe your story idea in one or two sentences.

### Q2: Core Conflict
**Q2: Core conflict [Brief description]**  
Please describe the novel’s core contradiction or main conflict in one sentence  
(e.g., underdog’s counterattack to slap down powerful enemies and reach the peak, sect disciples uncovering ancient secrets, fate choices in the war between immortals and demons, reborn protagonist rewriting destiny using memories from a past life, etc.)

### Q3: Story Tone
**Q3: Story tone [Choose one]**  
- Hot-blooded爽文·Slapdown and counterattack (underdog rise, showing off and slapping down, constantly overpowered)  
- Xianxia Romance·Fated for Three Lifetimes (immortal-mortal love, reincarnation fate, deep and unwavering affection)  
- Sect Rivalry·Peak Showdown (cultivation upgrade, sect conflicts, domination)  
- Primordial Myth·Creation of Heaven and Earth (the way is simple, chaos begins, sage’s game)  
- Or briefly describe your story tone

## Chapter File Naming Rules  
Filename format: `{STORY_NAME}-{NN}.md`  
Example: `斗破苍穹-01.md`, `斗破苍穹-02.md`

---

# Methodology for Creating Xuanhuan Cultivation Outlines

## Overall Orientation

Xuanhuan cultivation novels emphasize "**cultivation counterattack and hot-blooded爽感**," focusing on realm breakthroughs, slapping down rivals, and passionate struggle.

**Core Reference Works**: "Battle Through the Heavens," "Martial Movement of the Universe," "Coiling Dragon," "Swallowed Star"  
- Learn from "Battle Through the Heavens" the essence of "thirty years east of the river, thirty years west of the river, never underestimate a poor youth" counterattack slapdown  
- Learn from "Martial Movement" the hot-blooded growth and cultivation breakthrough of a bottom-tier youth  
- Learn from "Coiling Dragon" the clear realm system and爽感 of power upgrades  
- Learn from "Swallowed Star" the progressive grand scale from Earth to the universe

**Core Principles**:  
- Focus on爽点 topics (underdog counterattack, showing off and slapping down, cultivation breakthroughs, talent awakening)  
- Pursue "reading pleasure": tight pacing, dense爽点, hot-blooded excitement  
- Balance cultivation and emotion, but **do not stray from爽文 logic and slapdown rhythm**  
- Use realm breakthroughs, chance awakenings, and showing off to drive plot, **maintain fast-paced爽文 tone**  
- Keep web novel fluent style: straightforward, brisk,爽点 clear

---

## Overall Creation Formula
```
Xuanhuan short story = underdog setting + chance awakening + cultivation breakthrough + slapdown counterattack + domination ending
```

---

## 1. Core Synopsis Writing

### Formula
```
Core synopsis = underdog identity/setting + counterattack opportunity + hot-blooded theme
```

### Writing Points
| Element | Requirement | Correct Example | Incorrect Example |
|---------|-------------|-----------------|------------------|
| **Underdog identity** | Clear + contrast | "Rejected fiancé useless young master", "Genius who lost斗气" | "A cultivator" |
| **Counterattack opportunity** | Chance + awakening | "Devouring异火 to regain power", "Awakening ancient bloodline" | "Encountered a chance" |
| **Hot-blooded theme** | Clear爽点 | "Thirty years east of the river, thirty years west of the river, never underestimate a poor youth" | "Finally became strong" |

### Excellent Examples
- "Once a genius, but lost斗气 overnight, became the family’s useless trash, publicly rejected by his fiancée. Three years later, he devours异火 to rebuild power, rising against the heavens as an underdog, crushing all who mocked him."  
- "Lin Dong, a boy from Stone Village with mediocre talent, ranked last in the family competition. Yet in a chance encounter, he inherits ancient runes, beginning his cultivation path, rising from bottom to符祖."  
- "A powerful figure in a past life, betrayed and killed. Reborn with memories and cultivation experience, he crushes geniuses with absolute advantage, rewriting fate."

---

## 2. Prologue Writing

### Formula
```
Prologue = cultivation world opening + underdog identity setting + counterattack suspense hook
```

### Writing Points
| Element | Function | Writing Method |
|---------|----------|----------------|
| **First sentence** | Establish cultivation atmosphere | Directly show: cultivation realm/martial arts/sect world |
| **Middle part** | Explain underdog predicament | Use contrast and suppression to quickly position (once a genius vs now a trash) |
| **Last sentence** | Create counterattack suspense | Throw out awakening moment/chance arrival/rebirth return |

### Incorporating爽点 Topics

The prologue must touch core爽点 of xuanhuan cultivation:

| Topic Type | Specific Direction |
|------------|--------------------|
| **Underdog counterattack** | Genius falls → chance rise, looked down upon → slapdown showing off |
| **Rejected fiancé slapdown** | Rejected and humiliated → cultivation return, thirty years east/west |
| **Rebirth revenge** | Past life harmed → return in this life, rewrite fate and crush enemies |
| **Talent awakening** | Mediocre youth → awaken bloodline, trash → prodigy |

**Goal**: Make readers feel "This underdog is about to counterattack" expectation (爽点 immersion)

### Example Comparison
| Type | Content |
|------|---------|
| ✅ **Correct** | "斗气 continent, the strong rule. In the萧 family mansion, once a genius youth萧炎 is now mocked by all as trash. Three years ago, he was the brightest star of the family, condensing斗气 at nine, hailed as a century’s genius. Yet overnight, his斗气 mysteriously vanished, falling from the clouds to the valley. Today,纳兰嫣然 personally came, tore the marriage contract in front of the clan. '萧炎, you are trash, unworthy to be my husband. I cancel this marriage.' Humiliation, mockery, disdain. The youth clenched his fist, nails piercing his palm, blood seeping out. He raised his head, eyes burning with unyielding flame: 'Thirty years east of the river, thirty years west of the river, never underestimate a poor youth!'" |
| ❌ **Incorrect** | "There was a boy who could cultivate, later became strong, started revenge..." |

---

## 3. Narrative Structure Design (Qi Cheng Zhuan He 起承转合)

### 【Qi 起】Chapter 1: Underdog Setting and Humiliation (2000-3000 words)

#### Writing Focus
```
Qi = cultivation world display + underdog protagonist appearance + humiliation suppression + chance opportunity
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Worldview display** | Establish cultivation atmosphere within first 500 words | First paragraph shows: realm system/cultivation culture/strong rule |
| **Underdog appearance** | Quickly show protagonist’s "trash" and "humiliation" | Protagonist appears within 300 words<br>Appearance method: mocked/suppressed/humiliated |
| **Humiliation suppression** | Show protagonist’s predicament and unwillingness | Rejected fiancé humiliation/family cold eyes/genius turned trash contrast |
| **Chance opportunity** | Drive counterattack start | Devour异火/inherit legacy/rebirth return/awaken bloodline |

#### Xuanhuan Cultivation Specific Techniques
- **Realm contrast**: Use realm gap to show protagonist’s weakness and enemy’s strength  
- **Dense suppression**: Must have enough suppression at start to build energy for later slapdown  
- **Reasonable chance**: Chance must be foreshadowed, not totally random  
- **斗气 culture**: Quickly establish "strong rule, weak are grass" worldview

#### Taboos
- ❌ Long setting exposition without plot progression  
- ❌ Protagonist appears strong immediately, no contrast  
- ❌ Insufficient suppression, no爽感 in later slapdown  
- ❌ Chance too abrupt, no foreshadowing

---

### 【Cheng 承】Chapters 2-3: Cultivation Breakthrough and First Slapdown (2000-3000 words each)

#### Chapter 2 Writing Focus
```
Chapter 2 = cultivation awakening + power surge + small test + first show of edge
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Cultivation awakening** | Power control after chance | Refine异火/cultivate功法/absorb legacy<br>Show cultivation hardship and gains |
| **Power surge** | Fast realm breakthrough |爽感 of breaking through layers of realms<br>Use quantified data to show power growth (e.g.,斗气 stage 3 → stage 7) |
| **Small test** | First display of power | Defeat those who suppressed him/shock onlookers |
| **First show of edge** | Plant bigger conflict | Attract stronger attention/anger bigger enemies |

#### Chapter 3 Writing Focus
```
Chapter 3 = encounter strong enemy + perilous trial + breakthrough again + showing off slapdown
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Encounter strong enemy** | Difficulty upgrade | Stronger opponent/more dangerous conspiracy/bigger crisis |
| **Perilous trial** | Growth between life and death | Secret realm exploration/magical beast forest/ancient ruins |
| **Breakthrough again** | Explosion under pressure | Realization between life and death/devour to gain power/bloodline awakening |
| **Showing off slapdown** |爽感 of defeating strong enemy | Counterkill/crush/shocking showing off moment |

---

### 【Zhuan 转】Chapter 4: Peak Showdown and Extreme Explosion (2000-3000 words)

#### Writing Focus
```
Zhuan = strongest opponent + life and death crisis + extreme explosion + earth-shattering counterattack
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Strongest opponent** | Encounter the strongest enemy in this story | Sect prodigy/family strong/fiancée herself |
| **Life and death crisis** | Protagonist trapped in desperate situation | Huge power gap/surrounded/deadly predicament |
| **Extreme explosion** | Reveal trump cards | Secret technique/bloodline/legacy/true power of异火 |
| **Earth-shattering counterattack** | Stunning victory by the weak over the strong | Cross-level defeat/one move kill/shock everyone |

#### Xuanhuan Cultivation Specific Techniques
- **Realm crushing reversal**: Enemy realm high but crushed by protagonist for爽感 contrast  
- **Showing off quotes**: Say showing off lines during battle (e.g., "Ants dare provoke the true dragon?")  
- **Trump card reversal**: Let enemy think victory assured, protagonist reveals trump card  
- **Whole scene shock**: Use onlookers’ shock to highlight protagonist’s power

#### Taboos
- ❌ Enemy too weak, no threat  
- ❌ Protagonist wins too easily, no explosion feeling  
- ❌ Over-the-top showing off, awkward  
- ❌ Cross-level too ridiculous, loses credibility

---

### 【He 合】Chapter 5: Domination and New Journey Begin (2000-3000 words)

#### Writing Focus
```
He = fame and establishment + slapdown revenge + power proof + bigger journey
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Fame and establishment** | From trash to prodigy | Family recognition/sect attention/fame spreads |
| **Slapdown revenge** | Severely slapdown those who mocked before | Fiancée regrets/mocker terrified/oppressor submits |
| **Power proof** | Speak with power | Realm breakthrough/defeat strong enemy/gain recognition |
| **Bigger journey** | Open broader world | Go to stronger sect/bigger stage/higher realm |

#### Xuanhuan Cultivation Ending Types
| Type | Features | Suitable Scenes |
|------|----------|-----------------|
| **Slapdown perfect ending** | Severely slapdown all who looked down, feel proud | Rejected fiancé flow, underdog counterattack flow |
| **Journey beginning type** | King of local, go to bigger world | Progressive grand scale stories |
| **Revenge success type** | Kill enemies, avenge hatred | Rebirth revenge flow |
| **Dominate one side type** | Become local strongest, build power | Rivalry flow |

#### Taboos
- ❌ Ending too rushed, slapdown not爽 enough  
- ❌ Enemy’s fate too light, no爽感  
- ❌ Protagonist growth not obvious, no爽感 contrast  
- ❌ Too many un-slapdown people left

---

## 4. Character Shaping Methods

### Protagonist Design

| Dimension | Requirement | Correct Example | Incorrect Example |
|-----------|-------------|-----------------|------------------|
| **Underdog identity** | Clear "trash" | "斗气 disappeared genius", "useless young master" | "Ordinary person" |
| **Counterattack trait** | Unyielding "pride" | "Never bow head despite humiliation", "eyes burning with unyielding flame" | "Very insecure" |
| **Personality tags** | 2-3 distinct traits | "Fierce and decisive", "calm and wise", "loyal and righteous" | "Good person" |
| **Growth trajectory** | Transformation from trash to strong | "斗气 stage 3 →斗师→大斗师" | "Always strong" |

### Personality Specificity
```
✅ "萧炎 expressionless watched纳兰嫣然’s departing back. Others saw calm, but his clenched fist pierced his palm. Three years of humiliation, today’s rejection, all remembered. This grudge, he will repay!"  
❌ "He was angry and wanted revenge."
```

### Protagonist Archetypes (Common in Xuanhuan)

| Type | Features | Personality | Suitable Theme |
|------|----------|-------------|----------------|
| **Fallen genius** | Once genius → fallen trash | Unwilling, patient, explosive | Counterattack slapdown |
| **Underdog rise** | Always trash → chance awakening | Stubborn, hardworking, hot-blooded | Hot-blooded growth |
| **Rebirth return** | Past strong → reborn now | Mature, decisive, crushing | Rewrite fate |
| **Transmigration arrival** | Earthling → other world | Wise, unconventional | Otherworld domination |
| **Bloodline awakening** | Ordinary → awaken divine blood | Surprised, confused, growing | Talent counterattack |

### Supporting Characters Design (Xuanhuan Features)

| Type | Role | Notes |
|------|------|-------|
| **Rejected fiancé** | Create humiliation, later slapped down | Must be arrogant enough for爽感 slapdown |
| **Loyal partner** | Accompany growth, life and death | Not tool characters, have own growth |
| **Powerful mentor** | Teach功法, guide | Cannot fight for protagonist, mainly guidance |
| **Rival prodigy** | Competitor, motivate growth | Must be strong, not just villain |

### Relationship Network Design (Xuanhuan Specific)

| Element | Requirement |
|---------|-------------|
| **Hatred** | Rejected fiancé humiliation/family suppression/enemy pursuit |
| **Brotherhood** | Shared hardship/life and death/mutual achievement |
| **Romantic interest** | Unwavering/fight side by side/emotional bond |
| **Mentor** | Teach and guide/huge gratitude/direction |

---

## 5. Cultivation Elements Design

### Worldbuilding Formula
```
Xuanhuan world = realm system +功法 martial arts + power structure + heavenly materials and treasures
```

### Realm System Design (Core)

Xuanhuan cultivation must have a clear realm system, the foundation of爽感.

#### Classic Realm System Examples

**"Battle Through the Heavens" style (斗气 system)**:
```
斗之气 (stages 1-10) → 斗者 → 斗师 → 大斗师 → 斗灵 → 斗王 → 斗皇 → 斗宗 → 斗尊 → 斗圣 → 斗帝
```

**"Martial Movement" style (元力 system)**:
```
淬体境 (nine layers) → 地元境 (early/mid/late/peak) → 天元境 → 造化境 → 涅槃境 → 生死玄境 → 转轮境 → 轮回境 → 祖境
```

**"Coiling Dragon" style (warrior/mage system)**:
```
Level 1 warrior → Level 2 warrior → ... → Level 9 warrior → Holy Domain → God level (lower/mid/upper) → Main God
```

#### Realm Design Principles

| Element | Requirement |
|---------|-------------|
| **Layered** | At least 5-7 major realms, each with sub-stages |
| **Distinct** | Clear power gap between realms (e.g., one斗师 can kill 10斗者) |
| **Threshold** | Realm breakthroughs are difficult, not casual |
| **Meaningful** | Each realm corresponds to specific abilities and status |

###功法 Martial Arts Design

| Element | Requirement |
|---------|-------------|
| **Ranked** | Yellow rank/玄 rank/earth rank/heaven rank/god rank |
| **Distinctive** | Each功法 has unique abilities and effects |
| **Power description** | Clear power description (e.g., earth rank斗技 can destroy a small mountain in one strike) |
| **Cultivation difficulty** | Stronger功法 harder to cultivate, showing protagonist’s talent |

### Common功法 Types

| Type | Features | Examples |
|------|----------|----------|
| **Flame** | Overbearing, explosive, burns all | Burning Technique,异火 Devouring |
| **Thunder** | Fierce, fast, destructive | Thunder Emperor’s Manual, Thunder Might |
| **Sword Dao** | Sharp, elegant, sword气 everywhere | Ten Thousand Sword Technique, Sword Dao to Heaven |
| **Body Cultivation** | Strong body, immense strength | Diamond Body, Body Refining Technique |
| **Rune** | Mysterious, variable, sealing | Rune Ancestor Legacy, Ancient Runes |

### Heavenly Materials and Treasures Setting

| Type | Function | Examples |
|------|----------|----------|
| **异火** | Devour and refine, boost power | Azure Lotus地心火, Bone Spirit Cold Fire |
| **Spiritual herbs** | Heal, breakthrough, enhance | Grade 7 pills, Breakthrough pills |
| **Divine weapons** | Boost combat power, special abilities |玄 Heavy Ruler, Devour Heaven Demon Spear |
| **Bloodline** | Awaken talent, cross-level fight | Ancient Dragon Blood, Phoenix Bloodline |

---

## 6. Conflict Design

### Conflict Formula
```
Xuanhuan conflict = external enemies (rejected fiancé/humiliation/pursuit) + cultivation pressure (realm/resources) + showing off slapdown
```

### External Conflict (Main Line)

| Conflict Type | Specific Method | Example |
|---------------|-----------------|---------|
| **Rejected fiancé humiliation** | Rejected/mocked/suppressed | 纳兰嫣然 rejection/family cold eyes |
| **Enemy pursuit** | Past life enemy/father’s killer/treasure rival | Soul Hall pursuit/rival revenge |
| **Sect rivalry** | Sect competition/prodigy battle | Inner sect competition/genius war |
| **Secret realm treasure hunt** | Ruins exploration/fighting for chance | Ancient ruins/异火 contest |

### Internal Conflict (Side Line)

| Conflict Type | Design Method |
|---------------|---------------|
| **Cultivation bottleneck** | Realm hard to break/功法 hard to train |
| **Resource scarcity** | Need heavenly materials/pills/功法 |
| **Time pressure** | Three-year agreement/sect competition imminent |
| **Emotional entanglement** | Love interest leaves/brother betrayal |

### Conflict Progressive Layers
```
Layer 1: Humiliated and suppressed (rejected fiancé/mocked)  
    ↓  
Layer 2: Chance rise cultivation (gain power)  
    ↓  
Layer 3: Slapdown prove self (initial counterattack)  
    ↓  
Layer 4: Confront strongest enemy (final proof)  
    ↓  
Layer 5: Fame and domination (complete counterattack)
```

---

## 7.爽点 Management (Xuanhuan Exclusive)

###爽点 Types and Placement

|爽点 Type | Appearance Timing | Specific Performance |
|----------|-------------------|---------------------|
| **Showing off爽** | Chapters 2-5 | Show power to shock/say showing off lines |
| **Slapdown爽** | Chapters 3-5 | Defeat mockers/make rejected fiancé regret |
| **Upgrade爽** | Chapters 2-4 | Realm breakthrough description/power surge爽感 |
| **Gain爽** | Chapters 1-3 | Obtain chance/devour异火/inherit legacy |
| **Crush爽** | Chapters 4-5 | Weak defeat strong/cross-level kill/one move kill |

###爽点 Density Requirement
```
1000 words = 1 small爽点  
2000 words = 1 medium爽点 (e.g., realm breakthrough)  
5000 words = 1 big爽点 (e.g., slapdown rejected fiancé)
```

### Classic爽点 Quotes
```
"Thirty years east of the river, thirty years west of the river, never underestimate a poor youth!"
"Your humiliation today will be repaid a thousandfold in the future!"
"An insignificant斗灵 dares to be arrogant before me?"
"You ignored me back then, now I make you unreachable!"
```

---

## 8. Foreshadowing Management

### Foreshadowing Carriers (Xuanhuan Specific)

| Carrier Type | Example |
|--------------|---------|
| **Mysterious ring/soul** | Medicine Elder/Artifact Spirit/Predecessor’s remnant soul |
| **Ancient legacy** | Rune Ancestor legacy/Sword Dao truth/功法 fragments |
| **Identity secret** | Ancient family descendant/divine beast bloodline/foreign prodigy |
| **Enemy shadow** | Clan extermination culprit/past enemy/Soul Hall pursuit |
| **Heavenly treasures** | 异火/divine artifact/spiritual root/bloodline |

### Foreshadowing Setting Principles

| Stage | Method |
|-------|--------|
| **Planting** | Naturally integrated, not emphasized<br>Example: "That ancient black ring was the only relic left by his father."<br>Example: "Though his斗气 vanished, a strange flame seemed to sleep deep in his dantian." |
| **Reveal** | Unveiled at critical moment<br>Example: In crisis, Medicine Elder emerges from ring, teaching him pill refining and powerful功法 |

### Common Foreshadowing Designs

**Mysterious Legacy Foreshadowing**:
```
Planting: Protagonist obtains a broken功法, only first three layers  
Reveal: Later finds full version in ruins, power surges
```

**Bloodline Awakening Foreshadowing**:
```
Planting: Protagonist occasionally shows mysterious power surges in battle  
Reveal: Actually has ancient divine beast bloodline, awakens in crisis
```

**Identity Mystery Foreshadowing**:
```
Planting: Protagonist thought to be ordinary family trash young master  
Reveal: Actually descendant of ancient family, bloodline awakening shocks all
```

---

## 9. Chapter Style Design (Xuanhuan Specific)

### Chapter Title Style

Xuanhuan titles must be **bold, straightforward, with爽点**:

| Element | Method |
|---------|--------|
| **Title style** | Straightforward and powerful, hint爽点<br>Example: "Chapter 1 Rejected Humiliation"<br>Example: "Chapter 3 Devour异火"<br>Example: "Chapter 5 Slapdown纳兰" |
| **Chapter opening** | Direct to theme, fast pacing<br>Example: "萧炎 opened his eyes, a scorching power boiled in his dantian."<br>Example: "斗气 stage 3, breakthrough!" |
| **Chapter ending** |爽点 or suspense<br>Example: "He looked at纳兰嫣然’s shocked face, a cold smile curled his lips: 'Three-year agreement, I’m waiting for you.'" <br>Example: "'异火 ranked nineteenth, Azure Lotus地心火... I claim it!'" |

### Dialogue Design (Xuanhuan Core)

Xuanhuan dialogue must be **straightforward,爽快, with showing off feeling**:

**Good dialogue example**:
```
"萧炎, you are trash, unworthy to be my husband. I cancel this marriage."  
萧炎 raised his head, eyes burning with unyielding flame: "Today’s humiliation will be repaid a thousandfold. Three-year agreement, I’m waiting for you."  
"Three years?" 纳兰嫣然 sneered, "With you, a trash?"  
"Whether I’m trash, we’ll see in three years."
```

**Bad dialogue example**:
```
"I want to cancel the marriage."  
"Okay."  
"Aren’t you angry?"  
"A little."
```

### Battle Description (Xuanhuan Feature)

Must have **visual sense,爽感, and showing off**:

**Good battle description**:
```
萧炎 flipped his palm, azure flames soared, the scorching heat twisted the air.  
"This... this is异火!" the opponent retreated in terror.  
"Now you know fear? Too late."萧炎 smiled coldly, "Azure Lotus地心火, devour!"  
The azure flames lunged like a giant python, instantly engulfing the opponent. Screams rose then quickly ceased.  
The entire scene fell silent.  
Everyone stared shocked at the youth cloaked in azure flames, as if looking at a demon god.  
"Anyone else?"萧炎 glanced around, speaking calmly.  
No one dared respond.
```

**Bad battle description**:
```
He attacked with fire, the opponent was defeated. Everyone was surprised.
```

### Pace Control (Xuanhuan Core)

**Pace formula**:
```
500 words = 1 plot advancement OR 1 cultivation breakthrough OR 1 showing off slapdown
```

Each scene must have: clear goal + intense conflict +爽快 result

---

## 10. Common Xuanhuan Modes

### Mode A: Rejected Fiancé Counterattack (Reference "Battle Through the Heavens")

**Structure**:  
- Qi: Genius falls, rejected fiancé humiliation  
- Cheng: Chance gains power, hard cultivation  
- Zhuan: Three-year agreement, defeat rejected fiancé  
- He: Fame and establishment, go to bigger world

**Features**: Strongest slapdown爽感, rejection is classic humiliation, three-year agreement classic slapdown

### Mode B: Underdog Rise (Reference "Martial Movement of the Universe")

**Structure**:  
- Qi: Family bottom, looked down upon  
- Cheng: Obtain legacy, breakthrough realm  
- Zhuan: Family competition, shock all  
- He: Become family pride, start journey

**Features**: Hot-blooded growth, from bottom to top contrast

### Mode C: Rebirth Revenge (Classic Rebirth Flow)

**Structure**:  
- Qi: Past life harmed, reborn return  
- Cheng: Use past memories, quickly grow strong  
- Zhuan: Kill enemies, rewrite fate  
- He: Achieve peak not reached in past life

**Features**: Crushing爽文, protagonist has prophet advantage

### Mode D: Secret Realm Treasure Hunt (Chance Encounter Flow)

**Structure**:  
- Qi: Accidentally enter secret realm, gain chance  
- Cheng: Refine treasure, power surge  
- Zhuan: Secret realm fight, defeat prodigy  
- He: Bring chance to fame worldwide

**Features**: Focus on chance and treasure, protagonist luck maxed

---

**【Special Reminder】**  
Keys to success of xuanhuan short stories:  
1. First 500 words must establish "underdog" setting and cultivation atmosphere  
2. Every 1000 words must have爽点 advancement (showing off/slapdown/upgrade)  
3. Dialogue must be straightforward and爽快, no dragging  
4. Realm system must be clear, let readers see growth  
5. Ending must be a satisfying slapdown,爽到底  
6. Showing off must be moderate, slapdown must be fierce but not ridiculous  
7. Protagonist can be overpowered but must have foreshadowing and cost