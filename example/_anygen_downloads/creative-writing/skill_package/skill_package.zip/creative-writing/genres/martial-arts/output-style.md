---
name: wuxia-output-style
description: The output style for wuxia novels, featuring elegant classical language, profound artistic conception, a blend of literary and vernacular styles, majestic momentum, and chivalrous heroism
---

# General Writing Style Principles
- Elegant Classical Style: Language blends classical and vernacular, combining the charm of classical prose with accessibility
- Profound Artistic Conception: Use imagery and deliberate pauses to leave readers with lingering reflections
- Majestic Momentum: Grand jianghu scenes, flashes of swords and blades, heroic spirit soaring to the skies
- Chivalrous Heroism: Highlighting righteous vengeance, loyalty, and dedication to country and people
- Clear Distinction Between Good and Evil: Justice prevails, chivalry shines, providing readers with positive energy
- Satisfying Endings: Wuxia short stories should conclude with justice served and grudges resolved
- Integrated Outline: Chapter outlines serve as categorized information, not narrative sequence; during creation, reorganize events to advance the story naturally, avoiding block-by-block copying; background information should be seamlessly woven into the narrative

## Specific Practices

### When Writing Dialogue
- **Elegant and Courteous**: Jianghu characters speak with a jianghu flavor, both bold and respectful
  - ✅ "Your swordsmanship is exquisite! May I ask your honorable name?" "A chance meeting, no need for names. Your sword style is unorthodox, clearly from the Sword Sect lineage."
  - ❌ "Your martial arts are awesome! What's your name?"
- **Sense of Identity**: Different characters speak differently according to their status
  - ✅ "This humble monk from Shaolin, Puci, greets you." (Shaolin monk)
  - ✅ "Young brother, you look unfamiliar—are you new to the jianghu?" (Old jianghu veteran)
  - ✅ "A true man born under heaven and earth shall never surrender!" (Heroic chivalrous man)
  - ❌ All characters speak in the same style
- **Use Jianghu Terminology**: Naturally incorporate jianghu slang and etiquette
  - ✅ "I have eyes but failed to recognize a great mountain, forgive my offense!" "Brother, no offense taken. The jianghu is vast; we shall meet again."
  - ❌ "Sorry, I don't know you." "Goodbye."
- **Fit the Character**: Different roles have distinct speech patterns
  - Righteous masters: calm and courteous, words conceal sharpness
  - Demonic sect members: act strangely, words carry hostility
  - Jianghu elders: few words but profound, hitting the mark
  - Hot-blooded youths: full of heroic spirit, sometimes reckless

### When Writing Description
- **Use Artistic Language**: Avoid blunt description; create atmosphere
  - ✅ Moonlight like water, sword light like a rainbow. The youth in white stands atop the mountain peak, robes fluttering like an immortal.
  - ❌ The moon is bright, the youth wearing white stands on the mountain.
- **Engage Multiple Senses**: Visual, auditory, tactile interwoven
  - ✅ The clear sound of the sword’s ring enters the ear, accompanied by the howling mountain wind. He grips the sword hilt tightly, knuckles slightly whitening.
  - ❌ He holds a sword; the wind is strong.
- **Skillful Use of Contrast**: Use stillness to depict motion, scenery to reflect emotion
  - ✅ In the silence of all sounds, sword light suddenly flashes! That strike was unbelievably fast, so swift that even the sword’s ring sounded after the strike.
  - ❌ He strikes very fast.
- **Express Emotions Through Scenery**: Use landscape to reflect character’s mood
  - ✅ The setting sun bleeds red, staining the youth’s clothes crimson. He stands atop a mountain of corpses, silent for a long time.
  - ❌ The sun is about to set; he stands there.

### When Writing Psychological Activities
- **Express Inner Feelings Through Actions**: Wuxia characters are reserved; avoid excessive internal monologue
  - ✅ His hand gripping the sword trembled slightly, knuckles already white. After a while, he slowly closed his eyes and exhaled deeply.
  - ❌ He thought: I’m so scared, what should I do?
- **Use Imagery to Convey Emotions**: Express aspirations and feelings through objects and scenery
  - ✅ The night wind was like a knife, cutting painfully across his face. He recalled his master’s last words, feeling as if a huge stone pressed on his heart.
  - ❌ He felt very sad.
- **Maintain Restraint**: Emotional expression should be subtle
  - ✅ He wanted to say something but only parted his lips, finally uttering: "Take care."
  - ❌ He cried profusely and said: "I’ll miss you so much!"

### When Writing Martial Arts Combat Scenes
- **Use Named Techniques**: Martial arts moves should have names to add ritualistic flavor
  - ✅ Sword light flashed, revealing Huashan Sect’s ultimate technique "White Rainbow Piercing the Sun"! This strike was swift and fierce, like lightning tearing through the sky.
  - ❌ He attacked the opponent with his sword.
- **Impressionistic Rather Than Detailed**: Focus on spirit and charm, leave details to readers’ imagination
  - ✅ The two figures intertwined, three moves passed in a flash of lightning. When they stood apart, one’s sleeve already bore a sword scar.
  - ❌ He first stabbed left, then chopped right, then lifted upwards... (a dry list of moves)
- **Include Inner Energy Description**: Martial arts is not just external moves
  - ✅ His dantian warmed, a thick internal energy circulated through the meridians, and the sword suddenly gleamed with cold light.
  - ❌ He swung the sword with force.
- **Show Restraint and Interaction**: Martial arts have mutual strengths and weaknesses
  - ✅ Huashan swordsmanship emphasizes "direct meets indirect to win," yet this strange sword style countered him tightly. For a moment, he could not unleash his full power.
  - ❌ He couldn’t beat the opponent.

### When Writing Life-and-Death Scenes
- **Harsh but Not Gory**: Hint at violence without excessive gore
  - ✅ Sword light flashed, a blood line appeared on the man’s throat. He paused, then slowly fell.
  - ❌ Blood gushed out, staining the ground red... (overly graphic)
- **Dying with Meaning**: Important characters’ deaths must be significant
  - ✅ "Take good care of... her..." he smiled faintly, as if a heavy burden was lifted.
  - ❌ He died.
- **Heroic and Tragic**: Wuxia deaths should be full of heroic spirit
  - ✅ "Eighteen years later, I am a hero again!" he laughed to the sky, charging into the sword light.
  - ❌ He died scared.

### When Writing Emotional Scenes
- **Subtle and Reserved**: Wuxia emotions should be hinted at, not fully exposed
  - ✅ He watched her back, hesitating to speak. In the end, he softly said: "Take care on your journey."
  - ❌ "I love you! Please marry me!"
- **Express Feelings Through Martial Arts**: Use martial arts exchanges to convey emotions
  - ✅ Their sword tips touched, eyes locked. Thousands of words were contained in that single strike.
  - ❌ They gazed at each other affectionately.
- **Hint and Leave Space**: Leave room for readers’ imagination
  - ✅ The mountain wind brushed past, lifting strands of her hair. He silently hid the wooden hairpin in his bosom.
  - ❌ He confessed his love wildly at length.

### When Managing Pace
- **Establish Jianghu Atmosphere Within First 500 Words**: Immerse readers immediately in the martial world
  - ✅ At Huashan’s summit, sword aura stretched across the sky. Today was the once-in-a-decade "Huashan Sword Discussion."
  - ❌ This story takes place in ancient times. Back then, many practiced martial arts...
- **Every Scene Must Advance Plot**: Each scene must have meaning
  - ✅ Although defeated in this battle, he discerned flaws in the opponent’s swordplay. The next fight’s outcome was uncertain.
  - ❌ He fought a battle, then kept walking.
- **Balance Tension and Relaxation**: Alternate between intense and calm moments
  - ✅ After the fierce battle, he found a cave to rest. Moonlight spilled in, he sat cross-legged, beginning to cultivate and heal.
  - ❌ Continuous high-intensity fighting without pause

### When Ending Chapters
- **Leave Suspense**: Make readers eager for the next chapter
  - ✅ At that moment, footsteps sounded outside the cave. The visitor’s steps were light as if a supreme master. He tightened his grip on the sword, holding his breath.
  - ❌ This chapter ends here.
- **End at Emotional High Point or Turning Point**: Leave readers wanting more
  - ✅ "Master!" he looked at the familiar back, heart full of mixed feelings. After twenty years, he finally found the murderer of his family—his most respected master.
  - ❌ He discovered the truth.
- **Heroic Aftertaste**: End sentences like the lingering notes of a zither
  - ✅ Moon sets, crows cry, sword points to the horizon. The youth hoisted his pack and embarked on the long jianghu road. Years ahead, unknown when he will return.
  - ❌ He left.

## Language Taboos

### Absolutely Forbidden
- ❌ Modern slang: "so hype," "yyds," "absolutely awesome"
- ❌ Excessive gore: unnecessary cruel details
- ❌ Internet clichés: "trash," "overpowered protagonist," "face slap"
- ❌ Preachy tone: "This teaches us..." "We must learn..."
- ❌ Overly colloquial: completely lacking classical charm
- ❌ Historical errors: obvious mistakes in dynasty, artifacts, titles

### Must Achieve
- ✅ Elegant language blending classical and vernacular
- ✅ Martial arts descriptions full of spirit and charm
- ✅ Character dialogue with jianghu flavor
- ✅ Emotional expression subtle and reserved
- ✅ Clear distinction between good and evil, chivalry evident
- ✅ Satisfying endings with righteous vengeance

## Special Reminders

### Special Requirements for Short Stories
- **Balance Jianghu and Humanity**: Martial arts as exterior, humanity as interior, complementing each other
- **Clear Growth Mainline**: Every 1000 words should show growth or martial arts progress
- **Deep Dive into Single Theme**: Avoid covering too much; thoroughly explore one chivalrous theme
- **Complete Within Five Chapters**: Clear structure of beginning, development, turn, and conclusion

### Perspective Recommendations
- **Third-Person Omniscient**: Most common, shows the entire jianghu panorama
- **Third-Person Limited**: Follow the protagonist, enhance immersion
- **First-Person**: Suitable for memoir or monologue style

### Control of Wuxia Characteristics
- **Heroic Does Not Mean Reckless**: Heroes are brave and wise
- **Justice Is Not Simple**: Good and evil are sometimes ambiguous
- **Reserved Does Not Mean Indifferent**: Wuxia characters have deep feelings, expressed subtly
- **Classical Style Does Not Mean Obscure**: Easy to understand yet with classical charm

### Emotional Scale Control
- **Brotherhood Can Be Deep**: Loyal and life-sharing bonds
- **Master-Disciple Affection Can Be Touching**: Heavy gratitude and orderly inheritance
- **Romantic Love Should Be Subtle**: Use "heartfelt intentions" or "affection" instead of "love"
- **Patriotism Must Be Highlighted**: The great chivalrous one serves country and people

## Special Notes on Jin Yong’s Style

### Core Reference Works

Creation should focus on Jin Yong’s three classics: **"The Legend of the Condor Heroes"**, **"Demi-Gods and Semi-Devils"**, **"The Heaven Sword and Dragon Saber"**

#### Style Highlights of "The Legend of the Condor Heroes"
- **Protagonist Portrayal**: Guo Jing’s "great wisdom in simplicity"—average talent but pure heart, compensates with diligence, great skill without artifice
- **Growth Mainline**: Complete transformation from naive youth to great hero, clear growth trajectory
- **Chivalrous Spirit**: "The great chivalrous one serves country and people"—linking personal martial arts with national destiny
- **Emotional Handling**: Complementary relationship of Huang Rong and Guo Jing—one clever and smart, the other honest and simple
- **Martial Arts Features**: The powerful Dragon Subduing Palm, the exquisite Nine Yin Manual, moves with majestic names

#### Style Highlights of "Demi-Gods and Semi-Devils"
- **Multi-Threaded Narrative**: Interwoven storylines of Xiao Feng, Duan Yu, and Xu Zhu, converging in the end
- **Tragic Core**: "All love is sin, no one is without grievance"—fate’s unpredictability and human struggle
- **Mystery of Identity**: Confusion and pursuit of self-identity, often harsh truths
- **Unique Martial Arts**: Six Meridian Divine Sword, Dragon Subduing Palm, Northern Darkness Divine Skill, each distinctive
- **Grand Scale**: Historical backdrop of Song-Liao confrontation, heavy theme of national duty

#### Style Highlights of "The Heaven Sword and Dragon Saber"
- **Youthful Growth**: Zhang Wuji’s passive involvement—helpless yet full of adventures
- **Sect Rivalries**: Feuds between Ming Cult and six major sects, good and evil not simply black and white
- **Martial Arts Fusion**: Nine Yang Divine Skill, Heaven and Earth Great Shift, Tai Chi Fist and Sword—only integration leads to supremacy
- **Emotional Entanglements**: Multiple women’s emotional ties, conflicts between romance and jianghu ethics
- **Historical Integration**: Chaotic late Yuan and early Ming era, martial world intertwined with national affairs

### Core Characteristics of Jin Yong’s Wuxia

1. **Well-Rounded Characters**:
   - Protagonists imperfect but lovable (e.g., Guo Jing’s dullness, Zhang Wuji’s indecisiveness)
   - Villains not stereotypical, with logical motives (e.g., Murong Fu’s obsession, Cheng Kun’s hatred)
   - Supporting characters distinctive, not mere tools (e.g., Hong Qigong’s boldness, Huang Yaoshi’s eccentricity)

2. **Martial Arts with Culture**:
   - Martial arts names have allusions and artistic conception (Dragon Subduing Palm from I Ching, Dugu Nine Swords aligning with swordsmanship)
   - Moves embody philosophy (soft overcoming hard, last strike first, no moves surpass moves)
   - Martial arts realm corresponds with character’s mindset (only focused mind can master supreme skills)

3. **Sincere Emotions**:
   - Love is deep yet subtle (Jing-Rong’s love, Wuji’s entanglements)
   - Brotherhood is loyal and heartfelt (Xiao Feng, Duan Yu, Xu Zhu’s brotherhood)
   - Family and master-disciple bonds are profound (Guo Jing and Hong Qigong, Zhang Wuji and Zhang Sanfeng)

4. **Jianghu Has Rules**:
   - Sect inheritance (Shaolin, Wudang, Emei each with origins)
   - Jianghu ethics (a promise is a promise, clear debts and favors)
   - Heroes have bottom lines (do not harm innocents, do not bully the weak)

5. **Deep Themes**:
   - Explore human nature’s good and evil (distinction often blurred)
   - Reflect on true meaning of chivalry (what makes a true hero)
   - Care for country and world (individual fate and historical tides)

## Core Philosophy

Writing wuxia requires remembering three keywords:
1. **Chivalry**: The great chivalrous one serves country and people; the lesser chivalrous one aids the weak and fights oppression
2. **Affection**: Deep brotherhood, enduring romantic feelings, heavy master-disciple bonds
3. **Martial Way**: Martial arts are external, mindset is internal; the martial way is the human way

**Most important point**: Wuxia is an adult fairy tale. A good wuxia novel lets young readers see flashes of swords and thrilling vengeance, while adults read human affairs and patriotism. It is passionate but not impulsive; heroic but measured; exhilarating but profound. This is the charm of Jin Yong’s wuxia.