---
name: wuxia-outline-method
description: Methodology for creating outlines of classical-style wuxia short stories, including core synopsis extraction, lead design, plot structure planning, and character development guidance
---

## Q1-Q3 Question Templates

### Q1: Core Idea
**Q1: Core idea and appeal of the story [Brief description]**  
Please describe your story idea in one or two sentences.

### Q2: Core Conflict
**Q2: Core conflict [Brief description]**  
Please describe the main contradiction or primary conflict of the novel in one sentence  
(e.g., a youth seeking revenge to find the true culprit of his family’s massacre, a hero protecting a martial arts treasure, a disciple of a prestigious sect falsely accused embarking on a path of vindication, or martial artists caught between loyalty and hatred, etc.)

### Q3: Story Tone
**Q3: Story tone [Choose one]**  
- Passionate vengeance · Hot-blooded Jianghu (sword clashes, passionate vengeance, exhilarating)  
- Chivalrous tenderness · Romantic entanglements (balance of chivalry and love, deep feelings)  
- Suspense and mystery · Jianghu intrigue (martial arts conspiracies, layered revelations, truth unveiled)  
- Growth and transformation · The path of a great hero (from unknown novice to legendary hero)  
- Or briefly describe your story tone

## Chapter File Naming Rules  
Filename format: `{STORY_NAME}-{NN}.md`  
Example: `Blood-Sword-01.md`, `Blood-Sword-02.md`

---

# Wuxia Outline Creation Methodology

## Overall Orientation

Wuxia novels emphasize "**the spirit of chivalry and the vicissitudes of the Jianghu**," focusing on grudges and affections amid sword clashes, and growth and transformation.

**Core Reference Works**: "The Legend of the Condor Heroes," "Demi-Gods and Semi-Devils," "Heaven Sword and Dragon Sabre"  
- From "Condor Heroes," learn the patriotic chivalry of "the great chivalry serves the country and the people" and hero growth  
- From "Demi-Gods," learn the tragic aesthetics of fate’s unpredictability and the depth of human nature where affection is also sin  
- From "Heaven Sword," learn the continuous adventures and ambiguous good and evil in Jianghu conflicts and emotional entanglements

**Core Principles**:  
- Focus on chivalry themes (serving country and people, eradicating evil, clear distinctions of grudges, loyalty to the heavens)  
- Pursue "Jianghu resonance": passionate vengeance, romantic entanglements, heroic spirit  
- Balance martial arts and humanity, but **do not stray from chivalrous logic and the goodness of human nature**  
- Use martial arts, opportunities, and enlightenment to drive the plot, **maintaining a clear moral baseline of good and evil**  
- Maintain an elegant classical style: mix of literary and vernacular, profound artistic conception, majestic momentum

---

## Overall Creation Formula
```
Wuxia short story = Jianghu hook + Martial arts growth + Grudge entanglement + Chivalrous fulfilling ending
```

---

## I. Core Synopsis Writing

### Formula
```
Core synopsis = Jianghu identity/setting + Core grudge + Chivalry theme
```

### Writing Points
| Element | Requirement | Correct Example | Incorrect Example |
|---------|-------------|-----------------|------------------|
| **Jianghu Identity** | Unique + attractive | "A swordsman expelled from the sect" "An orphan with secret skills" | "A martial artist" |
| **Core Grudge** | Challenges both internal and external | "Must uncover the truth of the family massacre before the Mount Hua Sword Contest" | "Encountered an enemy" |
| **Chivalry Theme** | Clear life insight | "Realizing that the greatest chivalry serves the country and the people" | "Finally defeated the villain" |

### Excellent Examples
- "An orphan raised by the Six Freaks of Jiangnan, dull-witted but kind-hearted since childhood. When he steps into the martial world’s turmoil, he must choose between his master’s last wish and his own sense of justice, ultimately realizing that the highest realm of martial arts lies not in swordsmanship but in benevolence."  
- "A young swordsman bearing the blood feud of his family’s massacre ventures alone into the demon cult’s headquarters. He discovers the truth is not black and white and must choose between hatred and justice."  
- "A girl regarded as useless unexpectedly obtains a lost sword manual. When various sects covet it, she embarks on a path of escape, ultimately overcoming hardness with softness and winning people over with virtue."

---

## II. Lead Writing

### Formula
```
Lead = Jianghu world opening + Protagonist’s predicament setup + Grudge suspense hook
```

### Writing Points
| Element | Function | Approach |
|---------|----------|----------|
| **First sentence** | Open Jianghu world | Directly depict martial arts scene: summit of Mount Hua / Shaolin ancient temple / lonely smoke in the desert |
| **Middle part** | Explain protagonist’s situation | Quickly position by identity, martial arts, predicament |
| **Last sentence** | Create grudge suspense | Imminent conflict / truth waiting to be revealed / fate’s choice |

### Integration of Chivalry Themes

The lead should touch on core chivalry themes:

| Theme Type | Specific Direction |
|------------|--------------------|
| **Chivalrous growth** | From Jianghu novice to great hero, from hatred to broad-mindedness |
| **Grudge choice** | Blood feud and right and wrong, sect interests and Jianghu righteousness |
| **Emotional dilemma** | Romantic love and Jianghu morality, sect loyalty and inner justice |
| **Martial enlightenment** | From moves to inner methods, from killing to benevolence, from competition to detachment |

**Goal**: Make readers eager to know "how this Jianghu storm will end" (Jianghu immersion)

### Example Comparison
| Type | Content |
|------|---------|
| ✅ **Correct** | "Linghu Chong, orphaned heir of Mount Hua Sect, was raised by his master Yue Buqun as his own. Yet twenty years later, overnight, he was expelled from the sect, disgraced. 'You are unworthy to be a disciple of Mount Hua.' His master’s words still ring in his ears. Rumors spread that he stole the Bixie Sword Manual and colluded with the demon cult, making him a target for all. In desperation, he meets an old man unwilling to reveal his name and learns a sword technique that is both righteous and evil. The wheels of fate begin to turn. What earth-shattering secret does the bloodshed at Mount Hua twenty years ago hide?" |
| ❌ **Incorrect** | "There was a young man who knew martial arts, got kicked out by his master, later met a master and learned powerful martial arts, then started revenge..." |

---

## III. Plot Structure Design (Qǐ-Chéng-Zhuǎn-Hé 起承转合)

### 【Beginning】Chapter 1: Jianghu Storms Begin (2000-3000 words)

#### Writing Focus
```
Beginning = Martial world display + Protagonist introduction + Core predicament presentation + Jianghu opportunity
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Martial World Display** | Show Jianghu atmosphere within first 500 words | First paragraph includes: martial sects / Jianghu grudges / martial arts contests |
| **Protagonist Introduction** | Quickly introduce protagonist | Protagonist appears within 300 words<br>Appearance mode: in danger / bearing heavy responsibility / accidentally involved |
| **Core Predicament** | Show protagonist’s imperfections | Weak martial arts / mysterious background / bearing injustice / personality flaws |
| **Jianghu Opportunity** | Push story start | Family or national hatred / chance encounter and transmission / involvement in conflicts / entrusted escort mission |

#### Taboos
- ❌ Large blocks of explanatory text introducing martial sects  
- ❌ Protagonist appears invincible immediately  
- ❌ Unclear or unreasonable motive for entering Jianghu

---

### 【Development】Chapters 2-3: Martial World Training and Entanglements (2000-3000 words each)

#### Chapter 2 Writing Focus
```
Chapter 2 = Enter Jianghu + Meet heroes + First trial + Foreshadowing
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Enter Jianghu** | Leave familiar environment | Descend mountain to train / set out on journey / enter Jianghu conflicts<br>Show longing and unease about Jianghu |
| **Meet Heroes** | Establish bonds of loyalty | Meet at tavern / make friends through duel / help in danger<br>Companions should have complementary martial arts and personalities |
| **First Trial** | First confrontation | Small bandits / sect conflicts / Jianghu contests<br>Show protagonist’s martial arts strengths and weaknesses |
| **Foreshadowing** | Lay groundwork for later | Mysterious figures / lost manuals / unresolved grudges |

#### Chapter 3 Writing Focus
```
Chapter 3 = Major trial + Deepening bonds + Self-doubt + Key turning point
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Major Trial** | Increased difficulty | Stronger opponents / more dangerous conspiracies / greater sacrifices |
| **Deepening Bonds** | Jianghu friendships | Life-and-death companionship / mutual trust / entrusting lives |
| **Self-Doubt** | Inner struggle | Question own martial arts / question own beliefs / face moral dilemmas |
| **Key Turning Point** | Lead to climax | Discover truth / enlightenment in martial arts / make a choice |

---

### 【Turn】Chapter 4: Life-and-Death Crisis and Enlightenment (2000-3000 words)

#### Writing Focus
```
Turn = Greatest crisis + Near-death moment + Martial enlightenment + Counterattack from despair
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Greatest Crisis** | Danger peaks | Surrounded by enemies / conspiracy exposed / trapped in desperate situation |
| **Near-Death Moment** | Protagonist hits rock bottom | Seriously injured / betrayed by all / faith collapses<br>This is the darkest moment before dawn |
| **Martial Enlightenment** | Sudden insight and breakthrough | Recall master’s teachings / comprehend martial principles / realize great chivalry<br>Foreshadowed seeds sprout here |
| **Counterattack from Despair** | Self-breakthrough | Martial arts improve / inner strength breakthrough / mental state ascends |

#### Taboos
- ❌ Solving problems by divine weapons falling from the sky  
- ❌ Protagonist’s martial arts suddenly skyrocketing without buildup  
- ❌ Enlightenment too rushed, lacking emotional accumulation  
- ❌ **Excessive gore and cruelty**: maintain wuxia’s chivalrous tone

---

### 【Conclusion】Chapter 5: Chivalrous Fulfillment (2000-3000 words)

#### Writing Focus
```
Conclusion = Final showdown + Justice triumphs + Grudges resolved + Chivalrous ending
```

| Module | Writing Points | Specific Methods |
|--------|----------------|------------------|
| **Final Showdown** | Use martial arts after enlightenment | Combination of martial arts and wisdom / power of loyalty / victory of chivalry |
| **Justice Triumphs** | Evil does not prevail | Villains punished / conspiracies exposed / truth revealed |
| **Grudges Resolved** | Plot closure | Feuds resolved / misunderstandings cleared / Jianghu returns to peace |
| **Chivalrous Ending** | Theme sublimation | Retire to mountains / roam the world / found a sect / serve the country |

#### Taboos
- ❌ Rushed ending without emotional satisfaction  
- ❌ Too many unresolved grudges left  
- ❌ Protagonist shows no obvious growth  
- ❌ Ending too tragic (wuxia short stories should have clear good and evil, justice served)

---

## IV. Character Development Methods

### Protagonist Design

| Dimension | Requirement | Correct Example | Incorrect Example |
|-----------|-------------|-----------------|------------------|
| **Jianghu Identity** | Unique + attractive | "The eldest disciple expelled from the sect" "An orphan bearing a deep blood feud" | "An ordinary martial artist" |
| **Core Flaw** | Room for growth | "Weak martial arts / reckless personality / obsession / too naive" | "Peerless martial arts and perfect character" |
| **Personality Tags** | 2-3 distinct traits | "Honest but principled" "Clever but emotional" "Cold but loyal" | "Good person" |
| **Appearance Features** | Concise and memorable | "Sword-shaped eyebrows and starry eyes" "Dressed in white" "A sword scar on left cheek" | "Very handsome" |

### Personality Specificity
```
✅ "Linghu Chong is carefree and unrestrained, despising bullies. He would rather suffer himself than harm the weak. Wine is his confidant, the sword his lover, and friends are those he would risk his life for."  
❌ "He is straightforward and has a sense of justice."
```

### Protagonist Archetypes (Common in Wuxia)

| Type | Characteristics | Personality | Suitable Themes |
|------|-----------------|-------------|-----------------|
| **Prestigious Sect Disciple** | Born into a noble family but suffers misfortune | Upright and loyal / undergoes transformation | Growth and choices |
| **Jianghu Orphan** | Mysterious background / trained since childhood | Tenacious / longing for belonging | Searching roots and revenge |
| **Fallen Hero** | Bearing injustice / fallen in Jianghu | Enduring and resolute / holds justice | Vindication and reputation restoration |
| **Disciple of Hermit Master** | Trained by a recluse / naive about the world | Innocent and kind / exceptional martial arts | Entering the world and choices |
| **Heroine** | Woman who rivals men | Heroic and spirited / loyal and emotional | Independence and loyalty |

### Supporting Character Design (Wuxia Features)

| Type | Role | Notes |
|------|------|-------|
| **Hermit Master** | Teach martial arts, give enlightenment | Cannot solve all problems for protagonist, mainly guidance |
| **Jianghu Close Friend** | Accompany adventures, life-and-death bond | Must have unique martial arts and personality, not just sidekick |
| **Villain Grandmaster** | Create crises, promote growth | Highly skilled but with fatal flaw, acts logically |
| **Romantic Interest** | Emotional bond, difficult choices | Not a mere ornament, must have own chivalrous spirit and stance |

### Relationship Network Design (Wuxia Specific)

| Element | Requirement |
|---------|-------------|
| **With Origins** | Sect lineage / generational grudges / Jianghu heritage |
| **Complementary** | Martial arts complement / personality complement / balance of hard and soft |
| **With Loyalty** | Life-and-death friendship / mutual trust / entrusting lives |
| **With Change** | From hostility to mutual respect / from strangers to life-and-death friends / from misunderstanding to trust |

---

## V. Martial World Elements Design

### Worldview Construction Formula
```
Wuxia world = Sect landscape + Martial arts system + Jianghu rules
```

### Common Martial Sects

| Type | Characteristics | Examples |
|------|-----------------|----------|
| **Prestigious orthodox sects** | Upright and exemplary in Jianghu | Shaolin Temple / Wudang Sect / Mount Hua Sect / Emei Sect |
| **Jianghu guilds** | Loyalty first, large in number | Beggars’ Sect / Canal Guild / Salt Guild |
| **Hermit immortal sects** | Detached from worldly affairs, mysterious martial arts | Xiaoyao Sect / Lingjiu Palace / Peach Blossom Island |
| **Demonic cults and evil sects** | Cunning, domineering martial arts | Sun Moon Holy Cult / Divine Dragon Sect / Star Lodge |
| **Lone heroes** | Belong to no sect, unique style | Lone hero wolf / mysterious swordsman |

### Martial Arts System Design

| Element | Requirement |
|---------|-------------|
| **Distinctive** | Each martial art has unique style and move names |
| **Hierarchical** | From basic skills to peerless divine arts, progressive |
| **Costly** | Divine arts are not invincible, cultivation requires sacrifice |
| **Counterbalanced** | Martial arts interact with strengths and weaknesses, no absolute superiority |

### Martial Arts Description Principles

| Requirement | Example |
|-------------|---------|
| **Elegant move names** | "White Rainbow Piercing the Sun" "Wind Sweeping the Clouds" "Fire Raising the Sky" |
| **Concise action description** | Avoid piling up moves, convey spirit and artistic conception |
| **Internal and external cultivation** | Describe both external moves and inner energy flow |
| **Martial arts with philosophy** | Martial arts echo character personality and mindset |

---

## VI. Conflict Design

### Conflict Formula
```
Wuxia conflict = External grudges (enemies/conspiracies) + Internal struggle (obsession/choices) + Chivalrous awakening
```

### External Conflict (Mainline)

| Conflict Type | Specific Method | Example |
|---------------|-----------------|---------|
| **Blood feud and family hatred** | Family massacre / father’s murder | Uncover truth / kill enemy |
| **Jianghu conspiracy** | Fight for divine arts / martial supremacy | Foil conspiracy / save Jianghu |
| **Good vs Evil struggle** | Prestigious sect vs demon cult | Choose sides / resolve disputes |
| **National hatred and family grief** | Foreign invasion / defend country | Great chivalry serves country and people |

### Internal Conflict (Subline)

| Conflict Type | Design Method |
|---------------|--------------|
| **Hatred obsession** | Ruthless revenge / hatred blinds mind |
| **Emotional dilemma** | Sect loyalty vs justice / love vs morality |
| **Identity confusion** | Discover own background relates to hated enemy |
| **Moral dilemma** | To kill or not / conflict between benevolence and righteousness |

### Conflict Progression Levels
```
Level 1: External grudges (enemies/conspiracies/conflicts)
    ↓
Level 2: Internal struggle (obsession/confusion/choices)
    ↓
Level 3: Chivalrous awakening (transcend hatred / realize great righteousness / mental ascension)
```

---

## VII. Foreshadowing Management

### Foreshadowing Carriers (Wuxia Specific)

| Carrier Type | Example |
|--------------|---------|
| **Mysterious objects** | Fragmented sword manual / mysterious heavy sword / jade pendant token / treasure map |
| **Martial legends** | Peerless divine arts / Jianghu secrets / past truth |
| **Special martial arts** | Hidden inner strength / incomplete sword technique / a move left by master |
| **Mysterious figures** | Masked expert / hermit master / recluse elder |
| **Celestial omens** | Sun and moon conjunction / full moon night / cold light on sword |

### Foreshadowing Setting Principles

| Stage | Method |
|-------|--------|
| **Embedding** | Naturally integrate into scenes, 1-2 sentences mention<br>Example: "He unintentionally took the rusty sword; a warm current surged in his palm."<br>Example: "Before dying, the master left half a sentence: 'The truth of Mount Hua’s incident back then was not...'" |
| **Revealing** | Reveal function at critical moments<br>Example: In a crisis, the rusty sword gleams coldly, actually the long-lost mysterious heavy sword |

### Common Foreshadowing Designs

**Hidden Identity Foreshadowing**:  
```
Embedding: The boy has a birthmark on his left arm shaped like a swimming dragon  
Revealing: He is actually the missing young prince from years ago
```

**Martial Arts Awakening Foreshadowing**:  
```
Embedding: Whenever emotionally stirred, he feels a hot flow in his dantian  
Revealing: That is inner energy secretly planted by his master, erupting at life-and-death moments
```

**Object Function Foreshadowing**:  
```
Embedding: That ordinary copper coin is the only relic left by his mother  
Revealing: The coin contains the whereabouts of a martial arts treasure
```

---

## VIII. Chapter Layout Design (Wuxia Specific)

### Chapter Title Style

Wuxia titles should be **elegant, evocative, and captivating**:

| Element | Method |
|---------|--------|
| **Title style** | Imagery style, rich in classical charm<br>Example: "Chapter 1 The Lone Sword Comes from the West" "Chapter 3 Night Rain on Mount Hua" "Chapter 5 Chivalrous Tenderness" |
| **Chapter opening** | Use scenery to evoke mood<br>Example: "Moon at its zenith, sword shadows like rainbows."<br>Example: "Lonely smoke rises straight in the desert, the setting sun over the long river. The youth carries his bag, stepping into the Jianghu he had long heard of." |
| **Chapter ending** | Suspense or heroic spirit<br>Example: "Sword light flashes, the outcome decided. But the real test is just beginning."<br>Example: "He turns and leaves, leaving a desolate silhouette. The Jianghu road is long, years to come." |

### Dialogue Design (Core of Wuxia)

Wuxia dialogue should be **elegant, bold, and full of Jianghu flavor**:

**Good dialogue example**:
```
"Your swordsmanship is exquisite. May I ask which sect you belong to?" the youth bowed.  
The old man smiled faintly: "I no longer concern myself with Jianghu affairs, why ask about the past?"  
"I mean no offense, but this move 'White Rainbow Piercing the Sun' is clearly from Mount Hua swordsmanship..."  
The old man’s gaze sharpened, then returned to calm: "Mount Hua Sect? That was thirty years ago."  
```

**Poor dialogue example**:
```
"Your martial arts are very good."  
"Not bad."  
"Which sect are you from?"  
"I won’t tell you."  
```

### Martial Arts Description (Wuxia Feature)

Must **convey artistic conception and spirit**, not just pile up moves:

**Good martial arts description**:
```
Sword light suddenly rose like a long rainbow spanning the sky. Linghu Chong flipped his wrist, the sword tip drawing a silver arc, the essence of the "Sword Breaking Form" from the Dugu Nine Swords. He did not attack the opponent’s sword but the hand holding it—no matter how varied swordsmanship is, it always comes down to the "grip."  
The opponent’s sword momentum faltered, heart shocked: this young man’s swordsmanship has already reached a realm of refinement!  
```

**Poor martial arts description**:
```
He swung his sword to attack, the opponent dodged. He swung again, the opponent dodged again. He attacked many times like this.  
```

### Rhythm Control (Core of Wuxia)

**Rhythm formula**:
```
500 words = 1 martial fight OR 1 plot advancement OR 1 emotional change
```

Each scene must have: Jianghu atmosphere + emotional warmth + story significance

---

## IX. Growth Rhythm (Wuxia Exclusive)

### Five-Stage Growth Method
```
Enter Jianghu → Training and trials → Encounter disaster → Enlightenment in despair → Chivalrous fulfillment
```

| Stage | Word Count Ratio | Key Events | Martial Arts / Realm |
|-------|------------------|------------|---------------------|
| **Enter Jianghu** | 10-15% | Show initial state and predicament | Basic martial arts / immature mindset |
| **Training and trials** | 15-20% | Set out on journey / meet heroes | Some progress / beginning enlightenment |
| **Encounter disaster** | 25-30% | Face strong enemies / fall into predicament | Martial arts improve / mindset shaken |
| **Enlightenment in despair** | 20-25% | Life-and-death crisis / sudden insight and breakthrough | Martial arts advance / mental state ascends |
| **Chivalrous fulfillment** | 15-20% | Final showdown / resolve grudges | Martial path mastery / chivalry manifests |

### Growth Expression Techniques

**Martial arts growth**:
```
Start: Only basic skills, struggles against slightly stronger enemies  
Mid: Learn new martial arts, can contend with experts  
End: Integrate comprehensively, form unique style  
```

**Mindset growth**:
```
Start: Only knows hatred or sect honor  
Mid: Experience life and death, begin questioning and reflection  
End: Realize true chivalry, broaden mind and heart  
```

**Relationship growth**:
```
Start: Alone / hostile to others  
Mid: Make close friends, experience life and death together  
End: Mutual trust and loyalty, eternal bonds  
```

---

## X. Common Wuxia Patterns

**Core Reference**: When creating, focus on the narrative structures of Jin Yong’s three classics: "The Legend of the Condor Heroes," "Demi-Gods and Semi-Devils," and "Heaven Sword and Dragon Sabre."

### Pattern A: Heroic Growth (Reference: "The Legend of the Condor Heroes")

**Structure**:  
- Beginning: Youth with difficult background, mediocre talent but pure heart  
- Development: Apprenticeship, meet romantic interest, enter Jianghu  
- Turn: Major upheaval, torn between national hatred and romantic love  
- Conclusion: Realize great chivalry, become a legendary hero

**Features**: Clear growth arc, protagonist transforms from dull youth to towering hero, emphasizing "the great chivalry serves the country and the people"

### Pattern B: Fate’s Tragedy (Reference: "Demi-Gods and Semi-Devils")

**Structure**:  
- Beginning: Protagonist’s mysterious background or burdened fate  
- Development: Enter Jianghu, meet life-and-death friends, gradually learn truth  
- Turn: Identity revealed, faith collapses, faces greatest crisis  
- Conclusion: Transcend hatred and obsession, resolve tragedy with righteousness

**Features**: The impermanence of fate and struggle of human nature, tragic core of "affection is also sin," but ultimately elevated by chivalry

### Pattern C: Adventure and Rise (Reference: "Heaven Sword and Dragon Sabre")

**Structure**:  
- Beginning: Youth suffers misfortune, poisoned or trapped  
- Development: Fortune from misfortune, continuous adventures, martial arts advance greatly  
- Turn: Involved in sect conflicts, good and evil ambiguous, emotional entanglements  
- Conclusion: Integrate comprehensively, win people over with virtue, resolve grudges

**Features**: Passively involved but continuously lucky, martial arts integrated, good and evil not simply black and white

### Pattern D: Road of Revenge

**Structure**:  
- Beginning: Protagonist’s family suffers great calamity (massacre / framing / betrayal)  
- Development: Embark on revenge path, train martial arts, uncover truth  
- Turn: Discover truth is not as imagined, face moral dilemma  
- Conclusion: Transcend hatred, resolve grudges with chivalry

### Pattern E: Jianghu Conflicts

**Structure**:  
- Beginning: Martial world conflicts erupt (power struggle / treasure hunt / sect destruction)  
- Development: Protagonist involved, gradually understands factions  
- Turn: Conspiracy revealed, protagonist becomes key figure  
- Conclusion: Quell conflicts, Jianghu returns to peace

---

**【Special Reminder】**  
Keys to success of wuxia short stories:  
1. Establish Jianghu atmosphere within first 500 words  
2. Every 1000 words must include martial arts or growth advancement  
3. Dialogue must be elegant with Jianghu flavor  
4. Martial arts description must convey artistic conception and spirit  
5. Ending must clearly distinguish good and evil, highlighting chivalry