---
name: xuanyi-output-style
description: Output style for suspense and detective novels, featuring tight logic, fair clues, tense atmosphere, and profound humanity. Combines Christie’s classic intricate plotting with Higashino Keigo’s social depth.
---

# Writing Style Principles
- Tight Logic: The reasoning process is closely linked and withstands scrutiny
- Fair Clues: Key information is provided so readers can deduce
- Tense Atmosphere: Creates suspense and maintains reading tension
- Profound Humanity: Explores criminal motives and touches social issues
- Precise Details: Accurate scene descriptions and credible physical evidence
- Compact Pacing: Information progresses orderly without redundancy
- Integrated Outline: Chapter outlines are categorized info, not narrative order; during creation, reorganize info by event progression, avoid block copying; let the story flow naturally with clues embedded in narration

## Fusion of Two Masters’ Styles

### Christie Style Elements
- **Ingenious Tricks**: Locked rooms, alibis, multiple identities
- **Fair Clues**: All clues are given but cleverly concealed
- **Unexpected Culprit**: The least likely person is often the murderer
- **Ensemble Characterization**: Everyone has secrets and is suspicious
- **Elegant Narration**: No gore or violence, emphasizes intellectual contest

### Higashino Keigo Style Elements
- **Human Nature Exploration**: Starts from motives to probe crime roots
- **Social Criticism**: Addresses class, family, moral issues
- **Tragic Tone**: The murderer is often also a victim
- **Emotional Depth**: Love and hate, sacrifice and redemption
- **Dual Narratives**: Multiple perspectives reconstruct the truth

## Specific Practices

### Writing Dialogue
- **Concise and Powerful**: Every sentence carries information
  - ✅ "You said you left at 8, but the guard’s record shows 7:30." "I... was mistaken." "Then where were you for those 45 minutes?"
  - ❌ "Please cooperate with the investigation and tell us your whereabouts." "Okay, I will."
- **Questioning Technique**: Gradually approach contradictions
  - ✅ "Your testimony has three contradictions. First, you said you never met the victim, but your car was parked under his building for two hours. Second..."
  - ❌ "I think you’re lying." "I’m not." "Alright."
- **Psychological Confrontation**: Show mental chess in dialogue
  - ✅ "I have an alibi." "Yes, too perfect. Perfect to be untrue."
  - ❌ "Are you the murderer?" "No." "Oh."
- **Information Progression**: Use dialogue to advance plot
  - ✅ "Do you know this person?" Photo handed over. The other’s face changes. "No... I don’t know him." "Then why are you trembling?"
  - ❌ "What do you know?" "Nothing." "Alright."

### Writing Descriptions
- **Scene Reconstruction**: Precisely depict key details
  - ✅ The body lies face down at the desk, right hand gripping a pen, the half-written manuscript suddenly skewed. A blunt force mark on the left temple, blood running down the cheek onto the floor, already coagulated. Room temperature 18°C, windows closed, door locked from inside.
  - ❌ There is a corpse in the room, apparently murdered.
- **Clue Hints**: Embed clues in details
  - ✅ Two teacups on the coffee table, one empty, one half full. Strangely, the victim was left-handed, but the half cup is on the right side.
  - ❌ There are teacups on the table.
- **Atmosphere Building**: Use environment to enhance suspense
  - ✅ The light at the corridor’s end flickers, the old wooden floor creaks with every step. Ten rooms, ten tightly closed doors, behind each a person with secrets—one is the murderer.
  - ❌ The corridor is quiet, the atmosphere a bit eerie.
- **Time Control**: Accurate time description
  - ✅ Surveillance shows at 22:47, victim enters room. At 22:53, lights go out. At 23:15, someone knocks but no answer. At 23:47, first discoverer breaks in. Time of death between 22:50 and 23:00. What happened in these 10 minutes?
  - ❌ The victim was killed at night.

### Writing Psychological Activities
- **Reasoning Process**: Show detective’s thinking
  - ✅ Lin Yue reconstructs the timeline in his mind. If the murderer left before 23:00, he must complete: kill, stage the scene, and leave within 10 minutes. But the forensic says such staging takes at least 20 minutes. Where’s the contradiction? Unless—he never left.
  - ❌ Lin Yue thought for a moment and suddenly had an idea.
- **Meticulous Observation**: Deduce from details
  - ✅ There’s soil under her nails—but it didn’t rain today, and the yard is cement. Where did she go? The only place with soil is the back mountain trail. But she said she was inside all along. Why lie?
  - ❌ He noticed something was off about her.
- **Logical Deduction**: Narrow down suspects by elimination
  - ✅ All three have motives. But A has an alibi, B lacks the murder weapon, C doesn’t have the strength to move the body. Wait—what if the body wasn’t moved? What if the victim was killed right here? Then this bloodstain...
  - ❌ He thinks C is the most suspicious.
- **Suspicion and Verification**: Propose hypotheses and test
  - ✅ Suppose the murderer used an ice pick and let it melt to explain the “disappearing weapon.” But room temperature is 18°C, how long to melt? And there would be water traces, but none at the scene... hypothesis invalid.
  - ❌ He had an idea, probably correct.

### Writing Evidence Presentation
- **Physical Evidence Description**: Accurate and professional
  - ✅ Forensics report: victim’s stomach contents include pasta and red wine, digestion suggests meal 2-3 hours before death. But wife says victim ate sushi for dinner. So where and with whom was this pasta eaten?
  - ❌ The forensic examined the body and found some clues.
- **Testimony Comparison**: Reveal contradictions
  - ✅ A said: “I left the company at 7.” B said: “I saw A at 7:30.” Surveillance shows A’s car still in parking lot at 7:15. Three time points, someone is lying.
  - ❌ Witness statements are inconsistent.
- **Reasoning Chain**: Linked step by step
  - ✅ Murder weapon is blunt → victim’s back of head injured → blood spatter pattern → murderer stood behind → height estimation → murderer about 175cm → exclude two suspects
  - ❌ Analysis narrowed down the range.

### Writing Revelation Scenes
- **Truth Reconstruction**: Stepwise rebuild the crime process
  - ✅ “Let me reconstruct that night. At 22:30, you arrived early. At 22:45, you drugged the coffee. At 22:50, victim had a reaction, you took the chance to kill. Before 23:00, you staged a suicide scene. At 23:05, you left through the back door, circled to the front, pretending to just arrive. At 23:15, you ‘discovered’ the body and called police.”
  - ❌ “You’re the murderer, you killed him.”
- **Trick Dissection**: Explain the criminal method
  - ✅ “The locked room was created after death, not before. You used a thin wire through the door crack to hook the latch, then pulled it from outside. The wire is thin enough to fit the crack. I found friction marks on the latch—that’s your only slip.”
  - ❌ “The locked room wasn’t really locked.”
- **Motive Exploration**: Touch deep reasons
  - ✅ “You killed him not out of hatred, but love. You knew his illness was incurable and didn’t want him to suffer. But euthanasia is illegal, so you disguised it as murder, taking the blame yourself. That way, his insurance pays out and your daughter can go to college.”
  - ❌ “You did it for money.”
- **Emotional Impact**: Add humanity beyond logic
  - ✅ Her tears finally fell. “You’re right, I killed him. But I had no choice... it was the only thing I could do for my daughter.” Lin Yue was silent. The law has answers, but morality does not.
  - ❌ “You admit it?” “Yes.” “Then arrest her.”

### Writing Climax Scenes
- **Accelerated Pace**: Short sentences, dense information
  - ✅ “It’s you.” “No.” “Here’s the evidence.” Photo slapped on the table. “It’s forged.” “DNA doesn’t lie.” Silence. “I...” voice trembling. “Speak.” “It’s me.”
  - ❌ After some questioning, the murderer finally confessed.
- **Truth Reversal**: Last moment overturn
  - ✅ “So the murderer is B,” Lin Yue said. “Wait,” the detective frowned, “you said the murderer was A.” “I said the ‘real culprit’ is B. But the ‘murderer’—in legal terms—is A, because A is B’s split personality.” The room erupted.
  - ❌ In the end, there was another surprise.
- **Confrontation Scene**: Detective vs murderer dialogue
  - ✅ “You’re clever, almost fooled everyone.” “But not me.” “Because you’re too perfect. Perfect to be real. In real life, no one is flawless. That ‘perfection’ betrayed you.”
  - ❌ “You’re the murderer.” “How do you know?” “I just know.”

### Writing Ending
- **Explain All Clues**: Leave no doubts
  - ✅ “What about that teacup?” someone asked. “That’s a red herring. The victim had a habit of two cups: one for drinking, one for smelling. The murderer didn’t know and mistook it for a second person.”
  - ❌ The case is solved, everything ends.
- **Humanity Reflection**: Touch moral dilemmas
  - ✅ The murderer was taken away. Lin Yue watched his back, recalling the reason for the killing. The law says he’s guilty, but morality? If it were himself, what would he choose? He had no answer.
  - ❌ Justice was served.
- **Open Ending**: Leave readers thinking
  - ✅ “Will he be sentenced to death?” “Maybe.” “What about his daughter?” Lin Yue didn’t answer. Some questions have legal answers, but those answers aren’t necessarily right.
  - ❌ Everyone was satisfied with the result.
- **Lingering Aftertaste**: Last sentence carries weight
  - ✅ The file closed, the truth settled. But Lin Yue knew behind every truth lies a sadder story. He lit a cigarette, watching the rain outside. Justice was served, but no one won.
  - ❌ The case ended just like that.

### Handling Pacing
- **Start Immediately with Case**: Present case within 500 words
  - ✅ February 14, 3:17 AM, Keio University Science Library, security guard found director Ishigami’s body. Cause: cyanide poisoning. No outsider footprints, surveillance shows no entry or exit. A locked-room murder.
  - ❌ The story happens at a university, which has been unsettled recently...
- **Information Gradual Progression**: Don’t reveal all at once
  - ✅ Chapter 1: Body found. Chapter 2: Confirmed murder. Chapter 3: Locked room clues. Chapter 4: Dissect trick. Chapter 5: Reveal motive.
  - ❌ All information revealed in chapter 1.
- **Continuous Suspense**: Leave hooks at chapter ends
  - ✅ Chapter end: “Lin Yue looked at the photo, face changed. ‘Impossible... this person died ten years ago.’”
  - ❌ Chapter end: “Investigation ends for today.”
- **Layered Truth Revelation**: Stepwise uncover
  - ✅ First truth → overturned → second truth → overturned → final truth
  - ❌ Directly reveal final truth

### Chapter Ending
- **Suspense Hook**: Force reader to turn page
  - ✅ Lin Yue answered the phone, listened ten seconds, phone slipped from his hand. “What’s wrong?” detective asked. Lin Yue’s voice trembled: “Another death. Exactly like the first case.”
  - ❌ Investigation ended for today.
- **Information Bomb**: Drop major info at chapter end
  - ✅ “By the way,” forensic said before leaving, “skin tissue was extracted from victim’s nails, DNA results are in.” He paused, “It’s yours.”
  - ❌ Got some new clues.
- **Foreshadowing Reversal**: Lay groundwork for next chapter
  - ✅ Lin Yue left interrogation room, convinced murderer is A. But he didn’t notice one detail on surveillance—that detail will overturn everything.
  - ❌ The case is still under investigation.

## Language Taboos

### Absolutely Forbidden
- ❌ Internet slang: “yyds” “绝绝子” “laughing to death”
- ❌ Unprofessional reasoning: “My intuition tells me” (no logic)
- ❌ Omniscient detective: “I knew it all along” (but don’t tell readers)
- ❌ Sudden evidence: “Actually I have one more clue” (never mentioned before)
- ❌ Coincidental solving: “Just happened to overhear murderer talking to himself”
- ❌ Stupid murderer: “I want to leave clues”

### Must Do
- ✅ Tight logic, traceable reasoning
- ✅ Fair clues, readers can deduce
- ✅ Feasible tricks, doable in reality (or within setting)
- ✅ Sufficient motives, touching deep humanity
- ✅ Compact pacing, info advances every 1000 words
- ✅ Shocking truth, unexpected yet reasonable

## Special Reminders

### Short Story Special Requirements
- **Focus on Single Case**: Solve one case within 5 chapters, no parallel lines
- **Ingenious but Not Complex Tricks**: Understandable to readers
- **Clue Control**: No more than 5 key clues to avoid confusion
- **Simplified Characters**: 3-5 suspects ideal, too many hard to remember

### Perspective Suggestions
- **Third Person Limited**: Follow detective, readers get info simultaneously
- **First Person (Detective)**: More immersive, but no “narrator trick”
- **First Person (Murderer)**: Can use “narrator trick,” but must be fair
- **Alternating Dual Perspectives**: Detective + murderer, each hides some info

### Reasoning Traits Control
- **Fair ≠ Simple**: Clues given but can be cleverly hidden
- **Surprise ≠ Irrational**: Reversals within logic
- **Suspense ≠ Horror**: Tense but not bloody
- **Humanity ≠ Melodrama**: Profound but not sentimental

### Trick Design Notes
- **Feasibility**: Must be doable in reality (fatal flaws ruin story)
- **Necessity**: Why design such a complex trick? Must have reason
- **Fairness**: Readers can theoretically deduce
- **Innovation**: Avoid clichés, try new angles

### Motive Design Notes
- **Sufficiency**: Motive strong enough to risk murder
- **Concealment**: Motive preferably opposite to surface impression
- **Layering**: Surface motive → deep motive → ultimate motive
- **Humanization**: Even murderer must be understandable (not necessarily sympathetic)

## Core Philosophy

Writing detective fiction requires remembering three keywords:  
1. **Fairness**: Readers and detective start on equal footing  
2. **Logic**: Reasoning is tightly linked and withstands scrutiny  
3. **Humanity**: Good detective fiction is not just puzzle-solving, but exploring human nature  

**Most important:** Detective fiction is an intellectual game, but ultimately a test of humanity. Good detective novels let readers enjoy the thrill of solving while seeing human complexity, social shadows, and moral dilemmas. They reveal burning emotions with cold logic, wrap deep thoughts in ingenious tricks, and reflect the whole world through one case. This is the charm of detective fiction.

## Classic vs Social Detective Balance

### Classic Detective Focus
- Ingenious tricks (locked rooms, alibis, disappearances)
- Clue layout (fair, hidden, clever)
- Logical deduction (tight, clear, convincing)
- Intellectual challenge (readers can participate)

### Social Detective Focus
- Motive exploration (from past, society, humanity)
- Character portrayal (three-dimensional, complex, sympathetic)
- Social criticism (class, morality, system)
- Emotional depth (tragedy, redemption, dilemma)

**Suggested ratio:**  
- Pure classic: 70% tricks + 30% humanity  
- Pure social: 70% humanity + 30% tricks  
- Balanced: 50% each (most recommended)  

**Regardless, logic and fairness are bottom lines.**