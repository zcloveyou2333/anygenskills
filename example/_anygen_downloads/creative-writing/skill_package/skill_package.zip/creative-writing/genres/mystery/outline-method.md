---
name: xuanyi-outline-method
description: Methodology for creating outlines of suspense detective short stories, including trick design, clue placement, logical reasoning, and human motives. Integrates the essence of Agatha Christie's classic detective fiction and Keigo Higashino's social mystery style.
---

## Q1-Q3 Question Templates

### Q1: Core Idea
**Q1: Core idea and appeal of the story [Brief description]**  
Please describe your story idea in one or two sentences.

### Q2: Core Conflict
**Q2: Core conflict [Brief description]**  
Please describe the novel’s core contradiction or main conflict in one sentence  
(e.g., the earth-shattering secret behind a serial murder, impossible crime in a locked room, layers of fog in the pursuit of truth, intellectual battle between good and evil, etc.)

### Q3: Story Tone
**Q3: Story tone [Choose one]**  
- Classic detective fiction · Logical rigor (fair clues, locked-room trick, logical deduction)  
- Social mystery · Deep human nature (criminal motives, social issues, human darkness)  
- Suspense thriller · Tense and exciting (rising suspense, tight pacing, constant twists)  
- Crime investigation · Justice served (police perspective, case solving, law enforcement)  
- Or briefly describe your story tone

## Chapter File Naming Rules  
Filename format: `{STORY_NAME}-{NN}.md`  
Example: `NoOneSurvives-01.md`, `WhiteNight-02.md`

---

# Suspense Detective Outline Creation Methodology

## Overall Orientation

Suspense detective fiction emphasizes "**logic and truth**," centering on trick design, clue arrangement, and human nature exploration.

**Core Principles**:  
- Focus on the core puzzle (locked-room murder, alibi, hidden motive, secret identity, etc.)  
- Pursue "intellectual shock": ingenious tricks, fair clues, rigorous reasoning  
- Balance classic detective and social mystery styles, but **never abandon logical consistency and clue fairness**  
- Drive plot by evidence, reasoning, and revelation, **aiming for progressively unfolding truth**  
- Maintain Christie’s classic tricks: multiple identities, psychological traps, unexpected culprits  
- Incorporate Higashino’s human depth: emotional motives, social issues, moral dilemmas

---

## Overall Creation Formula
```
Detective short story = Core trick + Fair clues + Logical reasoning + Shocking truth
```

---

## 1. Core Synopsis Writing

### Formula
```
Core synopsis = Case setting + Impossible crime + Truth core
```

### Writing Points
| Element       | Requirement          | Correct Example                                                                 | Incorrect Example       |
|---------------|---------------------|---------------------------------------------------------------------------------|-------------------------|
| **Case setting** | Specific + unusual  | "In a sealed library, the curator died of cardiac arrest, but everyone has an alibi." | "A murder happened."     |
| **Impossibility** | Create logical paradox | "The killer must be on site, but everyone has ironclad alibis."                 | "The killer is hard to find." |
| **Truth core**  | Touch deep motives   | "Explores the cost of revenge and twisted love."                               | "The killer was caught in the end." |

### Excellent Examples
- "On an isolated island villa sealed by heavy snow, ten people die one by one according to a nursery rhyme prophecy. No outsiders entered; the killer must be among them—but who can kill everyone, including themselves?"  
- "A math genius designs a perfect alibi for his beloved woman by substituting a vagrant’s corpse. All police evidence points to natural death, but the detective smells something off in the 'too perfect' scenario."  
- "In a locked room late at night, the victim was stabbed in the heart. The door was locked from inside, windows sealed, and only the victim’s footprints were found. This is not suicide—so how did the killer get in and out?"

---

## 2. Lead-in Writing

### Formula
```
Lead-in = Eerie scene + Impossible puzzle + Suspense hook
```

### Writing Points
| Element       | Purpose             | How to Write                                   |
|---------------|---------------------|-----------------------------------------------|
| **First sentence** | Establish suspense atmosphere | Directly show: strange death method / locked room / scene defying logic |
| **Middle part** | Explain core puzzle | Use precise details to quickly locate contradiction |
| **Last sentence** | Create strong suspense | Throw out impossible crime / subversive clue / shocking discovery |

### Incorporating Suspense Themes

Lead-in should touch on the core theme of the mystery:

| Theme Type       | Specific Direction                         |
|------------------|--------------------------------------------|
| **Impossible crime** | Locked-room murder, alibi, missing murder weapon, illogical scene |
| **Human motives** | Revenge, jealousy, greed, protection, twisted love |
| **Social shadows** | Class conflict, domestic violence, workplace rivalry, moral dilemma |
| **Identity secrets** | Dual identity, faked death, body double, unknown past |

**Goal**: Make readers feel "How is this possible?" — intellectual immersion

### Example Comparison
| Type       | Content                                                                                                                                                                                                                                                                                                                                                  |
|------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| ✅ **Correct** | "At 3:17 AM on February 14, Keio University Science Library. The curator Ishigami’s body was found dead for over six hours. Cause of death: cardiac arrest. Seemingly natural, but the forensic exam found anomalies—a tiny needle hole in the right hand’s webbing, cyanide detected in blood. This is murder. The sealed library showed no other footprints; surveillance recorded no entry that night. How was poison administered? Even stranger, everyone who contacted Ishigami has an unbreakable alibi. Detective Yukawa looked at the floor plan and whispered, 'It’s not that the killer is smart, but that we misunderstood something.'" |
| ❌ **Incorrect** | "A murder happened in the library; the curator died, and the police started investigating..."                                                                                                                                                                                                                                                        |

---

## 3. Narrative Structure Design (Introduction, Development, Twist, Conclusion)

### 【Introduction】Chapter 1: Crime and Puzzle (2000-3000 words)

#### Writing Focus
```
Introduction = Crime occurrence + Scene presentation + Initial contradiction + Detective appearance
```

| Module          | Writing Points                        | Specific Methods                                                                                   |
|-----------------|-------------------------------------|--------------------------------------------------------------------------------------------------|
| **Crime occurrence** | Present crime within first 500 words | The first paragraph shows: body / scene / anomaly<br>Use details instead of explanations: show irrationality |
| **Scene presentation** | Accurately depict key info          | Present the scene fully within 500 words<br>Every detail is a clue or a distraction: bloodstains / positions / objects / time |
| **Initial contradiction** | Show impossibility               | Point out obvious logical paradox: locked room / alibi / lack of motive                           |
| **Detective appearance** | Establish investigative ability    | Show insight through observation: notice details others ignore                                  |

#### Christie Techniques
- **Fair clues**: All key clues appear in Chapter 1 but hidden in details  
- **Multiple suspects**: Everyone is suspicious but all have "proof"  
- **Psychological misdirection**: Lead readers to wrong conclusions with conventional thinking

#### Taboos
- ❌ Hide key physical evidence from readers  
- ❌ Detective has omniscient viewpoint, readers passively accept  
- ❌ Puzzle too simple, obvious at first glance

---

### 【Development】Chapters 2-3: Investigation and Fog (2000-3000 words each)

#### Chapter 2 Focus
```
Chapter 2 = Evidence collection + Witness questioning + Contradictory clues + New death
```

| Module          | Writing Points                        | Specific Methods                                                                                   |
|-----------------|-------------------------------------|--------------------------------------------------------------------------------------------------|
| **Evidence collection** | Detective begins investigation    | Examine scene / check physical evidence / find anomalies                                        |
| **Witness questioning** | Reconstruct from different angles | Each witness says different things / some lie / some conceal                                    |
| **Contradictory clues** | Create more confusion            | Evidence conflicts / timeline mismatches / unclear motives                                     |
| **New death** | Raise tension                        | Informant silenced / killer strikes again / danger approaches                                   |

#### Chapter 3 Focus
```
Chapter 3 = Key discovery + Suspect analysis + Unmasking disguise + Partial truth
```

| Module          | Writing Points                        | Specific Methods                                                                                   |
|-----------------|-------------------------------------|--------------------------------------------------------------------------------------------------|
| **Key discovery** | Find breakthrough                   | Overlooked detail / hidden relationship / timeline loophole                                    |
| **Suspect analysis** | Eliminate suspects one by one      | Motive / means / opportunity — each lacks one element                                           |
| **Unmasking disguise** | Pierce first layer of illusion    | Alibi has problems / testimony conflicts                                                       |
| **Partial truth** | Reveal secondary trick              | Reveal minor trick but core puzzle is deeper                                                   |

#### Higashino Techniques
- **Emotional clues**: Dig motives from character relationships  
- **Social background**: Find crime roots in profession/class/family  
- **Moral dilemma**: Make readers understand or even sympathize with the killer

---

### 【Twist】Chapter 4: Reasoning and Revelation (2000-3000 words)

#### Writing Focus
```
Twist = Comprehensive review + Logical deduction + Trick reveal + Motive excavation
```

| Module          | Writing Points                        | Specific Methods                                                                                   |
|-----------------|-------------------------------------|--------------------------------------------------------------------------------------------------|
| **Comprehensive review** | Detective organizes all info       | Timeline / relationships / evidence list / contradictions                                       |
| **Logical deduction** | Step-by-step infer truth           | Use known to infer unknown / exclude impossibilities / what remains is truth                    |
| **Trick reveal** | Explain crime method                 | How locked room was created / how alibi was faked / where murder weapon was                      |
| **Motive excavation** | Reveal why murder occurred          | Past secrets / hidden relationships / unknown truths                                           |

#### Reasoning Display Techniques
```
✅ Good reasoning process:
"There are no footprints of outsiders at the scene, which means what? The killer is either an insider or never left.
Look at the timeline—the death time is 10 PM, but the last sighting was 9:30 PM. What happened in these 30 minutes?
The key is this teacup. It has the victim’s fingerprints, proving he drank from it. But the forensic report says no tea was found in the stomach, only whiskey.
So—this tea was poured after death. Why fake that he drank tea?
Because the killer needed to create the illusion that the victim was alive at 10 PM.
Then the real time of death is—"
```

```
❌ Poor reasoning process:
"I already knew who the killer was. It’s him. See, all the evidence is here."
```

#### Taboos
- ❌ Detective suddenly produces evidence not shown before  
- ❌ Killer confesses due to "conscience"  
- ❌ Truth relies on coincidence, not logic

---

### 【Conclusion】Chapter 5: Truth and Aftermath (2000-3000 words)

#### Writing Focus
```
Conclusion = Complete truth + Confrontation with killer + Deep motive excavation + Human reflection
```

| Module          | Writing Points                        | Specific Methods                                                                                   |
|-----------------|-------------------------------------|--------------------------------------------------------------------------------------------------|
| **Complete truth** | Restore entire crime process        | Explain every step from planning to execution                                                   |
| **Confrontation with killer** | Detective dialogues with killer       | Killer’s justification / despair / or calm acceptance                                          |
| **Deep motive excavation** | Reveal story behind crime           | Past trauma / twisted love / social oppression                                                 |
| **Human reflection** | Respond to core theme               | Law and morality / justice and revenge / boundary of good and evil                             |

#### Types of Deductive Endings
| Type             | Characteristics                   | Suitable Scene                      |
|------------------|---------------------------------|-----------------------------------|
| **Perfect resolution** | Killer caught, truth revealed    | Classic detective fiction, emphasizing logic |
| **Tragic**       | Truth is harsh, killer has pathos | Social mystery, digging motives    |
| **Open-ended**   | Conflict between legal and moral justice | Explore ethical dilemmas           |
| **Twist**        | Last second overturns all deductions | Shocking narrative trick           |
| **Dual truth**   | Surface truth and deeper truth    | Multiple narrative tricks          |

#### Taboos
- ❌ Motive too weak, "just wanted to kill"  
- ❌ Killer is an unseen 11th person  
- ❌ Unexplained logical loopholes remain

---

## 4. Character Design Methods

### Detective Design

| Dimension       | Requirement          | Correct Example                         | Incorrect Example   |
|-----------------|----------------------|---------------------------------------|---------------------|
| **Occupation**  | Clear + reasonable   | "Retired detective", "Physics professor", "Amateur detective" | "Detective"          |
| **Core ability** | Specific skill       | "Microexpression observation", "Logical reasoning", "Physics knowledge" | "Very smart"         |
| **Personality** | 2-3 distinct traits  | "Obsessively meticulous", "Calm and rational but somewhat reclusive" | "Good person"        |
| **Thinking style** | Show reasoning process | "Start from contradictions, use elimination to deduce" | "Suddenly thought of it" |

### Detective Archetypes (Common in detective fiction)

| Type             | Features                      | Personality                 | Suitable Themes              |
|------------------|-------------------------------|-----------------------------|-----------------------------|
| **Amateur detective** | Driven by interest, keen insight | Curious, logical, justice-driven | Classic detective, intellectual challenge |
| **Professional detective** | Experienced, authoritative       | Calm, professional, stubborn, seen human darkness | Crime investigation, procedural justice |
| **Psychologist**  | Focus on motives               | Observant, empathetic, understands human nature | Social mystery, human exploration |
| **Scientist**     | Uses professional knowledge   | Rational, evidence-focused, truth-seeker | Scientific tricks, logical deduction |
| **Victim’s relative/friend** | Investigates for personal reasons | Persistent, emotional, growth character | Emotional lines, revenge theme |

### Killer Design (Core of detective fiction)

| Element         | Requirement           | Method                                  |
|-----------------|-----------------------|-----------------------------------------|
| **Hidden identity** | Not obvious at first glance | Set misdirection / fake alibi / scapegoat |
| **Reasonable motive** | Must be sufficient and real | Dig from past / relationships / human nature |
| **Capability**   | Means must be credible | Professional knowledge / special identity / careful preparation |
| **Psychological portrayal** | Not stereotypical       | Killer is human too, with struggles / fears / reasons |

### Suspect Design

Each suspect needs:

| Element         | Description            |
|-----------------|------------------------|
| **Motive**      | Has a reason to kill   |
| **Means**       | Has ability to commit the crime |
| **Opportunity** | Was near the scene     |
| **Secret**      | Hides something (not necessarily the killer) |
| **Flaw**        | Has some inconsistency |

### Victim Design

| Element         | Role                   |
|-----------------|------------------------|
| **Unlikeability** | Provides motive for many |
| **Hidden side** | Has unknown secrets before death |
| **Relationship network** | Complex ties with many people |
| **Function**    | Death itself is part of the puzzle |

---

## 5. Trick Design

### Trick Formula
```
Classic trick = Apparent impossibility + Hidden mechanism + Logical consistency
```

### Common Trick Types

#### 1. Locked-room Tricks

| Trick Method   | Principle                     | Notes                          |
|----------------|-------------------------------|--------------------------------|
| **Physical locked room** | Doors and windows truly locked, but other exits exist | Must have reasonable hidden passage |
| **Psychological locked room** | Appears locked room, but someone is lying | Must provide motive for lying    |
| **Time trick** | Death time is falsified        | Must have scientific basis      |
| **Ice trick** | Use ice to make weapon or mechanism | Consider melting time           |

#### 2. Alibi Tricks

| Trick Method   | Principle                     | Notes                          |
|----------------|-------------------------------|--------------------------------|
| **Time difference** | Fake death time               | Must have medical/physical basis |
| **Body double** | Have someone impersonate self | Explain why no one noticed       |
| **Remote killing** | Set trap in advance          | Trap must be feasible            |
| **Witness collusion** | Witnesses give false testimony | Must have reason for collusion  |

#### 3. Narrative Tricks

| Trick Method   | Principle                     | Notes                          |
|----------------|-------------------------------|--------------------------------|
| **Narrator trick** | Narrator is the killer        | Must be fair—reader can detect  |
| **Pronoun trick** | Use pronouns to mislead identity | Re-reading reveals clues        |
| **Snowstorm mansion** | Isolated environment, killer inside | Must create oppressive atmosphere |
| **Nursery rhyme murder** | Kill according to a pattern | Pattern must be meaningful      |

#### 4. Identity Tricks

| Trick Method   | Principle                     | Notes                          |
|----------------|-------------------------------|--------------------------------|
| **Twins**      | Use identical appearance      | Must foreshadow existence       |
| **Plastic surgery/disguise** | Change identity           | Must have technical support     |
| **Faked death** | Pretend to be dead            | Must explain source of corpse   |
| **Dissociative identity** | One person with dual identity | Must have psychological basis   |

### Trick Design Principles

| Principle      | Explanation                 |
|----------------|-----------------------------|
| **Feasibility** | Can be done in reality (or within story setting) |
| **Fairness**   | Clues are given; readers can deduce |
| **Surprise**   | Truth revelation causes "aha" moment |
| **Necessity**  | Why is the trick so complex? Must have reason |

---

## 6. Clue Management

### Clue Setting Principles
```
Fair clues = Necessary info given + cleverly hidden + not deliberately misleading
```

### Clue Types

| Clue Type      | Role                        | Placement Method                      |
|----------------|-----------------------------|-------------------------------------|
| **Physical evidence** | Directly points to truth    | Hidden among many details / misinterpreted |
| **Testimony clues** | What characters say         | Partly true, partly lies / inadvertently revealed |
| **Behavioral clues** | Characters’ actions         | Abnormal behavior / subconscious gestures |
| **Timeline clues** | Time contradictions         | Timeline mismatches / deliberately confused |
| **Psychological clues** | Motive hints               | Derived from relationships / past / personality |

### Red Herrings (False Clues)

**Role**: Mislead readers’ attention, increase deduction difficulty

| Setup Method   | Notes                       |
|----------------|-----------------------------|
| **Obvious suspect** | Most suspicious person often not the killer |
| **Irrelevant anomalies** | Create unrelated mysteries |
| **Coincidences** | Appear related but are not |

**Important**: Red herrings must be explained clearly in the end, not meaningless distractions

### Clue Placement Timeline

| Chapter        | Clue Task                   |
|----------------|-----------------------------|
| **Chapter 1**  | Plant all key clues (hidden in details) |
| **Chapter 2**  | Add contradictory clues, create fog |
| **Chapter 3**  | Hint key clues to truth (may be unnoticed by readers) |
| **Chapter 4**  | Review clues one by one, show true meaning |
| **Chapter 5**  | Explain all clues fully     |

---

## 7. Atmosphere Creation

### Atmosphere Formula
```
Suspense atmosphere = Environmental oppression + Psychological tension + Information asymmetry
```

### Environment Settings

| Environment Type | Atmosphere Effect          | Suitable Scenes               |
|------------------|---------------------------|------------------------------|
| **Isolated island/mansion** | Isolated, no help, killer inside | Snowstorm mansion mode        |
| **Closed space** | Oppressive, no escape     | Train / elevator / locked room |
| **Night/rainstorm** | Limited vision, sensory fear | Enhance tension               |
| **Familiar place** | Security broken          | Home / school / office        |

### Time Pressure

| Technique       | Effect                     |
|-----------------|----------------------------|
| **Countdown**   | Must solve before deadline |
| **Serial killings** | Killer will strike again   |
| **Evidence destruction** | Clues are being destroyed |
| **Identity exposure** | Detective/witness in danger |

### Psychological Pressure

| Technique       | Effect                     |
|-----------------|----------------------------|
| **Everyone suspicious** | Killer unknown            |
| **Trust collapse** | Anyone might lie            |
| **Moral dilemma** | Truth may be harsher        |

---

## 8. Chapter Design (Detective Specific)

### Chapter Title Style

Detective titles should **hint content without spoilers**:

| Title Type     | Example                     |
|----------------|-----------------------------|
| **Event type** | "Chapter 1: Library Locked Room" |
| **Time type**  | "Chapter 2: The Missing Thirty Minutes" |
| **Character type** | "Chapter 3: The Lying Witness" |
| **Clue type**  | "Chapter 4: The Secret of the Left Hand" |
| **Reasoning type** | "Chapter 5: There Is Only One Truth" |

### Chapter Pace

```
500 words = 1 clue reveal OR 1 questioning OR 1 reasoning step
```

### Dialogue Design (Core of deduction)

**Questioning witnesses**:
```
✅ Good questioning:
"You said you left at 8, but the gatekeeper’s record says 7:30."
"I must have remembered wrong..."
"Your car stayed in the parking lot until 8:15. Where were you for those 45 minutes?"
Silence.
"Think carefully before answering. Lying only makes you more suspicious."
```

```
❌ Poor questioning:
"Anything to say?"
"No."
"Okay."
```

### Reasoning Display (Detective thinking)

```
✅ Good reasoning:
Lin Yue stared at the floor plan. All rooms checked, no secret passages, no hidden doors.
But the killer did disappear.
Wait—what if it’s not about space?
He looked at the timeline. Death time: 10 PM. Last sighting: 9:30 PM.
Discovery time: 11 PM.
What happened in that hour?
```

```
❌ Poor reasoning:
He suddenly thought of the answer.
```

---

## 9. Truth Progression (Detective Exclusive)

### Five-stage Revelation Method
```
Crime occurrence → Investigation and evidence collection → Clarify contradictions → Logical deduction → Truth revealed
```

| Stage             | Word Count Ratio | Key Events                  | Truth Clarity        |
|-------------------|------------------|-----------------------------|---------------------|
| **Crime occurrence** | 10-15%          | Present case, set puzzle     | ☆☆☆☆☆               |
| **Investigation**  | 20-25%           | Collect clues, question witnesses | ★☆☆☆☆           |
| **Clarify contradictions** | 25-30%    | Find contradictions, form hypotheses | ★★☆☆☆          |
| **Logical deduction** | 20-25%        | Deduce truth, verify hypotheses | ★★★★☆             |
| **Truth revealed** | 15-20%           | Complete revelation, motive excavation | ★★★★★          |

### Truth Layer Progression

```
First layer: Surface truth (appears suicide)
    ↓
Second layer: Initial truth (actually murder)
    ↓
Third layer: Core truth (killer’s identity)
    ↓
Fourth layer: Ultimate truth (why murder)
```

---

## 10. Common Deduction Patterns

### Pattern A: Locked-room Murder
**Structure**:  
- Introduction: Body found in locked room  
- Development: Investigate room structure, eliminate suspects  
- Twist: Find flaw in locked-room trick  
- Conclusion: Reveal how locked room was created, killer identity

### Pattern B: Snowstorm Mansion
**Structure**:  
- Introduction: Closed environment, first death  
- Development: More deaths, everyone suspicious  
- Twist: Discover pattern/connection  
- Conclusion: Final confrontation, reveal killer (possibly the "dead" person)

### Pattern C: Alibi
**Structure**:  
- Introduction: Crime occurs, suspect has perfect alibi  
- Development: Investigate alibi details  
- Twist: Find flaw (time/witness/evidence)  
- Conclusion: Expose fake alibi

### Pattern D: Social Mystery Exploration
**Structure**:  
- Introduction: Crime occurs  
- Development: Surface investigation stalls  
- Twist: Explore character past/social background  
- Conclusion: Reveal deep motive, touch social issues

---

## 11. Motive Design (Higashino Style)

### Motive Formula
```
Sufficient motive = Strong emotion + Oppressive situation + Twisted psychology
```

### Classic Motive Types

| Motive Type    | Emotional Drive               | Suitable Scenes            |
|----------------|------------------------------|---------------------------|
| **Revenge**    | Victimized / bullied / betrayed | Past trauma               |
| **Protection** | Protect loved ones            | Family / love             |
| **Jealousy**   | Lost / unattainable           | Rival / competition       |
| **Greed**      | Money / inheritance / benefit | Economic crime            |
| **Concealment** | Hide secrets                 | Silence / destroy evidence |
| **Despair**    | No way out                   | Social oppression         |
| **Twisted love** | Unrequited / extreme love    | Abnormal affection        |

### Deep Motive Excavation Method

From surface motive to deep motive:

```
Surface: For money
    ↓
Deeper: To pay for daughter’s terminal illness treatment
    ↓
Core: To make up for years of neglect and guilt toward daughter
```

---

**【Special Reminder】**  
The key to success in detective short stories:  
1. The first 500 words must present the core conflict of the case  
2. All key clues must be fairly given (though cleverly hidden)  
3. Tricks must be ingenious but feasible, withstand scrutiny  
4. Truth revelation should be progressive, not all at once  
5. Motives must be sufficient, touching deep human nature  
6. Logic must be rigorous, no obvious loopholes  
7. The final truth must be "unexpected yet reasonable"