---
name: Creative-Writing  
description: Novel, screenplay, and story creative writing. Covers the entire process of conception, world-building, character development, scene writing, and revision, supporting 17 genre styles (martial arts/sci-fi/mystery/romance/history, etc.), providing professional creation methodologies and style guidance.  
---

## 1. Supported Creation Genres

| Genre ID        | Genre Name | Style Characteristics          | Reference Works               |
| --------------- | ---------- | ----------------------------- | ---------------------------- |
| martial-arts    | Martial Arts | Elegant ancient style, chivalrous spirit | "The Legend of the Condor Heroes", "Demi-Gods and Semi-Devils" |
| sci-fi          | Sci-Fi     | Cool and rational, cosmic contemplation | "The Three-Body Problem", "Foundation" |
| fantasy         | Fantasy    | Gorgeous fantasy, passionate and exhilarating | "Battle Through the Heavens", "A Record of a Mortal’s Journey to Immortality" |
| romance         | Contemporary Romance | Colloquial and natural, delicate emotions | Urban romance novels         |
| fairy-tale      | Fairy Tale | Poetic and warm, innocent and interesting | Andersen’s Fairy Tales       |
| classical       | Classical  | Elegant and graceful, classical charm | Classical romance novels     |
| mystery         | Mystery   | Tense and brain-burning, logically rigorous | "White Night", "The Untouchable" |
| horror          | Horror    | Thrilling and oppressive, psychological fear | "The Lost Tomb"              |
| historical      | Historical | Heavy and steady, blending historical facts | "Stories of the Ming Dynasty" |
| urban           | Urban     | Modern pace, workplace life     | Urban workplace novels       |
| youth           | Youth     | Fresh and bright, youthful beauty | "You Are the Apple of My Eye", "To Our Youth That Is Fading Away" |
| apocalypse      | Apocalypse | Desolate and oppressive, survival struggle | "The Last Ship"              |
| tech            | Technology | Entrepreneurial passion, technical details | Silicon Valley startup stories |
| popular-science | Popular Science | Accessible and interesting knowledge | Popular science stories      |
| medical         | Medical   | Professional and rigorous, humanistic care | "Heart Surgery"              |

---

## 2. Complete Creation Workflow

### Stage 1: Conception and Planning

#### 1.1 Define Creation Core (Constitution)

Before starting creation, clarify the story’s core values and thematic boundaries.

**Three core questions to answer (Q1-Q3):**

| Question              | Content                         | Purpose                  |
| --------------------- | -------------------------------| ------------------------ |
| **Q1: Core Idea**     | Describe the story idea and appeal in 1-2 sentences | Define the story’s unique selling point |
| **Q2: Core Conflict** | Describe the main contradiction/conflict in 1 sentence | Determine the story’s driving force |
| **Q3: Story Tone**    | Choose or describe the emotional tone of the story | Unify the overall style  |

#### 1.2 Formulate Creation Plan

**Story Structure Options:**

| Structure Type           | Suitable Scenario       | Chapter Distribution            |
| ------------------------ | ---------------------- | -------------------------------|
| **Introduction-Development-Twist-Conclusion** (recommended) | Short stories (5 chapters) | Intro 1 chapter → Development 2 chapters → Twist 1 chapter → Conclusion 1 chapter |
| **Three-Act Structure**  | Medium to long stories, scripts | Beginning 25% → Conflict 50% → Ending 25% |
| **Hero’s Journey**       | Growth stories          | 12 stages                      |
| **Multi-threaded Narrative** | Ensemble stories     | Multiple intertwined main lines |

### Stage 2: World-Building and Character Development

#### 2.1 Worldview Construction

Build world settings according to genre:

| Genre      | Core Worldview Elements          |
| ---------- | ------------------------------- |
| Martial Arts | Sect structure, martial arts system, jianghu rules |
| Sci-Fi     | Technology settings, cosmic laws, social structure |
| Fantasy    | Cultivation system, rank divisions, sect powers |
| Mystery   | Case background, clue system, character relationships |
| Historical | Dynasty background, social system, rituals and customs |

#### 2.2 Character Development Methods

**Four Dimensions of Protagonist Design:**

| Dimension           | Requirement       | Correct Example               | Incorrect Example          |
| ------------------- | ----------------- | -----------------------------| --------------------------|
| **Identity/Setting** | Unique + Attractive | "The eldest disciple expelled from the sect" | "An ordinary person"       |
| **Core Flaw**       | Room for growth   | "Martial arts weak but pure-hearted" | "Gifted and flawless"      |
| **Personality Tags** | 2-3 distinct traits | "Simple but principled"       | "Good person"              |
| **Appearance Features** | Concise and memorable | "A sword scar on the left cheek" | "Very handsome"            |

**Character Arc Design:**

```
Initial State (Flaw/Dilemma)
    ↓
Catalyst Event (Breaks balance)
    ↓
Desire vs Need (Surface goal vs deeper need)
    ↓
Growth Milestone (Key turning point)
    ↓
Final Transformation (Meaningful change)
```

**Relationship Network Design Principles:**

- Have origins (sect/mastery/resentments/legacy)
- Have complementarity (personality/ability complement)
- Have tension (conflict/misunderstanding/tests)
- Have change (relationship development and transformation)

### Stage 3: Scene Creation

#### 3.1 Core Scene Writing Process

| Step               | Content                      | Key Points                       |
| ------------------ | ----------------------------| --------------------------------|
| **Scene Purpose**  | Define the change that must occur by scene end | Each scene must advance the plot |
| **Perspective Choice** | Select the viewpoint that maximizes emotional impact | Usually follows the character with the greatest emotional stake |
| **Environment Setting** | Build the scene with sensory details | Specific > general              |
| **Dialogue Design** | Write revealing and authentic dialogue | Each character has a unique voice |
| **Pacing Control** | Balance description, dialogue, and action | Rhythm with tension and release |
| **Tension Building** | Introduce obstacles and conflicts | Continuous escalation           |
| **Scene Closure**  | Create hooks that drive readers forward | Suspense or emotional climax    |

#### 3.2 Scene Writing Formula

**500 words = 1 complete scene unit**

- Includes: 1 conflict OR 1 plot advancement OR 1 emotional change
- Each scene must have: environmental perception + emotional temperature + story significance

### Stage 4: Review and Revision

#### 4.1 Structural Review Checklist

- [ ] Is the plot logic coherent?
- [ ] Is the pacing balanced?
- [ ] Is the climax sufficiently powerful?
- [ ] Is the ending satisfying?

#### 4.2 Character Consistency Check

- [ ] Are appearance descriptions consistent?
- [ ] Is personality portrayal coherent?
- [ ] Are motivations clear and reasonable?
- [ ] Is the growth arc complete?

#### 4.3 Style Polishing Points

- [ ] Are dialogues authentic and natural?
- [ ] Is the balance between showing and telling appropriate?
- [ ] Are sensory details sufficient?
- [ ] Is there any redundant content?

---

## 3. Document Template System

### 3.1 Outline Template (outline-template.md)

```markdown
# "《<Book Title>》" Story Outline

## Novel Information
- **Title**: <Book Title>
- **Genre**: <Novel Genre>
- **Story Tone**: <Specific tone chosen from Q3>

## Main Characters
<Briefly list 3-5 core characters, one sentence each>

## Core Synopsis
<One sentence summarizing the core idea and appeal of the story>

## Introduction
<50-150 words, create atmosphere, show core conflict, build suspense>

## Story Outline

### Introduction: <Stage Name> (Chapter 1)
<500-750 words>

### Development: <Stage Name> (Chapters 2-3)
<500-750 words>

### Twist: <Stage Name> (Chapter 4)
<500-750 words>

### Conclusion: <Stage Name> (Chapter 5)
<500-750 words>
```

### 3.2 Character Profile Template (character-template.md)

```markdown
# Character Profile

## Main Characters

**<Character Name>** (Protagonist)

<Appearance features>. <Personality traits>. <Abilities/identity>. <Core flaw>. <Role and growth trajectory in the story>.

[Each main character 150-200 words, 3-5 total]

## Antagonist/Opposing Characters

**<Character Name>**

<Appearance>. <Personality and behavior patterns>. <Abilities>. <Motivations and conflicts with protagonist>.

[Each 100-150 words]

## Important Supporting Characters

**<Character Name>**

<Appearance>. <Personality>. <Abilities>. <Role in the plot>.

[Each 80-100 words]

## Other Characters

**<Character Name>**: <One sentence description>
```

### 3.3 Chapter Index Template (chapter-index-template.md)

```markdown
# Chapter Index

**Chapter 1** <Chapter Title>
<One sentence plot summary, 30-50 words>

**Chapter 2** <Chapter Title>
<One sentence plot summary>

**Chapter 3** <Chapter Title>
<One sentence plot summary>

**Chapter 4** <Chapter Title>
<One sentence plot summary>

**Chapter 5** <Chapter Title>
<One sentence plot summary>
```

### 3.4 Chapter Text Template (chapter-template.md)

```markdown
# Chapter <N>: <Chapter Title>

<Main text content, 2000-3000 words>
```

---

## 4. Creation Execution Process

### Step Zero: Determine Genre

Select genre based on story theme (GENRE_TYPE), load corresponding configurations:

- Creation methodology: `genres/{GENRE_TYPE}/outline-method.md` (includes Q1-Q3 question templates and chapter naming rules)
- Writing style: `genres/{GENRE_TYPE}/output-style.md`

### Step One: Identify Creation Stage

| Stage            | Criteria                        | Resources to Load              |
| ---------------- | ------------------------------ | ----------------------------- |
| **Outline Creation** | Discussing story outline or outline.md does not exist | Templates + methodology + style + examples |
| **Character Creation** | Discussing characters or outline completed | outline.md + templates + methodology + style |
| **Catalog Creation** | Discussing chapter planning   | outline.md + character.md + templates |
| **Chapter Creation** | Writing main text              | All existing documents + templates + style + examples |

### Step Two: Load Creation Resources

**Outline Creation Stage**:

1. templates/outline-template.md  
2. genres/{GENRE_TYPE}/outline-method.md  
3. genres/{GENRE_TYPE}/output-style.md  

**Character Creation Stage**:

1. outline.md (completed outline)  
2. templates/character-template.md  
3. genres/{GENRE_TYPE}/outline-method.md (character section)  

**Catalog Creation Stage**:

1. outline.md + character.md  
2. templates/chapter-index-template.md  
3. genres/{GENRE_TYPE}/outline-method.md (chapter planning section)  

**Chapter Creation Stage**:

1. outline.md + character.md + chapter_index.md  
2. templates/chapter-template.md  
3. genres/{GENRE_TYPE}/output-style.md (most important)  

### Step Three: Execute Professional Creation

Strictly follow:

- Template format and structure  
- Genre-specific creation methodology  
- Genre-specific writing style  

### Step Four: Return Results

Output complete content conforming to template format.

---

## 5. Creation Principles

### 5.1 Template Compliance Principles

- All documents must strictly follow template formats  
- No omission of necessary headings and paragraphs  
- Do not change hierarchical structure  
- Adjust detail level as needed  

### 5.2 Style Consistency Principles

- Maintain consistent style within the genre  
- Strictly follow writing style in output-style.md  
- Ensure outline, characters, and chapters have coordinated style  

### 5.3 Contextual Coherence Principles

```
character creation → based on outline  
catalog creation → based on outline + character  
chapter creation → based on outline + character + catalog  
```

### 5.4 Quality Standards

| Document | Word Count Requirement | Quality Standard           |
| -------- | ---------------------- | ------------------------- |
| Outline  | 2000-3000 words        | Rich genre elements, complete structure |
| Characters | Protagonist 150-200 words each | Vivid images, genre traits |
| Catalog  | Fixed 5 chapters       | Reasonable layout, smooth pacing |
| Chapters | 2000-3000 words per chapter | Unified style, plot advancement |

---

## 6. General Writing Best Practices

### 6.1 Scene Writing Techniques

| Principle              | Explanation                      | Example                         |
| ---------------------- | --------------------------------| -------------------------------|
| **Show, don’t tell**   | Reveal character and emotion through actions and dialogue | ✅ His hand trembled slightly holding the sword ❌ He was nervous |
| **Start with conflict** | Begin the scene with tension    | Directly enter confrontation/crisis/conflict |
| **Use concrete details** | "Rusty iron sword" beats "old sword" | Specific > general              |
| **Vary sentence structure** | Mix short and long sentences | Short sentences create tension, long sentences ease pace |
| **Cut ruthlessly**     | Every word must serve character, plot, or atmosphere | Remove all redundancy          |
| **Read dialogue aloud** | Rewrite if it sounds stiff      | Dialogue must be natural        |
| **Plant foreshadowing** | Early details must pay off later | Chekhov’s gun principle         |
| **Continuous escalation** | Make protagonist face increasingly difficult challenges | Difficulty progression          |
| **Avoid clichés**      | Express familiar concepts in fresh ways | Original expression             |
| **Use active voice**  | "She pushed the door" not "The door was pushed by her" | Active > passive                |
| **Trust the reader**  | Don’t over-explain emotions or motives | Leave space for reader          |
| **Meaningful obstacles** | Challenges should test core character flaws | Obstacles must be targeted      |
| **Balance description** | Enough for reader imagination but not slow pacing | Moderation principle            |
| **Maintain consistent POV** | Don’t jump perspectives within a scene | POV consistency                |
| **End chapters with hooks** | Give readers reasons to continue | Suspense/reversal/emotional peak |

### 6.2 Pacing Control

**Basic formula:**

```
Tense scene → Relaxed scene → Tense scene (escalation) → ...
```

**Word count distribution reference** (short story 5 chapters):

- Chapter 1 (Introduction): 15-20%  
- Chapters 2-3 (Development): 35-40%  
- Chapter 4 (Twist): 20-25%  
- Chapter 5 (Conclusion): 15-20%  

### 6.3 Dialogue Writing

**Good dialogue features:**

- Each character has a unique voice  
- Drives plot or reveals character  
- Contains subtext and implication  
- Avoids "preachy" dialogue  

**Dialogue ratio:**

- Action/mystery scenes: 30-40% dialogue  
- Emotional/relationship scenes: 50-60% dialogue  
- Everyday scenes: 40-50% dialogue  

---

## 7. Common Pitfalls to Avoid

### Creation Process Pitfalls

❌ **Over-reliance on AI** - You are the author, AI is the assistant  
❌ **Skipping planning** - Some structures prevent major rewrites later  
❌ **Ignoring consistency** - Small errors accumulate and break credibility  
❌ **Writing too much at once** - Focus on quality over quantity  
❌ **Trying to do too much** - Short stories focus on a single theme  

### Content Quality Pitfalls

❌ **Slow start** - First 500 words must establish appeal  
❌ **No conflict progression** - Every 1000 words must advance plot  
❌ **Flat characters** - Avoid stereotyped roles  
❌ **Rushed ending** - Give ending enough emotional space  
❌ **Inconsistent style** - Maintain consistent style throughout  

---

## 8. File Structure

```
story-master/
├── SKILL.md                        # This file (core skill package configuration)
├── templates/                      # General document templates
│   ├── outline-template.md
│   ├── character-template.md
│   ├── chapter-index-template.md
│   └── chapter-template.md
└── genres/                         # Genre-specific configurations (15 types)
    ├── martial-arts/               # Martial Arts
    │   ├── outline-method.md       # Outline creation methodology (includes Q1-Q3 question templates)
    │   └── output-style.md         # Writing style
    ├── sci-fi/                     # Sci-Fi
    ├── fantasy/                    # Fantasy
    ├── romance/                    # Contemporary Romance
    ├── fairy-tale/                 # Fairy Tale
    ├── classical/                  # Classical
    ├── mystery/                    # Mystery
    ├── horror/                     # Horror
    ├── historical/                 # Historical
    ├── urban/                      # Urban
    ├── youth/                      # Youth
    ├── apocalypse/                 # Apocalypse
    ├── tech/                       # Technology
    ├── popular-science/            # Popular Science
    └── medical/                    # Medical
```
