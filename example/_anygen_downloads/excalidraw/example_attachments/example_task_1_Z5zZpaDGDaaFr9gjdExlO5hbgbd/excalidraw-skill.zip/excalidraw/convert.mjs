#!/usr/bin/env node
/**
 * excalidraw_convert.mjs
 *
 * Converts AI-friendly Excalidraw element JSON → standard .excalidraw file.
 * Handles: label → bound text, delete, cameraUpdate → viewport, arrow bindings, defaults.
 *
 * Usage:
 *   node convert.mjs <input.json> <output.excalidraw>           # new file
 *   node convert.mjs <input.json> <output.excalidraw> --merge   # edit existing
 *   echo '<json>' | node convert.mjs - <output.excalidraw>      # stdin
 *
 * Zero dependencies — pure Node.js.
 */

import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { argv, stdin } from "node:process";
import { createHash } from "node:crypto";

// ─── Constants ───────────────────────────────────────────────
const EXCALIFONT = 5; // fontFamily ID for Excalidraw's hand-drawn font
const LINE_HEIGHT = 1.25;
const CHAR_WIDTH_RATIO = 0.55; // approximate width per char / fontSize

const PSEUDO_TYPES = new Set(["cameraUpdate", "delete", "restoreCheckpoint"]);

// ─── Helpers ─────────────────────────────────────────────────
const BASE62 =
  "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

function genIndex(n) {
  if (n < 62) return "a" + BASE62[n];
  return "a" + BASE62[Math.floor(n / 62) % 62] + BASE62[n % 62];
}

function randSeed() {
  return Math.floor(Math.random() * 2_000_000_000);
}

function shortId() {
  return createHash("md5")
    .update(String(Math.random()) + Date.now())
    .digest("hex")
    .slice(0, 8);
}


// ─── Text dimension estimation ───────────────────────────────
// Approximate — Excalidraw recalculates on open (restore → refreshDimensions).
function estimateTextSize(text, fontSize) {
  const lines = text.split("\n");
  const maxLen = Math.max(...lines.map((l) => l.length));
  return {
    width: Math.ceil(maxLen * fontSize * CHAR_WIDTH_RATIO),
    height: Math.ceil(lines.length * fontSize * LINE_HEIGHT),
  };
}

// ─── Base defaults for all element types ─────────────────────
function baseProps(overrides, index) {
  const base = {
    angle: 0,
    strokeColor: "#1e1e1e",
    backgroundColor: "transparent",
    fillStyle: "solid",
    strokeWidth: 2,
    strokeStyle: "solid",
    roughness: 1,
    opacity: 100,
    groupIds: [],
    frameId: null,
    index: genIndex(index),
    roundness: null,
    seed: randSeed(),
    version: 1,
    versionNonce: randSeed(),
    isDeleted: false,
    boundElements: null,
    updated: Date.now(),
    link: null,
    locked: false,
  };
  // Merge — overrides win, but keep base fields that aren't in overrides
  return { ...base, ...overrides };
}

// ─── Build a text element (bound or standalone) ──────────────
function makeTextEl(props, index) {
  const fontSize = props.fontSize ?? 20;
  const estimated = estimateTextSize(props.text, fontSize);
  return baseProps(
    {
      type: "text",
      width: estimated.width,
      height: estimated.height,
      fontFamily: EXCALIFONT,
      textAlign: "left",
      verticalAlign: "top",
      lineHeight: LINE_HEIGHT,
      autoResize: true,
      containerId: null,
      ...props,
      originalText: props.text,
    },
    index,
  );
}

// ─── Process a single raw element → one or more output elements ─
function convertElement(raw, idx) {
  // Skip pseudo-elements
  if (PSEUDO_TYPES.has(raw.type)) return { elements: [], nextIdx: idx };

  const { label, ...rest } = raw;
  const results = [];

  // --- Text element ---
  if (raw.type === "text") {
    results.push(makeTextEl(rest, idx++));
    return { elements: results, nextIdx: idx };
  }

  // --- Arrow element ---
  if (raw.type === "arrow" || raw.type === "line") {
    const el = baseProps(
      {
        ...rest,
        points: raw.points ?? [
          [0, 0],
          [raw.width ?? 100, raw.height ?? 0],
        ],
        startBinding: raw.startBinding
          ? { focus: 0, gap: 1, ...raw.startBinding }
          : null,
        endBinding: raw.endBinding
          ? { focus: 0, gap: 1, ...raw.endBinding }
          : null,
        startArrowhead: raw.startArrowhead ?? null,
        endArrowhead:
          raw.type === "arrow"
            ? (raw.endArrowhead ?? "arrow")
            : (raw.endArrowhead ?? null),
        elbowed: raw.elbowed ?? false,
      },
      idx++,
    );

    // Arrow label
    if (label) {
      const textId = `${el.id}_label`;
      const fontSize = label.fontSize ?? 16;
      const { width: tw, height: th } = estimateTextSize(label.text, fontSize);
      // Place at midpoint of arrow
      const midX = el.x + (el.width ?? 0) / 2 - tw / 2;
      const midY = el.y + (el.height ?? 0) / 2 - th / 2;

      el.boundElements = [...(el.boundElements || []), { id: textId, type: "text" }];
      results.push(el);
      results.push(
        makeTextEl(
          {
            id: textId,
            x: midX,
            y: midY,
            text: label.text,
            fontSize,
            textAlign: "center",
            verticalAlign: "middle",
            containerId: el.id,
            strokeColor: label.strokeColor ?? el.strokeColor ?? "#1e1e1e",
          },
          idx++,
        ),
      );
    } else {
      results.push(el);
    }
    return { elements: results, nextIdx: idx };
  }

  // --- Shape elements (rectangle, ellipse, diamond, etc.) ---
  const el = baseProps({ ...rest }, idx++);

  if (label) {
    const textId = `${el.id}_label`;
    const fontSize = label.fontSize ?? 20;
    const { width: tw, height: th } = estimateTextSize(label.text, fontSize);

    el.boundElements = [...(el.boundElements || []), { id: textId, type: "text" }];
    results.push(el);
    results.push(
      makeTextEl(
        {
          id: textId,
          x: el.x + ((el.width ?? 200) - tw) / 2,
          y: el.y + ((el.height ?? 100) - th) / 2,
          text: label.text,
          fontSize,
          textAlign: label.textAlign ?? "center",
          verticalAlign: label.verticalAlign ?? "middle",
          containerId: el.id,
          strokeColor: label.strokeColor ?? el.strokeColor ?? "#1e1e1e",
        },
        idx++,
      ),
    );
  } else {
    results.push(el);
  }

  return { elements: results, nextIdx: idx };
}

// ─── Wire up arrow bindings → target shapes' boundElements ───
function wireBindings(elements) {
  const byId = new Map(elements.map((el) => [el.id, el]));

  for (const el of elements) {
    if (el.type !== "arrow" && el.type !== "line") continue;
    for (const key of ["startBinding", "endBinding"]) {
      const binding = el[key];
      if (!binding?.elementId) continue;
      const target = byId.get(binding.elementId);
      if (!target) continue;
      if (!target.boundElements) target.boundElements = [];
      if (!target.boundElements.some((b) => b.id === el.id)) {
        target.boundElements.push({ id: el.id, type: "arrow" });
      }
    }
  }
}

// ─── Snap arrow endpoints to binding targets ─────────────────
// When an arrow has startBinding/endBinding with fixedPoint,
// recalculate the arrow's x,y and points so the endpoints
// physically touch the target shape's edge.
// This makes the binding "stick" when you move shapes in Excalidraw.
function resolveBindingPositions(elements) {
  const byId = new Map(elements.map((el) => [el.id, el]));

  for (const el of elements) {
    if (el.type !== "arrow" && el.type !== "line") continue;
    if (!el.startBinding && !el.endBinding) continue;

    const pts = el.points;
    if (!pts || pts.length < 2) continue;

    // Current absolute start & end
    let absStart = [el.x + pts[0][0], el.y + pts[0][1]];
    let absEnd = [el.x + pts[pts.length - 1][0], el.y + pts[pts.length - 1][1]];

    // Compute target points from bindings
    let newStart = null;
    let newEnd = null;

    if (el.startBinding?.fixedPoint) {
      const t = byId.get(el.startBinding.elementId);
      if (t && t.width != null && t.height != null) {
        const [fx, fy] = el.startBinding.fixedPoint;
        newStart = [t.x + t.width * fx, t.y + t.height * fy];
      }
    }

    if (el.endBinding?.fixedPoint) {
      const t = byId.get(el.endBinding.elementId);
      if (t && t.width != null && t.height != null) {
        const [fx, fy] = el.endBinding.fixedPoint;
        newEnd = [t.x + t.width * fx, t.y + t.height * fy];
      }
    }

    // Apply corrections
    const start = newStart || absStart;
    const end = newEnd || absEnd;

    // For multi-point arrows (>2 points), scale intermediate points proportionally
    if (pts.length > 2) {
      const oldDx = absEnd[0] - absStart[0] || 1;
      const oldDy = absEnd[1] - absStart[1] || 1;
      const newDx = end[0] - start[0];
      const newDy = end[1] - start[1];
      for (let i = 1; i < pts.length - 1; i++) {
        pts[i] = [
          (pts[i][0] / oldDx) * newDx,
          (pts[i][1] / oldDy) * newDy,
        ];
      }
    }

    // Set arrow origin to start point
    el.x = start[0];
    el.y = start[1];

    // Update last point relative to new origin
    pts[0] = [0, 0];
    pts[pts.length - 1] = [end[0] - start[0], end[1] - start[1]];

    // Update width/height
    el.width = Math.abs(end[0] - start[0]) || 0.01;
    el.height = Math.abs(end[1] - start[1]) || 0.01;
  }
}

// ─── Main processing pipeline ────────────────────────────────
function processInput(rawElements, startIndex = 0) {
  // 1. Collect pseudo-element data
  const deleteIds = new Set();
  let camera = null;

  for (const el of rawElements) {
    if (el.type === "delete") {
      for (const id of String(el.ids ?? el.id).split(","))
        deleteIds.add(id.trim());
    }
    if (el.type === "cameraUpdate") {
      camera = { x: el.x, y: el.y, width: el.width, height: el.height };
    }
  }

  // 2. Convert real elements
  const converted = [];
  let idx = startIndex;
  for (const raw of rawElements) {
    const { elements, nextIdx } = convertElement(raw, idx);
    converted.push(...elements);
    idx = nextIdx;
  }

  // 3. Wire arrow bindings + snap positions
  wireBindings(converted);
  resolveBindingPositions(converted);

  return { elements: converted, deleteIds, camera };
}

// ─── Build .excalidraw file structure ────────────────────────
function buildFile(elements, camera, existingAppState) {
  const appState = {
    viewBackgroundColor: "#ffffff",
    ...existingAppState,
    // If camera specified, set gridSize=null to avoid grid interfering
    ...(camera ? { gridSize: null } : {}),
  };

  return {
    type: "excalidraw",
    version: 2,
    source: "excalidraw-skill",
    elements,
    appState,
    files: {},
  };
}

// ─── CLI ─────────────────────────────────────────────────────
async function main() {
  const args = argv.slice(2);
  const inputPath = args[0];
  const outputPath = args[1];
  const merge = args.includes("--merge");

  if (!inputPath || !outputPath) {
    console.error(
      "Usage: node convert.mjs <input.json> <output.excalidraw> [--merge]",
    );
    console.error('  Use "-" as input to read from stdin.');
    process.exit(1);
  }

  // Read input
  let rawJson;
  if (inputPath === "-") {
    const chunks = [];
    for await (const chunk of stdin) chunks.push(chunk);
    rawJson = Buffer.concat(chunks).toString("utf-8");
  } else {
    rawJson = readFileSync(inputPath, "utf-8");
  }

  const rawElements = JSON.parse(rawJson);
  if (!Array.isArray(rawElements)) {
    console.error("Error: input must be a JSON array of elements.");
    process.exit(1);
  }

  // Read existing file if merging
  let existingElements = [];
  let existingAppState = {};
  let existingFiles = {};
  let existingExtra = {};
  if (merge && existsSync(outputPath)) {
    const existing = JSON.parse(readFileSync(outputPath, "utf-8"));
    existingElements = existing.elements || [];
    existingAppState = existing.appState || {};
    existingFiles = existing.files || {};
    // Preserve any unknown top-level keys (future-proofing)
    const knownKeys = new Set(["type", "version", "source", "elements", "appState", "files"]);
    for (const [k, v] of Object.entries(existing)) {
      if (!knownKeys.has(k)) existingExtra[k] = v;
    }
  }

  // Process new elements
  const { elements: newElements, deleteIds, camera } = processInput(
    rawElements,
    existingElements.length,
  );

  // Merge: filter deleted from existing, append new
  const filtered = existingElements.filter(
    (el) => !deleteIds.has(el.id) && !deleteIds.has(el.containerId),
  );

  // Clean stale boundElements refs pointing to deleted elements
  if (deleteIds.size > 0) {
    for (const el of filtered) {
      if (el.boundElements) {
        el.boundElements = el.boundElements.filter((b) => !deleteIds.has(b.id));
        if (el.boundElements.length === 0) el.boundElements = null;
      }
    }
  }

  // Also wire bindings between new arrows and existing shapes
  const allElements = [...filtered, ...newElements];
  wireBindings(allElements);
  resolveBindingPositions(allElements);

  // Build and write
  const file = buildFile(allElements, camera, existingAppState);
  file.files = { ...existingFiles, ...file.files };
  Object.assign(file, existingExtra);
  writeFileSync(outputPath, JSON.stringify(file, null, 2));

  // Summary
  const stats = {
    total: allElements.length,
    new: newElements.length,
    deleted: deleteIds.size,
    merged: filtered.length,
  };
  console.log(JSON.stringify({ ok: true, output: outputPath, ...stats }));
}

main().catch((err) => {
  console.error(`Error: ${err.message}`);
  process.exit(1);
});
