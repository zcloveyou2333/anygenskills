#!/usr/bin/env node
/**
 * excalidraw_read.mjs
 *
 * Reads a .excalidraw file and outputs AI-friendly simplified JSON.
 * Reverse of convert.mjs:
 *   - Merges bound text (containerId) back into container as `label`
 *   - Strips internal/default properties (seed, version, versionNonce, etc.)
 *   - Keeps only meaningful non-default values
 *
 * Usage:
 *   node read.mjs <input.excalidraw>                   # pretty print
 *   node read.mjs <input.excalidraw> --compact          # single-line per element
 *   node read.mjs <input.excalidraw> --summary          # short text summary (no JSON)
 *
 * Zero dependencies — pure Node.js.
 */

import { readFileSync } from "node:fs";
import { argv } from "node:process";

// ─── Default values to strip ─────────────────────────────────
const DEFAULTS = {
  angle: 0,
  strokeColor: "#1e1e1e",
  backgroundColor: "transparent",
  fillStyle: "solid",
  strokeWidth: 2,
  strokeStyle: "solid",
  roughness: 1,
  opacity: 100,
  locked: false,
};

// Properties to always remove (internal/noise)
const STRIP_KEYS = new Set([
  "seed",
  "version",
  "versionNonce",
  "isDeleted",
  "updated",
  "link",
  "frameId",
  "index",
  // groupIds — keep! users may have grouped elements
  "boundElements", // reconstructed via label
  "originalText", // redundant with text
  "autoResize",
  "lineHeight",
  "fontFamily",
  "hasTextLink",
  "rawText",
  "customData",
  "elbowed",       // default false
  "moveMidPointsWithElement",
  "containerId",   // handled by label merge
]);

// Keys that go first in output for readability
const KEY_ORDER = ["type", "id", "x", "y", "width", "height"];

// ─── Simplify one element ────────────────────────────────────
function simplify(el) {
  const props = {};
  const isText = el.type === "text";

  for (const [k, v] of Object.entries(el)) {
    // Skip internal keys
    if (STRIP_KEYS.has(k)) continue;

    // Skip default values
    if (k in DEFAULTS && v === DEFAULTS[k]) continue;

    // Skip empty arrays
    if (Array.isArray(v) && v.length === 0) continue;

    // Skip null values (except endArrowhead which can be meaningfully null)
    // startArrowhead: null is the default (no start arrowhead) — skip it
    if (v === null && k !== "endArrowhead") continue;

    // Skip computed width/height on standalone text (derived from fontSize + content)
    if (isText && (k === "width" || k === "height")) continue;

    // Skip default text alignment
    if (k === "textAlign" && v === "left") continue;
    if (k === "textAlign" && v === "center") continue; // default for labels
    if (k === "verticalAlign" && (v === "top" || v === "middle")) continue;

    // Simplify bindings — strip focus/gap, keep elementId + fixedPoint
    if ((k === "startBinding" || k === "endBinding") && v) {
      const clean = { elementId: v.elementId };
      if (v.fixedPoint) clean.fixedPoint = v.fixedPoint;
      props[k] = clean;
      continue;
    }

    // Round floating-point coordinates/dimensions
    if ((k === "x" || k === "y" || k === "width" || k === "height") && typeof v === "number") {
      props[k] = Math.round(v * 100) / 100;
      continue;
    }

    props[k] = v;
  }

  // Build output with consistent key order: type, id, x, y, width, height first
  const out = {};
  for (const k of KEY_ORDER) {
    if (k in props) { out[k] = props[k]; delete props[k]; }
  }
  Object.assign(out, props);
  return out;
}

// ─── Merge bound text back into containers as label ──────────
function mergeLabels(elements) {
  // Index: containerId → text element
  const boundTexts = new Map();
  for (const el of elements) {
    if (el.type === "text" && el.containerId) {
      boundTexts.set(el.containerId, el);
    }
  }

  const result = [];

  for (const el of elements) {
    // Skip bound text elements (they become labels)
    if (el.type === "text" && el.containerId) continue;

    const textEl = boundTexts.get(el.id);
    if (textEl) {
      // Merge text into container as label
      const label = { text: textEl.text };
      if (textEl.fontSize && textEl.fontSize !== 20) label.fontSize = textEl.fontSize;
      if (textEl.fontSize === 20) label.fontSize = 20; // always include for clarity
      if (textEl.strokeColor && textEl.strokeColor !== "#1e1e1e" && textEl.strokeColor !== el.strokeColor) {
        label.strokeColor = textEl.strokeColor;
      }
      el.label = label;
    }

    result.push(simplify(el));
  }

  return result;
}

// ─── Summary mode ────────────────────────────────────────────
function summarize(elements) {
  const lines = [];
  lines.push(`Total: ${elements.length} elements\n`);

  for (const el of elements) {
    const parts = [`[${el.id}] ${el.type}`];

    // Position & size
    parts.push(`at (${Math.round(el.x)},${Math.round(el.y)}) ${Math.round(el.width ?? 0)}x${Math.round(el.height ?? 0)}`);

    // Text content
    if (el.label) parts.push(`label="${el.label.text}"`);
    else if (el.text) parts.push(`text="${el.text}"`);

    // Colors (non-default)
    if (el.backgroundColor && el.backgroundColor !== "transparent") parts.push(`bg=${el.backgroundColor}`);
    if (el.strokeColor && el.strokeColor !== "#1e1e1e") parts.push(`stroke=${el.strokeColor}`);

    // Arrow specifics
    if (el.startBinding) parts.push(`from=${el.startBinding.elementId}`);
    if (el.endBinding) parts.push(`to=${el.endBinding.elementId}`);
    if (el.strokeStyle === "dashed") parts.push("dashed");

    lines.push(parts.join(" | "));
  }

  return lines.join("\n");
}

// ─── CLI ─────────────────────────────────────────────────────
const args = argv.slice(2);
const inputPath = args[0];
const compact = args.includes("--compact");
const summary = args.includes("--summary");

if (!inputPath) {
  console.error("Usage: node read.mjs <input.excalidraw> [--compact] [--summary]");
  process.exit(1);
}

const raw = JSON.parse(readFileSync(inputPath, "utf-8"));
const elements = raw.elements || [];

// Filter out deleted elements
const live = elements.filter((el) => !el.isDeleted);

// Merge labels and simplify
const simplified = mergeLabels(live);

if (summary) {
  console.log(summarize(simplified));
} else if (compact) {
  // One element per line for readability
  console.log("[");
  simplified.forEach((el, i) => {
    const comma = i < simplified.length - 1 ? "," : "";
    console.log("  " + JSON.stringify(el) + comma);
  });
  console.log("]");
} else {
  console.log(JSON.stringify(simplified, null, 2));
}
