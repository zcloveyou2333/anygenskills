---
name: excalidraw
description: Draw hand-drawn style diagrams by generating Excalidraw element JSON and converting to .excalidraw files. Use when the user asks to create or edit diagrams, flowcharts, architecture charts, or any visual illustration.
allowed-tools: Bash, Read, Write, Glob
---

# Excalidraw Diagram Skill

Draw hand-drawn style diagrams by generating Excalidraw element JSON, then converting to `.excalidraw` files.

> **Scripts location**: `convert.mjs` and `read.mjs` are in the same directory as this SKILL.md.

## Workflow — New Diagram

1. Write an element JSON array (format below)
2. Save it to a temp file
3. Run the conversion script
4. Tell user the output file path

```bash
cat > excalidraw_input.json << 'ELEMENTS'
[...your elements...]
ELEMENTS
node convert.mjs excalidraw_input.json output.excalidraw
```

## Workflow — Edit Existing Diagram

1. **Read** the file in AI-friendly format
2. **Understand** the current layout and elements
3. **Write** a patch JSON with `delete` pseudo-elements + new/changed elements
4. **Merge** the patch into the existing file

```bash
# Step 1: Read existing file (choose one mode)
node read.mjs existing.excalidraw              # full JSON
node read.mjs existing.excalidraw --compact     # one element per line
node read.mjs existing.excalidraw --summary     # text overview

# Step 2-3: Write patch and merge
cat > excalidraw_input.json << 'ELEMENTS'
[
  { "type": "delete", "ids": "old_element_id1,old_element_id2" },
  { ...new or replacement elements... }
]
ELEMENTS
node convert.mjs excalidraw_input.json existing.excalidraw --merge
```

**Read modes:**
- Default (pretty JSON): Full detail, best for understanding element properties
- `--compact`: One element per line, good for large files — easy to scan
- `--summary`: Text overview with positions, labels, and connections — fastest for getting the big picture

---

## Color Palette (use consistently across all diagrams)

### Primary Colors
| Name | Hex | Use |
|------|-----|-----|
| Blue | `#4a9eed` | Primary actions, links, data series 1 |
| Amber | `#f59e0b` | Warnings, highlights, data series 2 |
| Green | `#22c55e` | Success, positive, data series 3 |
| Red | `#ef4444` | Errors, negative, data series 4 |
| Purple | `#8b5cf6` | Accents, special items, data series 5 |
| Pink | `#ec4899` | Decorative, data series 6 |
| Cyan | `#06b6d4` | Info, secondary, data series 7 |
| Lime | `#84cc16` | Extra, data series 8 |

### Excalidraw Fills (pastel, for shape backgrounds)
| Color | Hex | Good For |
|-------|-----|----------|
| Light Blue | `#a5d8ff` | Input, sources, primary nodes |
| Light Green | `#b2f2bb` | Success, output, completed |
| Light Orange | `#ffd8a8` | Warning, pending, external |
| Light Purple | `#d0bfff` | Processing, middleware, special |
| Light Red | `#ffc9c9` | Error, critical, alerts |
| Light Yellow | `#fff3bf` | Notes, decisions, planning |
| Light Teal | `#c3fae8` | Storage, data, memory |
| Light Pink | `#eebefa` | Analytics, metrics |

### Background Zones (use with opacity: 30 for layered diagrams)
| Color | Hex | Good For |
|-------|-----|----------|
| Blue zone | `#dbe4ff` | UI / frontend layer |
| Purple zone | `#e5dbff` | Logic / agent layer |
| Green zone | `#d3f9d8` | Data / tool layer |

---

## Excalidraw Elements

### Required Fields (all elements)
`type`, `id` (unique string), `x`, `y`, `width`, `height`

### Defaults (skip these — auto-filled by convert script)
strokeColor="#1e1e1e", backgroundColor="transparent", fillStyle="solid", strokeWidth=2, roughness=1, opacity=100
Canvas background is white.

### Element Types

**Rectangle**: `{ "type": "rectangle", "id": "r1", "x": 100, "y": 100, "width": 200, "height": 100 }`
- `roundness: { "type": 3 }` for rounded corners
- `backgroundColor: "#a5d8ff"`, `fillStyle: "solid"` for filled

**Ellipse**: `{ "type": "ellipse", "id": "e1", "x": 100, "y": 100, "width": 150, "height": 150 }`

**Diamond**: `{ "type": "diamond", "id": "d1", "x": 100, "y": 100, "width": 150, "height": 150 }`

**Labeled shape (PREFERRED)** — auto-centered text, no separate text element needed:
`{ "type": "rectangle", "id": "r1", "x": 100, "y": 100, "width": 200, "height": 80, "label": { "text": "Hello", "fontSize": 20 } }`
- Works on rectangle, ellipse, diamond
- Text auto-centers and container auto-resizes to fit
- `label.strokeColor` inherits from the shape's strokeColor if not specified

**Labeled arrow**: `"label": { "text": "connects" }` on an arrow element.
- `label.strokeColor` inherits from the arrow's strokeColor if not specified

**Standalone text** (titles, annotations only):
`{ "type": "text", "id": "t1", "x": 150, "y": 138, "text": "Hello", "fontSize": 20 }`
- x is the LEFT edge of the text. To center text at position cx: set x = cx - estimatedWidth/2
- estimatedWidth ≈ text.length × fontSize × 0.5
- Do NOT rely on textAlign or width for positioning — they only affect multi-line wrapping

**Arrow**: `{ "type": "arrow", "id": "a1", "x": 300, "y": 150, "width": 200, "height": 0, "points": [[0,0],[200,0]], "endArrowhead": "arrow" }`
- points: [dx, dy] offsets from element x,y
- endArrowhead: `null` | `"arrow"` | `"bar"` | `"dot"` | `"triangle"`
- startArrowhead: same options (default null)
- `strokeStyle: "dashed"` for dashed arrows

**Multi-point curved arrow** (for arcs, self-loops):
Use 5-7 points to approximate a smooth curve. Example semicircular self-loop above a shape:
```json
{ "type": "arrow", "id": "loop", "x": 450, "y": 200, "width": 100, "height": 70,
  "points": [[0,0],[-5,-35],[-20,-60],[-50,-70],[-80,-60],[-95,-35],[-100,0]],
  "endArrowhead": "arrow" }
```
- Do NOT use bindings on multi-point self-loop arrows — the binding resolver will flatten the curve

### Arrow Bindings — arrows MUST start/end from a shape's edge

Arrows bind to shapes via `startBinding` / `endBinding`. The `fixedPoint` controls where on the shape the arrow connects.

**What fixedPoint means:** `[x, y]` is a normalized coordinate on the shape — `[0,0]` = top-left corner, `[1,1]` = bottom-right corner.

**Arrows must connect at the shape's border, never from inside.** To place the point on an edge, one of the two values must be exactly `0` or `1`:

```
Exit from right edge  → pin x to 1:  [1, 0.5]   (right edge, middle)
Enter from left edge  → pin x to 0:  [0, 0.5]   (left edge, middle)
Exit from bottom edge → pin y to 1:  [0.5, 1]   (bottom edge, middle)
Enter from top edge   → pin y to 0:  [0.5, 0]   (top edge, middle)
```

**Quick reference — all valid fixedPoints:**

| Edge | Position | fixedPoint | How it works |
|------|----------|-----------|--------------|
| Right center | `[1, 0.5]` | x=1 pins to right edge, y=0.5 centers vertically |
| Right upper | `[1, 0.35]` | x=1 pins to right edge, y offset up |
| Right lower | `[1, 0.65]` | x=1 pins to right edge, y offset down |
| Left center | `[0, 0.5]` | x=0 pins to left edge |
| Left upper | `[0, 0.35]` | x=0 pins to left edge, y offset up |
| Left lower | `[0, 0.65]` | x=0 pins to left edge, y offset down |
| Top center | `[0.5, 0]` | y=0 pins to top edge |
| Top left | `[0.3, 0]` | y=0 pins to top edge, x offset left |
| Top right | `[0.7, 0]` | y=0 pins to top edge, x offset right |
| Bottom center | `[0.5, 1]` | y=1 pins to bottom edge |
| Bottom left | `[0.3, 1]` | y=1 pins to bottom edge, x offset left |
| Bottom right | `[0.7, 1]` | y=1 pins to bottom edge, x offset right |

> **`[0.5, 0.5]` is the shape CENTER — not on any edge. NEVER use it.**
> Rule: at least one of the two values must be exactly 0 or 1. Otherwise the point is inside the shape.

**Example — A right edge → B left edge (horizontal connection):**
```json
{
  "startBinding": { "elementId": "A", "fixedPoint": [1, 0.5] },
  "endBinding":   { "elementId": "B", "fixedPoint": [0, 0.5] }
}
```

**How to choose the correct edge:**
- Shapes side by side → right/left edges (x=1 / x=0)
- Shapes stacked vertically → bottom/top edges (y=1 / y=0)
- Multiple arrows from the same edge → offset them (e.g. `[0.3, 1]`, `[0.5, 1]`, `[0.7, 1]`)
- Bidirectional pair (A↔B) → offset to avoid overlap: A→B uses `[1, 0.35]→[0, 0.35]`, B→A uses `[0, 0.65]→[1, 0.65]`

The convert script automatically wires up `boundElements` on the target shapes and snaps arrow endpoints to the correct positions.

### Pseudo-Elements

**cameraUpdate** (optional — stripped from file output, but useful for layout planning):
`{ "type": "cameraUpdate", "width": 800, "height": 600, "x": 0, "y": 0 }`

**delete** — remove elements by id:
`{ "type": "delete", "ids": "b2,a1,t3" }`
- Comma-separated list of element IDs to remove
- Also removes bound text elements (matching `containerId`)
- Use with `--merge` to surgically edit existing files
- Reusing a deleted ID for the replacement element is OK (delete happens before add)

---

## Sizing Rules

**Font size rules:**
- Minimum fontSize: **16** for body text, labels, descriptions
- Minimum fontSize: **20** for titles and headings
- Minimum fontSize: **14** for secondary annotations only (sparingly)
- NEVER use fontSize below 14 — it becomes unreadable at display scale

**Element sizing rules:**
- Minimum shape size: **120×60** for labeled rectangles/ellipses
- For multi-line labels (e.g. "Tool Registry\n(Schema + Auth)"), use at least **180×80**
- Leave **20-30px** gaps between elements minimum
- Prefer fewer, larger elements over many tiny ones

**Arrow label sizing rules:**
- Arrow labels are placed at the midpoint of the arrow. If the arrow is too short, the label overflows and overlaps with nearby elements.
- **Minimum arrow length for labeled arrows: 120px** (the longer dimension of width/height)
- If a label has 10+ characters, the arrow needs at least **150px**
- When multiple labeled arrows are parallel or close together, space them at least **60px** apart vertically or horizontally so their labels don't collide

**Layout strategy for dense diagrams:**
- When a shape has 4+ arrows, increase spacing around it — at least **100px** gap to neighboring shapes
- Do NOT cram many labeled arrows into a small area. If an area becomes dense, spread shapes further apart or reduce the number of labeled arrows (use unlabeled arrows for obvious connections)
- Prefer simple, straight (horizontal or vertical) arrows. Diagonal arrows with labels are harder to read and labels may collide with nearby elements

**Drawing Order** (array order = z-order, first = back, last = front):
- Emit progressively: background zones → shape → its label → its arrows → next shape
- BAD: all rectangles → all texts → all arrows
- GOOD: bg_zone → shape1 → text1 → arrow1 → shape2 → text2 → ...

---

## Common Mistakes to Avoid

- **fixedPoint must have 0 or 1 in at least one coordinate** — otherwise the point is inside the shape and the arrow pierces through it. Valid: `[1, 0.5]`, `[0.5, 0]`, `[0.3, 1]`. Invalid: `[0.5, 0.5]`, `[0.3, 0.7]`.
- **Multiple arrows from the same edge overlap** — offset them along the edge (e.g. `[0.3, 1]`, `[0.5, 1]`, `[0.7, 1]` for 3 bottom-exiting arrows)
- **Text contrast is CRITICAL** — never use light gray (#b0b0b0, #999) on white backgrounds. Minimum text color on white: `#757575`. For colored text on light fills, use dark variants (`#15803d` not `#22c55e`, `#2563eb` not `#4a9eed`). White text needs dark backgrounds
- **Elements overlap when y-coordinates are close** — text, boxes, and labels must not stack on top of each other
- **Arrow labels need space** — a labeled arrow must be at least 120px long. If the label is 10+ characters, the arrow needs 150px+. Short labeled arrows cause labels to overflow and overlap nearby elements
- **Labeled arrows too close together** — when multiple labeled arrows are within 60px of each other, their labels overlap and become unreadable. Space them out or remove labels from obvious connections
- **Too many arrows in a small area** — if a shape has 4+ arrows, increase the gap around it to at least 100px. Dense arrow clusters are the #1 cause of unreadable diagrams
- **Center titles relative to the diagram below** — estimate the diagram's total width and center the title text over it, not over the canvas
- Do NOT use emoji in text — they don't render in Excalidraw's font
- Draw art/illustrations LAST — cute decorations (sun, stars, icons) should appear as the final drawing step

---

## Example 1: Two Connected Labeled Boxes

```json
[
  { "type": "rectangle", "id": "b1", "x": 100, "y": 100, "width": 200, "height": 100, "roundness": { "type": 3 }, "backgroundColor": "#a5d8ff", "fillStyle": "solid", "label": { "text": "Start", "fontSize": 20 } },
  { "type": "rectangle", "id": "b2", "x": 450, "y": 100, "width": 200, "height": 100, "roundness": { "type": 3 }, "backgroundColor": "#b2f2bb", "fillStyle": "solid", "label": { "text": "End", "fontSize": 20 } },
  { "type": "arrow", "id": "a1", "x": 300, "y": 150, "width": 150, "height": 0, "points": [[0,0],[150,0]], "endArrowhead": "arrow", "startBinding": { "elementId": "b1", "fixedPoint": [1, 0.5] }, "endBinding": { "elementId": "b2", "fixedPoint": [0, 0.5] } }
]
```

## Example 2: Photosynthesis Diagram

A complex diagram with background zones, multiple element types, colored flows, and a decorative sun illustration.

```json
[
  {"type":"text","id":"ti","x":280,"y":10,"text":"Photosynthesis","fontSize":28,"strokeColor":"#1e1e1e"},
  {"type":"text","id":"fo","x":245,"y":48,"text":"6CO2 + 6H2O --> C6H12O6 + 6O2","fontSize":16,"strokeColor":"#757575"},
  {"type":"rectangle","id":"lf","x":150,"y":90,"width":520,"height":380,"backgroundColor":"#d3f9d8","fillStyle":"solid","roundness":{"type":3},"strokeColor":"#22c55e","strokeWidth":1,"opacity":35},
  {"type":"text","id":"lfl","x":170,"y":96,"text":"Inside the Leaf","fontSize":16,"strokeColor":"#15803d"},
  {"type":"rectangle","id":"lr","x":190,"y":190,"width":160,"height":70,"backgroundColor":"#fff3bf","fillStyle":"solid","roundness":{"type":3},"strokeColor":"#f59e0b","label":{"text":"Light Reactions","fontSize":16}},
  {"type":"arrow","id":"a1","x":350,"y":225,"width":120,"height":0,"points":[[0,0],[120,0]],"strokeColor":"#1e1e1e","strokeWidth":2,"endArrowhead":"arrow","label":{"text":"ATP","fontSize":14}},
  {"type":"rectangle","id":"cc","x":470,"y":190,"width":160,"height":70,"backgroundColor":"#d0bfff","fillStyle":"solid","roundness":{"type":3},"strokeColor":"#8b5cf6","label":{"text":"Calvin Cycle","fontSize":16}},
  {"type":"rectangle","id":"sl","x":10,"y":200,"width":120,"height":50,"backgroundColor":"#fff3bf","fillStyle":"solid","roundness":{"type":3},"strokeColor":"#f59e0b","label":{"text":"Sunlight","fontSize":16}},
  {"type":"arrow","id":"a2","x":130,"y":225,"width":60,"height":0,"points":[[0,0],[60,0]],"strokeColor":"#f59e0b","strokeWidth":2,"endArrowhead":"arrow"},
  {"type":"rectangle","id":"wa","x":200,"y":360,"width":140,"height":50,"backgroundColor":"#a5d8ff","fillStyle":"solid","roundness":{"type":3},"strokeColor":"#4a9eed","label":{"text":"Water (H2O)","fontSize":16}},
  {"type":"arrow","id":"a3","x":270,"y":360,"width":0,"height":-100,"points":[[0,0],[0,-100]],"strokeColor":"#4a9eed","strokeWidth":2,"endArrowhead":"arrow"},
  {"type":"rectangle","id":"co","x":480,"y":360,"width":130,"height":50,"backgroundColor":"#ffd8a8","fillStyle":"solid","roundness":{"type":3},"strokeColor":"#f59e0b","label":{"text":"CO2","fontSize":16}},
  {"type":"arrow","id":"a4","x":545,"y":360,"width":0,"height":-100,"points":[[0,0],[0,-100]],"strokeColor":"#f59e0b","strokeWidth":2,"endArrowhead":"arrow"},
  {"type":"rectangle","id":"ox","x":540,"y":100,"width":100,"height":40,"backgroundColor":"#ffc9c9","fillStyle":"solid","roundness":{"type":3},"strokeColor":"#ef4444","label":{"text":"O2","fontSize":16}},
  {"type":"arrow","id":"a5","x":310,"y":190,"width":230,"height":-50,"points":[[0,0],[230,-50]],"strokeColor":"#ef4444","strokeWidth":2,"endArrowhead":"arrow"},
  {"type":"rectangle","id":"gl","x":690,"y":195,"width":120,"height":60,"backgroundColor":"#c3fae8","fillStyle":"solid","roundness":{"type":3},"strokeColor":"#22c55e","label":{"text":"Glucose","fontSize":18}},
  {"type":"arrow","id":"a6","x":630,"y":225,"width":60,"height":0,"points":[[0,0],[60,0]],"strokeColor":"#22c55e","strokeWidth":2,"endArrowhead":"arrow"},
  {"type":"ellipse","id":"sun","x":30,"y":110,"width":50,"height":50,"backgroundColor":"#fff3bf","fillStyle":"solid","strokeColor":"#f59e0b","strokeWidth":2},
  {"type":"arrow","id":"r1","x":55,"y":108,"width":0,"height":-14,"points":[[0,0],[0,-14]],"strokeColor":"#f59e0b","strokeWidth":2,"endArrowhead":null,"startArrowhead":null},
  {"type":"arrow","id":"r2","x":55,"y":162,"width":0,"height":14,"points":[[0,0],[0,14]],"strokeColor":"#f59e0b","strokeWidth":2,"endArrowhead":null,"startArrowhead":null},
  {"type":"arrow","id":"r3","x":28,"y":135,"width":-14,"height":0,"points":[[0,0],[-14,0]],"strokeColor":"#f59e0b","strokeWidth":2,"endArrowhead":null,"startArrowhead":null},
  {"type":"arrow","id":"r4","x":82,"y":135,"width":14,"height":0,"points":[[0,0],[14,0]],"strokeColor":"#f59e0b","strokeWidth":2,"endArrowhead":null,"startArrowhead":null},
  {"type":"arrow","id":"r5","x":73,"y":117,"width":10,"height":-10,"points":[[0,0],[10,-10]],"strokeColor":"#f59e0b","strokeWidth":2,"endArrowhead":null,"startArrowhead":null},
  {"type":"arrow","id":"r6","x":37,"y":117,"width":-10,"height":-10,"points":[[0,0],[-10,-10]],"strokeColor":"#f59e0b","strokeWidth":2,"endArrowhead":null,"startArrowhead":null},
  {"type":"arrow","id":"r7","x":73,"y":153,"width":10,"height":10,"points":[[0,0],[10,10]],"strokeColor":"#f59e0b","strokeWidth":2,"endArrowhead":null,"startArrowhead":null},
  {"type":"arrow","id":"r8","x":37,"y":153,"width":-10,"height":10,"points":[[0,0],[-10,10]],"strokeColor":"#f59e0b","strokeWidth":2,"endArrowhead":null,"startArrowhead":null}
]
```

## Example 3: Sequence Diagram

UML-style sequence diagram with 4 actors, dashed lifelines, and labeled message arrows.

```json
[
  {"type":"text","id":"title","x":200,"y":15,"text":"MCP Apps — Sequence Flow","fontSize":24,"strokeColor":"#1e1e1e"},
  {"type":"rectangle","id":"sHead","x":600,"y":60,"width":130,"height":40,"backgroundColor":"#ffd8a8","fillStyle":"solid","roundness":{"type":3},"strokeColor":"#f59e0b","strokeWidth":2,"label":{"text":"MCP Server","fontSize":16}},
  {"type":"arrow","id":"sLine","x":665,"y":100,"width":0,"height":490,"points":[[0,0],[0,490]],"strokeColor":"#b0b0b0","strokeWidth":1,"strokeStyle":"dashed","endArrowhead":null},
  {"type":"rectangle","id":"appHead","x":400,"y":60,"width":130,"height":40,"backgroundColor":"#b2f2bb","fillStyle":"solid","roundness":{"type":3},"strokeColor":"#22c55e","strokeWidth":2,"label":{"text":"App iframe","fontSize":16}},
  {"type":"arrow","id":"appLine","x":465,"y":100,"width":0,"height":490,"points":[[0,0],[0,490]],"strokeColor":"#b0b0b0","strokeWidth":1,"strokeStyle":"dashed","endArrowhead":null},
  {"type":"rectangle","id":"aHead","x":230,"y":60,"width":100,"height":40,"backgroundColor":"#d0bfff","fillStyle":"solid","roundness":{"type":3},"strokeColor":"#8b5cf6","strokeWidth":2,"label":{"text":"Agent","fontSize":16}},
  {"type":"arrow","id":"aLine","x":280,"y":100,"width":0,"height":490,"points":[[0,0],[0,490]],"strokeColor":"#b0b0b0","strokeWidth":1,"strokeStyle":"dashed","endArrowhead":null},
  {"type":"rectangle","id":"uHead","x":60,"y":60,"width":100,"height":40,"backgroundColor":"#a5d8ff","fillStyle":"solid","roundness":{"type":3},"strokeColor":"#4a9eed","strokeWidth":2,"label":{"text":"User","fontSize":16}},
  {"type":"arrow","id":"uLine","x":110,"y":100,"width":0,"height":490,"points":[[0,0],[0,490]],"strokeColor":"#b0b0b0","strokeWidth":1,"strokeStyle":"dashed","endArrowhead":null},
  {"type":"arrow","id":"m1","x":110,"y":135,"width":170,"height":0,"points":[[0,0],[170,0]],"strokeColor":"#1e1e1e","strokeWidth":2,"endArrowhead":"arrow","label":{"text":"display a chart","fontSize":14}},
  {"type":"rectangle","id":"note1","x":130,"y":162,"width":310,"height":26,"backgroundColor":"#fff3bf","fillStyle":"solid","roundness":{"type":3},"strokeColor":"#f59e0b","strokeWidth":1,"opacity":50,"label":{"text":"Interactive app rendered in chat","fontSize":14}},
  {"type":"arrow","id":"m2","x":280,"y":210,"width":385,"height":0,"points":[[0,0],[385,0]],"strokeColor":"#8b5cf6","strokeWidth":2,"endArrowhead":"arrow","label":{"text":"tools/call","fontSize":16}},
  {"type":"arrow","id":"m3","x":665,"y":250,"width":-385,"height":0,"points":[[0,0],[-385,0]],"strokeColor":"#f59e0b","strokeWidth":2,"endArrowhead":"arrow","strokeStyle":"dashed","label":{"text":"tool input/result","fontSize":16}},
  {"type":"arrow","id":"m4","x":280,"y":290,"width":185,"height":0,"points":[[0,0],[185,0]],"strokeColor":"#8b5cf6","strokeWidth":2,"endArrowhead":"arrow","strokeStyle":"dashed","label":{"text":"result -> app","fontSize":16}},
  {"type":"arrow","id":"m5","x":110,"y":340,"width":355,"height":0,"points":[[0,0],[355,0]],"strokeColor":"#4a9eed","strokeWidth":2,"endArrowhead":"arrow","label":{"text":"user interacts","fontSize":16}},
  {"type":"arrow","id":"m6","x":465,"y":380,"width":-185,"height":0,"points":[[0,0],[-185,0]],"strokeColor":"#22c55e","strokeWidth":2,"endArrowhead":"arrow","label":{"text":"tools/call request","fontSize":16}},
  {"type":"arrow","id":"m7","x":280,"y":420,"width":385,"height":0,"points":[[0,0],[385,0]],"strokeColor":"#8b5cf6","strokeWidth":2,"endArrowhead":"arrow","label":{"text":"tools/call (forwarded)","fontSize":16}},
  {"type":"arrow","id":"m8","x":665,"y":460,"width":-385,"height":0,"points":[[0,0],[-385,0]],"strokeColor":"#f59e0b","strokeWidth":2,"endArrowhead":"arrow","strokeStyle":"dashed","label":{"text":"fresh data","fontSize":16}},
  {"type":"arrow","id":"m9","x":280,"y":500,"width":185,"height":0,"points":[[0,0],[185,0]],"strokeColor":"#8b5cf6","strokeWidth":2,"endArrowhead":"arrow","strokeStyle":"dashed","label":{"text":"fresh data","fontSize":16}},
  {"type":"rectangle","id":"note2","x":130,"y":522,"width":310,"height":26,"backgroundColor":"#d3f9d8","fillStyle":"solid","roundness":{"type":3},"strokeColor":"#22c55e","strokeWidth":1,"opacity":50,"label":{"text":"App updates with new data","fontSize":14}},
  {"type":"arrow","id":"m10","x":465,"y":570,"width":-185,"height":0,"points":[[0,0],[-185,0]],"strokeColor":"#22c55e","strokeWidth":2,"endArrowhead":"arrow","strokeStyle":"dashed","label":{"text":"context update","fontSize":16}}
]
```

---

## Dark Mode

If the user asks for a dark theme/mode diagram, use a massive dark background rectangle as the FIRST element. Make it 10x the content size so it covers the entire viewport:

`{"type":"rectangle","id":"darkbg","x":-4000,"y":-3000,"width":10000,"height":7500,"backgroundColor":"#1e1e2e","fillStyle":"solid","strokeColor":"transparent","strokeWidth":0}`

**Text colors (on dark):**
| Color | Hex | Use |
|-------|-----|-----|
| White | `#e5e5e5` | Primary text, titles |
| Muted | `#a0a0a0` | Secondary text, annotations |
| NEVER | `#555` or darker | Invisible on dark bg! |

**Shape fills (on dark):**
| Color | Hex | Good For |
|-------|-----|----------|
| Dark Blue | `#1e3a5f` | Primary nodes |
| Dark Green | `#1a4d2e` | Success, output |
| Dark Purple | `#2d1b69` | Processing, special |
| Dark Orange | `#5c3d1a` | Warning, pending |
| Dark Red | `#5c1a1a` | Error, critical |
| Dark Teal | `#1a4d4d` | Storage, data |

**Stroke/arrow colors (on dark):**
Use the Primary Colors from above — they're bright enough on dark backgrounds. For shape borders, use slightly lighter variants or `#555555` for subtle outlines.

---

## Editing Existing Files

When the user asks to modify an existing `.excalidraw` file:

### Step 1: Read the current state

```bash
# Quick overview to understand structure
node read.mjs existing.excalidraw --summary

# Full detail when you need exact properties
node read.mjs existing.excalidraw --compact
```

The read script reverse-converts standard `.excalidraw` back to the simplified AI format:
- Bound text elements are merged back into their containers as `label`
- Internal properties (seed, version, boundElements, etc.) are stripped
- Default values are removed — only meaningful non-defaults remain
- Coordinates are rounded to 2 decimal places

### Step 2: Write a patch JSON

The patch JSON contains:
- `delete` pseudo-elements to remove old elements
- New or replacement elements to add

```json
[
  { "type": "delete", "ids": "old_box,old_arrow" },
  { "type": "rectangle", "id": "new_box", "x": 100, "y": 100, "width": 200, "height": 80,
    "backgroundColor": "#a5d8ff", "fillStyle": "solid", "roundness": {"type": 3},
    "label": {"text": "Replacement", "fontSize": 18} }
]
```

### Step 3: Merge

```bash
node convert.mjs patch.json existing.excalidraw --merge
```

**Rules:**
- To modify a shape: delete it, then add a replacement (same or new id both work)
- To modify just the label: delete the shape (its bound text is auto-removed), add the shape back with new label
- The merge cleans up stale `boundElements` references from deleted arrows/shapes
- Unmodified elements are preserved as-is
- External files (from any source) are fully supported — images, groups, custom fields are all preserved during merge
