#!/usr/bin/env python3
"""OCR +结构化解析流水线。

目标：把手写文字/表格/图表的图片或PDF解析为结构化JSON，并导出便于后续生成 doc/xlsx/流程图 的中间文件。

优先策略：
- 若设置 --engine llm/auto：使用多模态LLM做手写/图表理解（更强）
- 若设置 --engine tesseract：使用 tesseract 做基础印刷体OCR（对手写/图表弱）

输出：
- <out_dir>/ocr_result.json
- <out_dir>/ocr_text.md（把所有 text 拼接成Markdown，便于直接做 doc）
- 若识别到表格/图表CSV：<out_dir>/tables/table_*.csv, <out_dir>/charts/chart_*.csv
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional


def run(cmd: List[str]) -> None:
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if p.returncode != 0:
        raise RuntimeError(f"Command failed ({p.returncode}): {' '.join(cmd)}\n{p.stdout}")


def is_pdf(p: Path) -> bool:
    return p.suffix.lower() == ".pdf"


def pdf_to_images(pdf_path: Path, out_dir: Path, dpi: int = 300) -> List[Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    prefix = out_dir / (pdf_path.stem + "_page")
    # pdftoppm -png -r 300 input.pdf outprefix
    run(["pdftoppm", "-png", "-r", str(dpi), str(pdf_path), str(prefix)])
    images = sorted(out_dir.glob(pdf_path.stem + "_page-*.png"))
    if not images:
        # some versions use _page-1.png etc; keep fallback glob
        images = sorted(out_dir.glob(pdf_path.stem + "_page*.png"))
    if not images:
        raise RuntimeError(f"No images generated from PDF: {pdf_path}")
    return images


def normalize_json_text(s: str) -> str:
    # Extract first JSON object/array from model output
    s = s.strip()
    # remove ```json fences
    s = re.sub(r"^```(?:json)?\s*", "", s)
    s = re.sub(r"\s*```$", "", s)
    # best-effort: find first { ... } or [ ... ]
    m = re.search(r"(\{.*\}|\[.*\])", s, flags=re.S)
    return m.group(1) if m else s


def llm_ocr_image(image_path: Path, lang: str) -> Dict[str, Any]:
    """Use OpenAI multimodal model to OCR handwriting + parse tables/charts."""
    from openai import OpenAI

    client = OpenAI()
    b64 = base64.b64encode(image_path.read_bytes()).decode("utf-8")
    mime = "image/png" if image_path.suffix.lower() in {".png"} else "image/jpeg"

    schema_hint = {
        "page": 1,
        "items": [
            {
                "kind": "text",
                "title": "可选：段落/标题",
                "content": "转写出的文字（保持原有换行/段落）",
            },
            {
                "kind": "table",
                "title": "可选：表格标题",
                "csv": "逗号分隔CSV（含表头；若无法确定表头则用col1,col2...）",
                "notes": "可选：不确定处/推断说明",
            },
            {
                "kind": "chart",
                "title": "可选：图表标题",
                "chart_type": "bar|line|pie|scatter|area|unknown",
                "csv": "把图上数据整理成CSV（如 x,y 或 category,value）",
                "notes": "可选：轴含义/单位/不确定处",
            },
        ],
    }

    prompt = f"""你是一个OCR+图表理解引擎。请从图片中识别：手写/印刷文字、表格、统计图表（柱状/折线/饼图等），并输出严格 JSON（不要多余文本）。

要求：
1) 语言偏好：{lang}。如果原文是别的语言也要忠实转写，不要翻译。
2) 对手写文字：尽量完整转写；不确定用 (??) 标记。
3) 对表格：输出 items.kind=table，并给出 csv 字符串。尽量保留行列结构。
4) 对图表：尽量读出关键数据点并输出 csv；如果只能估计，notes 里说明。
5) JSON 必须符合此结构（示例）：{json.dumps(schema_hint, ensure_ascii=False)}
"""

    resp = client.responses.create(
        model="gpt-4.1-mini",
        input=[
            {
                "role": "user",
                "content": [
                    {"type": "input_text", "text": prompt},
                    {"type": "input_image", "image_url": f"data:{mime};base64,{b64}"},
                ],
            }
        ],
    )

    text = resp.output_text
    text = normalize_json_text(text)
    return json.loads(text)


def tesseract_ocr_image(image_path: Path, lang: str) -> Dict[str, Any]:
    """Basic OCR via tesseract. Only returns text blocks."""
    out_base = image_path.with_suffix("")
    cmd = ["tesseract", str(image_path), str(out_base), "-l", lang, "--psm", "6"]
    run(cmd)
    txt_path = out_base.with_suffix(".txt")
    content = txt_path.read_text(encoding="utf-8", errors="ignore")
    return {
        "page": 1,
        "items": [
            {
                "kind": "text",
                "title": None,
                "content": content.strip(),
            }
        ],
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("inputs", nargs="+", help="Image/PDF paths")
    ap.add_argument("--out-dir", default="output/ocr", help="Output directory")
    ap.add_argument(
        "--engine",
        choices=["auto", "llm", "tesseract"],
        default="auto",
        help="OCR engine",
    )
    ap.add_argument(
        "--lang",
        default="chi_sim",
        help="OCR language. tesseract: chi_sim/eng/...; llm: used as hint",
    )
    ap.add_argument("--dpi", type=int, default=300, help="PDF render DPI")
    args = ap.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "tables").mkdir(parents=True, exist_ok=True)
    (out_dir / "charts").mkdir(parents=True, exist_ok=True)

    pages: List[Dict[str, Any]] = []
    global_table_i = 1
    global_chart_i = 1

    def save_csv(kind: str, csv_text: str, idx: int) -> str:
        sub = "tables" if kind == "table" else "charts"
        p = out_dir / sub / f"{kind}_{idx:03d}.csv"
        p.write_text(csv_text.strip() + "\n", encoding="utf-8")
        return str(p)

    for input_path_str in args.inputs:
        p = Path(input_path_str)
        if not p.exists():
            raise FileNotFoundError(str(p))

        image_paths: List[Path]
        if is_pdf(p):
            image_paths = pdf_to_images(p, out_dir / "_pdf_pages", dpi=args.dpi)
        else:
            image_paths = [p]

        for page_i, img in enumerate(image_paths, start=1):
            if args.engine == "tesseract":
                page = tesseract_ocr_image(img, args.lang)
            elif args.engine == "llm":
                page = llm_ocr_image(img, args.lang)
            else:
                # auto: try llm; if fails fall back to tesseract
                try:
                    page = llm_ocr_image(img, args.lang)
                except Exception:
                    page = tesseract_ocr_image(img, args.lang)

            page["source"] = str(p)
            page["image"] = str(img)
            page["page_index"] = page_i

            # externalize CSV fields to separate files
            for it in page.get("items", []):
                if it.get("kind") == "table" and it.get("csv"):
                    csv_path = save_csv("table", it["csv"], global_table_i)
                    it["csv_path"] = csv_path
                    global_table_i += 1
                if it.get("kind") == "chart" and it.get("csv"):
                    csv_path = save_csv("chart", it["csv"], global_chart_i)
                    it["csv_path"] = csv_path
                    global_chart_i += 1

            pages.append(page)

    result = {"pages": pages}
    (out_dir / "ocr_result.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    # Build concatenated markdown text
    md_lines: List[str] = []
    for page in pages:
        md_lines.append(f"## 来源：{page.get('source')} | 页/图：{page.get('page_index')}\n")
        for it in page.get("items", []):
            if it.get("kind") == "text":
                title = it.get("title")
                if title:
                    md_lines.append(f"### {title}\n")
                md_lines.append((it.get("content") or "").strip() + "\n")
        md_lines.append("\n")
    (out_dir / "ocr_text.md").write_text("\n".join(md_lines).strip() + "\n", encoding="utf-8")

    print(str(out_dir / "ocr_result.json"))


if __name__ == "__main__":
    main()
