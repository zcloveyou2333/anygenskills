#!/usr/bin/env python3
"""从自然语言/要点生成 Mermaid 流程图（.mmd）。

用法：
  python scripts/text_to_mermaid_flowchart.py --text "..." --out flow.mmd
或
  python scripts/text_to_mermaid_flowchart.py --text-file notes.txt --out flow.mmd

输出的 .mmd 可用 anygen-render-diagram 渲染成 SVG/PNG。
"""

from __future__ import annotations

import argparse
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--text", default=None)
    ap.add_argument("--text-file", default=None)
    ap.add_argument("--out", required=True)
    ap.add_argument("--direction", default="TD", choices=["TD", "LR", "RL", "BT"])
    args = ap.parse_args()

    if not args.text and not args.text_file:
        raise SystemExit("Need --text or --text-file")

    text = args.text
    if args.text_file:
        text = Path(args.text_file).read_text(encoding="utf-8")

    from openai import OpenAI

    client = OpenAI()
    prompt = f"""把下面内容抽象成 Mermaid flowchart（只输出 mermaid 代码，不要解释）。

规则：
- 输出必须以 `flowchart {args.direction}` 开头。
- 节点尽量短；必要时用换行 `<br/>`。
- 如果包含分支，用 `-- yes -->` / `-- no -->` 标注。

内容：\n{text}\n"""

    resp = client.responses.create(
        model="gpt-4.1-mini",
        input=prompt,
    )

    code = resp.output_text.strip()
    # remove fences
    code = code.replace("```mermaid", "").replace("```", "").strip()

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(code + "\n", encoding="utf-8")
    print(str(out))


if __name__ == "__main__":
    main()
