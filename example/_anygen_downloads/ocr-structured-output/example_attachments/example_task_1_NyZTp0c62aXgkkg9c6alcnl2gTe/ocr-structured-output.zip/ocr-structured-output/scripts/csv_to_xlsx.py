#!/usr/bin/env python3
"""把 CSV 转成格式化的 .xlsx。

用法：
  python scripts/csv_to_xlsx.py input.csv --out output.xlsx

特点：
- 自动设置列宽
- 首行加粗、冻结
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font


def autosize(ws):
    for col in ws.columns:
        max_len = 0
        col_letter = col[0].column_letter
        for cell in col:
            v = "" if cell.value is None else str(cell.value)
            max_len = max(max_len, len(v))
        ws.column_dimensions[col_letter].width = min(max(10, max_len + 2), 60)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv_path")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    csv_path = Path(args.csv_path)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    wb = Workbook()
    ws = wb.active
    ws.title = "Sheet1"

    with csv_path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.reader(f)
        for r_i, row in enumerate(reader, start=1):
            ws.append(row)
            if r_i == 1:
                for c_i in range(1, len(row) + 1):
                    cell = ws.cell(row=1, column=c_i)
                    cell.font = Font(bold=True)
                    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ws.freeze_panes = "A2"
    autosize(ws)

    wb.save(out)
    print(str(out))


if __name__ == "__main__":
    main()
