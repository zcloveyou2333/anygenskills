---
name: ocr-structured-output
description: OCR handwriting / scanned docs / whiteboard photos / tables / charts, then structure results as JSON/CSV and generate editable outputs such as Word(.doc), Excel(.xlsx), or flowcharts (Mermaid → SVG/PNG) based on user needs. Use for requests like "OCR handwriting", "image to text", "organize scanned notes", "extract chart data", "paper table to Excel", or "draw a flowchart from steps".
---

# OCR Structured Output (Handwriting/Tables/Charts → doc/xlsx/flowchart)

## The problem this skill solves
Turn user-provided images/PDFs (handwriting, tables, statistical charts) into **editable content**, and produce outputs based on the user’s goal:
- **Word document** (.doc)
- **Excel spreadsheet** (.xlsx)
- **Flowchart** (Mermaid + SVG/PNG, can be inserted into a doc)

## Core workflow (recommended)

### 1) Clarify what the user wants to output
Confirm these 3 items first (if unclear, default to: `.doc` + key tables to `.xlsx`):
- Input type: images or PDF (how many pages/images)? Is it mainly **handwriting**?
- Target outputs: `.doc` / `.xlsx` / flowchart / all of them?
- Language: Chinese / English / mixed (affects OCR prompting and tesseract language packs)

### 2) Run structured OCR (JSON + CSV + Markdown)
Use: `scripts/ocr_pipeline.py`

**Recommended (default):**
```bash
python scripts/ocr_pipeline.py <input1> <input2> --out-dir output/ocr --engine auto --lang chi_sim
```

Outputs (important):
- `output/ocr/ocr_result.json`: structured results (text/table/chart)
- `output/ocr/ocr_text.md`: concatenated text (handy for building a doc)
- `output/ocr/tables/*.csv`: extracted tables
- `output/ocr/charts/*.csv`: extracted chart data (best-effort; may include estimates)

**Engine selection tips:**
- `--engine auto/llm`: stronger for handwriting, tables, charts (recommended)
- `--engine tesseract`: good for clean printed text; unstable for handwriting/charts

### 3) Generate the final deliverables

#### A) Generate Word (.doc)
- Main input: `output/ocr/ocr_text.md` (optionally also `ocr_result.json`)
- Editing rules:
  - You may **reorder structure / add headings / fix obvious line breaks**
  - Do not invent facts; mark unclear parts as “(unclear)”
- Use `doc_agent` to generate the `.doc`:
  - Re-organize OCR text into the structure the user wants (minutes/report/homework answers, etc.)
  - If there are tables/charts: convert the corresponding CSV into a table or chart and insert it

#### B) Generate Excel (.xlsx)
Convert any CSV into an editable Excel file:
```bash
python scripts/csv_to_xlsx.py output/ocr/tables/table_001.csv --out output/table_001.xlsx
```

(If the user wants a master spreadsheet: merge multiple CSVs first or output multiple sheets.)

#### C) Generate a flowchart (Mermaid → SVG/PNG)
1) Generate Mermaid from OCR text / user steps:
```bash
python scripts/text_to_mermaid_flowchart.py --text-file output/ocr/ocr_text.md --out output/flow.mmd --direction TD
```

2) Render:
```bash
anygen-render-diagram output/flow.mmd -o output/flow.svg
```

3) Delivery:
- Provide `flow.svg` / `flow.png` directly, or
- Insert into a `.doc` via `doc_agent` (attach the SVG path in the section reference)

## Key references
- JSON structure: `references/json_schema.md`
- Common examples: `references/examples.md`
