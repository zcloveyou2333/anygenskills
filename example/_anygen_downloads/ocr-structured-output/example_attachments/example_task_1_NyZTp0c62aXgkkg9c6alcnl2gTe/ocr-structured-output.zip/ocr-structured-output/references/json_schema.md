# Structured OCR JSON Contract

`ocr_pipeline.py` outputs `ocr_result.json` with this core structure:

```json
{
  "pages": [
    {
      "source": "Original input file path (image/pdf)",
      "image": "The image actually used for OCR (PDF pages are rendered first)",
      "page_index": 1,
      "items": [
        {
          "kind": "text",
          "title": "optional",
          "content": "Recognized text (preserve original line breaks/paragraphs as much as possible)"
        },
        {
          "kind": "table",
          "title": "optional",
          "csv": "CSV string (may be externalized to csv_path)",
          "csv_path": "tables/table_001.csv",
          "notes": "optional"
        },
        {
          "kind": "chart",
          "title": "optional",
          "chart_type": "bar|line|pie|scatter|area|unknown",
          "csv": "CSV string (may be externalized to csv_path)",
          "csv_path": "charts/chart_001.csv",
          "notes": "optional"
        }
      ]
    }
  ]
}
```

Notes:
- If `items[*].csv` is long, the script writes it to a separate file and adds `csv_path`.
- The `tesseract` engine only produces `text`; `llm/auto` will also attempt to extract `table/chart`.
