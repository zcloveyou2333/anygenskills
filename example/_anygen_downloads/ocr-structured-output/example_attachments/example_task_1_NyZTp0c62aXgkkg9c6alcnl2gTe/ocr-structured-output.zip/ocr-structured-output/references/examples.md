# Typical Usage Examples

## Example 1: Handwritten meeting notes → Word (.doc)
User: "Turn these handwritten meeting notes into a Word document."

Workflow:
1) Run:

```bash
python scripts/ocr_pipeline.py upload/notes1.jpg upload/notes2.jpg --out-dir output/ocr --engine auto --lang chi_sim
```

2) Use `output/ocr/ocr_text.md` (or `ocr_result.json`) as the main content.
3) Generate `.doc` with `doc_agent`:
   - Title: Meeting Minutes
   - Structure: Background / Attendees / Discussion Points / Decisions & Action Items
   - Reorder OCR text logically (but do not fabricate facts).

## Example 2: A photographed paper table → Excel (.xlsx)
User: "Convert this paper table photo into an editable Excel file."

Workflow:
1) Run OCR first:

```bash
python scripts/ocr_pipeline.py upload/table.jpg --out-dir output/ocr --engine llm
```

2) Find `output/ocr/tables/table_001.csv` and convert to xlsx:

```bash
python scripts/csv_to_xlsx.py output/ocr/tables/table_001.csv --out output/table.xlsx
```

## Example 3: Process sketch / bullet steps → Flowchart (Mermaid + SVG)
User: "Make a flowchart from these steps."

Workflow:
1) Generate Mermaid:

```bash
python scripts/text_to_mermaid_flowchart.py --text-file output/ocr/ocr_text.md --out output/flow.mmd --direction TD
```

2) Render (SVG/PNG):

```bash
anygen-render-diagram output/flow.mmd -o output/flow.svg
```

3) If you need to put it into a doc: attach `output/flow.svg` in the `doc_agent` section reference.
