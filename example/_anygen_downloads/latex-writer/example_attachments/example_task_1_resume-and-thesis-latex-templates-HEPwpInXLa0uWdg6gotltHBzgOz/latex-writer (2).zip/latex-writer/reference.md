# LaTeX Quick Reference

## Document Structure

```latex
\documentclass[options]{class}  % article, report, book, ctexart
\usepackage{package}

\begin{document}
Content here
\end{document}
```

## Common Document Classes

| Class | Use Case |
|-------|----------|
| `article` | Papers, short documents |
| `report` | Longer reports with chapters |
| `book` | Books |
| `ctexart` | Chinese articles |
| `ctexrep` | Chinese reports |
| `IEEEtran` | IEEE papers |

## Text Formatting

```latex
\textbf{bold}
\textit{italic}
\underline{underline}
\texttt{monospace}
{\small small} {\large large} {\Large Larger}
```

## Math Mode

### Inline Math
```latex
The equation $E = mc^2$ is famous.
```

### Display Math
```latex
\begin{equation}
    f(x) = \int_{-\infty}^{\infty} e^{-x^2} dx
    \label{eq:gaussian}
\end{equation}
```

### Common Symbols
```latex
\alpha \beta \gamma \delta \epsilon    % Greek
\sum \prod \int \oint                   % Operators
\frac{a}{b}  \sqrt{x}  x^2  x_i        % Fractions, roots, super/sub
\leq \geq \neq \approx \equiv          % Relations
\rightarrow \Rightarrow \leftrightarrow % Arrows
```

### Matrices
```latex
\begin{pmatrix}
    a & b \\
    c & d
\end{pmatrix}
```

## Figures

```latex
\begin{figure}[htbp]
    \centering
    \includegraphics[width=0.8\textwidth]{image.png}
    \caption{Figure caption}
    \label{fig:label}
\end{figure}
```

Placement options: `h`(here), `t`(top), `b`(bottom), `p`(page)

## Tables

```latex
\begin{table}[htbp]
    \centering
    \caption{Table caption}
    \label{tab:label}
    \begin{tabular}{lcc}  % l=left, c=center, r=right
        \toprule
        Header 1 & Header 2 & Header 3 \\
        \midrule
        Data 1 & Data 2 & Data 3 \\
        Data 4 & Data 5 & Data 6 \\
        \bottomrule
    \end{tabular}
\end{table}
```

Requires: `\usepackage{booktabs}`

## Lists

```latex
% Bulleted
\begin{itemize}
    \item First item
    \item Second item
\end{itemize}

% Numbered
\begin{enumerate}
    \item First item
    \item Second item
\end{enumerate}

% Description
\begin{description}
    \item[Term] Definition
\end{description}
```

## Citations & References

### BibTeX
```latex
% In preamble
\bibliographystyle{IEEEtran}  % or plain, alpha, etc.

% In document
As shown in~\cite{author2024}...

% At end
\bibliography{references}
```

### BibLaTeX (recommended)
```latex
% In preamble
\usepackage[backend=bibtex,style=numeric]{biblatex}
\addbibresource{references.bib}

% In document
As shown in~\cite{author2024}...

% At end
\printbibliography
```

### Cross-references
```latex
See Figure~\ref{fig:label}
See Table~\ref{tab:label}
See Equation~\eqref{eq:label}
See Section~\ref{sec:label}
```

## Code Listings

```latex
\usepackage{listings}

\begin{lstlisting}[language=Python, caption=Example]
def hello():
    print("Hello, World!")
\end{lstlisting}
```

## Chinese Support (ctex)

```latex
\documentclass[UTF8]{ctexart}

% Or with article class:
\documentclass{article}
\usepackage{ctex}
```

### Font Selection (macOS)
```latex
\setCJKmainfont{Hiragino Sans GB}
\setCJKsansfont{PingFang SC}
\setCJKmonofont{STFangsong}
```

## Useful Packages

| Package | Purpose |
|---------|---------|
| `geometry` | Page margins |
| `hyperref` | Clickable links |
| `graphicx` | Images |
| `amsmath` | Advanced math |
| `booktabs` | Professional tables |
| `listings` | Code highlighting |
| `biblatex` | Modern bibliography |
| `xcolor` | Colors |
| `tikz` | Diagrams |

## Pandoc Conversion

### Markdown to PDF
```bash
pandoc input.md -o output.pdf --pdf-engine=xelatex
```

### With Chinese
```bash
pandoc input.md -o output.pdf \
    --pdf-engine=xelatex \
    -V CJKmainfont="Hiragino Sans GB"
```

### With Template
```bash
pandoc input.md -o output.pdf \
    --template=template.tex \
    --pdf-engine=xelatex
```

## Common Errors

| Error | Solution |
|-------|----------|
| `Undefined control sequence` | Missing package or typo |
| `Missing $ inserted` | Math mode issue |
| `File not found` | Check path, run from correct directory |
| `Font not found` | Install font or change font name |
| `I can't write on file` | Check permissions, close PDF viewer |
