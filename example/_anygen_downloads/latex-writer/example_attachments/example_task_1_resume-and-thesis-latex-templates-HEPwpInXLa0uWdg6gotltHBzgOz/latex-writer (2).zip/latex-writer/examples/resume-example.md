---
name: 李明
title: 全栈工程师
email: liming@example.com
phone: 139-0000-0000
location: 上海市
github: github.com/liming
linkedin: linkedin.com/in/liming
---

# 个人简介

5年全栈开发经验，专注于 React 和 Node.js 技术栈。参与多个千万级用户产品开发，具备良好的架构设计能力。

# 工作经历

## 某头部互联网公司 | 高级前端工程师 | 2021-至今

- 主导公司核心产品前端架构升级，首屏加载时间降低 60%
- 设计并实现微前端方案，支持 20+ 业务模块独立部署
- 建立前端监控体系，线上问题发现率提升至 99%

## 某创业公司 | 全栈工程师 | 2019-2021

- 从零搭建 React + Node.js 技术栈，支撑百万级用户
- 实现实时消息系统，单机并发连接数达 10 万

# 教育背景

## 复旦大学 | 计算机科学硕士 | 2019

# 技能

- **前端**: React, Vue, TypeScript, Webpack, Vite
- **后端**: Node.js, Python, Go
- **数据库**: MySQL, PostgreSQL, Redis, MongoDB
- **DevOps**: Docker, Kubernetes, CI/CD

# 开源项目

## react-awesome-component

React 组件库，GitHub 2000+ Star，NPM 周下载量 5000+
