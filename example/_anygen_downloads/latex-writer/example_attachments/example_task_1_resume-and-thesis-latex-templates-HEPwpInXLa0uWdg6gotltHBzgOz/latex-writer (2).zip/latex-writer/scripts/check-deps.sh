#!/bin/bash
# Check macOS dependencies for LaTeX Writer skill
# Supports BasicTeX and full MacTeX installations

echo "=== LaTeX Writer Dependency Check ==="
echo ""

# Add BasicTeX to PATH if not already available
if ! command -v xelatex &>/dev/null; then
    if [ -d "/Library/TeX/texbin" ]; then
        export PATH="/Library/TeX/texbin:$PATH"
        echo "Note: Added /Library/TeX/texbin to PATH"
        echo ""
    fi
fi

MISSING=0
MISSING_PKGS=()

check_cmd() {
    local name="$1"
    local install_hint="$2"
    if command -v "$name" &>/dev/null; then
        local path=$(command -v "$name")
        local version=$("$name" --version 2>/dev/null | head -1 || echo "unknown")
        echo "✓ $name: $path"
        echo "  Version: $version"
    else
        echo "✗ $name: NOT INSTALLED"
        echo "  Install: $install_hint"
        MISSING=$((MISSING + 1))
    fi
    echo ""
}

check_optional() {
    local name="$1"
    local install_hint="$2"
    if command -v "$name" &>/dev/null; then
        echo "✓ $name (optional): $(command -v $name)"
    else
        echo "○ $name (optional): not installed"
        echo "  Install: $install_hint"
    fi
    echo ""
}

check_pkg() {
    local pkg="$1"
    local required="${2:-true}"
    if kpsewhich "$pkg.sty" &>/dev/null; then
        echo "✓ $pkg"
    else
        if [ "$required" = "true" ]; then
            echo "✗ $pkg (required)"
            MISSING=$((MISSING + 1))
            MISSING_PKGS+=("$pkg")
        else
            echo "○ $pkg (optional)"
        fi
    fi
}

echo "--- Core Tools ---"
check_cmd "pandoc" "brew install pandoc"
check_cmd "xelatex" "brew install --cask basictex (then add /Library/TeX/texbin to PATH)"
check_cmd "bibtex" "(included with BasicTeX/MacTeX)"

echo "--- Optional Tools ---"
check_optional "typst" "brew install typst"
check_optional "tectonic" "brew install tectonic"
check_optional "latexmk" "sudo tlmgr install latexmk"

echo "--- Chinese Font Check ---"
if command -v fc-list &>/dev/null; then
    CJK_FONTS=$(fc-list :lang=zh family 2>/dev/null | sort -u | head -5)
    if [ -n "$CJK_FONTS" ]; then
        echo "✓ Chinese fonts detected:"
        echo "$CJK_FONTS" | sed 's/^/  - /'
    else
        echo "✗ No Chinese fonts detected"
        echo "  Recommended: Install Noto Sans CJK or use system Hiragino"
        MISSING=$((MISSING + 1))
    fi
else
    echo "○ fc-list not available, skipping font check"
fi
echo ""

echo "--- LaTeX Packages Check ---"
if command -v kpsewhich &>/dev/null; then
    echo "Required packages:"
    check_pkg "ctex"
    check_pkg "geometry"
    check_pkg "hyperref"
    check_pkg "graphicx"
    check_pkg "amsmath"
    check_pkg "xcolor"
    check_pkg "fontspec"
    check_pkg "booktabs"
    echo ""
    echo "Optional packages (for full template support):"
    check_pkg "biblatex" "false"
    check_pkg "fontawesome5" "false"
    check_pkg "titlesec" "false"
    check_pkg "listings" "false"
else
    echo "○ kpsewhich not available, skipping package check"
fi
echo ""

echo "=== Summary ==="
if [ $MISSING -eq 0 ]; then
    echo "All required dependencies are installed!"
    echo ""
    echo "Optional: For full template support, run:"
    echo "  sudo tlmgr install biblatex biber fontawesome5 titlesec listings"
    exit 0
else
    echo "$MISSING issue(s) found."
    echo ""
    if [ ${#MISSING_PKGS[@]} -gt 0 ]; then
        echo "Install missing LaTeX packages with:"
        echo "  sudo tlmgr install ${MISSING_PKGS[*]}"
        echo ""
    fi
    echo "For BasicTeX users, ensure PATH includes:"
    echo "  export PATH=\"/Library/TeX/texbin:\$PATH\""
    echo ""
    echo "Add to ~/.zshrc or ~/.bash_profile for persistence."
    exit 1
fi
