#!/bin/bash
# Compile LaTeX document with BibTeX support
# Usage: compile.sh <file.tex> [engine] [--clean]
set -e

FILE="$1"
ENGINE="${2:-xelatex}"
CLEAN="${3:-}"

if [ -z "$FILE" ]; then
    echo "Usage: compile.sh <file.tex> [xelatex|pdflatex|lualatex] [--clean]"
    exit 1
fi

if [ ! -f "$FILE" ]; then
    echo "Error: File not found: $FILE"
    exit 1
fi

BASE="${FILE%.tex}"
DIR=$(dirname "$FILE")
cd "$DIR"
FILE=$(basename "$FILE")
BASE=$(basename "$BASE")

echo "=== Compiling $FILE with $ENGINE ==="

# First pass
echo "[1/4] First compilation pass..."
$ENGINE -interaction=nonstopmode -halt-on-error "$FILE"

# BibTeX pass (if .aux exists and has citations)
if [ -f "${BASE}.aux" ] && grep -q '\\citation' "${BASE}.aux" 2>/dev/null; then
    echo "[2/4] Running BibTeX..."
    bibtex "$BASE" 2>/dev/null || biber "$BASE" 2>/dev/null || echo "  (no bibliography processed)"

    echo "[3/4] Second compilation pass..."
    $ENGINE -interaction=nonstopmode "$FILE"

    echo "[4/4] Final compilation pass..."
    $ENGINE -interaction=nonstopmode "$FILE"
else
    echo "[2-4] No citations found, skipping BibTeX passes"
fi

# Clean auxiliary files if requested
if [ "$CLEAN" = "--clean" ]; then
    echo "Cleaning auxiliary files..."
    rm -f "${BASE}.aux" "${BASE}.log" "${BASE}.bbl" "${BASE}.blg" \
          "${BASE}.out" "${BASE}.toc" "${BASE}.lof" "${BASE}.lot" \
          "${BASE}.fls" "${BASE}.fdb_latexmk" "${BASE}.synctex.gz" \
          "${BASE}.run.xml" "${BASE}-blx.bib"
fi

echo ""
echo "=== Done ==="
if [ -f "${BASE}.pdf" ]; then
    echo "Output: $(pwd)/${BASE}.pdf"
    ls -lh "${BASE}.pdf"
else
    echo "Warning: PDF not generated. Check ${BASE}.log for errors."
    exit 1
fi
