#!/usr/bin/env python3
"""
Convert DOI to BibTeX entry.
Usage: doi2bib.py <doi> [<doi2> ...]

Examples:
    doi2bib.py 10.1145/1234567.1234568
    doi2bib.py https://doi.org/10.1145/1234567.1234568
"""
import sys
import urllib.request
import urllib.error
import re


def extract_doi(input_str: str) -> str:
    """Extract DOI from URL or plain DOI string."""
    # Remove URL prefix if present
    input_str = input_str.strip()
    patterns = [
        r'https?://doi\.org/(.+)',
        r'https?://dx\.doi\.org/(.+)',
        r'^(10\.\d{4,}/[^\s]+)$'
    ]
    for pattern in patterns:
        match = re.match(pattern, input_str)
        if match:
            return match.group(1) if pattern.startswith('^') else match.group(1)
    return input_str  # Return as-is if no pattern matches


def doi_to_bibtex(doi: str) -> str:
    """Fetch BibTeX entry from DOI."""
    doi = extract_doi(doi)
    url = f"https://doi.org/{doi}"

    req = urllib.request.Request(
        url,
        headers={
            "Accept": "application/x-bibtex",
            "User-Agent": "LaTeXWriter/1.0 (mailto:user@example.com)"
        }
    )

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        return f"% Error: HTTP {e.code} for DOI {doi}"
    except urllib.error.URLError as e:
        return f"% Error: Could not reach doi.org - {e.reason}"
    except Exception as e:
        return f"% Error: {str(e)}"


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    for doi in sys.argv[1:]:
        result = doi_to_bibtex(doi)
        print(result)
        print()  # Blank line between entries


if __name__ == "__main__":
    main()
