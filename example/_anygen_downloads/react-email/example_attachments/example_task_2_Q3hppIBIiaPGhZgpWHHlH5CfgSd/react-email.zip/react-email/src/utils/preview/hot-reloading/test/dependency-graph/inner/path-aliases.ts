import '@/some-file';
